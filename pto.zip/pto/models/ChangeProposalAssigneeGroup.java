package com.assertco.mybatis.pto.models;

import lombok.Data;

@Data
public class ChangeProposalAssigneeGroup {
}
