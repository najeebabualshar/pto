package com.assertco.mybatis.pto.mappers;

import com.assertco.mybatis.pto.models.ChangeProposalState;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface ChangeProposalStateMapper {

    @Insert("""
            INSERT INTO change_proposal_state(fk_change_proposal_id,create_ts,create_user_id,lock_control_no) 
            VALUES(#{fk_change_proposal_id},#{create_ts},#{create_user_id},#{lock_control_no})
    """)
    Integer save(ChangeProposalState changeProposalState);

    @Update("""
              UPDATE change_proposal_state 
              SET last_mod_ts = #{last_mod_ts}, 
              last_mod_user_id = #{last_mod_user_id}, 
              proposal_phase_tx= #{proposal_phase_tx}, 
              proposal_subphase_tx=: #{proposal_subphase_tx},
              definition_id=#{definition_id}, 
              process_end_ts=#{process_end_ts}, 
              process_instance_id=#{process_instance_id}, 
              process_start_ts= #{process_start_ts}, 
              proposal_state_ct=#{proposal_state_ct}
              WHERE     
            """)
        // TODO: add the ID
    void updateChangeProposalStateByGuidID(ChangeProposalState changeProposalState);

    @Update("""
            UPDATE change_proposal_state 
            SET last_mod_ts = #{last_mod_ts}, 
            last_mod_user_id =#{last_mod_user_id}, 
            lock_control_no =#{lock_control_no} 
            WHERE change_proposal_id =#{change_proposal_id}
    """)
    void updateChangeProposalStateByChangeProposalId(ChangeProposalState changeProposalState);
}
