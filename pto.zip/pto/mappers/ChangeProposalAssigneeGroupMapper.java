package com.assertco.mybatis.pto.mappers;

import com.assertco.mybatis.pto.models.ChangeProposalAssigneeGroup;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ChangeProposalAssigneeGroupMapper {
    @Insert("""
        INSERT INTO change_proposal_assignee_group 
        (create_ts,create_user_id,fk_assignee_ipo_cd,fk_assignee_role_cd,fk_state_task_id) 
        VALUES(#{create_ts},#{create_user_id},#{fk_assignee_ipo_cd},#{fk_assignee_role_cd},#{fk_state_task_id})
    """)
    Integer save(ChangeProposalAssigneeGroup changeProposalAssigneeGroup);


    @Delete("""
            DELETE FROM ChangeProposalAssigneeGroup r 
            WHERE r.id IN  (SELECT r2.id FROM ChangeProposalAssigneeGroup r2 WHERE r2.task.changeProposalState.id =#{stateId})
    """)
    void deleteChangeProposalAssigneeGroupByChangeProposalStateId(@Param("stateId") Integer stateId);
}
