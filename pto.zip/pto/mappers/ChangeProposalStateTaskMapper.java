package com.assertco.mybatis.pto.mappers;

import com.assertco.mybatis.pto.models.ChangeProposalStateTask;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ChangeProposalStateTaskMapper {

    @Delete("""
            DELETE FROM ChangeProposalStateTask r 
            WHERE r.id IN  (SELECT r2.id FROM ChangeProposalStateTask r2 WHERE r2.changeProposalState.id = #{stateId})
    """)
    void deleteChangeProposalStateTaskByChangeProposalStateId(@Param("stateId") Integer stateId);

    @Insert("""
            INSERT INTO change_proposal_state_task 
            (cfk_task_assignee_id,
            create_ts,create_user_id,
            last_mod_ts,last_mod_user_id,
            cfk_task_assignee_role_tx,cfk_task_assignee_office_cd,
            lock_control_no,task_start_ts,task_id,task_name_tx,task_due_ts) 
            VALUES(
            #{cfk_task_assignee_id},
            #{create_ts},#{create_user_id},
            #{last_mod_ts},#{last_mod_user_id},
            #{cfk_task_assignee_role_tx},#{cfk_task_assignee_office_cd},
            #{lock_control_no},#{task_start_ts},#{task_id},#{task_name_tx},#{task_due_ts}
            )
    """)
    Integer save(ChangeProposalStateTask changeProposalStateTask);


}
