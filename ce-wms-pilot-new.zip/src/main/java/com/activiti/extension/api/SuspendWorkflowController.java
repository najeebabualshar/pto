package com.activiti.extension.api;

import org.activiti.engine.IdentityService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.task.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.data.annotation.Transient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.activiti.service.api.GroupService;
import com.activiti.service.api.UserService;

import gov.uspto.tasks.Enum.ProposalStateType;
import gov.uspto.tasks.service.ProposalService;
import gov.uspto.tasks.service.TaskListenerHelper;
import gov.uspto.tasks.service.Utils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Component
@Api(value = "/enterprise/cpcipc", description = "PTO Suspend/Terminate Workflow ")
@RestController
@RequestMapping("/enterprise/cpcipc")
public class SuspendWorkflowController {
	private static final Logger log = LoggerFactory.getLogger(SuspendWorkflowController.class);

	@Autowired
//	@Transient
	private UserService userService;
	@Autowired
//	@Transient
	private GroupService groupService;
	@Autowired
//	@Transient
	private IdentityService identityService;
	@Autowired
//	@Transient
	private RuntimeService runtimeService;
	@Autowired
//	@Transient
	private TaskService taskService;
//	@Autowired
//	@Transient
//	private HistoryService historyService;
	@Autowired
//	@Transient
	private ProposalService proposalService;
	@Autowired
	@Qualifier("transactionManager")
//	@Transient
	private PlatformTransactionManager transactionManager;

	/*
	 * End point to suspend the current workflow/process instance
	 * 
	 * @param currentTaskId
	 * 
	 */
	@ApiResponses({ @ApiResponse(code = 200, message = "Workflow Suspend/termination Successful"),
			@ApiResponse(code = 400, message = "Bad Request / Unknown Exception ") })
	@ApiOperation("Complete current task and Suspend Workflow ")
	@RequestMapping(value = "/workflow/suspend", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> suspendWorkflow(
			@RequestParam(value = "currentTaskId", required = true) String currentTaskId) {

		try {
			log.debug("Suspend Request for Current Task {}  ", currentTaskId);

			Task currentTask = taskService.createTaskQuery().taskId(currentTaskId).singleResult();
			if (currentTask == null) {
				log.error("Invalid Task id no tasks found ");
				throw new Exception("Invalid Task id no tasks found ");
			}
			String pid = currentTask.getExecutionId();

			log.info(
					"******LISTENER IS SUSPEND CALLED NOW, for the TASK ID = {} ; "
							+ "and TASK_KEY--Assignee = {}-{} ****************",
					currentTask.getId(), currentTask.getTaskDefinitionKey(), currentTask.getAssignee());
			log.info("ProcessIntsacneId : {} ", currentTask.getExecutionId());

			// for Saved task, the assignee should not be null.
			if (currentTask.getAssignee() == null) {
				log.error("Task assignee can't be null");
				throw new Exception("Task assignee can't be null, Workflow Suspend cannot proceed");
			}
//			String assignee = TaskListenerHelper.getEmailOfUser(userService, identityService,
//					currentTask.getAssignee());

			log.info("Complete current task from change_proposal_state_task: {}", currentTask.getId());
			if (transactionManager == null) {
				TaskListenerHelper.updateProposalStateWithStatus((DelegateTask) currentTask, proposalService,
						taskService, userService, groupService, identityService, ProposalStateType.SUSPENDED);
			} else {
				final DelegateTask delTask = (DelegateTask) currentTask;
				TransactionTemplate tmpl = new TransactionTemplate(transactionManager);
				tmpl.execute(new TransactionCallbackWithoutResult() {

					@Override
					protected void doInTransactionWithoutResult(TransactionStatus status) {
						TaskListenerHelper.updateProposalStateWithStatus(delTask, proposalService, taskService,
								userService, groupService, identityService, ProposalStateType.SUSPENDED);
					}

				});
			}
			log.debug("About to Suspend process Instance");
			runtimeService.suspendProcessInstanceById(pid);
			log.debug("Workflow suspended for pid {} successfull ", pid);

			return ResponseEntity.ok(Utils.toJson("Workflow Suspended"));
		} catch (Exception e) {
			log.error("Exception while suspending the workflow ", e.getLocalizedMessage());
			try {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Utils.toJsonOrStacktrace(e));
			} catch (Exception e1) {
				e1.printStackTrace();
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body("{ \"Unknown Exception while suspending the workflow\" }");
			}
		}
	}

}
