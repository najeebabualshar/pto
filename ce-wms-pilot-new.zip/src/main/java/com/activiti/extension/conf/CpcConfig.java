package com.activiti.extension.conf;

import java.util.TimeZone;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.joda.time.DateTimeZone;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import lombok.extern.slf4j.Slf4j;

/**
 * This is custom resource loader, to load resource file from CPC jar.
 * 
 * @author 2020LLC
 * @release 1.13
 *
 */
@Slf4j
@Configuration
//@ImportResource({ "classpath:applicationContext.xml" })

@MapperScan("gov.uspto.myBatis.mappers")
public class CpcConfig {

	public CpcConfig() {
		super();
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
	}

	@Value("${cpc.jdbc.driver}")
	private String driverName;

	@Value("${cpc.jdbc.url}")
	private String url;

	@Value("${cpc.jdbc.user}")
	private String username;

	@Value("${cpc.jdbc.password}")
	private String password;

	@Bean
	public DataSource dataSource() {

		log.debug("***********************************************");
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverName);
		dataSource.setUrl(url);
		dataSource.setUsername(username);
		dataSource.setPassword(password);
		log.debug(dataSource.toString());
		log.debug("***********************************************");
		return dataSource;
	}

	@Bean
	public SqlSessionFactory sqlSessionFactory() throws Exception {
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		factoryBean.setDataSource(dataSource());
		return factoryBean.getObject();
	}

}
