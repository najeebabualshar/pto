
package com.activiti.extension.bean.uspto.listener;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricActivityInstanceQuery;
import org.activiti.engine.impl.context.Context;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.data.annotation.Transient;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.activiti.service.api.GroupService;
import com.activiti.service.api.UserService;

import gov.uspto.myBatis.mappers.ChangeProposalMapper;
//import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import gov.uspto.tasks.Enum.ProposalStatus;
import gov.uspto.tasks.service.Constants;
import gov.uspto.tasks.service.ProposalService;
import gov.uspto.tasks.service.TaskListenerHelper;

/**
 * This is custom listener, responsible to get called at certain tasks, to
 * update CPC database for form fields or proposal state, and execute other
 * logics.
 * 
 * @author 2020LLC
 * @release 1.13
 *
 */
@Component("commonTaskCompletionListener")
public class CommonTaskCompletionListener implements TaskListener {

	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger(CommonTaskCompletionListener.class);

	@Autowired
	private UserService userService;
	@Autowired
	private GroupService groupService;
	@Autowired
	private IdentityService identityService;
//	@Autowired
//	private RuntimeService runtimeService;
	@Autowired
	private TaskService taskService;
	@Autowired
	private HistoryService historyService;
//	@Autowired
//	private FormService formService;
	@Autowired
	private ProposalService proposalService;

	@Autowired
	@Qualifier("transactionManager")
	private PlatformTransactionManager transactionManager;

	@Autowired
	ChangeProposalMapper changeProposalMapper;

	@Override
	public void notify(final DelegateTask task) {

		// BRT07 RP/MP/DP Check
		// Check for the Rp-MP-DP variable check
//		1.RP-Revision Project
//		2.MP-Maintenance Project 
//		3.DP-Definition Project 
//		4.QF-Quick Fixes
//		5.HP-Harmonization Project
//		6.HX- Cross Technology
		
		log.info("#################################commonTaskCompletionListener#######################################");
		String taskKey = task.getTaskDefinitionKey();
		String processDef = task.getExecution().getProcessDefinitionId();
		String returnKey = TaskListenerHelper.getTaskReturnVariable(processDef, taskKey);

		boolean migrateAction = false;

		if ((taskKey.equalsIgnoreCase("BRT07") && task.getVariable("wfFormBRT07_ACTION").equals("Approve")) ||

				(taskKey.equalsIgnoreCase("IPC_BAT01") && task.getVariable("wfFormIPCBAT01_ACTION").equals("Approve"))
				||

				(taskKey.equalsIgnoreCase("EC_BAT01") && task.getVariable("wfFormECBAT01_ACTION").equals("Approve")) ||

				(taskKey.equalsIgnoreCase("BH_BAT01") && task.getVariable("wfFormBHBAT01_ACTION").equals("Approve")))

		{

			HistoricActivityInstanceQuery query = historyService.createHistoricActivityInstanceQuery()
					.processInstanceId(task.getExecutionId());

			if (processDef.startsWith("CPC_REVISION")) {

				query = query.activityId("BAT01");

			} else if (processDef.startsWith("EC")) {

				query = query.activityId("EC_BAT02");

			} else if (processDef.startsWith("IPC")) {

				query = query.activityId("IPC_BAT02");

			} else if (processDef.startsWith("HARMONIZATION")) {

				query = query.activityId("BH_BAT02");

			}

			List<HistoricActivityInstance> list = query.list();
			if (list != null && list.size() > 0) {
				log.debug("This project has already mirgrated .. no conversion needed : list size {} ", list.size());
			} else {
				migrateAction = true;
				log.debug("This project is ready for migration ");
			}

			String projectType = (String) task.getVariable(Constants.VAR_PI_PROJECT_TYPE + "_PD");

			log.debug("projectType before trimming : {} ", projectType);
			projectType = projectType.substring(0, 2);
			if (Constants.PROJECT_TYPES.contains(projectType)) {
				log.debug("Project type is handled:  {} ", projectType);
				task.getExecution().setVariable(Constants.VAR_PI_PROJECT_TYPE, projectType);
			} else {
				log.error("Project type NOT handled:  {} ", projectType);
				throw new RuntimeException("Project type NOT handled: " + projectType);
			}

		}

		if (processDef.startsWith("EC") || processDef.startsWith("IPC") || processDef.startsWith("HARMONIZATION")) {

			if (task.hasVariable("projectSource_PD")) {
				String projectSource = (String) task.getVariable("projectSource_PD");
				task.setVariable(Constants.VAR_PI_PROJECT_SOURCE, projectSource);
				log.debug("Update projectSource {} ", projectSource);
			} else {
				log.debug(" projectSource_PD  no found  ");
			}
			// remove underscore for EC & IPC & HARMONIZATION IPC_BAT01 to IPCBAT01
			returnKey = returnKey.replace("_", "");
		}

		identityService = Context.getProcessEngineConfiguration().getIdentityService();

		log.info("******LISTENER IS GETTING CALLED NOW, for the TASK ID = {} ; and TASK_NAME = {}-{} ****************",
				task.getId(), task.getTaskDefinitionKey(), task.getName());
		// for completed task, the assignee is not null.
		String assignee = TaskListenerHelper.getEmailOfUser(userService, identityService, task.getAssignee());
		task.getExecution().setVariable(Constants.VAR_PI_ACTOR, assignee);
		task.getExecution().setVariable(Constants.VAR_PI_PREVIOUS_TASK_KEY, task.getTaskDefinitionKey());

		// Special Handling for Task19 as unchecked values are passed as null.
		for (String key : Constants.esclationTaskVars.keySet()) {
			if (task.getTaskDefinitionKey().equals(key)) {
				Object obj = task.getExecution().getVariable(Constants.esclationTaskVars.get(key));
				if (obj == null) {
					String formControl = Constants.esclationTaskVars.get(key);
					log.debug("ESCALATION is null setting {} to false :  ", formControl);
					task.getExecution().setVariable(formControl, Boolean.FALSE);
				}
			}
		}

		/*
		 * rapporteurOffice_PD from task from and save it to process level if its BRTO7
		 * , IPC_BAT01 , EC_BAT01 call migrateDraft
		 */

		if (migrateAction) {

			String varFormRo = task.getVariable(Constants.FORM_VAR_RAPPORTEUR_OFFICE, String.class);
			if (StringUtils.isNotBlank(varFormRo)) {

				if (varFormRo.equals(Constants.OFFICE_EP) || varFormRo.equals(Constants.OFFICE_US)) {
					task.getExecution().setVariable(Constants.VAR_PI_RAPPORTEUR_OFFICE, varFormRo);
				} else {
					log.error("Invalid OFFICE received : " + varFormRo);
					throw new RuntimeException("Invalid OFFICE received : " + varFormRo);
				}

			}

			TransactionTemplate tmpl = new TransactionTemplate(transactionManager);
			tmpl.execute(new TransactionCallbackWithoutResult() {

				@Override
				protected void doInTransactionWithoutResult(TransactionStatus status) {
					TaskListenerHelper.updateProposalState(task, proposalService, taskService, userService,
							groupService, identityService);

					UUID proposalUuid = UUID.fromString(task.getExecution().getProcessBusinessKey());
					proposalService.migrateDraft(proposalUuid, task.getAssignee());

					log.debug("Updating proposalService. updateProposalWorkflowStatus ");
					proposalService.updateProposalWorkflowStatus(proposalUuid, ProposalStatus.ACTIVE);

				}

			});

		} else {
			TransactionTemplate tmpl = new TransactionTemplate(transactionManager);
			tmpl.execute(new TransactionCallbackWithoutResult() {

				@Override
				protected void doInTransactionWithoutResult(TransactionStatus status) {
					TaskListenerHelper.updateProposalState(task, proposalService, taskService, userService,
							groupService, identityService);

				}

			});
		}

		// remove below vars from local copy
		Map<String, Object> variables = task.getExecution().getVariables();
//		variables.remove(Constants.VAR_PI_TARGET_OFFICE);
		variables.remove(Constants.VAR_PI_TASK_START_DATE);
		variables.remove(Constants.VAR_PI_TASK_DUE_DATE);
		task.setVariablesLocal(variables);

		log.debug("Removing Unneccary variables from process level ");

		// Remove unnecessary copy of process vars
		for (Iterator<String> iterator = variables.keySet().iterator(); iterator.hasNext();) {
			String key = iterator.next();
			log.debug("Checking for Var : {} ", key);
			if (!Constants.PID_VARS.contains(key) &&
//					!key.equals("wfForm"+task.getTaskDefinitionKey() +"_ACTION") &&  // no more valid
					!key.endsWith("_ACTION") && !key.endsWith("_KEEP") && // if variable ends with '_KEEP', those wont
																			// get deleted.
					!key.equals(returnKey) && !Constants.esclationTaskVars.containsValue(key)
					&& task.getExecution().hasVariable(key)) {

				task.getExecution().removeVariable(key);
				log.debug("---------------------------------->Removed ");
			}
		}

//		ProposalSummary proposalSummary = proposalService
//				.getProposalSummaryByExternalId(UUID.fromString(task.getExecution().getProcessBusinessKey()));

		String displayName = changeProposalMapper
				.findAliasDisplayNameByGuidId(UUID.fromString(task.getExecution().getProcessBusinessKey()).toString());
		task.setVariable(Constants.VAR_PI_PROPOSAL_ALIAS, displayName);

		TaskListenerHelper.printTaskVariables("Complete", task);

		log.info("Complete current task from change_proposal_state_task: {}", task.getId());
	}
}