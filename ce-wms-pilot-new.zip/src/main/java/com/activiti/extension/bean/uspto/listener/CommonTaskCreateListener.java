package com.activiti.extension.bean.uspto.listener;

import java.util.Date;
import java.util.List;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.annotation.Transient;
import org.springframework.stereotype.Component;

import com.activiti.domain.idm.User;
import com.activiti.service.api.GroupService;
import com.activiti.service.api.UserService;

import gov.uspto.tasks.pojo.UserGroupDetails;
import gov.uspto.tasks.service.Constants;
import gov.uspto.tasks.service.TaskListenerHelper;

@Component("commonTaskCreateListener")
public class CommonTaskCreateListener implements TaskListener {

	private static final Logger log = LoggerFactory.getLogger(CommonTaskCreateListener.class);

	@Autowired
	private GroupService groupService;

	@Autowired
	private UserService userService;
//	@Autowired
////	@Transient
//	private IdentityService identityService;
//	@Autowired
////	@Transient
//	private TaskService taskService;

	private static final long serialVersionUID = 1L;

	private static final Long tenantId = 1L;

	/**
	 * Custom Tasklistener implementation triggered when task is created. Identifies
	 * the NR/RO/Pub Task and sets the target groups for the task
	 * 
	 * @param task
	 * @return
	 */
	@Override
	public void notify(DelegateTask task) {
		
		log.info("###############################commonTaskCreateListener###############################");

		String phaseCd = TaskListenerHelper.getPhaseCode(task);
		log.debug("***** START of " + this.getClass().getName() + "  *****");
//		log.debug(" groupService              : " + groupService);
		log.debug(" Task.getId                   : " + task.getId());
		log.debug(" Task.getName                 : " + task.getName());
		log.debug(" Task.getFormKey              : " + task.getFormKey());
		log.debug(" Task.getTaskDefinitionKey    : " + task.getTaskDefinitionKey());
		log.debug(" Task.Exec RAPPORTEUR_OFFICE  : "
				+ task.getExecution().getVariable(Constants.VAR_PI_RAPPORTEUR_OFFICE));
		log.debug(" Task. phaseCd                : " + phaseCd);

		String taskKey = task.getTaskDefinitionKey();
		String processDef = task.getExecution().getProcessDefinitionId();
		String returnKey = TaskListenerHelper.getTaskReturnVariable(processDef, taskKey);

		// Remove previous task approval & returns

		String previousTaskKey = (String) task.getExecution().getVariable(Constants.VAR_PI_PREVIOUS_TASK_KEY);
		if (StringUtils.isNotBlank(previousTaskKey)) {
//			task.getExecution().removeVariable("wfForm"+previousTaskKey +"_ACTION");  // no more valid
			task.getExecution().removeVariable(TaskListenerHelper.getTaskActionVariable(processDef, previousTaskKey));
			task.getExecution().removeVariable(returnKey);
			for (int i = 0; i < Constants.REMOVE_VARS.length; i++) {
				if (task.getExecution().hasVariable(Constants.REMOVE_VARS[i]))
					task.getExecution().removeVariable(Constants.REMOVE_VARS[i]);
			}

			log.debug("clean up done, previous task key");
		} else {
			log.error("Previous Task is blank , can lead to unexpected results...");
		}

		// Determine task is RO or Pub task
		boolean isROTask = false;
		for (int i = 0; i < Constants.RO_TASKS.length; i++) {
			if (task.getTaskDefinitionKey().equals(Constants.RO_TASKS[i])) {
				isROTask = true;
				break;
			}

		}
		boolean isPubTask = false;
		for (int i = 0; i < Constants.PUB_TASKS.length; i++) {
			if (task.getTaskDefinitionKey().equals(Constants.PUB_TASKS[i])) {
				isPubTask = true;
				break;
			}

		}

		log.info("Curent task is RO task ? {} ", isROTask);
		log.info("Curent task is pub task ? {} ", isPubTask);
		String assignedOffice = "";

		try {
			String ro = (String) task.getExecution().getVariable(Constants.VAR_PI_RAPPORTEUR_OFFICE);
			if (StringUtils.isNotBlank(ro)) {
				log.info("ro ? {} ", ro);
				assignedOffice = ro;
			}
		} catch (Exception e) {
			log.error("Missing variable RAPPORTEUR_OFFICE ,,Defaulting to US");
			assignedOffice = Constants.OFFICE_US;
		}
		log.info("assignedOffice ? {} ", assignedOffice);
		String subPhase = "";
		if (assignedOffice.equalsIgnoreCase(Constants.OFFICE_US)) {
			subPhase = Constants.SUB_PHASE_US_APPROVALS;
		} else {
			subPhase = Constants.SUB_PHASE_EPO_APPROVALS;
		}

		String targetOffice = "";
		if (isROTask || isPubTask)
			targetOffice = assignedOffice;
		else
			targetOffice = assignedOffice.equalsIgnoreCase(Constants.OFFICE_US) ? Constants.OFFICE_EP
					: Constants.OFFICE_US;
		log.info("targetOffice ? {} ", targetOffice);
		// PUB TASK is always US
//		if(isPubTask) {
//			targetOffice = Constants.OFFICE_US;
//		}

		log.info("PHASE-->{} , SUB_PHASE--{}", task.getExecution().getVariable(Constants.VAR_PI_PHASE),
				task.getExecution().getVariable(Constants.VAR_PI_SUB_PHASE));

		/*
		 * Call the service for target groups and task due days
		 */

//		StandardWorkflowTaskConfig taskConfigDueDays;
		int taskDueDays = -1;
		try {
			log.debug("Call to wmsCommonService.getTaskConfigDueDays : phaseCd:{} ", phaseCd);
//			taskConfigDueDays = wmsCommonService.getTaskConfigDueDays(phaseCd, task.getTaskDefinitionKey());
//			taskDueDays = taskConfigDueDays.getTaskDays().intValue();
			taskDueDays = TaskListenerHelper.getTaskDays(phaseCd, task.getTaskDefinitionKey());
		} catch (Exception e) {
			log.error("Task due days unavailable can't proceed check DB ... for taskid : {} , taskKey {} ",
					task.getId(), task.getTaskDefinitionKey());
			throw new RuntimeException(
					"Task due days unavailable can't proceed check DB ... taskKey : " + task.getTaskDefinitionKey(), e);

		}

		// PUB tasks logic, exclude few pub tasks.
		boolean isPubHandling = false;
		if (isPubTask) {
			isPubHandling = true;
			for (int i = 0; i < Constants.NON_PUB_TASKS.length; i++) {
				if (task.getTaskDefinitionKey().equals(Constants.NON_PUB_TASKS[i])) {
					isPubHandling = false;
					break;
				}

			}
		}
		if (isPubHandling) {
			targetOffice = Constants.OFFICE_US;
		}
		log.info("targetOffice-->{} , isPubHandling--{} ", targetOffice, isPubHandling);

		TaskListenerHelper.removeInitialTempGroups(task);

		List<UserGroupDetails> assginedGroupsList = TaskListenerHelper.getAssignedGroups(task.getTaskDefinitionKey());
		List<String> candidateGroupList = TaskListenerHelper.getTaskGroups(assginedGroupsList, targetOffice,
				groupService, tenantId, task.getTaskDefinitionKey());

		if (candidateGroupList.size() == 0) {
			log.error("Task group assignment failed for taskid : {} , taskKey {} ", task.getId(),
					task.getTaskDefinitionKey());
			throw new RuntimeException("Task group assignment failed for taskKey : " + task.getTaskDefinitionKey());
		}

		task.addCandidateGroups(candidateGroupList);

		User user = userService
				.getUser(Long.parseLong((String) task.getExecution().getVariable(Constants.VAR_PI_INITIATOR)));

		Date dueDate = TaskListenerHelper.getTaskEndDate(task.getCreateTime(), taskDueDays);
		task.setDueDate(dueDate);

		// Set Process instance variables
		task.setVariable(Constants.VAR_PI_TASK_START_DATE, TaskListenerHelper.dateToString(task.getCreateTime()));
		task.setVariable(Constants.VAR_PI_TASK_DUE_DATE, TaskListenerHelper.dateToString(dueDate));

		task.setVariable(Constants.VAR_PI_TARGET_OFFICE, targetOffice);
		task.setVariable(Constants.VAR_PI_NR_TASK_VARIABLE, targetOffice);
		task.setVariable(Constants.VAR_PI_IS_ROTASK, isROTask);
		task.setVariable(Constants.VAR_PI_PHASE, phaseCd);
//		task.setVariable(Constants.VAR_PI_SUB_PHASE, subPhase);
		task.setVariable(Constants.VAR_PI_ACTOR, user.getEmail());
		task.setVariable(Constants.VAR_PI_PROPOSAL_ID, task.getExecution().getProcessBusinessKey());

		// Set Task local variables
		task.setVariableLocal(Constants.VAR_TASK_OFFICE, targetOffice);
		task.setVariableLocal(Constants.VAR_TASK_EXPECTED_DAYS, taskDueDays);
		task.setVariableLocal(Constants.VAR_TASK_TASK_PHASE, phaseCd);
		task.setVariableLocal(Constants.VAR_TASK_STARTED_BY, user.getEmail());
		task.setVariableLocal(Constants.VAR_TASK_TASK_NUMBER,
				TaskListenerHelper.getTaskNumber(task.getTaskDefinitionKey()));
		task.setVariableLocal(Constants.VAR_PI_SUB_PHASE, subPhase);
//		task.setVariableLocal(Constants.VAR_TASK_ROLE, TaskListenerHelper.getFirstTaskOfficeRole(assginedGroupsList, targetOffice) );

		log.debug("Task Start Date : " + task.getCreateTime());
		log.debug("Task Due Date : " + dueDate + " | Days : " + taskDueDays);

		// update tasked role
		// log.info("task.getId() : " + task.getId());
		// ChangeProposalStateTask changeProposalStateTask =
		// changeProposalStateTaskRepository.findByTaskId(task.getId());
		// log.info("changeProposalStateTask : " + changeProposalStateTask);
		/*
		 * String newTaskedRole = ""; for (String taskedRole : candidateGroupList) {
		 * log.info("taskedRole : " + taskedRole);
		 * 
		 * if (taskedRole.contains("_")) { newTaskedRole += taskedRole.replace("_", ":")
		 * + ","; } else { newTaskedRole += taskedRole + ",";
		 * 
		 * } }
		 * 
		 * log.info("newTaskedRole : " + newTaskedRole);
		 * 
		 * changeProposalStateTask.setTaskedRole(newTaskedRole);
		 * log.info("newTaskedRole2 : " + changeProposalStateTask.getTaskedRole());
		 * changeProposalStateTaskRepository.save(changeProposalStateTask);
		 */

		TaskListenerHelper.printTaskVariables("Create", task);
	}

}
