package gov.uspto.myBatis.models;

import java.util.Date;
import java.util.Set;

import gov.uspto.tasks.Enum.StandardIpOfficeCode;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table
 * change_proposal_state_task primary key column is state_task_id
 * 
 * @author 2020
 * @version 1.14.0
 * @date: October 20, 2018
 *
 */
@Data
public class ChangeProposalStateTask {

	/**
	 * Allowing serialization of datamodel elements
	 */
//    private static final long serialVersionUID = 1L;
//    @Id
//    @NotNull
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "state_task_id_seq")
//    @SequenceGenerator(name = "state_task_id_seq", sequenceName = "state_task_id_seq", initialValue = 1, allocationSize = 1)
//    @Column(name = "state_task_id")
	private Long state_task_id;

	/** user with this associated settings */
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalState.class)
//    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "fk_change_proposal_id")
	private ChangeProposalState changeProposalState;

//    @NotNull
//    @Column(name = "task_id")
	private String task_id;

//    @NotNull
//    @Column(name = "task_name_tx")
	private String task_name_tx;

//    @Column(name = "task_start_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date task_start_ts;

//    @Column(name = "task_due_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date task_due_ts;

//    @Column(name = "cfk_task_assignee_id")
	private String cfk_task_assignee_id; // VARCHAR2(320) - this is the first user field of

//    @Column(name = "cfk_task_assignee_role_tx")
	private String cfk_task_assignee_role_tx; // VARCHAR2(100) this is a comma separated list of roles associated with
												// this task

//    @Column(name = "cfk_task_assignee_office_cd")
//    @Enumerated(EnumType.STRING)
	private StandardIpOfficeCode cfk_task_assignee_office_cd; // VARCHAR2(50)

//    @CreatedBy
//    @NotNull
//    @Column(name = "create_user_id")
	private String create_user_id; // VARCHAR2(100)

//    @CreatedDate
//    @NotNull
//    @Column(name = "create_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date create_ts;

//    @LastModifiedBy
//    @NotNull
//    @Column(name = "last_mod_user_id")
	private String last_mod_user_id; // VARCHAR2(100)

//    @LastModifiedDate
//    @NotNull
//    @Column(name = "last_mod_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date last_mod_ts;

//    @SuppressWarnings("CPD-END")
//    @NotNull
//    @Version
//    @Column(name = "lock_control_no")
	private Integer lock_control_no;

//    @OrderBy("fk_assignee_ipo_cd, fk_assignee_role_cd")
//    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "task", targetEntity = ChangeProposalAssigneeGroup.class)
	private Set<ChangeProposalAssigneeGroup> assignmentGroups;

//    /**
//     * @return Long id
//     */
//    public Long getId() {
//        return id;
//    }
//    
//    /**
//     * @param id
//     */
//    public void setId(Long id) {
//        this.id = id;
//    }
//    
//    /**
//     * @return changeProposalState
//     */
//    public ChangeProposalState getChangeProposalState() {
//        return changeProposalState;
//    }
//    
//    /**
//     * @param changeProposalState
//     */
//    public void setChangeProposalState(ChangeProposalState changeProposalState) {
//        this.changeProposalState = changeProposalState;
//    }
//    
//    /**
//     * @return taskId
//     */
//    public String getTaskId() {
//        return taskId;
//    }
//    
//    /**
//     * @param taskId
//     */
//    public void setTaskId(String taskId) {
//        this.taskId = taskId;
//    }
//    
//    /**
//     * @return taskName
//     */
//    public String getTaskName() {
//        return taskName;
//    }
//    
//    /**
//     * @param taskName
//     */
//    public void setTaskName(String taskName) {
//        this.taskName = taskName;
//    }
//    
//    /**
//     * @return taskStartTs
//     */
//    public Date getTaskStartTs() {
//        return taskStartTs;
//    }
//    
//    /**
//     * @param taskStartTs
//     */
//    public void setTaskStartTs(Date taskStartTs) {
//        this.taskStartTs = taskStartTs;
//    }
//    
//    /**
//     * @return taskDueTs
//     */
//    public Date getTaskDueTs() {
//        return taskDueTs;
//    }
//    
//    /**
//     * @param taskDueTs
//     */
//    public void setTaskDueTs(Date taskDueTs) {
//        this.taskDueTs = taskDueTs;
//    }
//    
//    /**
//     * @return assignee
//     */
//    public String getAssignee() {
//        return assignee;
//    }
//    
//    /**
//     * @param assignee
//     */
//    public void setAssignee(String assignee) {
//        this.assignee = assignee;
//    }
//    
//    
//    /**
//	 * @return the taskedRole
//	 */
//	public String getTaskedRole() {
//		return taskedRole;
//	}
//
//	/**
//	 * @param taskedRole the taskedRole to set
//	 */
//	public void setTaskedRole(String taskedRole) {
//		this.taskedRole = taskedRole;
//	}
//
//	/**
//	 * @return the taskedOffice
//	 */
//	public StandardIpOfficeCode getTaskedOffice() {
//		return taskedOffice;
//	}
//
//	/**
//	 * @param taskedOffice the taskedOffice to set
//	 */
//	public void setTaskedOffice(StandardIpOfficeCode taskedOffice) {
//		this.taskedOffice = taskedOffice;
//	}
//
//	/**
//     * @return createUserId
//     */
//    public String getCreateUserId() {
//        return createUserId;
//    }
//    
//    /**
//     * @param createUserId
//     */
//    public void setCreateUserId(String createUserId) {
//        this.createUserId = createUserId;
//    }
//    
//    /**
//     * @return createTs
//     */
//    public Date getCreateTs() {
//        return createTs;
//    }
//    
//    /**
//     * @param createTs
//     */
//    public void setCreateTs(Date createTs) {
//        this.createTs = createTs;
//    }
//    
//    /**
//     * @return lastModifiedUserId
//     */
//    public String getLastModifiedUserId() {
//        return lastModifiedUserId;
//    }
//    
//    /**
//     * @param lastModifiedUserId
//     */
//    public void setLastModifiedUserId(String lastModifiedUserId) {
//        this.lastModifiedUserId = lastModifiedUserId;
//    }
//    
//    /**
//     * @return lastModifiedTs
//     */
//    public Date getLastModifiedTs() {
//        return lastModifiedTs;
//    }
//    
//    /**
//     * @param lastModifiedTs
//     */
//    public void setLastModifiedTs(Date lastModifiedTs) {
//        this.lastModifiedTs = lastModifiedTs;
//    }
//    
//    /**
//     * @return lockControl
//     */
//    public Integer getLockControl() {
//        return lockControl;
//    }
//    
//    /**
//     * @param lockControl
//     */
//    public void setLockControl(Integer lockControl) {
//        this.lockControl = lockControl;
//    }
//
//    /**
//     * returns non-null set (treeset)
//     * 
//     * @return
//     */
//    public Set<ChangeProposalAssigneeGroup> getAssignmentGroups() {
//        if (this.assignmentGroups == null) {
//            this.assignmentGroups = new TreeSet<>();
//        }
//        return assignmentGroups;
//    }
//
//    /**
//     * 
//     * @param assignmentGroups
//     */
//    public void setAssignmentGroups(Set<ChangeProposalAssigneeGroup> assignmentGroups) {
//        this.assignmentGroups = assignmentGroups;
//    }
//    
//    /**
//     * used for hash based collections.
//     */
//    @Override
//    public int hashCode() {
//        final int prime = 37;
//        int result = 1;
//        result = prime * result + ((this.changeProposalState == null) ? 0 : this.changeProposalState.hashCode());
//        result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());
//        result = prime * result + ((this.taskId == null) ? 0 : this.taskId.hashCode());
//        result = prime * result + ((this.taskStartTs == null) ? 0 : this.taskStartTs.hashCode());
//        return result;
//    }
//    
//    /**
//     * Indicates whether some other object is "equal to" this one
//     */
//    @Override
//    public boolean equals(Object obj) {
//        boolean ret = false;
//
//        if (obj != null) {
//            if (obj == this) {
//                ret = true;
//            } else if (ChangeProposalStateTask.class.isAssignableFrom(obj.getClass())) {
//                ChangeProposalStateTask that = (ChangeProposalStateTask) obj;
//                ret = new EqualsBuilder().append(this.getChangeProposalState(), that.getChangeProposalState())
//                        .append(this.getTaskStartTs(), that.getTaskStartTs()).append(this.getTaskId(), that.getTaskId())
//                        .append(this.getId(), that.getId()).isEquals();
//            }
//        }
//        return ret;
//    }
//    
//    /**
//     * @see java.lang.Comparable#compareTo(java.lang.Object)
//     */
//    @Override
//    public int compareTo(ChangeProposalStateTask other) {
//        return new CompareToBuilder().append(this.getChangeProposalState(), other.getChangeProposalState())
//                .append(this.getTaskStartTs(), other.getTaskStartTs()).append(this.getTaskId(), other.getTaskId())
//                .append(this.getId(), other.getId()).toComparison();
//    }
//    
//    /**
//     * @see java.lang.Object#toString()
//     */
//    @Override
//    public String toString() {
//        return "ChangeProposalStateTask [id=" + id + ", taskId=" + taskId + ", taskName=" + taskName + ", taskStartTs="
//                + taskStartTs + ", taskDueTs=" + taskDueTs + ", assignee=" + assignee + ", createUserId=" + createUserId
//                + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId + ", lastModifiedTs="
//                + lastModifiedTs + ", lockControl=" + lockControl + ", assignmentGroups=" + assignmentGroups + "]";
//    }
}
