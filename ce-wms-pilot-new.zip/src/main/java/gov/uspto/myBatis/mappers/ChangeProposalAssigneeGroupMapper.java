package gov.uspto.myBatis.mappers;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import gov.uspto.myBatis.models.ChangeProposalAssigneeGroup;

@Mapper
public interface ChangeProposalAssigneeGroupMapper {
	@Insert("INSERT INTO change_proposal_assignee_group (create_ts,create_user_id,fk_assignee_ipo_cd,fk_assignee_role_cd,fk_state_task_id) "
			+ "VALUES(#{create_ts},#{create_user_id},#{fk_assignee_ipo_cd},#{fk_assignee_role_cd},#{fk_state_task_id})")
	Integer save(ChangeProposalAssigneeGroup changeProposalAssigneeGroup);

	@Delete("DELETE FROM change_proposal_assignee_group cpag WHERE cpag.TASK_ASSIGNEE_GROUP_ID IN "
			+ "(SELECT cpag2.TASK_ASSIGNEE_GROUP_ID "
			+ "FROM change_proposal_assignee_group cpag2 , change_proposal_state_task cpst , change_proposal_state cps "
			+ "WHERE cpag2.FK_STATE_TASK_ID = cpst.STATE_TASK_ID "
			+ "and cpst.FK_CHANGE_PROPOSAL_ID = cps.FK_CHANGE_PROPOSAL_ID "
			+ "and cps.FK_CHANGE_PROPOSAL_ID =#{stateId})")
	Integer deleteChangeProposalAssigneeGroupByChangeProposalStateId(@Param("stateId") Long stateId);

}
