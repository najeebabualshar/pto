package gov.uspto.tasks.service;


//import javax.inject.Inject;

import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Service;

@Service 
public class SpringI18NMessageSource {
    
    public static ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;
    
//    @Inject
    public SpringI18NMessageSource(ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource ) {
        this.reloadableResourceBundleMessageSource = reloadableResourceBundleMessageSource;   
    }
    
    

}
