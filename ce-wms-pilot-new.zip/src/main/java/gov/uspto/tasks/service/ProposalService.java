package gov.uspto.tasks.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;


import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.comparators.ReverseComparator;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import gov.uspto.myBatis.mappers.ChangeProposalAssigneeGroupMapper;
import gov.uspto.myBatis.mappers.ChangeProposalMapper;
import gov.uspto.myBatis.mappers.ChangeProposalStateMapper;
import gov.uspto.myBatis.mappers.ChangeProposalStateTaskMapper;
import gov.uspto.myBatis.models.ChangeProposal;
import gov.uspto.myBatis.models.ChangeProposalAlias;
import gov.uspto.myBatis.models.ChangeProposalAssigneeGroup;
import gov.uspto.myBatis.models.ChangeProposalState;
import gov.uspto.myBatis.models.ChangeProposalStateTask;
import gov.uspto.tasks.Enum.ExternalSystemCategory;
import gov.uspto.tasks.Enum.I18nMessageKey;
import gov.uspto.tasks.Enum.ProposalNamePrefix;
import gov.uspto.tasks.Enum.ProposalPhase;
import gov.uspto.tasks.Enum.ProposalStateType;
import gov.uspto.tasks.Enum.ProposalStatus;
import gov.uspto.tasks.Enum.ProposalSubphase;
import gov.uspto.tasks.Enum.StandardIpOfficeCode;
import gov.uspto.tasks.pojo.AssignmentGroup;
import gov.uspto.tasks.pojo.TaskStateDetails;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProposalService {

	@Autowired
	ChangeProposalMapper changeProposalMapper;

	@Autowired
	ChangeProposalAssigneeGroupMapper changeProposalAssigneeGroupMapper;

	@Autowired
	ChangeProposalStateTaskMapper changeProposalStateTaskMapper;

	@Autowired
	ChangeProposalStateMapper changeProposalStateMapper;
	
	public static final Integer INITIAL_LOCK_CONTROL = 0;

	public void updateProposalStatus(UUID proposalUuid, String wmsProcessInstanceId, String wmsDefinitionId,
			Date startTs, Date endTs, ProposalPhase phase, ProposalSubphase subphase, ProposalStateType state,
			String userUpdateEmail, ProposalNamePrefix prefix, TaskStateDetails... tasks) {
		Date now = new Date();

		ChangeProposal p = changeProposalMapper.findByGuidId(toDatabaseFormat(proposalUuid));// changeProposalRepository.findByExternalId(GUIDUtils.toDatabaseFormat(proposalUuid));
		if (p == null) {
			try {
				throw new Exception("proposal " + proposalUuid + " does not exist");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (prefix != null) {
			addAlias(p, createNewProposalName(getDisplayName(p.getAliases()), prefix), ExternalSystemCategory.CE, now,
					userUpdateEmail);
		}
		ChangeProposalState cpState = p.getState();
		if (cpState == null) {
			cpState = new ChangeProposalState();
			p.setState(cpState);
			cpState.setChangeProposal(p);
			cpState.setCreate_ts(now);
			cpState.setCreate_user_id(userUpdateEmail);
			cpState.setLock_control_no(INITIAL_LOCK_CONTROL - 1);
			Long cpId = changeProposalStateMapper.save(cpState);
			cpState.setFk_change_proposal_id(cpId);

		} else {
			int deletedGroups = changeProposalAssigneeGroupMapper
					.deleteChangeProposalAssigneeGroupByChangeProposalStateId(cpState.getFk_change_proposal_id());
			log.debug("Deleted {} assignment groups", deletedGroups);
			int deletedTasks = changeProposalStateTaskMapper
					.deleteChangeProposalStateTaskByChangeProposalStateId(cpState.getFk_change_proposal_id());
			log.debug("Deleted {} assignment tasks", deletedTasks);

			if (CollectionUtils.isNotEmpty(cpState.getActiveTasks())) {
				cpState.getActiveTasks().clear();
			}

		}
		cpState.setLast_mod_ts(now);
		cpState.setLast_mod_user_id(userUpdateEmail);
		cpState.setProposal_phase_tx(phase);
		cpState.setProposal_subphase_tx(subphase);
		cpState.setDefinition_id(wmsDefinitionId);
		cpState.setProcess_end_ts(endTs);
		cpState.setProcess_instance_id(wmsProcessInstanceId);
		cpState.setProcess_start_ts(startTs);
		cpState.setProposal_state_ct(state);

		changeProposalStateMapper.updateChangeProposalStateByGuidID(cpState);

		/**
		 * There can only be tasks on processes that are not complete
		 */
		if (tasks != null && cpState.getProcess_end_ts() == null) {
			log.debug("Tasks Not null");
			createStateTasks(cpState, now, userUpdateEmail, tasks);

		} else {
			log.debug("tasks == null ({}) or state.processEndTs is Non-null ({})", (tasks == null),
					(cpState.getProcess_end_ts() != null));
		}

		// p = changeProposalMapper.save(p);//

	}

	public String migrateDraft( UUID proposalGuid, String userId) {
		Date now = new Date();
//		final ProposalFormType formType = ProposalFormType.PROJECT_DETAIL;
		ChangeProposal cp = changeProposalMapper.findByGuidId(toDatabaseFormat(proposalGuid));
		if (cp == null) {
			try {
				throw new Exception(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
						I18nMessageKey.PROPOSAL_EXTERNALID_NOTFOUND.name(), new Object[] { proposalGuid },
						LocaleContextHolder.getLocale()));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		String currentAlias = getDisplayName(cp.getAliases());
		if (!StringUtils.equals(StringUtils.substring(currentAlias, 0, ProposalNamePrefix.XX.name().length()),
				ProposalNamePrefix.XX.name())) {
			throw new IllegalArgumentException(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
					I18nMessageKey.PROPOSAL_NOT_DRAFT.name(), new Object[] { proposalGuid, currentAlias },
					LocaleContextHolder.getLocale()));
		}

		String cpDetails = changeProposalMapper.getDetailTRX(cp.getChange_proposal_id());
		String projType = StringUtils.EMPTY;
		if (cpDetails != null && !cpDetails.isEmpty()) {
			projType = cpDetails;
		} else {
			throw new IllegalArgumentException(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
					I18nMessageKey.PROPOSAL_PROJECT_DETAILS_KVP_NOT_FOUND.name(),
					new Object[] { proposalGuid, "PROJECT_TYPE_KEY" }, LocaleContextHolder.getLocale()));
		}
		if (projType.length() > ProposalNamePrefix.XX.name().length()) {
			projType = StringUtils.substring(projType, 0, ProposalNamePrefix.XX.name().length());
		}
		ProposalNamePrefix prefix = null;
		try {
			prefix = ProposalNamePrefix.fromValue(projType);
		} catch (Exception e) {
			log.warn("failed to get prefix from projType {}", projType, e);
			throw new IllegalArgumentException(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
					I18nMessageKey.PROPOSAL_PREFIX_NOT_VALID.name(),
					new Object[] { proposalGuid, projType, "PROJECT_DETAIL", "PROJECT_TYPE_KEY" },
					LocaleContextHolder.getLocale()));
		}
		addAlias(cp, prefix.name() + StringUtils.substring(currentAlias, ProposalNamePrefix.XX.name().length()),
				ExternalSystemCategory.CE, now, userId);

		cp.setLast_mod_user_id(userId);
		cp.setLast_mod_ts(now);
		cp.setLock_control_no(cp.getLock_control_no() + 1);

		changeProposalMapper.updateChangeProposalByChangeProposalId(cp);

//		cp = changeProposalRepository.save(cp);
		log.debug("new Alias = {}", getDisplayName(cp.getAliases()));

		return getDisplayName(cp.getAliases());
	}

	public String createNewProposalName(String changeProposalCode, ProposalNamePrefix prefix) {
		StringBuilder newName = new StringBuilder();
		newName.append(prefix.name());
		int startIdx = 0;
		String originalTypeMaybe = StringUtils.substring(changeProposalCode, 0, 2);
		if (EnumUtils.isValidEnum(ProposalNamePrefix.class, originalTypeMaybe)) {
			startIdx += originalTypeMaybe.length();
		}
		newName.append(StringUtils.substring(changeProposalCode, startIdx));
		return newName.toString();
	}

	private void addAlias(ChangeProposal proposalEntity, String aliasName, ExternalSystemCategory ce, Date now,
			String email) {

		ChangeProposalAlias alias = new ChangeProposalAlias();
		alias.setFk_change_proposal_id(proposalEntity);
		alias.setCreate_ts(now);
		alias.setLast_mod_ts(now);
		alias.setLock_control_no(INITIAL_LOCK_CONTROL);
		alias.setChange_proposal_alias_cd(aliasName);
		alias.setSource_system_ct(ce);
		alias.setCreate_user_id(email);
		alias.setLast_mod_user_id(email);
		// insert alias
		changeProposalMapper.insertIntoChangeProposalAlias(alias);
		proposalEntity.getAliases().add(alias);

	}

	String getDisplayName(Collection<ChangeProposalAlias> aliases) {
		String name = null;
		List<ChangeProposalAlias> sorted = new ArrayList<>();
		sorted.addAll(aliases);
		Collections.sort(sorted, new ReverseComparator<>(new BeanComparator<>("last_mod_ts")));
		for (ChangeProposalAlias a : sorted) {
			if (Arrays.asList(ExternalSystemCategory.CE.name(), ExternalSystemCategory.CPC.name(),
					ExternalSystemCategory.CEF.name()).contains(a.getSource_system_ct().name())) {
				name = a.getChange_proposal_alias_cd();
				break;
			}
		}
		return name;
	}

	private void createStateTasks(ChangeProposalState cpState, Date now, String userUpdateEmail,
			TaskStateDetails[] tasks) {
		for (TaskStateDetails task : tasks) {
			ChangeProposalStateTask t = createStateTaskFromWmsTask(task, now, userUpdateEmail);
			if (t != null) {
				t.setChangeProposalState(cpState);
				cpState.getActiveTasks().add(t);
			}

		}
	}

	ChangeProposalStateTask createStateTaskFromWmsTask(TaskStateDetails task, Date now, String updateUserEmail) {
		ChangeProposalStateTask t = null;
		log.debug("task != null ({}) and completeTs == null ({})", (task != null), (task.getCompleteTs() == null));
		if (task != null && task.getCompleteTs() == null) {
			t = new ChangeProposalStateTask();
			t.setCfk_task_assignee_id(task.getAssignee());
			t.setCreate_ts(now);
			t.setCreate_user_id(updateUserEmail);
			t.setLast_mod_ts(now);
			t.setLast_mod_user_id(updateUserEmail);
			t.setCfk_task_assignee_role_tx(task.getTaskedRole());
			t.setCfk_task_assignee_office_cd(task.getTaskedOffice());
			t.setLock_control_no(INITIAL_LOCK_CONTROL);
			t.setTask_start_ts(task.getStartTs()); // ALLWAYS NULL
			t.setTask_id(task.getTaskId());
			t.setTask_name_tx(task.getTaskName());
			t.setTask_due_ts(task.getDueTs());
			if (CollectionUtils.isNotEmpty(task.getAssigneeCandidateGroups())) {
				populateAssignmentCollections(task, t, now, updateUserEmail);
			}
			changeProposalStateTaskMapper.save(t);

		}
		return t;
	}

	String toDatabaseFormat(UUID guid) {
		String ret = null;
		if (guid != null) {
			ret = guid.toString().toLowerCase().replaceAll("(\\{)|(\\})|(-)", StringUtils.EMPTY);
		}
		return ret;
	}

	void populateAssignmentCollections(TaskStateDetails task, ChangeProposalStateTask t, Date now,
			String updateUserEmail) {
		for (AssignmentGroup grp : task.getAssigneeCandidateGroups()) {
			for (StandardIpOfficeCode office : grp.getOffices()) {
				ChangeProposalAssigneeGroup dbGroup = new ChangeProposalAssigneeGroup();
				dbGroup.setCreate_ts(now);
				dbGroup.setCreate_user_id(updateUserEmail);
				dbGroup.setFk_assignee_ipo_cd(office);
				dbGroup.setFk_assignee_role_cd(grp.getRole());
				dbGroup.setTask(t);
				changeProposalAssigneeGroupMapper.save(dbGroup);
				t.getAssignmentGroups().add(dbGroup);
			}
		}
	}

	public void updateProposalWorkflowStatus(UUID uuid, ProposalStatus status) {
		ChangeProposal cp = changeProposalMapper.findByGuidId(uuid.toString());
		// .findByExternalId(GUIDUtils.toDatabaseFormat(uuid));
		if (cp == null) {
			try {
				throw new Exception("proposal " + uuid + " does not exist");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		cp.setProposal_status_ct(status.name());
		changeProposalMapper.updateChangeProposalByChangeProposalId(cp);
//		changeProposalRepository.save(cp);
	}

}
