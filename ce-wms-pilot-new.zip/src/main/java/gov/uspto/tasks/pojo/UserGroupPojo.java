package gov.uspto.tasks.pojo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserGroupPojo {

	protected String fk_ipo_cd;
	protected String fk_proposer_role_cd;

}
