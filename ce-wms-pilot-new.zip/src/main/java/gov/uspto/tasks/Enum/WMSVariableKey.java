package gov.uspto.tasks.Enum;


public enum WMSVariableKey {
	 PROPOSAL_ID,
	    STARTED_BY,

	    /**
	     * This is the EMAIL for Project Coordinator PERSON who Is responsible for the Rappator
	     * 						workflow instance
	     * 
	     */
	    PRIMARY_COORDINATOR,

	    /**
	     * This is the EMAIL for Editorial Board PERSON who Is responsible for the Rappator
	     * 						workflow instance
	     * 
	     */
	    PRIMARY_EDITORIAL_BOARD,

	    /**
	     * This is the EMAIL for QN PERSON who Is responsible for the Rappator
	     * 						workflow instance
	     * 
	     */
	    PRIMARY_QN_TECH_EXPERT,

	    /**
	     * This is the EMAIL for Project Coordinator PERSON who might have parallel tasks in non-reppator office
	     * 						workflow instance
	     * 
	     */
	    SECONDARY_COORDINATOR,

	    /**
	     * This is the EMAIL for Editorial Board PERSON who Is responsible for the non-Rappator
	     * 						workflow instance
	     * 
	     */
	    SECONDARY_EDITORIAL_BOARD,

	    /**
	     * This is the EMAIL for QN PERSON PERSON who Is responsible for the non-Rappator
	     * 						workflow instance
	     * 
	     */
	    SECONDARY_QN_TECH_EXPERT,

	    /**
	     * Type expected here is enum for
	     * 						StandardIpOfficeCode not string
	     * 
	     */
	    RAPPORTEUR_OFFICE,

	    /**
	     * Variable used to pass the entry point during
	     *                     workflow kickoff.  This is only used by workflow kickoff and not maintained
	     *                     by subsequent updates to the running wms instance
	     * 
	     */
	    ENTRY_POINT,

	    /**
	     * Variable used to pass the phase entry point during
	     *                     workflow kickoff.  This is only used by workflow kickoff and not maintained
	     *                     by subsequent updates to the running wms instance
	     * 
	     */
	    PHASE_ENTRY_POINT;

	    public String value() {
	        return name();
	    }

	    public static WMSVariableKey fromValue(String v) {
	        return valueOf(v);
	    }

}
