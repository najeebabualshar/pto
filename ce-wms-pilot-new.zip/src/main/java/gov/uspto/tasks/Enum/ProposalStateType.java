package gov.uspto.tasks.Enum;

public enum ProposalStateType {

	ACTIVE, TERMINATED, SUSPENDED, ESCALATED, COMPLETED;

	public String value() {
		return name();
	}

	public static ProposalStateType fromValue(String v) {
		return valueOf(v);
	}
}
