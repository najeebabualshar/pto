package gov.uspto.tasks.Enum;

public enum ProposalNamePrefix {

	/**
	 * Draft
	 * 
	 */
	XX,

	/**
	 * Sandbox
	 * 
	 */
	SB,

	/**
	 * Maintenance Project
	 * 
	 */
	MP,

	/**
	 * Definition Project
	 * 
	 */
	DP,

	/**
	 * CEF Maintenance
	 * 
	 */
	CM,

	/**
	 * IA
	 * 
	 */
	IA,

	/**
	 * ID
	 * 
	 */
	ID,

	/**
	 * IZ
	 * 
	 */
	IZ,

	/**
	 * IV
	 * 
	 */
	IV,

	/**
	 * IW
	 * 
	 */
	IW,

	/**
	 * IU
	 * 
	 */
	IU,

	/**
	 * E-proposals (pre-IP5 phase)
	 * 
	 */
	IE,

	/**
	 * IPC Maintenance
	 * 
	 */
	IM,

	/**
	 * IPC Revision Project
	 * 
	 */
	IC,

	/**
	 * IPC and IP5 related
	 * 
	 */
	IF,

	/**
	 * IPC revision requests
	 * 
	 */
	IQ,

	/**
	 * J-proposal (pre-IP5 phase)
	 * 
	 */
	IJ,

	/**
	 * P-proposals (IP5)
	 * 
	 */
	IP,

	/**
	 * Project Documentation Template
	 * 
	 */
	PD,

	/**
	 * Project Management
	 * 
	 */
	PM,

	/**
	 * Revision Project
	 * 
	 */
	RP,

	/**
	 * Revision Request
	 * 
	 */
	RR,

	/**
	 * EC-Editorial Corrections
	 * 
	 */
	EC,

	/**
	 * Harmonization Project
	 * 
	 */
	HP,

	/**
	 * Harmonization Project
	 * 
	 */
	HX;

	public String value() {
		return name();
	}

	public static ProposalNamePrefix fromValue(String v) {
		return valueOf(v);
	}

}
