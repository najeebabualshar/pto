package gov.uspto.tasks.Enum;

/**
 * <p>
 * Java class for TaskAction.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * <p>
 * 
 * <pre>
 * &lt;simpleType name="TaskAction"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="INITIAL_APPROVE"/&gt;
 *     &lt;enumeration value="INITIAL_REJECT"/&gt;
 *     &lt;enumeration value="REPEAT_APPROVE"/&gt;
 *     &lt;enumeration value="REPEAT_REJECT"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
public enum TaskAction {

	INITIAL_APPROVE, INITIAL_REJECT, REPEAT_APPROVE, REPEAT_REJECT;

	public String value() {
		return name();
	}

	public static TaskAction fromValue(String v) {
		return valueOf(v);
	}

}
