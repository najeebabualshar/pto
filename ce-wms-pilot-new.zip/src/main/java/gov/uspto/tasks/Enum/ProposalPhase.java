package gov.uspto.tasks.Enum;

/**
 * <p>Java class for ProposalPhase.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ProposalPhase"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="INTERNAL"/&gt;
 *     &lt;enumeration value="REQUEST"/&gt;
 *     &lt;enumeration value="PROJECT"/&gt;
 *     &lt;enumeration value="COMPLETED"/&gt;
 *     &lt;enumeration value="XX"/&gt;
 *     &lt;enumeration value="I"/&gt;
 *     &lt;enumeration value="E"/&gt;
 *     &lt;enumeration value="Q"/&gt;
 *     &lt;enumeration value="A"/&gt;
 *     &lt;enumeration value="PI"/&gt;
 *     &lt;enumeration value="DI"/&gt;
 *     &lt;enumeration value="R"/&gt;
 *     &lt;enumeration value="U"/&gt;
 *     &lt;enumeration value="F"/&gt;
 *     &lt;enumeration value="PF"/&gt;
 *     &lt;enumeration value="DF"/&gt;
 *     &lt;enumeration value="C"/&gt;
 *     &lt;enumeration value="P"/&gt;
 *     &lt;enumeration value="D"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
public enum ProposalPhase {

    INTERNAL,
    REQUEST,
    PROJECT,
    COMPLETED,
    XX,
    I,
    E,
    Q,
    A,
    PI,
    DI,
    R,
    U,
    F,
    PF,
    DF,
    C,
    P,
    D;

    public String value() {
        return name();
    }

    public static ProposalPhase fromValue(String v) {
        return valueOf(v);
    }

}
