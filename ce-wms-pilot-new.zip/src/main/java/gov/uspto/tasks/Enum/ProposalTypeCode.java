package gov.uspto.tasks.Enum;

public enum ProposalTypeCode {

	/**
	 * Definition Project
	 * 
	 */
	DP,

	/**
	 * Maintenance Project
	 * 
	 */
	MP,

	/**
	 * Revision Project
	 * 
	 */
	RP,

	/**
	 * Quick Fix
	 * 
	 */
	QF,

	/**
	 * Harmonization Project
	 * 
	 */
	HP,

	/**
	 * Intl Pat Class Project
	 * 
	 */
	IPC,

	/**
	 * Project Management
	 * 
	 */
	PM,

	/**
	 * Project Documentation
	 * 
	 */
	PD;

	public String value() {
		return name();
	}

	public static ProposalTypeCode fromValue(String v) {
		return valueOf(v);
	}

}
