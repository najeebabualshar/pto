package com.activiti.extension.bean.uspto.listener;

import java.util.UUID;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.annotation.Transient;
import org.springframework.stereotype.Component;

//import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalStatus;
//import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import gov.uspto.tasks.Enum.ProposalStatus;
import gov.uspto.tasks.service.ProposalService;

@Component("wfEndListener")
public class WfEndListener implements ExecutionListener {

	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger(WfEndListener.class);

	@Autowired
//	@Transient
//	@Qualifier("proposalService")
	private ProposalService proposalService;
//
//	@Autowired
//	@Qualifier("transactionManager")
////	@Transient
//	private PlatformTransactionManager transactionManager;

	@Override
	public void notify(DelegateExecution execution) {

		log.debug("******ENTERING WF END LISTENER******");

		/*
		 * US348679 -> TA948351
		 */
		String processDef = execution.getProcessDefinitionId();
		log.debug("Process Def : {} ", processDef);

		if (processDef.startsWith("CPC_REVISION") || processDef.startsWith("EC") || processDef.startsWith("IPC")
				|| processDef.startsWith("HARMONIZATION")) {

			final UUID uuid = UUID.fromString(execution.getProcessInstanceBusinessKey());

			log.debug("Updating proposalService.updateProposalWorkflowStatus");
			proposalService.updateProposalWorkflowStatus(uuid, ProposalStatus.COMPLETED);
			
//			TransactionTemplate tmpl = new TransactionTemplate(transactionManager);
//			tmpl.execute(new TransactionCallbackWithoutResult() {
//
//				@Override
//				protected void doInTransactionWithoutResult(TransactionStatus status) {
//
//					log.debug("Updating proposalService.updateProposalWorkflowStatus");
//					proposalService.updateProposalWorkflowStatus(uuid, ProposalStatus.COMPLETED);
//				}
//			});

		} else {
			log.debug("Unkown Track Process Def : {} ", processDef);
		}

		log.debug("******EXITING WF END LISTENER******");
	}

}
