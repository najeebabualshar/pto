package com.activiti.extension.bean.uspto.listener;

import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import gov.uspto.tasks.service.Constants;

@Component("wfStartListener")
public class WfStartListener implements ExecutionListener {

	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger(WfStartListener.class);

	@Override
	public void notify(DelegateExecution execution) {//throws Exception {

		Map<String, Object> variables = execution.getVariables();

		log.debug("Printing Execution variables :");
		execution.getVariables().entrySet().stream()
				.forEach(e -> log.debug("WF  VAR:{} ::-->  {} ", e.getKey(), e.getValue()));

		String startPhase = null;

		if (execution.hasVariable(Constants.VAR_PI_PHASE_ENTRY_POINT)) {

			startPhase = (String) variables.get(Constants.VAR_PI_PHASE_ENTRY_POINT);
			log.debug("Start phase is --> |{}|", startPhase);

		}

		if (StringUtils.isBlank(startPhase)) {
			log.error("Missing PHASE_ENTRY_POINT , can't continue further");
			throw new RuntimeException("Missing PHASE_ENTRY_POINT");
		}

		String processDef = execution.getProcessDefinitionId();
		log.debug("Process Def : {} ", processDef);

		if (processDef.startsWith("CPC_REVISION")) {

			if (startPhase.equalsIgnoreCase("I") || startPhase.equalsIgnoreCase("E") || startPhase.equalsIgnoreCase("Q")
					|| startPhase.equalsIgnoreCase("A") || startPhase.equalsIgnoreCase("PI")
					|| startPhase.equalsIgnoreCase("DI") || startPhase.equalsIgnoreCase("R")
					|| startPhase.equalsIgnoreCase("U") || startPhase.equalsIgnoreCase("F")
					|| startPhase.equalsIgnoreCase("PF") || startPhase.equalsIgnoreCase("DF")
					|| startPhase.equalsIgnoreCase("C")) {

				log.debug("Start phase is --> |{}|", startPhase);

			} else {

				log.error("Start phase is missing, can't start workflow ");
				throw new RuntimeException("Track CPC_REVISION :  Invalid startPhase -> " + startPhase);

			}
		} else if (processDef.startsWith("IPC") || processDef.startsWith("HARMONIZATION")) {

			if (startPhase.equalsIgnoreCase("I") || startPhase.equalsIgnoreCase("A")
					|| startPhase.equalsIgnoreCase("C")) {

				log.debug("Start phase is --> |{}|", startPhase);

			} else {

				log.error("Start phase is missing, can't start workflow ");
				throw new RuntimeException("Track IPC :  Invalid startPhase -> " + startPhase);

			}
		} else if (processDef.startsWith("EC")) {

			if (startPhase.equalsIgnoreCase("I") || startPhase.equalsIgnoreCase("A") || startPhase.equalsIgnoreCase("P")
					|| startPhase.equalsIgnoreCase("D") || startPhase.equalsIgnoreCase("C")) {

				log.debug("Start phase is --> |{}|", startPhase);

			} else {

				log.error("Start phase is missing, can't start workflow ");
				throw new RuntimeException("Track IPC :  Invalid startPhase -> " + startPhase);

			}
		} else {
			log.error("Unknown workflow track");
			throw new RuntimeException("Unknown workflow track");
		}

	}

}
