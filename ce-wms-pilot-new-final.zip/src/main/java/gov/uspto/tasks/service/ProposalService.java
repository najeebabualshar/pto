package gov.uspto.tasks.service;

import java.util.Date;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.activiti.service.api.UserService;

import gov.uspto.myBatis.mappers.ChangeProposalAssigneeGroupMapper;
import gov.uspto.myBatis.mappers.ChangeProposalMapper;
import gov.uspto.myBatis.mappers.ChangeProposalStateMapper;
import gov.uspto.myBatis.mappers.ChangeProposalStateTaskMapper;
import gov.uspto.myBatis.models.ChangeProposal;
import gov.uspto.myBatis.models.ChangeProposalAliasInsert;
import gov.uspto.myBatis.models.ChangeProposalAssigneeGroupInsert;
import gov.uspto.myBatis.models.ChangeProposalInsert;
import gov.uspto.myBatis.models.ChangeProposalState;
import gov.uspto.myBatis.models.ChangeProposalStateInsert;
import gov.uspto.myBatis.models.ChangeProposalStateTask;
import gov.uspto.tasks.Enum.ExternalSystemCategory;
import gov.uspto.tasks.Enum.ProposalNamePrefix;
import gov.uspto.tasks.Enum.ProposalPhase;
import gov.uspto.tasks.Enum.ProposalStateType;
import gov.uspto.tasks.Enum.ProposalStatus;
import gov.uspto.tasks.Enum.ProposalSubphase;
import gov.uspto.tasks.Enum.StandardIpOfficeCode;
import gov.uspto.tasks.pojo.AssignmentGroup;
import gov.uspto.tasks.pojo.TaskStateDetails;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProposalService {

	@Autowired
	ChangeProposalMapper changeProposalMapper;

	@Autowired
	ChangeProposalAssigneeGroupMapper changeProposalAssigneeGroupMapper;

	@Autowired
	ChangeProposalStateTaskMapper changeProposalStateTaskMapper;

	@Autowired
	ChangeProposalStateMapper changeProposalStateMapper;

	@Autowired
	private UserService userService;

	public static final Integer INITIAL_LOCK_CONTROL = 0;

	public void updateProposalStatus(UUID proposalUuid, String wmsProcessInstanceId, String wmsDefinitionId,
			Date startTs, Date endTs, ProposalPhase phase, ProposalSubphase subphase, ProposalStateType state,
			String userUpdateEmail, ProposalNamePrefix prefix, TaskStateDetails... tasks) {
		Date now = new Date();
//		String nowDateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());

		ChangeProposal p = changeProposalMapper.findByGuidId(toDatabaseFormat(proposalUuid));// changeProposalRepository.findByExternalId(GUIDUtils.toDatabaseFormat(proposalUuid));
		if (p == null) {
			try {
				throw new Exception("proposal " + proposalUuid + " does not exist");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (prefix != null) {
			addAlias(p, createNewProposalName(getDisplayName(p.getChange_proposal_id()), prefix),
					ExternalSystemCategory.CE, now, userUpdateEmail);
		}
		log.info("#####################################################");
		log.info(p.toString());
		log.info("!!!!!!!!!!!!!!!!");

		ChangeProposalState cpState = changeProposalStateMapper.findById(p.getChange_proposal_id());

		log.info(cpState.toString());

		if (cpState == null) {
			cpState = new ChangeProposalState();
			p.setState(cpState);
//			cpState.setChangeProposal(p);
			cpState.setCreate_ts(now);
			cpState.setCreate_user_id(userUpdateEmail);
			cpState.setLock_control_no(INITIAL_LOCK_CONTROL - 1);

			ChangeProposalStateInsert cpsi = new ChangeProposalStateInsert();
			cpsi.setFk_change_proposal_id(p.getChange_proposal_id());
			cpsi.setProcess_start_ts(startTs);
			cpsi.setDefinition_id(wmsDefinitionId);
			cpsi.setProcess_instance_id(wmsProcessInstanceId);
			cpsi.setCreate_user_id(userUpdateEmail);
			cpsi.setCreate_ts(now);
			cpsi.setLast_mod_ts(now);
			cpsi.setLast_mod_user_id(userUpdateEmail);
			cpsi.setLock_control_no(INITIAL_LOCK_CONTROL - 1);
			cpsi.setProposal_subphase_tx(subphase.toString());
			cpsi.setProposal_phase_tx(phase.toString());
			cpsi.setProposal_state_ct(state.toString());

//			
			log.info("*******************************************************");
			log.info(cpsi.toString());
			log.info("*******************************************************");

			Long cpId = changeProposalStateMapper.save(cpsi);

			log.info(cpId.toString());
			log.info("*******************************************************");

			cpState.setFk_change_proposal_id(cpId);

		} else {
			int deletedGroups = changeProposalAssigneeGroupMapper
					.deleteChangeProposalAssigneeGroupByChangeProposalStateId(cpState.getFk_change_proposal_id());
			log.debug("Deleted {} assignment groups", deletedGroups);
			int deletedTasks = changeProposalStateTaskMapper
					.deleteChangeProposalStateTaskByChangeProposalStateId(cpState.getFk_change_proposal_id());
			log.debug("Deleted {} assignment tasks", deletedTasks);

			if (CollectionUtils.isNotEmpty(cpState.getActiveTasks())) {
				cpState.getActiveTasks().clear();
			}

		}

		cpState.setLast_mod_ts(now);
		cpState.setLast_mod_user_id(userUpdateEmail);
		cpState.setProposal_phase_tx(phase.name());
		cpState.setProposal_subphase_tx(subphase.name());
		cpState.setDefinition_id(wmsDefinitionId);
		cpState.setProcess_end_ts(endTs);
		cpState.setProcess_instance_id(wmsProcessInstanceId);
		cpState.setProcess_start_ts(startTs);
		cpState.setProposal_state_ct(state.name());

		ChangeProposalStateInsert cpsi = new ChangeProposalStateInsert();
//		cpsi.setCreate_ts(now);
//		cpsi.setCreate_user_id(userUpdateEmail);
//		cpsi.setLock_control_no(INITIAL_LOCK_CONTROL - 1);
		cpsi.setDefinition_id(wmsDefinitionId);
		cpsi.setProcess_instance_id(wmsProcessInstanceId);
		cpsi.setLast_mod_ts(now);
		cpsi.setLast_mod_user_id(userUpdateEmail);
		cpsi.setProposal_phase_tx(phase.toString());
		cpsi.setProposal_subphase_tx(subphase.toString());
		cpsi.setProcess_end_ts(endTs);
		cpsi.setProcess_start_ts(startTs);
		cpsi.setProposal_state_ct(state.toString());

		cpsi.setFk_change_proposal_id(cpState.getFk_change_proposal_id());

		log.info("*******************************************************");
		log.info(cpsi.toString());
		log.info("*******************************************************");

		changeProposalStateMapper.updateChangeProposalStateByGuidID(cpsi);

		log.info("**************************DONE***************");

		// changeProposalStateMapper.updateChangeProposalStateByGuidID(cpsi);

		/**
		 * There can only be tasks on processes that are not complete
		 */
		if (tasks != null && cpState.getProcess_end_ts() == null) {
			log.debug("Tasks Not null");
			createStateTasks(cpState, now, userUpdateEmail, tasks);

		} else {
			log.debug("tasks == null ({}) or state.processEndTs is Non-null ({})", (tasks == null),
					(cpState.getProcess_end_ts() != null));
		}

		// p = changeProposalMapper.save(p);//

	}

	public String migrateDraft(UUID proposalGuid, String userId) {
		Date now = new Date();

//		final ProposalFormType formType = ProposalFormType.PROJECT_DETAIL;
		ChangeProposal cp = changeProposalMapper.findByGuidId(toDatabaseFormat(proposalGuid));
		if (cp == null) {
//			try {
////				throw new Exception(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
////						I18nMessageKey.PROPOSAL_EXTERNALID_NOTFOUND.name(), new Object[] { proposalGuid },
////						LocaleContextHolder.getLocale()));
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		}
		String currentAlias = getDisplayName(cp.getChange_proposal_id());
//		if (!StringUtils.equals(StringUtils.substring(currentAlias, 0, ProposalNamePrefix.XX.name().length()),
//				ProposalNamePrefix.XX.name())) {
//			throw new IllegalArgumentException(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
//					I18nMessageKey.PROPOSAL_NOT_DRAFT.name(), new Object[] { proposalGuid, currentAlias },
//					LocaleContextHolder.getLocale()));
//		}

		String cpDetails = changeProposalMapper.getDetailTRX(cp.getChange_proposal_id());
		String projType = StringUtils.EMPTY;
		if (cpDetails != null && !cpDetails.isEmpty()) {
			projType = cpDetails;
		}
//		else {
//			throw new IllegalArgumentException(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
//					I18nMessageKey.PROPOSAL_PROJECT_DETAILS_KVP_NOT_FOUND.name(),
//					new Object[] { proposalGuid, "PROJECT_TYPE_KEY" }, LocaleContextHolder.getLocale()));
//		}
		if (projType.length() > ProposalNamePrefix.XX.name().length()) {
			projType = StringUtils.substring(projType, 0, ProposalNamePrefix.XX.name().length());
		}
		ProposalNamePrefix prefix = null;
		try {
			prefix = ProposalNamePrefix.fromValue(projType);
		} catch (Exception e) {
			log.warn("failed to get prefix from projType {}", projType, e);
//			throw new IllegalArgumentException(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
//					I18nMessageKey.PROPOSAL_PREFIX_NOT_VALID.name(),
//					new Object[] { proposalGuid, projType, "PROJECT_DETAIL", "PROJECT_TYPE_KEY" },
//					LocaleContextHolder.getLocale()));
		}
		addAlias(cp, prefix.name() + StringUtils.substring(currentAlias, ProposalNamePrefix.XX.name().length()),
				ExternalSystemCategory.CE, now, userId);

		cp.setLast_mod_user_id(userId);
		cp.setLast_mod_ts(now);
		cp.setLock_control_no(cp.getLock_control_no() + 1);

		ChangeProposalInsert cpi = new ChangeProposalInsert();

		cpi.setLast_mod_user_id(userId);
		cpi.setLast_mod_ts(now);
		cpi.setLock_control_no(cp.getLock_control_no() + 1);
		cpi.setChange_proposal_id(cp.getChange_proposal_id());

		changeProposalMapper.updateChangeProposalByChangeProposalId(cpi);

//		cp = changeProposalRepository.save(cp);
		log.debug("new Alias = {}", getDisplayName(cp.getChange_proposal_id()));

		return getDisplayName(cp.getChange_proposal_id());
	}

	public String createNewProposalName(String changeProposalCode, ProposalNamePrefix prefix) {
		StringBuilder newName = new StringBuilder();
		newName.append(prefix.name());
		int startIdx = 0;
		String originalTypeMaybe = StringUtils.substring(changeProposalCode, 0, 2);
		if (EnumUtils.isValidEnum(ProposalNamePrefix.class, originalTypeMaybe)) {
			startIdx += originalTypeMaybe.length();
		}
		newName.append(StringUtils.substring(changeProposalCode, startIdx));
		return newName.toString();
	}

	private void addAlias(ChangeProposal proposalEntity, String aliasName, ExternalSystemCategory ce, Date now,
			String email) {

		log.info("0000000000000000000000000000000000000000000000000000000");
		log.info(proposalEntity.toString());

		ChangeProposalAliasInsert alias = new ChangeProposalAliasInsert();
		alias.setChange_proposal_alias_id(changeProposalMapper.getNextSeq());
		alias.setFk_change_proposal_id(proposalEntity.getChange_proposal_id());
		alias.setCreate_ts(now);
		alias.setLast_mod_ts(now);
		alias.setLock_control_no(INITIAL_LOCK_CONTROL);
		alias.setChange_proposal_alias_cd(aliasName);
		alias.setSource_system_ct(ce.toString());
		alias.setCreate_user_id(getUserEmail(email));
		alias.setLast_mod_user_id(getUserEmail(email));
		// insert alias
		log.info("0000000000000000000000000000000000000000000000000000000");
		log.info(alias.toString());
		log.info("0000000000000000000000000000000000000000000000000000000");
		changeProposalMapper.insertIntoChangeProposalAlias(alias);
		log.info("000000000000--------------DONE----------000000000000000");

//		ChangeProposalAlias aliasObject = new ChangeProposalAlias();
//		aliasObject.setFk_change_proposal_id(proposalEntity);
//		aliasObject.setCreate_ts(now);
//		aliasObject.setLast_mod_ts(now);
//		aliasObject.setLock_control_no(INITIAL_LOCK_CONTROL);
//		aliasObject.setChange_proposal_alias_cd(aliasName);
//		aliasObject.setSource_system_ct(ce.toString());
//		aliasObject.setCreate_user_id(email);
//		aliasObject.setLast_mod_user_id(email);
//		// insert alias
//		// changeProposalMapper.insertIntoChangeProposalAlias(alias);
//		
//		proposalEntity.getAliases().add(aliasObject);

	}

	String getDisplayName(Long changeProposalId) {
		return changeProposalMapper.findAliasDisplayNameByProposalId(changeProposalId);
	}

	private void createStateTasks(ChangeProposalState cpState, Date now, String userUpdateEmail,
			TaskStateDetails[] tasks) {
		for (TaskStateDetails task : tasks) {
			ChangeProposalStateTask t = createStateTaskFromWmsTask(task, now, userUpdateEmail);
			if (t != null) {
				t.setChangeProposalState(cpState);
				cpState.getActiveTasks().add(t);
			}

		}
	}

	ChangeProposalStateTask createStateTaskFromWmsTask(TaskStateDetails task, Date now, String updateUserEmail) {
		ChangeProposalStateTask t = null;
		log.debug("task != null ({}) and completeTs == null ({})", (task != null), (task.getCompleteTs() == null));
		if (task != null && task.getCompleteTs() == null) {
			t = new ChangeProposalStateTask();
			t.setCfk_task_assignee_id(task.getAssignee());
			t.setCreate_ts(now);
			t.setCreate_user_id(updateUserEmail);
			t.setLast_mod_ts(now);
			t.setLast_mod_user_id(updateUserEmail);
			t.setCfk_task_assignee_role_tx(task.getTaskedRole());
			t.setCfk_task_assignee_office_cd(task.getTaskedOffice().name());
			t.setLock_control_no(INITIAL_LOCK_CONTROL);
			t.setTask_start_ts(task.getStartTs()); // ALLWAYS NULL
			t.setTask_id(task.getTaskId());
			t.setTask_name_tx(task.getTaskName());
			t.setTask_due_ts(task.getDueTs());
			if (CollectionUtils.isNotEmpty(task.getAssigneeCandidateGroups())) {
				populateAssignmentCollections(task, t, now, updateUserEmail);
			}
			changeProposalStateTaskMapper.save(t);

		}
		return t;
	}

	String toDatabaseFormat(UUID guid) {
		String ret = null;
		if (guid != null) {
			ret = guid.toString().toLowerCase().replaceAll("(\\{)|(\\})|(-)", StringUtils.EMPTY);
		}
		return ret;
	}

	void populateAssignmentCollections(TaskStateDetails task, ChangeProposalStateTask t, Date now,
			String updateUserEmail) {
		for (AssignmentGroup grp : task.getAssigneeCandidateGroups()) {
			for (StandardIpOfficeCode office : grp.getOffices()) {
				ChangeProposalAssigneeGroupInsert dbGroup = new ChangeProposalAssigneeGroupInsert();
				dbGroup.setCreate_ts(now);
				dbGroup.setCreate_user_id(updateUserEmail);
				dbGroup.setFk_assignee_ipo_cd(office.name());
				dbGroup.setFk_assignee_role_cd(grp.getRole().name());
				dbGroup.setState_task_id(t.getState_task_id());
				changeProposalAssigneeGroupMapper.save(dbGroup);
//				t.getAssignmentGroups().add(dbGroup);
			}
		}
	}

	public void updateProposalWorkflowStatus(UUID uuid, ProposalStatus status) {
		log.info("Inside updateProposalWorkflowStatus");

		String uuidStr = toDatabaseFormat(uuid);
		ChangeProposal cp = changeProposalMapper.findByGuidId(uuidStr);
		// .findByExternalId(GUIDUtils.toDatabaseFormat(uuid));
		if (cp == null) {
			try {
				throw new Exception("proposal " + uuid + " does not exist");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		changeProposalMapper.updateChangeProposalStatusByGuidId(status.toString(), uuidStr);
//		ChangeProposalInsert cpi = new ChangeProposalInsert();
//
//		cpi.setProposal_status_ct();
//		cpi.setChange_proposal_id();
//		changeProposalMapper.updateChangeProposalByChangeProposalId(cpi);
//		changeProposalRepository.save(cp);
		log.info("Done updateProposalWorkflowStatus");
	}

	String getUserEmail(String userId) {

		return userService.getUser(Long.valueOf(userId)).getEmail();
	}
}
