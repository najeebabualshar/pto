package gov.uspto.tasks.service;


import org.springframework.beans.factory.annotation.Autowired;

//import javax.inject.Inject;

import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Service;

@Service 
public class SpringI18NMessageSource {
    
//	
//    public static ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;
//    
//    @Autowired
//    public SpringI18NMessageSource(ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource ) {
//        this.reloadableResourceBundleMessageSource = reloadableResourceBundleMessageSource;   
//    }
    
    

}
