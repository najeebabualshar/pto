package gov.uspto.tasks.Enum;


public enum ProjectSizeCategory {
	
    SMALL,
    MEDIUM,
    LARGE;

    public String value() {
        return name();
    }

    public static ProjectSizeCategory fromValue(String v) {
        return valueOf(v);
    }


}
