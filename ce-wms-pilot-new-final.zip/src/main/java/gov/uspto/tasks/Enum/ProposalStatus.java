package gov.uspto.tasks.Enum;

public enum ProposalStatus {

	ACTIVE, ARCHIVED, SANDBOX, PROPOSAL, COMPLETED, SUSPENDED, PROJECT_MANAGEMENT, PROJECT_DOCUMENTATION;

	public String value() {
		return name();
	}

	public static ProposalStatus fromValue(String v) {
		return valueOf(v);
	}

}
