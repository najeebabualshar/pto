package gov.uspto.tasks.Enum;

/**
 * <p>Java class for OfficeContactType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="OfficeContactType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="EDITORIAL_BOARD"/&gt;
 *     &lt;enumeration value="COORDINATOR"/&gt;
 *     &lt;enumeration value="JOINT_BOARD"/&gt;
 *     &lt;enumeration value="QN_TECH_EXPERT"/&gt;
 *     &lt;enumeration value="PUBLICATION_BOARD"/&gt;
 *     &lt;enumeration value="JOINT_BOARD_POC"/&gt;
 *     &lt;enumeration value="PUB_MGR"/&gt;
 *     &lt;enumeration value="SCE"/&gt;
 *     &lt;enumeration value="GERANT"/&gt;
 *     &lt;enumeration value="CSD"/&gt;
 *     &lt;enumeration value="CBM"/&gt;
 *     &lt;enumeration value="SPE"/&gt;
 *     &lt;enumeration value="TC"/&gt;
 *     &lt;enumeration value="DIR"/&gt;
 *     &lt;enumeration value="SPC"/&gt;
 *     &lt;enumeration value="RECLASS_MGR"/&gt;
 *     &lt;enumeration value="PUB_WRITER"/&gt;
 *     &lt;enumeration value="PUB_SPCLST"/&gt;
 *     &lt;enumeration value="CPC_CE_ADMIN"/&gt;
 *     &lt;enumeration value="SCE_SPE"/&gt;
 *     &lt;enumeration value="TC_DIR"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
public enum OfficeContactType {


    /**
     * Editorial Board
     * 
     */
    EDITORIAL_BOARD,

    /**
     * coordinator
     * 
     */
    COORDINATOR,

    /**
     * joint board
     * 
     */
    JOINT_BOARD,

    /**
     * QN or Tech expert (SME)
     * 
     */
    QN_TECH_EXPERT,

    /**
     * Publications Board
     * 
     */
    PUBLICATION_BOARD,

    /**
     * Joint Board POC
     * 
     */
    JOINT_BOARD_POC,

    /**
     * PUB_MGR
     * 
     */
    PUB_MGR,

    /**
     * SCE
     * 
     */
    SCE,

    /**
     * GERANT
     * 
     */
    GERANT,

    /**
     * CSD
     * 
     */
    CSD,

    /**
     * CBM
     * 
     */
    CBM,

    /**
     * SPE
     * 
     */
    SPE,

    /**
     * TC
     * 
     */
    TC,

    /**
     * DIR
     * 
     */
    DIR,

    /**
     * SPC
     * 
     */
    SPC,

    /**
     * RECLASS_MGR
     * 
     */
    RECLASS_MGR,

    /**
     * PUB_WRITER
     * 
     */
    PUB_WRITER,

    /**
     * PUB_SPCLST
     * 
     */
    PUB_SPCLST,

    /**
     * CPC_CE_ADMIN
     * 
     */
    CPC_CE_ADMIN,

    /**
     * SCE_SPE
     * 
     */
    SCE_SPE,

    /**
     * TC_DIR
     * 
     */
    TC_DIR;

    public String value() {
        return name();
    }

    public static OfficeContactType fromValue(String v) {
        return valueOf(v);
    }

}
