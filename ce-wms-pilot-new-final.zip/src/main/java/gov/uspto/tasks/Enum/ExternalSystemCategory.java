package gov.uspto.tasks.Enum;


public enum ExternalSystemCategory {


    /**
     * CE is the Alias category for THIS APPLCIATION.  This is the 
     *                     only category for which we can generate our own aliases as opposed to  have them 
     *                     entered or added by users/workflow input
     * 
     */
    CE,
    CEF,
    CPC,
    IP5,
    IPC;


    public static ExternalSystemCategory fromValue(String v) {
    	return valueOf(v);
    }
}
