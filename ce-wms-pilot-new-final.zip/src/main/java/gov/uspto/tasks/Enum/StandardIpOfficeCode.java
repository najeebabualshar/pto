package gov.uspto.tasks.Enum;

public enum StandardIpOfficeCode {

	/**
	 * USPTO
	 * 
	 */
	US,

	/**
	 * EPO
	 * 
	 */
	EP,

	/**
	 * IPC
	 * 
	 */
	IP,

	/**
	 * Argentina (INPI)
	 * 
	 */
	AR,

	/**
	 * Austria (Ost Patentamt)
	 * 
	 */
	AT,

	/**
	 * Brazil (INPI)
	 * 
	 */
	BR,

	/**
	 * China (SIPO)
	 * 
	 */
	CN,

	/**
	 * Czech Republic (UPV)
	 * 
	 */
	CZ,

	/**
	 * Denmark (DKPTO)
	 * 
	 */
	DK,

	/**
	 * Estonia
	 * 
	 */
	EE,

	/**
	 * Eurasia (EAPO)
	 * 
	 */
	EA,

	/**
	 * Finland (PRH)
	 * 
	 */
	FI,

	/**
	 * Greece (OBI)
	 * 
	 */
	GR,

	/**
	 * Hungary (HIPO)
	 * 
	 */
	HU,

	/**
	 * Israel (ILPO)
	 * 
	 */
	IL,

	/**
	 * Korea (KIPO)
	 * 
	 */
	KR,

	/**
	 * Mexico
	 * 
	 */
	MX,

	/**
	 * Netherlands
	 * 
	 */
	NL,

	/**
	 * Norway
	 * 
	 */
	NO,

	/**
	 * Poland
	 * 
	 */
	PL,

	/**
	 * Portugal
	 * 
	 */
	PT,

	/**
	 * Russia
	 * 
	 */
	RU,

	/**
	 * Spain
	 * 
	 */
	ES,

	/**
	 * Sweden
	 * 
	 */
	SE,

	/**
	 * Switzerland
	 * 
	 */
	CH,

	/**
	 * Turkey
	 * 
	 */
	TR,

	/**
	 * United Kingdom
	 * 
	 */
	GB,

	/**
	 * Eritrea
	 * 
	 */
	ER,

	/**
	 * Ethiopia
	 * 
	 */
	ET,

	/**
	 * Fiji
	 * 
	 */
	FJ,

	/**
	 * Falkland Islands (Malvinas)
	 * 
	 */
	FK,

	/**
	 * Faroe Islands
	 * 
	 */
	FO,

	/**
	 * France
	 * 
	 */
	FR,

	/**
	 * Gabon
	 * 
	 */
	GA,

	/**
	 * Patent Office of the Cooperation Council for the Arab States of the Gulf
	 * (GCC)
	 * 
	 */
	GC,

	/**
	 * Grenada
	 * 
	 */
	GD,

	/**
	 * Georgia
	 * 
	 */
	GE,

	/**
	 * Guernsey
	 * 
	 */
	GG,

	/**
	 * Ghana
	 * 
	 */
	GH,

	/**
	 * Gibraltar
	 * 
	 */
	GI,

	/**
	 * Greenland
	 * 
	 */
	GL,

	/**
	 * Gambia
	 * 
	 */
	GM,

	/**
	 * Guinea
	 * 
	 */
	GN,

	/**
	 * Equatorial Guinea
	 * 
	 */
	GQ,

	/**
	 * South Georgia and the South Sandwich Islands
	 * 
	 */
	GS,

	/**
	 * Guatemala
	 * 
	 */
	GT,

	/**
	 * Guinea-Bissau
	 * 
	 */
	GW,

	/**
	 * Guyana
	 * 
	 */
	GY,

	/**
	 * The Hong Kong Special Administrative Region of the People's Republic of China
	 * 
	 */
	HK,

	/**
	 * Honduras
	 * 
	 */
	HN,

	/**
	 * Croatia
	 * 
	 */
	HR,

	/**
	 * Haiti
	 * 
	 */
	HT,

	/**
	 * International Bureau of the World Intellectual Property Organization (WIPO)
	 * 
	 */
	IB,

	/**
	 * Indonesia
	 * 
	 */
	ID,

	/**
	 * Ireland
	 * 
	 */
	IE,

	/**
	 * Isle of Man
	 * 
	 */
	IM,

	/**
	 * India
	 * 
	 */
	IN,

	/**
	 * Iraq
	 * 
	 */
	IQ,

	/**
	 * Iran (Islamic Republic of)
	 * 
	 */
	IR,

	/**
	 * Iceland
	 * 
	 */
	IS,

	/**
	 * Italy
	 * 
	 */
	IT,

	/**
	 * Jersey
	 * 
	 */
	JE,

	/**
	 * Jamaica
	 * 
	 */
	JM,

	/**
	 * Jordan
	 * 
	 */
	JO,

	/**
	 * Japan
	 * 
	 */
	JP,

	/**
	 * Kenya
	 * 
	 */
	KE,

	/**
	 * Kyrgyzstan
	 * 
	 */
	KG,

	/**
	 * Cambodia
	 * 
	 */
	KH,

	/**
	 * Kiribati
	 * 
	 */
	KI,

	/**
	 * Comoros
	 * 
	 */
	KM,

	/**
	 * Saint Kitts and Nevis
	 * 
	 */
	KN,

	/**
	 * Democratic People's Republic of Korea
	 * 
	 */
	KP,

	/**
	 * Kuwait
	 * 
	 */
	KW,

	/**
	 * Cayman Islands
	 * 
	 */
	KY,

	/**
	 * Kazakhstan
	 * 
	 */
	KZ,

	/**
	 * Lao People's Democratic Republic
	 * 
	 */
	LA,

	/**
	 * Lebanon
	 * 
	 */
	LB,

	/**
	 * Saint Lucia
	 * 
	 */
	LC,

	/**
	 * Liechtenstein
	 * 
	 */
	LI,

	/**
	 * Sri Lanka
	 * 
	 */
	LK,

	/**
	 * Liberia
	 * 
	 */
	LR,

	/**
	 * Lesotho
	 * 
	 */
	LS,

	/**
	 * Lithuania
	 * 
	 */
	LT,

	/**
	 * Luxembourg
	 * 
	 */
	LU,

	/**
	 * Czechoslovakia
	 * 
	 */
	CS,

	/**
	 * German Democratic Republic
	 * 
	 */
	DD,

	/**
	 * Union of Soviet Socialist Republics
	 * 
	 */
	SU,

	/**
	 * Yugoslavia
	 * 
	 */
	YU,

	/**
	 * Latvia
	 * 
	 */
	LV,

	/**
	 * Libya
	 * 
	 */
	LY,

	/**
	 * Morocco
	 * 
	 */
	MA,

	/**
	 * Monaco
	 * 
	 */
	MC,

	/**
	 * Republic of Moldova
	 * 
	 */
	MD,

	/**
	 * Montenegro
	 * 
	 */
	ME,

	/**
	 * Madagascar
	 * 
	 */
	MG,

	/**
	 * The former Yugoslav Republic of Macedonia
	 * 
	 */
	MK,

	/**
	 * Mali
	 * 
	 */
	ML,

	/**
	 * Myanmar
	 * 
	 */
	MM,

	/**
	 * Mongolia
	 * 
	 */
	MN,

	/**
	 * Macao
	 * 
	 */
	MO,

	/**
	 * Northern Mariana Islands
	 * 
	 */
	MP,

	/**
	 * Mauritania
	 * 
	 */
	MR,

	/**
	 * Montserrat
	 * 
	 */
	MS,

	/**
	 * Malta
	 * 
	 */
	MT,

	/**
	 * Mauritius
	 * 
	 */
	MU,

	/**
	 * Maldives
	 * 
	 */
	MV,

	/**
	 * Malawi
	 * 
	 */
	MW,

	/**
	 * Malaysia
	 * 
	 */
	MY,

	/**
	 * Mozambique
	 * 
	 */
	MZ,

	/**
	 * Namibia
	 * 
	 */
	NA,

	/**
	 * Niger
	 * 
	 */
	NE,

	/**
	 * Nigeria
	 * 
	 */
	NG,

	/**
	 * Nicaragua
	 * 
	 */
	NI,

	/**
	 * Nepal
	 * 
	 */
	NP,

	/**
	 * Nauru
	 * 
	 */
	NR,

	/**
	 * New Zealand
	 * 
	 */
	NZ,

	/**
	 * African Intellectual Property Organization (OAPI)
	 * 
	 */
	OA,

	/**
	 * Oman
	 * 
	 */
	OM,

	/**
	 * Panama
	 * 
	 */
	PA,

	/**
	 * Peru
	 * 
	 */
	PE,

	/**
	 * Papua New Guinea
	 * 
	 */
	PG,

	/**
	 * Philippines
	 * 
	 */
	PH,

	/**
	 * Pakistan
	 * 
	 */
	PK,

	/**
	 * Palau
	 * 
	 */
	PW,

	/**
	 * Paraguay
	 * 
	 */
	PY,

	/**
	 * Qatar
	 * 
	 */
	QA,

	/**
	 * Community Plant Variety Office (European Union) (CPVO)
	 * 
	 */
	QZ,

	/**
	 * Romania
	 * 
	 */
	RO,

	/**
	 * Serbia
	 * 
	 */
	RS,

	/**
	 * Rwanda
	 * 
	 */
	RW,

	/**
	 * Saudi Arabia
	 * 
	 */
	SA,

	/**
	 * Solomon Islands
	 * 
	 */
	SB,

	/**
	 * Seychelles
	 * 
	 */
	SC,

	/**
	 * Sudan
	 * 
	 */
	SD,

	/**
	 * Singapore
	 * 
	 */
	SG,

	/**
	 * Saint Helena, Ascension and Tristan da Cunha
	 * 
	 */
	SH,

	/**
	 * Slovenia
	 * 
	 */
	SI,

	/**
	 * Slovakia
	 * 
	 */
	SK,

	/**
	 * Sierra Leone
	 * 
	 */
	SL,

	/**
	 * San Marino
	 * 
	 */
	SM,

	/**
	 * Senegal
	 * 
	 */
	SN,

	/**
	 * Somalia
	 * 
	 */
	SO,

	/**
	 * Suriname
	 * 
	 */
	SR,

	/**
	 * South Sudan
	 * 
	 */
	SS,

	/**
	 * Sao Tome and Principe
	 * 
	 */
	ST,

	/**
	 * El Salvador
	 * 
	 */
	SV,

	/**
	 * Sint Maarten (Dutch part)
	 * 
	 */
	SX,

	/**
	 * Syrian Arab Republic
	 * 
	 */
	SY,

	/**
	 * Swaziland
	 * 
	 */
	SZ,

	/**
	 * Turks and Caicos Islands
	 * 
	 */
	TC,

	/**
	 * Chad
	 * 
	 */
	TD,

	/**
	 * Togo
	 * 
	 */
	TG,

	/**
	 * Thailand
	 * 
	 */
	TH,

	/**
	 * Tajikistan
	 * 
	 */
	TJ,

	/**
	 * Timor-Leste
	 * 
	 */
	TL,

	/**
	 * Turkmenistan
	 * 
	 */
	TM,

	/**
	 * Tunisia
	 * 
	 */
	TN,

	/**
	 * Tonga
	 * 
	 */
	TO,

	/**
	 * Trinidad and Tobago
	 * 
	 */
	TT,

	/**
	 * Tuvalu
	 * 
	 */
	TV,

	/**
	 * Taiwan, Province of China
	 * 
	 */
	TW,

	/**
	 * United Republic of Tanzania
	 * 
	 */
	TZ,

	/**
	 * Ukraine
	 * 
	 */
	UA,

	/**
	 * Uganda
	 * 
	 */
	UG,

	/**
	 * Uruguay
	 * 
	 */
	UY,

	/**
	 * Uzbekistan
	 * 
	 */
	UZ,

	/**
	 * Holy See
	 * 
	 */
	VA,

	/**
	 * Saint Vincent and the Grenadines
	 * 
	 */
	VC,

	/**
	 * Venezuela, Bolivarian Republic of
	 * 
	 */
	VE,

	/**
	 * Virgin Islands (British)
	 * 
	 */
	VG,

	/**
	 * Viet Nam
	 * 
	 */
	VN,

	/**
	 * Vanuatu
	 * 
	 */
	VU,

	/**
	 * World Intellectual Property Organization (WIPO) (International Bureau of)
	 * 
	 */
	WO,

	/**
	 * Samoa
	 * 
	 */
	WS,

	/**
	 * Nordic Patent Institute (NPI)
	 * 
	 */
	XN,

	/**
	 * International Union for the Protection of New Varieties of Plants (UPOV)
	 * 
	 */
	XU,

	/**
	 * Visegrad Patent Institute (VPI)
	 * 
	 */
	XV,

	/**
	 * Yemen
	 * 
	 */
	YE,

	/**
	 * South Africa
	 * 
	 */
	ZA,

	/**
	 * Zambia
	 * 
	 */
	ZM,

	/**
	 * Zimbabwe
	 * 
	 */
	ZW,

	/**
	 * Andorra
	 * 
	 */
	AD,

	/**
	 * United Arab Emirates
	 * 
	 */
	AE,

	/**
	 * Afghanistan
	 * 
	 */
	AF,

	/**
	 * Antigua and Barbuda
	 * 
	 */
	AG,

	/**
	 * Anguilla
	 * 
	 */
	AI,

	/**
	 * Albania
	 * 
	 */
	AL,

	/**
	 * Armenia
	 * 
	 */
	AM,

	/**
	 * Angola
	 * 
	 */
	AO,

	/**
	 * African Regional Intellectual Property Organization (ARIPO)
	 * 
	 */
	AP,

	/**
	 * Australia
	 * 
	 */
	AU,

	/**
	 * Aruba
	 * 
	 */
	AW,

	/**
	 * Azerbaijan
	 * 
	 */
	AZ,

	/**
	 * Bosnia and Herzegovina
	 * 
	 */
	BA,

	/**
	 * Barbados
	 * 
	 */
	BB,

	/**
	 * Bangladesh
	 * 
	 */
	BD,

	/**
	 * Belgium
	 * 
	 */
	BE,

	/**
	 * Burkina Faso
	 * 
	 */
	BF,

	/**
	 * Bulgaria
	 * 
	 */
	BG,

	/**
	 * Bahrain
	 * 
	 */
	BH,

	/**
	 * Burundi
	 * 
	 */
	BI,

	/**
	 * Benin
	 * 
	 */
	BJ,

	/**
	 * Bermuda
	 * 
	 */
	BM,

	/**
	 * Brunei Darussalam
	 * 
	 */
	BN,

	/**
	 * Bolivia, Plurinational State of
	 * 
	 */
	BO,

	/**
	 * Bonaire, Sint Eustatius and Saba
	 * 
	 */
	BQ,

	/**
	 * Bahamas
	 * 
	 */
	BS,

	/**
	 * Bhutan
	 * 
	 */
	BT,

	/**
	 * Bouvet Island
	 * 
	 */
	BV,

	/**
	 * Botswana
	 * 
	 */
	BW,

	/**
	 * Benelux Office for Intellectual Property (BOIP)
	 * 
	 */
	BX,

	/**
	 * Belarus
	 * 
	 */
	BY,

	/**
	 * Belize
	 * 
	 */
	BZ,

	/**
	 * Canada
	 * 
	 */
	CA,

	/**
	 * Democratic Republic of the Congo
	 * 
	 */
	CD,

	/**
	 * Central African Republic
	 * 
	 */
	CF,

	/**
	 * Congo
	 * 
	 */
	CG,

	/**
	 * Cote d'Ivoire
	 * 
	 */
	CI,

	/**
	 * Cook Islands
	 * 
	 */
	CK,

	/**
	 * Chile
	 * 
	 */
	CL,

	/**
	 * Cameroon
	 * 
	 */
	CM,

	/**
	 * Colombia
	 * 
	 */
	CO,

	/**
	 * Costa Rica
	 * 
	 */
	CR,

	/**
	 * Cuba
	 * 
	 */
	CU,

	/**
	 * Cabo Verde
	 * 
	 */
	CV,

	/**
	 * Curacao
	 * 
	 */
	CW,

	/**
	 * Cyprus
	 * 
	 */
	CY,

	/**
	 * Germany
	 * 
	 */
	DE,

	/**
	 * Djibouti
	 * 
	 */
	DJ,

	/**
	 * Dominica
	 * 
	 */
	DM,

	/**
	 * Dominican Republic
	 * 
	 */
	DO,

	/**
	 * Algeria
	 * 
	 */
	DZ,

	/**
	 * Ecuador
	 * 
	 */
	EC,

	/**
	 * Egypt
	 * 
	 */
	EG,

	/**
	 * Western Sahara
	 * 
	 */
	EH,

	/**
	 * European Union Intellectual Property Office (EUIPO)
	 * 
	 */
	EM;

	public String value() {
		return name();
	}

	public static StandardIpOfficeCode fromValue(String v) {
		return valueOf(v);
	}

}
