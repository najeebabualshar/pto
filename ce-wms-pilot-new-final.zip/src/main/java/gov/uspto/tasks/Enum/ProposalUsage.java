package gov.uspto.tasks.Enum;

public enum ProposalUsage {

	REGULAR, TRAINING, CEF_MIGRATION;

	public String value() {
		return name();
	}

	public static ProposalUsage fromValue(String v) {
		return valueOf(v);
	}
}
