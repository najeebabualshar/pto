package gov.uspto.tasks.pojo;

import java.util.Date;
import java.util.List;

//import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.Input;
//import gov.uspto.pe2e.cpc.ipc.rest.contract.common.PayPeriod;
//import gov.uspto.pe2e.cpc.ipc.rest.contract.outofoffice.v1_0.OutOfOfficeEvent;
//import gov.uspto.pe2e.cpc.ipc.rest.contract.smeconsult.v1_0.Consultation;
//import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskProposalReference;
import gov.uspto.tasks.Enum.OfficeContactType;
import gov.uspto.tasks.Enum.ProposalPhase;
import gov.uspto.tasks.Enum.ProposalSubphase;
import gov.uspto.tasks.Enum.StandardIpOfficeCode;
import gov.uspto.tasks.Enum.TaskAction;
import lombok.Data;

@Data
public class TaskStateDetails {

	
	protected String taskName;
//    protected TaskProposalReference proposalData;
    protected String processInstanceId;
    protected ProposalPhase phase;
    protected ProposalSubphase subphase;
    protected StandardIpOfficeCode taskedOffice;
    protected String taskedRole;
    protected String projectType;
    protected Date startTs;
    protected Date completeTs;
    protected Date dueTs;
    protected StandardIpOfficeCode ipOffice;
    protected OfficeContactType officeContactType;
    protected String assignee;
    protected List<AssignmentGroup> assigneeCandidateGroups;
//    protected List<Consultation> consultations;
//    protected List<OutOfOfficeEvent> outOfOfficeEvents;
    protected String papCode;
//    protected PayPeriod payPeriod;
    protected Integer actualWorkedDays;
    protected Integer exemptWorkDays;
    protected TaskAction action;
    protected List<UserGroupDetails> taskAssignedGroups;
    
    
    protected String taskId;
    protected String taskDefinitionKey;
    protected Integer estimatedDays;
    protected Integer actualElapsedDays;
//    protected List<Input> previousStateInputs;
//    protected List<Input> inputs;
    protected String nextState;
}
