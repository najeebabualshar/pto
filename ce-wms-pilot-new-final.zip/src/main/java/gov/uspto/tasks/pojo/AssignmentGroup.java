package gov.uspto.tasks.pojo;

import java.util.List;

import gov.uspto.tasks.Enum.OfficeContactType;
import gov.uspto.tasks.Enum.StandardIpOfficeCode;
import lombok.Data;

@Data
public class AssignmentGroup {

    protected List<StandardIpOfficeCode> offices;
  
    protected OfficeContactType role;



}
