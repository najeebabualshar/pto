package gov.uspto.tasks.pojo;

import java.util.Date;

import gov.uspto.tasks.Enum.StandardIpOfficeCode;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table
 * change_proposal_state_task primary key column is state_task_id
 * 
 * @author 2020
 * @version 1.14.0
 * @date: October 20, 2018
 *
 */
@Data
public class ChangeProposalStateTask {

	private Long stateTaskId;

//	    /** user with this associated settings */
//	    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalState.class)
//	    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "fk_change_proposal_id")
//	    private ChangeProposalState changeProposalState;
	private String taskId;

	private String taskNameTx;

	private Date taskStartTs;

	private Date taskDueTs;

//	    @Column(name = "cfk_task_assignee_id")
	private String cfkTaskAssigneeId; // VARCHAR2(320) - this is the first user field of

//	    @Column(name = "cfk_task_assignee_role_tx")
	private String cfkTaskAssigneeRoleTx; // VARCHAR2(100) this is a comma separated list of roles associated with this
											// task

//	    @Column(name = "cfk_task_assignee_office_cd")
//	    @Enumerated(EnumType.STRING)
	private StandardIpOfficeCode cfkTaskAssigneeOfficeCd; // VARCHAR2(50)

//	    @CreatedBy
//	    @NotNull
//	    @Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

//	    @CreatedDate
//	    @NotNull
//	    @Column(name = "create_ts")
//	    @Temporal(TemporalType.TIMESTAMP)
//	    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

//	    @LastModifiedBy
//	    @NotNull
//	    @Column(name = "last_mod_user_id")
	private String lastModUserId; // VARCHAR2(100)

//	    @LastModifiedDate
//	    @NotNull
//	    @Column(name = "last_mod_ts")
//	    @Temporal(TemporalType.TIMESTAMP)
//	    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModTs;

//	    @SuppressWarnings("CPD-END")
//	    @NotNull
//	    @Version
//	    @Column(name = "lock_control_no")
	private Integer lockControlNo;

//	    @OrderBy("fk_assignee_ipo_cd, fk_assignee_role_cd")
//	    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "task", targetEntity = ChangeProposalAssigneeGroup.class)
//	    private Set<ChangeProposalAssigneeGroup> assignmentGroups;

}
