package gov.uspto.myBatis.models;

import java.util.Date;

import lombok.Data;

@Data
public class ChangeProposalAliasInsert {

	/**
	 * Allowing serialization of datamodel elements
	 */
//	private static final long serialVersionUID = 1L;

//    @Id
//    @NotNull
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_alias_id_seq")
//    @SequenceGenerator(name = "change_proposal_alias_id_seq", 
//                  sequenceName = "change_proposal_alias_id_seq", initialValue = 1, allocationSize = 1)
//    @Column(name = "change_proposal_alias_id")
	private Long change_proposal_alias_id;

//    @NotNull
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
//    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
	private Long fk_change_proposal_id;

//    @NotNull
//    @Column(name = "change_proposal_alias_cd", length=20)
	private String change_proposal_alias_cd;

//    @Enumerated(EnumType.STRING)
//    @NotNull
//    @Column(name = "source_system_ct", length=20)
	private String source_system_ct;

//    @SuppressWarnings("CPD-START")
//    @CreatedBy
//    @NotNull
//    @Column(name = "create_user_id")
	private String create_user_id; // VARCHAR2(100) REALL? We had this fixed

//    @CreatedDate
//    @NotNull
//    @Column(name = "create_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date create_ts;

//    @LastModifiedBy
//    @NotNull
//    @Column(name = "last_mod_user_id")
	private String last_mod_user_id; // VARCHAR2(100)

//    @LastModifiedDate
//    @NotNull
//    @Column(name = "last_mod_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date last_mod_ts;

//    @NotNull
//    @Version
//    @Column(name = "lock_control_no")
	private Integer lock_control_no;
//    @SuppressWarnings("CPD-END") 
}