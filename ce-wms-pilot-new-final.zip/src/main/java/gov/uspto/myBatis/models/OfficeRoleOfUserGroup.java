package gov.uspto.myBatis.models;

import lombok.Data;

@Data
public class OfficeRoleOfUserGroup {
}
