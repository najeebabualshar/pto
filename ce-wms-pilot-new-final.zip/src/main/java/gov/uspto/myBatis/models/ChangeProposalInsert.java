package gov.uspto.myBatis.models;

import java.util.Date;
import java.util.Set;

import gov.uspto.tasks.Enum.ProjectSizeCategory;
import gov.uspto.tasks.Enum.ProposalStatus;
import gov.uspto.tasks.Enum.ProposalTypeCode;
import gov.uspto.tasks.Enum.ProposalUsage;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table change_proposal primary
 * key is change_proposal_id
 * 
 * @author 2020
 * @version 1.3
 * @date: 03/15/2016
 *
 */

@Data
public class ChangeProposalInsert {// implements Comparable<ChangeProposal>, Serializable {
//
//	/**
//	 * Allowing serialization of datamodel elements
//	 */
//	private static final long serialVersionUID = 1L;
//
//	@Id
//	@NotNull
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_id_seq")
//	@SequenceGenerator(name = "change_proposal_id_seq", sequenceName = "change_proposal_id_seq", initialValue = 1, allocationSize = 1)
//	@Column(name = "change_proposal_id")
	private Long change_proposal_id;

//	@Guid
//	@Column(name = "guid_id")
	private String guid_id;

	/**
	 * WARNING: This is junk data forced on the model be EDAD. There must be a
	 * unique value in this field to satisfy the contraints but it cannot be
	 * replied upon. This field should not be part of any hashcode(), equals()
	 * or compareTo() method
	 */
//	@Deprecated
//	@NotNull
//	@Column(name = "change_proposal_cd")
	private String change_proposal_cd; // VARCHAR2(10)

//	@Column(name = "business_case_tx")
	private String business_case_tx; // VARCHAR2(4000)

//	@NotNull
//	@Enumerated(EnumType.STRING)
//	@Column(name = "est_project_size_ct")
	private String est_project_size_ct;

//	@Enumerated(EnumType.STRING)
//	@Column(name = "fk_proposal_type_cd")
	private String fk_proposal_type_cd;
	
//	@NotNull
//	@Type(type = "yes_no")
//	@Column(name = "archive_in", columnDefinition = "char(1)")
	private Boolean archive_in; // Number
	
//	@NotNull
//	@Enumerated(EnumType.STRING)
//	@Column(name = "proposal_status_ct")
	private String proposal_status_ct;
	
//	@NotNull
//	@Enumerated(EnumType.STRING)
//	@Column(name = "proposal_usage_ct")
	private String proposal_usage_ct;

//	@SuppressWarnings("CPD-START")
//	@CreatedBy
//	@NotNull
//	@Column(name = "create_user_id")
	private String create_user_id; // VARCHAR2(100)

//	@CreatedDate
//	@NotNull
//	@Column(name = "create_ts")
//	@Temporal(TemporalType.TIMESTAMP)
//	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date create_ts;

//	@LastModifiedBy
//	@NotNull
//	@Column(name = "last_mod_user_id")
	private String last_mod_user_id; // VARCHAR2(100)

//	@LastModifiedDate
//	@NotNull
//	@Column(name = "last_mod_ts")
//	@Temporal(TemporalType.TIMESTAMP)
//	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date last_mod_ts;

//	@NotNull
//	@Version
//	@Column(name = "lock_control_no")
	private Integer lock_control_no;

//	@SuppressWarnings("CPD-END")
//
//	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalState.class)
//	private ChangeProposalState state;
//
//	@OrderBy("version_id")
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalVersion.class)
//	private Set<ChangeProposalVersion> revisions;
//
//	@OrderBy("change_proposal_office_id")
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalOffice.class)
//	private Set<ChangeProposalOffice> changeProposalOffices;
//
//	@OrderBy("change_proposer_role_id")
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposerRole.class)
//	private Set<ChangeProposerRole> changeProposerRoles;

//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalTechField.class)
//	private Set<ChangeProposalTechField> changeProposalTechnologies;
	
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalDetail.class)
//	private Set<ChangeProposalDetail> changeProposalDetail;

	// Subclass and scope have different order by (symbol name vs id
	// respectively) because the data
	// stored in each is different and sorting mechanism for each is not
	// comparable
	// subclass ONLY ever stores the 4 letter symbol name of the main group.
	// This means
	// it doesn't matter how it stored it can be sorted aphabetically and
	// produce a business friendly
	// order. scope symbols on the otherhand contain a mix of symbols at various
	// levels meaning they
	// cannot be sorted aphabetically by name. We sort by Id and and rely on the
	// saving logic to sort
	// prior to save(). This is all necessary do the shear size difference as
	// well
//	@OrderBy("subclass_cd")
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalSubclass.class)
//	private Set<ChangeProposalSubclass> changeProposalSubclasses;
//
//	@OrderBy("change_proposal_scope_id")
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalSymbolScope.class)
//	private Set<ChangeProposalSymbolScope> changeProposalScopeSymbols;
//
//	@OrderBy(value = "last_mod_ts DESC")
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalAlias.class)
//	private Set<ChangeProposalAlias> aliases;
//	
//	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ProjectDetailView.class)
//	private ProjectDetailView projectDetailView;

//	/**
//	 * @return Long id
//	 */
//	public Long getId() {
//		return id;
//	}
//
//	/**
//	 * @param id
//	 */
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	/**
//	 * @return the externalId
//	 */
//	public String getExternalId() {
//		return externalId;
//	}
//
//	/**
//	 * @param externalId
//	 *            the externalId to set
//	 */
//	public void setExternalId(String externalId) {
//		this.externalId = externalId;
//	}
//	/**
//	 * @return String businessCase
//	 */
//	public String getBusinessCase() {
//		return businessCase;
//	}
//
//	/**
//	 * @param businessCase
//	 */
//	public void setBusinessCase(String businessCase) {
//		this.businessCase = businessCase;
//	}
//
//	/**
//	 * @return projectSizeCategory
//	 */
//	public ProjectSizeCategory getProjectSizeCategory() {
//		return projectSizeCategory;
//	}
//
//	/**
//	 * @param projectSizeCategory
//	 */
//	public void setProjectSizeCategory(ProjectSizeCategory projectSizeCategory) {
//		this.projectSizeCategory = projectSizeCategory;
//	}
//
//	/**
//	 * @return the proposalType
//	 */
//	public ProposalTypeCode getProposalType() {
//		return proposalType;
//	}
//
//	/**
//	 * @param proposalType
//	 *            the proposalType to set
//	 */
//	public void setProposalType(ProposalTypeCode proposalType) {
//		this.proposalType = proposalType;
//	}
//
//	/**
//	 * @return String createUserId
//	 */
//	public String getCreateUserId() {
//		return createUserId;
//	}
//
//	/**
//	 * @param createUserId
//	 */
//	public void setCreateUserId(String createUserId) {
//		this.createUserId = createUserId;
//	}
//
//	/**
//	 * @return Date createTs
//	 */
//	public Date getCreateTs() {
//		return createTs;
//	}
//
//	/**
//	 * @param createTs
//	 */
//	public void setCreateTs(Date createTs) {
//		this.createTs = createTs;
//	}
//
//	/**
//	 * @return String lastModifiedUserId
//	 */
//	public String getLastModifiedUserId() {
//		return lastModifiedUserId;
//	}
//
//	/**
//	 * @param lastModifiedUserId
//	 */
//	public void setLastModifiedUserId(String lastModifiedUserId) {
//		this.lastModifiedUserId = lastModifiedUserId;
//	}
//
//	/**
//	 * @return Date lastModifiedTs
//	 */
//	public Date getLastModifiedTs() {
//		return lastModifiedTs;
//	}
//
//	/**
//	 * @param lastModifiedTs
//	 */
//	public void setLastModifiedTs(Date lastModifiedTs) {
//		this.lastModifiedTs = lastModifiedTs;
//	}
//
//	/**
//	 * @return Integer lockControl
//	 */
//	public Integer getLockControl() {
//		return lockControl;
//	}
//
//	/**
//	 * @param lockControl
//	 */
//	public void setLockControl(Integer lockControl) {
//		this.lockControl = lockControl;
//	}
//
//	/**
//	 * Get the revisions list
//	 * 
//	 * @return
//	 * @since Mar 28, 2016
//	 */
//	public Set<ChangeProposalVersion> getRevisions() {
//		if (this.revisions == null) {
//			this.revisions = new TreeSet<>();
//		}
//		return revisions;
//	}
//
//	/**
//	 * Adds ChangeProposalVersion to the list
//	 * 
//	 * @param child
//	 */
//	public void add(ChangeProposalVersion child) {
//		getRevisions().add(child);
//	}
//
//	/**
//	 * Sets the revisions list
//	 * 
//	 * @param revisions
//	 * @since Mar 28, 2016
//	 */
//	public void setRevisions(Set<ChangeProposalVersion> revisions) {
//		this.revisions = revisions;
//	}
//
//	/**
//	 * @return the changeProposalOffices
//	 * @since April 07, 2018
//	 */
//	public Set<ChangeProposalOffice> getChangeProposalOffices() {
//		if (this.changeProposalOffices == null) {
//			this.changeProposalOffices = new TreeSet<>();
//		}
//		return changeProposalOffices;
//	}
//
//	/**
//	 * Adds Change Proposal Office
//	 * 
//	 * @param child
//	 */
//	public void add(ChangeProposalOffice child) {
//		getChangeProposalOffices().add(child);
//	}
//
//	/**
//	 * @param changeProposalOffice
//	 *            the changeProposalOffice to set
//	 * @since April 07, 2018
//	 */
//	public void setChangeProposalOffices(Set<ChangeProposalOffice> changeProposalOfficeSet) {
//		this.changeProposalOffices = changeProposalOfficeSet;
//	}
//
//	/**
//	 * @return the changeProposerRoles
//	 * @since April 07, 2018
//	 */
//	public Set<ChangeProposerRole> getChangeProposerRoles() {
//		if (this.changeProposerRoles == null) {
//			this.changeProposerRoles = new TreeSet<>();
//		}
//		return changeProposerRoles;
//	}
//
//	/**
//	 * Adds Change Proposer Role
//	 * 
//	 * @param child
//	 */
//	public void add(ChangeProposerRole child) {
//		getChangeProposerRoles().add(child);
//	}
//
//	/**
//	 * @param changeProposerRole
//	 *            the changeProposerRoles to set
//	 * @since April 07, 2018
//	 */
//	public void setChangeProposerRoles(Set<ChangeProposerRole> changeProposerRoleSet) {
//		this.changeProposerRoles = changeProposerRoleSet;
//	}
//	/**
//	 * Adds Change Proposal Technology
//	 * 
//	 * @param child
//	 * @since Aug 13, 2018
//	 */
//	/* US334351 - ChangeProposalTechField table is removed as part fo this story
//	 * public void add(ChangeProposalTechField child) {
//	 * getChangeProposalTechnologies().add(child); }
//	 */
//
//	public ChangeProposalState getState() {
//		return state;
//	}
//
//	public void setState(ChangeProposalState state) {
//		this.state = state;
//	}
//
//	/**
//	 * @return the aliases
//	 */
//	public Set<ChangeProposalAlias> getAliases() {
//		if (this.aliases == null) {
//			this.aliases = new TreeSet<>(new ReverseComparator(new BeanComparator(
//					StandardField.LAST_MODIFIED_TS.getFieldName(), new NullableFieldChooseLeftIfEqualsComparator())));
//			// new
//			// BeanComparator(StandardField.LAST_MODIFIED_TS.getFieldName())));
//		}
//		return aliases;
//	}
//
//	/**
//	 * @return the changeProposalSubclasses
//	 */
//	public Set<ChangeProposalSubclass> getChangeProposalSubclasses() {
//		if (this.changeProposalSubclasses == null) {
//			this.changeProposalSubclasses = new TreeSet<>();
//		}
//		return changeProposalSubclasses;
//	}
//
//	/**
//	 * @param changeProposalSubclasses
//	 *            the changeProposalSubclasses to set
//	 */
//	public void setChangeProposalSubclasses(Set<ChangeProposalSubclass> changeProposalSubclasses) {
//		this.changeProposalSubclasses = changeProposalSubclasses;
//	}
//
//	/**
//	 * @param changeProposalScopeSymbols
//	 *            the changeProposalScopeSymbols to set
//	 */
//	public void setChangeProposalScopeSymbols(Set<ChangeProposalSymbolScope> changeProposalScopeSymbols) {
//		this.changeProposalScopeSymbols = changeProposalScopeSymbols;
//	}
//
//	/**
//	 * @return the changeProposalScopeSymbols
//	 */
//	public Set<ChangeProposalSymbolScope> getChangeProposalScopeSymbols() {
//		if (this.changeProposalScopeSymbols == null) {
//			this.changeProposalScopeSymbols = new TreeSet<>(
//					new ModelSymbolNameComparator<>("classificationSymbolCode"));
//		}
//		return changeProposalScopeSymbols;
//	}
//
//	public ProjectDetailView getProjectDetailView() {
//		return projectDetailView;
//	}
//
//	public void setProjectDetailView(ProjectDetailView projectDetailView) {
//		this.projectDetailView = projectDetailView;
//	}
//
//	@Override
//	public String toString() {
//		return "ChangeProposal [id=" + id + ", externalId=" + externalId + ", changeProposalCode=" + changeProposalCode
//				+ ", businessCase=" + businessCase + ", projectSizeCategory=" + projectSizeCategory + ", proposalType="
//				+ proposalType + ", archived=" + archived + ", proposalStatus=" + proposalStatus + ", createUserId="
//				+ createUserId + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId
//				+ ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + ", state=" + state
//				+ ", revisions=" + revisions + ", changeProposalOffices=" + changeProposalOffices
//				+ ", changeProposerRoles=" + changeProposerRoles + ", changeProposalDetail=" + changeProposalDetail
//				+ ", changeProposalSubclasses=" + changeProposalSubclasses + ", changeProposalScopeSymbols="
//				+ changeProposalScopeSymbols + ", aliases=" + aliases + ", projectDetailView=" + projectDetailView
//				+ "]";
//	}
//
//	/**
//	 * @see java.lang.Comparable#compareTo(java.lang.Object)
//	 */
//	@Override
//	public int compareTo(ChangeProposal other) {
//		return new CompareToBuilder().append(this.getId(), other.getId())
//				.append(this.getExternalId(), other.getExternalId()).toComparison();
//	}
//
//	/**
//	 * Indicates whether some other object is "equal to" this one
//	 */
//	@Override
//	public boolean equals(Object obj) {
//		boolean ret;
//		if (obj == null || !ChangeProposal.class.isAssignableFrom(obj.getClass())) {
//			ret = false;
//		} else if (ChangeProposal.class.isAssignableFrom(obj.getClass()) && obj == this) {
//			ret = true;
//		} else {
//			ChangeProposal thatObj = (ChangeProposal) obj;
//			ret = StringUtils.equals(this.getExternalId(), thatObj.getExternalId());
//		}
//		return ret;
//	}
//
//	/**
//	 * used for hash based collections.
//	 */
//	@Override
//	public int hashCode() {
//
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((id == null) ? 0 : id.hashCode());
//		result = prime * result + ((externalId == null) ? 0 : externalId.hashCode());
//		return result;
//
//	}
//
//	/**
//	 * @return the changeProposalCode
//	 */
//	@Deprecated
//	public String getChangeProposalCode() {
//		return changeProposalCode;
//	}
//
//	/**
//	 * @param changeProposalCode
//	 *            the changeProposalCode to set
//	 */
//	public void setChangeProposalCode(String changeProposalCode) {
//		this.changeProposalCode = changeProposalCode;
//	}
//
//	public Boolean getArchived() {
//		return archived;
//	}
//
//	public void setArchived(Boolean archived) {
//		this.archived = archived;
//	}
//	public ProposalStatus getProposalStatus() {
//		return proposalStatus;
//	}
//
//	public void setProposalStatus(ProposalStatus proposalStatus) {
//		this.proposalStatus = proposalStatus;
//	}
//
//	public Set<ChangeProposalDetail> getChangeProposalDetail() {
//		if(changeProposalDetail==null) {
//			this.changeProposalDetail = new TreeSet<>();
//		}
//		return changeProposalDetail;
//	}
//
//	public void setChangeProposalDetail(Set<ChangeProposalDetail> changeProposalDetail) {
//		this.changeProposalDetail = changeProposalDetail;
//	}
//
//	public ProposalUsage getProposalUsage() {
//		return proposalUsage;
//	}
//
//	public void setProposalUsage(ProposalUsage proposalUsage) {
//		this.proposalUsage = proposalUsage;
//	}
	
}
