package gov.uspto.myBatis.models;

import java.util.Date;
import java.util.Set;

import gov.uspto.tasks.Enum.ProposalPhase;
import gov.uspto.tasks.Enum.ProposalStateType;
import gov.uspto.tasks.Enum.ProposalSubphase;
import lombok.Data;

@Data
public class ChangeProposalStateInsert {

//
//	/**
//	 * Allowing serialization of datamodel elements
//	 */
//	private static final long serialVersionUID = 1L;
//
//	@Id
//	@NotNull
//	@Column(name = "fk_change_proposal_id", unique = true, nullable = false)
	private Long fk_change_proposal_id;

//	@NotNull
//	@Column(name = "process_start_ts")
//	@Temporal(TemporalType.TIMESTAMP)
//	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date process_start_ts;

//	@Enumerated(EnumType.STRING)
//	@Column(name = "proposal_phase_tx")
	private String proposal_phase_tx;

//	@Enumerated(EnumType.STRING)
//	@Column(name = "proposal_subphase_tx")
	private String proposal_subphase_tx;

//	@NotNull
//	@Column(name = "definition_id")
	private String definition_id;

//	@NotNull
//	@Column(name = "process_instance_id")
	private String process_instance_id;

//	@Enumerated(EnumType.STRING)
//	@Column(name = "proposal_state_ct")
	private String proposal_state_ct;

//	@Column(name = "process_end_ts")
//	@Temporal(TemporalType.TIMESTAMP)
//	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date process_end_ts;

//	@CreatedBy
//	@NotNull
//	@Column(name = "create_user_id")
	private String create_user_id; // VARCHAR2(100)

//	@CreatedDate
//	@NotNull
//	@Column(name = "create_ts")
//	@Temporal(TemporalType.TIMESTAMP)
//	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date create_ts;

//	@LastModifiedBy
//	@NotNull
//	@Column(name = "last_mod_user_id")
	private String last_mod_user_id; // VARCHAR2(100)

//	@LastModifiedDate
//	@NotNull
//	@Column(name = "last_mod_ts")
//	@Temporal(TemporalType.TIMESTAMP)
//	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date last_mod_ts;

//	@SuppressWarnings("CPD-END")
//	@NotNull
//	@Version
//	@Column(name = "lock_control_no")
	private Integer lock_control_no;
}