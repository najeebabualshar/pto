package gov.uspto.myBatis.models;

import java.util.Date;

import gov.uspto.tasks.Enum.ExternalSystemCategory;
import lombok.Data;

@Data
public class ChangeProposalAlias {

	/**
	 * Allowing serialization of datamodel elements
	 */
//	private static final long serialVersionUID = 1L;

//    @Id
//    @NotNull
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_alias_id_seq")
//    @SequenceGenerator(name = "change_proposal_alias_id_seq", 
//                  sequenceName = "change_proposal_alias_id_seq", initialValue = 1, allocationSize = 1)
//    @Column(name = "change_proposal_alias_id")
	private Long change_proposal_alias_id;

//    @NotNull
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
//    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
	private ChangeProposal fk_change_proposal_id;

//    @NotNull
//    @Column(name = "change_proposal_alias_cd", length=20)
	private String change_proposal_alias_cd;

//    @Enumerated(EnumType.STRING)
//    @NotNull
//    @Column(name = "source_system_ct", length=20)
    private String source_system_ct;

//    @SuppressWarnings("CPD-START")
//    @CreatedBy
//    @NotNull
//    @Column(name = "create_user_id")
	private String create_user_id; // VARCHAR2(100) REALL? We had this fixed

//    @CreatedDate
//    @NotNull
//    @Column(name = "create_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date create_ts;

//    @LastModifiedBy
//    @NotNull
//    @Column(name = "last_mod_user_id")
	private String last_mod_user_id; // VARCHAR2(100)

//    @LastModifiedDate
//    @NotNull
//    @Column(name = "last_mod_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date last_mod_ts;

//    @NotNull
//    @Version
//    @Column(name = "lock_control_no")
	private Integer lock_control_no;
//    @SuppressWarnings("CPD-END") 

//	/**
//     * Indicates whether some other object is "equal to" this one
//     */
//	@Override
//    public boolean equals(Object obj) {
//        boolean ret = true;
//        if (obj == null) {
//            ret = false;
//        } else if (!ChangeProposalAlias.class.isAssignableFrom(obj.getClass())) {
//            ret = false;
//        } else if (obj == this) {
//            ret = true;
//        } else {
//            ChangeProposalAlias thatObj = (ChangeProposalAlias) obj;  
//            ret = new EqualsBuilder().append(this.getSystemCategory(), thatObj.getSystemCategory())
//            		.append(this.getName(), thatObj.getName()).build();
//        }
//        return ret;
//    }
//    
//    /**
//   	 * @see java.lang.Object#hashCode()
//   	 */
//   	@Override
//   	public int hashCode() {
//   		final int prime = 37;
//   		int result = 1;
//   		result = prime * result + ((changeProposal == null) ? 0 : changeProposal.hashCode());
//   		result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
//   		result = prime * result + ((createUserId == null) ? 0 : createUserId.hashCode());
//   		result = prime * result + ((id == null) ? 0 : id.hashCode());
//   		result = prime * result + ((lastModifiedTs == null) ? 0 : lastModifiedTs.hashCode());
//   		result = prime * result + ((lastModifiedUserId == null) ? 0 : lastModifiedUserId.hashCode());
//   		result = prime * result + ((lockControl == null) ? 0 : lockControl.hashCode());
//   		result = prime * result + ((name == null) ? 0 : name.hashCode());
//   		result = prime * result + ((systemCategory == null) ? 0 : systemCategory.hashCode());
//   		return result;
//   	}
//
//    
//    /**
//     * order by last mod then id
//     * @see java.lang.Comparable#compareTo(java.lang.Object)
//     */
//    @Override
//    public int compareTo(ChangeProposalAlias other) {
//        return new CompareToBuilder()
//                .append(this.getLastModifiedTs(), other.getLastModifiedTs())
//                .append(this.getCreateTs(), other.getCreateTs())
//                .append(this.getId(), other.getId())
//                .append(this.getName(), other.getName()).toComparison();
//    }
//    
//    
//
//	/**
//	 * @see java.lang.Object#toString()
//	 */
//	@Override
//	public String toString() {
//		return "ChangeProposalAlias [id=" + id + ", changeProposal=" 
//				+ (changeProposal!=null?changeProposal.getId():"null") + ", name=" + name
//				+ ", systemCategory=" + systemCategory + ", createUserId=" + createUserId + ", createTs=" + createTs
//				+ ", lastModifiedUserId=" + lastModifiedUserId + ", lastModifiedTs=" + lastModifiedTs + ", lockControl="
//				+ lockControl + "]";
//	}
//
//	/**
//	 * @return the id
//	 */
//	public Long getId() {
//		return id;
//	}
//
//	/**
//	 * @param id the id to set
//	 */
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	/**
//	 * @return the changeProposal
//	 */
//	public ChangeProposal getChangeProposal() {
//		return changeProposal;
//	}
//
//	/**
//	 * @param changeProposal the changeProposal to set
//	 */
//	public void setChangeProposal(ChangeProposal changeProposal) {
//		this.changeProposal = changeProposal;
//	}
//
//	/**
//	 * @return the name
//	 * 
//	 */
//	public String getName() {
//		return name;
//	}
//
//	/**
//	 * @param name the name to set
//	 */
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	/**
//	 * @return the systemCategory
//	 */
//	public ExternalSystemCategory getSystemCategory() {
//		return systemCategory;
//	}
//
//	/**
//	 * @param systemCategory the systemCategory to set
//	 */
//	public void setSystemCategory(ExternalSystemCategory systemCategory) {
//		this.systemCategory = systemCategory;
//	}
//
//	/**
//	 * @return the createUserId
//	 */
//	public String getCreateUserId() {
//		return createUserId;
//	}
//
//	/**
//	 * @param createUserId the createUserId to set
//	 */
//	public void setCreateUserId(String createUserId) {
//		this.createUserId = createUserId;
//	}
//
//	/**
//	 * @return the createTs
//	 */
//	public Date getCreateTs() {
//		return createTs;
//	}
//
//	/**
//	 * @param createTs the createTs to set
//	 */
//	public void setCreateTs(Date createTs) {
//		this.createTs = createTs;
//	}
//
//	/**
//	 * @return the lastModifiedUserId
//	 */
//	public String getLastModifiedUserId() {
//		return lastModifiedUserId;
//	}
//
//	/**
//	 * @param lastModifiedUserId the lastModifiedUserId to set
//	 */
//	public void setLastModifiedUserId(String lastModifiedUserId) {
//		this.lastModifiedUserId = lastModifiedUserId;
//	}
//
//	/**
//	 * @return the lastModifiedTs
//	 */
//	public Date getLastModifiedTs() {
//		return lastModifiedTs;
//	}
//
//	/**
//	 * @param lastModifiedTs the lastModifiedTs to set
//	 */
//	public void setLastModifiedTs(Date lastModifiedTs) {
//		this.lastModifiedTs = lastModifiedTs;
//	}
//
//	/**
//	 * @return the lockControl
//	 */
//	public Integer getLockControl() {
//		return lockControl;
//	}
//
//	/**
//	 * @param lockControl the lockControl to set
//	 */
//	public void setLockControl(Integer lockControl) {
//		this.lockControl = lockControl;
//	}
}
