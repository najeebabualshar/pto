package gov.uspto.myBatis.models;

import java.util.Date;

import lombok.Data;

@Data
public class ChangeProposalAssigneeGroupInsert {

	/**
	 * Allowing serialization of datamodel elements
	 */
//    private static final long serialVersionUID = 1L;
// 
//    @Id
//    @NotNull
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "task_assignee_group_id_seq")
//    @SequenceGenerator(name = "task_assignee_group_id_seq", sequenceName = "task_assignee_group_id_seq", allocationSize = 1)
//    @Column(name = "task_assignee_group_id")
	private Long task_assignee_group_id;

//    @NotNull
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalStateTask.class)
//    @JoinColumn(name = "fk_state_task_id", referencedColumnName = "state_task_id")
	private Long state_task_id;

//    @NotNull
//    @Column(name = "fk_assignee_role_cd")
//    @Enumerated(EnumType.STRING)
	private String fk_assignee_role_cd;

//    @NotNull
//    @Column(name = "fk_assignee_ipo_cd")
//    @Enumerated(EnumType.STRING)
	private String fk_assignee_ipo_cd;

//    @CreatedBy
//    @NotNull
//    @Column(name = "create_user_id")
	private String create_user_id; // VARCHAR2(100)

//    @CreatedDate
//    @NotNull
//    @Column(name = "create_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date create_ts;
//
//    /**
//     * @return Long id
//     */
//    public Long getId() {
//        return id;
//    }
//
//    /**
//     * @param id
//     *            the id to set
//     */
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    /**
//     * @return ChangeProposalStateTask task
//     */
//    public ChangeProposalStateTask getTask() {
//        return task;
//    }
//
//    /**
//     * @param task
//     *            the task to set
//     */
//    public void setTask(ChangeProposalStateTask task) {
//        this.task = task;
//    }
//
//    /**
//     * @return OfficeContactType role
//     */
//    public OfficeContactType getRole() {
//        return role;
//    }
//
//    /**
//     * @param role
//     *            the role to set
//     */
//    public void setRole(OfficeContactType role) {
//        this.role = role;
//    }
//
//    /**
//     * @return StandardIpOfficeCode ipOfficeCode
//     */
//    public StandardIpOfficeCode getIpOfficeCode() {
//        return ipOfficeCode;
//    }
//
//    /**
//     * @param ipOfficeCode
//     *            the ipOfficeCode to set
//     */
//    public void setIpOfficeCode(StandardIpOfficeCode ipOfficeCode) {
//        this.ipOfficeCode = ipOfficeCode;
//    }
//
//    /**
//     * @return String createUserId
//     */
//    public String getCreateUserId() {
//        return createUserId;
//    }
//
//    /**
//     * @param createUserId
//     *            the createUserId to set
//     */
//    public void setCreateUserId(String createUserId) {
//        this.createUserId = createUserId;
//    }
//
//    /**
//     * @return Date createTs
//     */
//    public Date getCreateTs() {
//        return createTs;
//    }
//
//    /**
//     * @param createTs
//     *            the createTs to set
//     */
//    public void setCreateTs(Date createTs) {
//        this.createTs = createTs;
//    }
//
//    /**
//     * used for hash based collections.
//     */
//    @Override
//    public int hashCode() {
//        final int prime = 31;
//        int result = 1;
//        result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
//        result = prime * result + ((createUserId == null) ? 0 : createUserId.hashCode());
//        result = prime * result + ((id == null) ? 0 : id.hashCode());
//        result = prime * result + ((ipOfficeCode == null) ? 0 : ipOfficeCode.hashCode());
//        result = prime * result + ((role == null) ? 0 : role.hashCode());
//        result = prime * result + ((task == null) ? 0 : task.hashCode());
//        return result;
//    }
//
//    /**
//     * (non-Javadoc)
//     * 
//     * @see java.lang.Object#equals(java.lang.Object)
//     */
//    @Override
//    public boolean equals(Object obj) {
//        boolean ret = false;
//        if (obj != null) {
//            if (obj == this) {
//                ret = true;
//            } else if (ChangeProposalAssigneeGroup.class.isAssignableFrom(obj.getClass())) {
//                ChangeProposalAssigneeGroup that = (ChangeProposalAssigneeGroup) obj;
//                ret = new EqualsBuilder().append(getTask(), that.getTask())
//                        .append(getIpOfficeCode(), that.getIpOfficeCode()).append(getRole(), that.getRole()).isEquals();
//            }
//        }
//        return ret;
//    }
//
//    /**
//     * @see java.lang.Comparable#compareTo(java.lang.Object)
//     */
//    @Override
//    public int compareTo(ChangeProposalAssigneeGroup other) {
//        return new CompareToBuilder().append(this.getTask(), other.getTask())
//                .append(this.getIpOfficeCode(), other.getIpOfficeCode()).append(this.getRole(), other.getRole())
//                .toComparison();
//    }
}
