package gov.uspto.myBatis.mappers;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import gov.uspto.myBatis.models.ChangeProposalStateTask;

@Mapper
public interface ChangeProposalStateTaskMapper {

	@Delete("DELETE FROM change_proposal_state_task cpst WHERE cpst.state_task_id IN " + "(SELECT cpst2.state_task_id "
			+ "FROM change_proposal_state_task cpst2 , change_proposal_state cps "
			+ "WHERE cpst2.FK_CHANGE_PROPOSAL_ID = cps.FK_CHANGE_PROPOSAL_ID "
			+ "and cps.fk_change_proposal_id = #{stateId}) ")
	Integer deleteChangeProposalStateTaskByChangeProposalStateId(@Param("stateId") Long stateId);

	@Insert("INSERT INTO change_proposal_state_task (cfk_task_assignee_id, create_ts,create_user_id, "
			+ "last_mod_ts,last_mod_user_id, cfk_task_assignee_role_tx,cfk_task_assignee_office_cd, "
			+ "lock_control_no,task_start_ts,task_id,task_name_tx,task_due_ts) " + "VALUES( "
			+ "#{cfk_task_assignee_id}, " + "#{create_ts},#{create_user_id}, " + "#{last_mod_ts},#{last_mod_user_id}, "
			+ "#{cfk_task_assignee_role_tx},#{cfk_task_assignee_office_cd}, "
			+ "#{lock_control_no},#{task_start_ts},#{task_id},#{task_name_tx},#{task_due_ts} ) ")
	Integer save(ChangeProposalStateTask changeProposalStateTask);

}
