package gov.uspto.myBatis.mappers;

import java.util.Set;

import org.apache.ibatis.annotations.*;
import gov.uspto.myBatis.models.ChangeProposal;
import gov.uspto.myBatis.models.ChangeProposalAlias;
import gov.uspto.myBatis.models.ChangeProposalAliasInsert;
import gov.uspto.myBatis.models.ChangeProposalInsert;
import gov.uspto.myBatis.models.ChangeProposalState;
import gov.uspto.myBatis.models.ChangeProposalStateTask;
import gov.uspto.myBatis.models.OfficeRoleOfUserGroup;

@Mapper
public interface ChangeProposalMapper {

//	@Results(id="CHANGE_PROPOSAL_ID",value= {
//			@Result(property="state",column="change_proposal_id",one=@One(select="getChangeProposalStateByProposalId")),
//			@Result(property="aliases",column="change_proposal_id",many=@Many(select="getChangeProposalAliasesByProposalId"))
//	})
	@Select("SELECT * FROM CHANGE_PROPOSAL WHERE GUID_ID = #{guidId}")
	ChangeProposal findByGuidId(@Param("guidId") String guidId);
	
	
	@Select("select * from change_proposal_alias where fk_change_proposal_id=#{change_proposal_id}")
	Set<ChangeProposalAlias> getChangeProposalAliasesByProposalId(@Param("change_proposal_id") Long change_proposal_id); 

//	
//	@Results(id="CHANGE_PROPOSAL_STATE_ID",value= {
//			@Result(property="activeTasks",column="fk_change_proposal_id",many=@Many(select="getChangeProposalStateTaskByProposalId"))
//	})
	@Select("select * from change_proposal_state where fk_change_proposal_id=#{change_proposal_id}")
	ChangeProposalState getChangeProposalStateByProposalId(@Param("change_proposal_id") Long change_proposal_id); 
	
	@Select("select * from CHANGE_PROPOSAL_STATE_TASK where fk_change_proposal_id=#{fk_change_proposal_id}")
	Set<ChangeProposalStateTask> getChangeProposalStateTaskByProposalId(@Param("fk_change_proposal_id") Long fk_change_proposal_id); 
	
	

	
	
	
	@Select("SELECT detail_tx FROM CHANGE_PROPOSAL_DTL"
			+ " WHERE ITEM_TX = 'projectType_PD' AND FORM_TYPE_CT = 'PROJECT_DETAIL' "
			+ "AND FK_CHANGE_PROPOSAL_ID = #{fkChangeProposalId}")
	String getDetailTRX(@Param("fkChangeProposalId") Long fkChangeProposalId);

	@Select("SELECT cpa.change_proposal_alias_cd "
			+ "FROM change_proposal_alias cpa INNER JOIN change_proposal cp ON cpa.fk_change_proposal_id = cp.change_proposal_id "
			+ "WHERE cp.guid_id=#{guidId} " + "AND cpa.source_system_ct IN ('CE','CPC','CEF') "
			+ "ORDER BY cpa.last_mod_ts DESC" + " FETCH FIRST 1 ROWS ONLY")
	String findAliasDisplayNameByGuidId(@Param("guidId") String guidId);
	
	
	@Select("SELECT change_proposal_alias_cd " + 
			"FROM change_proposal_alias " + 
			"WHERE FK_CHANGE_PROPOSAL_ID = #{fkChangeProposalId} AND source_system_ct IN ('CE','CPC','CEF') " + 
			"ORDER BY last_mod_ts DESC " + 
			"FETCH FIRST 1 ROWS ONLY")
	String findAliasDisplayNameByProposalId(@Param("fkChangeProposalId") Long fkChangeProposalId);

	@Select("SELECT task_days_no FROM stnd_wf_task_config tc"
			+ "WHERE tc.fk_proposal_phase_cd=#{phaseId} AND tc.task_id =#{taskId} ")
	Integer findTaskDaysNumberByTaskId(@Param("phaseId") Integer phaseId, @Param("taskId") Integer taskId);

	@Select("SELECT fk_ipo_cd office ,fk_proposer_role_cd role " + "FROM stnd_wf_user_group "
			+ "WHERE fk_task_id =#{task_id} ")
	OfficeRoleOfUserGroup findOfficeAndRoleForUserByTaskId(@Param("taskId") Integer taskId);

	@Update("UPDATE change_proposal " + "SET last_mod_ts = #{last_mod_ts}, " + "last_mod_user_id =#{last_mod_user_id}, "
			+ "lock_control_no =#{lock_control_no} " + "WHERE change_proposal_id =#{change_proposal_id} ")
	void updateChangeProposalByChangeProposalId(ChangeProposalInsert changeProposal);

	@Update("UPDATE change_proposal " + "SET proposal_status_ct =#{status}" + "WHERE guid_id=#{guidId}")
	void updateChangeProposalStatusByGuidId(@Param("status") String status, @Param("guidId") String guidId);


	@Insert("INSERT INTO change_proposal_alias (change_proposal_alias_id,fk_change_proposal_id, create_ts, create_user_id, lock_control_no, change_proposal_alias_cd,source_system_ct,last_mod_user_id,last_mod_ts) "
			+ "VALUES (#{change_proposal_alias_id},#{fk_change_proposal_id}, #{create_ts}, #{create_user_id}, #{lock_control_no},#{change_proposal_alias_cd},#{source_system_ct},#{last_mod_user_id},#{last_mod_ts})")
	Integer insertIntoChangeProposalAlias(ChangeProposalAliasInsert changeProposalAlias);

	@Select ("select max(change_proposal_alias_id)+1 from change_proposal_alias")
	Long getNextSeq();
	
}
