package gov.uspto.myBatis.mappers;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import gov.uspto.myBatis.models.ChangeProposalState;
import gov.uspto.myBatis.models.ChangeProposalStateInsert;
import gov.uspto.myBatis.models.ChangeProposalStateTask;

@Mapper
public interface ChangeProposalStateMapper {

	@Insert("INSERT INTO change_proposal_state(fk_change_proposal_id,create_ts,create_user_id,lock_control_no,"
			+ "proposal_phase_tx,proposal_subphase_tx,last_mod_ts,last_mod_user_id,definition_id,process_instance_id,"
			+ "process_start_ts,proposal_state_ct) "
			+ "VALUES(#{fk_change_proposal_id},#{create_ts},#{create_user_id},#{lock_control_no},"
			+ "#{proposal_phase_tx},#{proposal_subphase_tx},#{last_mod_ts},#{last_mod_user_id},#{definition_id},#{process_instance_id},"
			+ "#{process_start_ts},#{proposal_state_ct}) ")
	Long save(ChangeProposalStateInsert changeProposalState);
	
	
	@Select("SELECT * FROM change_proposal_state WHERE fk_change_proposal_id = #{fk_change_proposal_id}")
	ChangeProposalState findById(@Param("fk_change_proposal_id") Long fk_change_proposal_id);
	
	
//
	@Update("UPDATE change_proposal_state " + "SET last_mod_ts = #{last_mod_ts}, "
			+ "last_mod_user_id = #{last_mod_user_id}, " + "proposal_phase_tx= #{proposal_phase_tx}, "
			+ "proposal_subphase_tx=#{proposal_subphase_tx}, " + "definition_id=#{definition_id}, "
			+ "process_end_ts=#{process_end_ts}, " + "process_instance_id=#{process_instance_id}, "
			+ "process_start_ts= #{process_start_ts}, " + "proposal_state_ct=#{proposal_state_ct} "
			+ "WHERE fk_change_proposal_id = #{fk_change_proposal_id}")
	// TODO: add the ID
	void updateChangeProposalStateByGuidID(ChangeProposalStateInsert changeProposalState);
	
	

//	@Update("UPDATE change_proposal_state " + "SET last_mod_ts = #{last_mod_ts}, "
//			+ "last_mod_user_id =#{last_mod_user_id}, " + "lock_control_no =#{lock_control_no} "
//			+ "WHERE change_proposal_id =#{change_proposal_id} ")
//	void updateChangeProposalStateByChangeProposalId(ChangeProposalStateInsert changeProposalState);

	@Select("SELECT * " + "FROM change_proposal_state_task cpst "
			+ "INNER JOIN change_proposal cp on cpst.fk_change_proposal_id = cp.change_proposal_id "
			+ "WHERE cp.guid_id=#{guidId}")
	ChangeProposalStateTask findTaskInfoByGuidId(@Param("guidId") Integer guidId);

}
