# Enterprise License location

Put the Activiti Enterprise license file (activiti.lic) in this directory.
It will then be copied into the WAR..............

And then not be part of any other classpaths.
   
  
 
