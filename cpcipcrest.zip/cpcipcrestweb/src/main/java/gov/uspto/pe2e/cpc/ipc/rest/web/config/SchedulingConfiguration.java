package gov.uspto.pe2e.cpc.ipc.rest.web.config;
import org.springframework.stereotype.Component;

import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;

@EnableSchedulerLock( defaultLockAtMostFor = "PT30M")
@Component
public class SchedulingConfiguration {

}
