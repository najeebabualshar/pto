/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 
 * @author 2020
 * @date Aug 25, 2022 3:45:34 PM
 * @version
 */
@Component
@Api(value = "/health", description = "Controller returns health data of the application")
@Controller
@RequestMapping(value = "/health")
@Slf4j
public class HealthController {
    
    private static final Logger log = LoggerFactory.getLogger(HealthController.class);
    
    
    /**
     * Get Manifest
     * 
     * @param request
     * @return Map
     */
    @ResponseBody
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<Map<String, Object>> getHealth() {
    	
    	RuntimeMXBean runTime = ManagementFactory.getRuntimeMXBean();
    	 
    	Map<String, Object> healthObject = new HashMap<String, Object>();
    	
    	int count = 0;
    	try {
        	healthObject.put("startTime",new DateTime(runTime.getStartTime()).toString());
        	healthObject.put("latestSchemePublication", new DateTime(SchemePublicationVersionContextHolder.getContext().getPublicationDate()).toString());
        	    	} catch (Exception e) {
    		log.warn("Unable to get indexed Count", e);
    	}
    	
        return new ResponseEntity<>(healthObject, RestUtils.buildRestHttpHeaders(), HttpStatus.OK);

    }    
    

}
