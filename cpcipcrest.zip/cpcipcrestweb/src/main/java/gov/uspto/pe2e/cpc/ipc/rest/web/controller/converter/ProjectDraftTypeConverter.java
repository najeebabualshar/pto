package gov.uspto.pe2e.cpc.ipc.rest.web.controller.converter;

import org.springframework.core.convert.converter.Converter;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ProjectDraftType;

/**
 * Converts to Enum type with the framework
 * 
 * @author 2020
 * @version 1.3.5
 * @date: 06/02/2016
 *
 */
public class ProjectDraftTypeConverter implements Converter<String, ProjectDraftType> {

    /**
     * Method to convert String to projectDraftType enum
     *
     * @param path param value 
     * @return ProjectDraftType
     */
    @Override
    public ProjectDraftType convert(String encodedName) {

        return ProjectDraftType.valueOf(encodedName.toUpperCase());
    }
}
