/**
 * REST access denied handler.
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.security;

import java.io.IOException;

import org.apache.commons.lang3.CharEncoding;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.RestError;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 
 * Class for Rest Access Denied Handler
 * 
 * @author 2020
 * @version 1.0
 * @date: 08/4/2015
 *
 */
public class RestAccessDeniedHandler extends AccessDeniedHandlerImpl {
    private String restHeader;

    @Override
    public void handle(HttpServletRequest req, HttpServletResponse resp, AccessDeniedException exc)
            throws IOException, ServletException {
        if (!StringUtils.isBlank(req.getHeader(restHeader))
                && req.getHeader(restHeader).toLowerCase().startsWith("application/json")) {
            //TODO We need to add support for XML at some point (maybe)
            resp.getOutputStream()
                    .write(JsonUtils.toJson(new RestError(HttpStatus.FORBIDDEN, "Insufficient Privilege/Access"))
                            .getBytes(CharEncoding.UTF_8));
        } else {
            super.handle(req, resp, exc);
        }

    }

    /**
     * Get the REST header.
     *
     * @return the REST header.
     */
    public String getRestHeader() {
        return restHeader;
    }

    /**
     * Set the REST header.
     *
     * @param restHeader the REST header.
     */
    public void setRestHeader(String restHeader) {
        this.restHeader = restHeader;
    }

}
