package gov.uspto.pe2e.cpc.ipc.rest.web.util;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;

/**
 * This class offers a Utility of evaluating messages to determine whether further 
 * action should be considered Valid
 * @author 2020
 * @date Jun 22, 2016
 * @version 
 *
 */
public final class ValidationMessageStatusUtil {
    
    /**
	 * 
	 * @param validationMessages
	 * @return
	 * @since Jun 22, 2016
	 */
	public static boolean ensureNoErrorLevelMessagesExist(List<ValidationMessage> validationMessages) {
		boolean hasNoErrLevel=true;
		  if (CollectionUtils.isNotEmpty(validationMessages)) {
		   for (ValidationMessage msg : validationMessages) {
		    if (msg.getLevel().equals(ValidationMessageLevel.ERROR)) {
		     hasNoErrLevel = false;
		     break;
		    }
		   }
		  }
		  return hasNoErrLevel;
	}
}