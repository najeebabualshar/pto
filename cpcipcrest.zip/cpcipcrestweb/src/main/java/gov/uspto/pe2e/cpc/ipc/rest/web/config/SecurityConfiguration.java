package gov.uspto.pe2e.cpc.ipc.rest.web.config;

import static org.springframework.security.config.Customizer.withDefaults;

import java.io.InputStream;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.opensaml.saml.saml2.core.NameIDType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.converter.RsaKeyConverters;
import org.springframework.security.core.AuthenticatedPrincipal;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.saml2.core.Saml2X509Credential;
import org.springframework.security.saml2.provider.service.authentication.OpenSaml4AuthenticationProvider;
import org.springframework.security.saml2.provider.service.authentication.OpenSaml4AuthenticationProvider.ResponseToken;
import org.springframework.security.saml2.provider.service.authentication.Saml2Authentication;
import org.springframework.security.saml2.provider.service.metadata.OpenSamlMetadataResolver;
import org.springframework.security.saml2.provider.service.registration.InMemoryRelyingPartyRegistrationRepository;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistration;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrations;
import org.springframework.security.saml2.provider.service.registration.Saml2MessageBinding;
import org.springframework.security.saml2.provider.service.web.DefaultRelyingPartyRegistrationResolver;
import org.springframework.security.saml2.provider.service.web.RelyingPartyRegistrationResolver;
import org.springframework.security.saml2.provider.service.web.Saml2MetadataFilter;
import org.springframework.security.saml2.provider.service.web.authentication.Saml2WebSsoAuthenticationFilter;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.UsptoSAMLUserDetailsService;
import jakarta.inject.Inject;
import jakarta.servlet.Filter;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableWebSecurity(debug = false)
@EnableMethodSecurity(prePostEnabled = true, 
	jsr250Enabled = true, securedEnabled = true)
@Slf4j
public class SecurityConfiguration {
	
	@Inject
	private UsptoSAMLUserDetailsService usptoSAMLUserDetailsService;
	
	// for how to register a SAML provider
	// https://javadoc.io/static/org.springframework.security/spring-security-saml2-service-provider/5.4.7/index.html?org/springframework/security/saml2/provider/service/registration/RelyingPartyRegistration.html
	@Value("urn:gov:uspto:cpcipcrest${environmental_idp_entity_id_suffix:}")
	private String entityId;
	
	@Value("${saml_entity_base_url:http://localhost:8080/cpcipcrestweb}")
	private String baseUrl;
	
	@Value("${classpath_idp_metadata_xml_file}")
	private String classpathMetadataFile;
	
	@Value("${saml.private.key}") String keyResource;
	@Value("${saml.public.certificate}") String certificateResource;
	
	static {
		Security.addProvider(new BouncyCastleProvider());
	}
	
//	@Bean
//	public Saml2MetadataResponseResolver metadataResponseResolver(RelyingPartyRegistrationRepository registrations) {
//		RequestMatcherMetadataResponseResolver metadata = new RequestMatcherMetadataResponseResolver(
//				(id) -> registrations.findByRegistrationId("relying-party"), null);
//		metadata.setMetadataFilename(classpathMetadataFile);
//		return metadata;
//	}
	
//	@Bean
//	public RelyingPartyRegistrationRepository relyingPartyRegistrationRepository() {
//		String registrationId = entityId;
//		
//	    //  final InputStream is = new ByteArrayInputStream(certBytes);
//	    CertificateFactory cf = CertificateFactory.getInstance("X.509");
//	    
//        String relyingPartyEntityId = "{baseUrl}/saml2/service-provider-metadata/{registrationId}";
//        String assertionConsumerServiceLocation = "{baseUrl}/login/saml2/sso/{registrationId}";
//        Saml2X509Credential relyingPartySigningCredential = ...;
//
//        String assertingPartyEntityId = "https://simplesaml-for-spring-saml.apps.pcfone.io/saml2/idp/metadata.php";
//        String singleSignOnServiceLocation = "https://simplesaml-for-spring-saml.apps.pcfone.io/saml2/idp/SSOService.php";
//        Saml2X509Credential assertingPartyVerificationCredential = ...;
//
//        RelyingPartyRegistrations.fromMetadataLocation("https://trial-27.okta.com/app/e/sso/saml/metadata").registrationId("layer7").build();
//        
//        
//        return RelyingPartyRegistration.withRegistrationId(registrationId)
//                .providerDetails(config -> config.entityId(idpEntityId))
//                .providerDetails(config -> config.webSsoUrl(webSsoEndpoint))
//                .providerDetails(config -> config.signAuthNRequest(false)) // THIS IS THE KEY
//                .credentials(c -> c.add(credential))
//                .localEntityIdTemplate(localEntityIdTemplate)
//                .assertionConsumerServiceUrlTemplate(acsUrlTemplate)
//                .build();
//
//
////        RelyingPartyRegistration rp = RelyingPartyRegistration.withRegistrationId(registrationId)
////                        .entityId(relyingPartyEntityId)
////                        .assertionConsumerServiceLocation(assertingConsumerServiceLocation)
////                        .signingX509Credentials((c) -> c.add(relyingPartySigningCredential))
////                        .assertingPartyDetails((details) -> details
////                                .entityId(assertingPartyEntityId));
////                                .singleSignOnServiceLocation(singleSignOnServiceLocation))
////                                .verifyingX509Credentials((c) -> c.add(assertingPartyVerificationCredential))
////                        .build();
////		
////		return rp;
//	}
	
	public RelyingPartyRegistration relyingPartyRegistration() {

		log.debug("resource {} ... {}", this.keyResource, this.certificateResource);
		RelyingPartyRegistration replyingPartyRegistration = null;
		try (InputStream privateKeyIs = Thread.currentThread().getContextClassLoader().getResourceAsStream(keyResource);
				InputStream certIs = Thread.currentThread().getContextClassLoader().getResourceAsStream(certificateResource);) {
			CertificateFactory certFactory = CertificateFactory.getInstance("X.509");

			RSAPrivateKey key = RsaKeyConverters.pkcs8().convert(privateKeyIs);
			X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(certIs);

			log.error("using metadata from classpath:{}", classpathMetadataFile);
			final Saml2X509Credential credential = Saml2X509Credential.signing(key, certificate);


			replyingPartyRegistration = RelyingPartyRegistrations
					.fromMetadataLocation("classpath:" + classpathMetadataFile)
					.registrationId("okta")
					.entityId(entityId)
//					.assertingPartyDetails(party -> party
//			                .entityId("https://idp.example.com/issuer")
//			                .singleSignOnServiceLocation("https://idp.example.com/SSO.saml2")
//			                .wantAuthnRequestsSigned(false)
//			                
//			                .verificationX509Credentials(c -> c.add(credential))
//			            )
					.authnRequestsSigned(false)
					.assertionConsumerServiceBinding(Saml2MessageBinding.REDIRECT)
					.nameIdFormat(NameIDType.EMAIL)
//					.nameIdFormat(NameIDType.TRANSIENT)
//					.nameIdFormat(NameIDType.PERSISTENT)
					.singleLogoutServiceLocation("{baseUrl}/saml/SingleLogout")
					.signingX509Credentials((signing) -> signing.add(credential))
//					.assertionConsumerServiceLocation("{baseUrl}/login/{registrationId}")
					.assertingPartyDetails(apdBuilder -> {
	                        apdBuilder.wantAuthnRequestsSigned(false);
	                    })
					.build();
		} catch (Exception e) {
			log.error("exe ->", e);
			throw new RuntimeException(e);
		}
		return replyingPartyRegistration;
	}
	
	
	@Bean
    public RelyingPartyRegistrationRepository relyingPartyRegistrationRepository() {
		//SAML configuration
        //Mapping this application to one or more Identity Providers
        return new InMemoryRelyingPartyRegistrationRepository(relyingPartyRegistration());
    }
	
	@Bean
	public Saml2MetadataFilter saml2MetadataFilter(RelyingPartyRegistrationRepository relyingPartyRegistrationRepository) {
		Converter<HttpServletRequest, RelyingPartyRegistration> relyingPartyRegistrationResolver =
				new DefaultRelyingPartyRegistrationResolver(relyingPartyRegistrationRepository);
		OpenSamlMetadataResolver metadataResolver = new OpenSamlMetadataResolver();
		log.info("metadata resolver instantiation complete");

		Saml2MetadataFilter filter = new Saml2MetadataFilter(
				(RelyingPartyRegistrationResolver) relyingPartyRegistrationResolver, metadataResolver);

		return filter;
	}
	
	/**
	 * This is the EXTREMELY important plugin into Spring security that does 3 things:
	 * 1) If No recognized roles are supplied in the authentication token, the default EMPLOYEE role
	 * is applied.  This only happens in DEV and FQT (trinet auth)
	 * 2) For Each role, Permissions are mapped from the coarse grained ApplicationRole
	 * 3) Incorporate the classpath role/permission mapping overrides from $TOMCAT_HOME/lib/
	 * @return
	 */
	public OpenSaml4AuthenticationProvider openSaml4AuthenticationProvider() {
		OpenSaml4AuthenticationProvider provider = new OpenSaml4AuthenticationProvider();
		final Converter<ResponseToken, Saml2Authentication> authenticationConverter =
				OpenSaml4AuthenticationProvider.createDefaultResponseAuthenticationConverter();
		provider.setResponseAuthenticationConverter(
				new Converter<OpenSaml4AuthenticationProvider.ResponseToken, AbstractAuthenticationToken>() {
					@Override
					public AbstractAuthenticationToken convert(ResponseToken responseToken) {
						Saml2Authentication authentication = authenticationConverter.convert(responseToken);
						if (authentication !=  null && authentication.isAuthenticated()) {
							Collection<ApplicationPermission> permissions = usptoSAMLUserDetailsService.loadRolesAndPermissions(authentication);
						
							List<GrantedAuthority> authoritiesList = permissions.stream()
			            		.map(it -> new SimpleGrantedAuthority(it.name()))
			            		.peek(it -> log.debug("Granted Authority = {}",it))
			            		.collect(Collectors.toList());
						
							return new Saml2Authentication((AuthenticatedPrincipal) authentication.getPrincipal(),
			            		authentication.getSaml2Response(), authoritiesList);
						} else {
							return authentication;
						}
					}
				}
		);
		return provider;
	}


	@Bean
	public DefaultSecurityFilterChain httpSecuritySaml(HttpSecurity http
			 , RelyingPartyRegistrationRepository relyingPartyRegistrationRepository
			 , Saml2MetadataFilter metadataFilter
			) throws Exception {

		http
  		  .csrf(AbstractHttpConfigurer::disable)
		  .authorizeHttpRequests(authorize -> authorize
				  .requestMatchers(new AntPathRequestMatcher("/info/**", "GET"), 
						  new AntPathRequestMatcher("/health", "GET")
/*						  ,new AntPathRequestMatcher("/v3/api-docs/**", "GET"),
						  new AntPathRequestMatcher("/v3/api-docs", "GET"),
						  
						  new AntPathRequestMatcher("/configuration/ui", "GET"),
						  new AntPathRequestMatcher("/swagger-resources/**", "GET"),
						  new AntPathRequestMatcher("/configuration/security","GET"),
						  new AntPathRequestMatcher("/swagger-ui/**","GET"),
						  new AntPathRequestMatcher("/index.html","GET"),
							
						  new AntPathRequestMatcher("/v3/swagger-ui**","GET"),
						  new AntPathRequestMatcher("/swagger-ui**","GET"),
						  new AntPathRequestMatcher("/webjars/**", "GET")
			*/			  
//						  ,"/logout.jsp", "/favicon.ico"
						  ).permitAll()
				  .anyRequest()
				  .authenticated() )
		  //https://stackoverflow.com/questions/69956447/spring-security-saml-assertion-to-roles-conversion
		  .saml2Login(withDefaults())
		    .authenticationManager(
		            new ProviderManager(
		            		openSaml4AuthenticationProvider()
		            )
		        )
		  //.authenticationProvider(null)
		  .saml2Logout(withDefaults())
		  .saml2Metadata(withDefaults())
		  
//		  
		  //.addFilterBefore(filter, Saml2WebSsoAuthenticationFilter.class);

			;
		
		 http.addFilterBefore(metadataFilter, Saml2WebSsoAuthenticationFilter.class);
		 
			
			log.debug("http configurer seems ready.  Calling build on {}", http);
		DefaultSecurityFilterChain chain= http.build();
		log.debug("Filter Chain");
		for (Filter f: chain.getFilters()) {
			log.info("Filter  = {}", f.getClass().getCanonicalName());
		}
		return chain;
	}
	
//	@Bean
//	@Primary
//	public SecurityExpressionHandler defaultMethodSecurityExpressionHandler() {
//		//GlobalMethodSecurityBeanDefinitionParser:203 Expressions were enabled for method security but no SecurityExpressionHandler was configured. All hasPermission() expressions will evaluate to false
//
//		DefaultWebSecurityExpressionHandler expressionHandler = new DefaultWebSecurityExpressionHandler();
//		expressionHandler.setPermissionEvaluator(null);
//	
//		return expressionHandler;
//	}
	
	
	
	
//	@Bean
//	public AuthenticationProvider samlAuthenticationProvider() {
//		return new SamlAuthenticationProvider();
//	}
	
	
//	@Bean
//	public PermissionEvaluator permissionEvaluator() {
//		return new UsptoPermissionEvaluator();
//	}
	//	public static class UsptoSecurityExpressionHandler implements  SecurityExpressionHandler {
//
//		@Override
//		public ExpressionParser getExpressionParser() {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//		@Override
//		public EvaluationContext createEvaluationContext(Authentication authentication, Object invocation) {
//			// TODO Auto-generated method stub
//			return null;
//		}
//		
//	}
//	public static class UsptoPermissionEvaluator implements PermissionEvaluator {
//
//		@Override
//		public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
//			log.info("calling hasPermission(Authentication authentication, Object targetDomainObject, Object permission)"
//					+"  with authentication object {} looking for permissions {}", authentication, permission);
//			return true;
//		}
//
//		@Override
//		public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType,
//				Object permission) {
//			log.info("calling  hasPermission(Authentication authentication, Serializable targetId, String targetType,"
//					+ " Object permission)"
//					+"  with authentication object {} looking for permissions {}", authentication, permission);
//
//			return true;
//		}
//		
//	}
//	@Bean
//	public Saml2MetadataResponseResolver saml2MetadataResponseResolver() {
//		
//		
//		return new RequestMatcherMetadataResponseResolver();
//	}
	

//    @Autowired
//    RelyingPartyRegistrationRepository relyingPartyRegistrationRepository;
//
//    @Bean
//    protected void configure(HttpSecurity http) throws Exception {
//
//        // This will enable the m
//        Converter<HttpServletRequest, RelyingPartyRegistration> relyingPartyRegistrationResolver =
//                new DefaultRelyingPartyRegistrationResolver(this.relyingPartyRegistrationRepository);
//
//        Saml2MetadataFilter filter = new Saml2MetadataFilter(
//                relyingPartyRegistrationResolver,
//                new OpenSamlMetadataResolver());
//
//        http
//            .saml2Login(withDefaults())
//            .addFilterBefore(filter, Saml2WebSsoAuthenticationFilter.class)
//                .antMatcher("/**")
//                .authorizeRequests()
//                .antMatchers("/**").authenticated();
//    }
}