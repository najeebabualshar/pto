package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.IdpDiscoveryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import jakarta.annotation.Nonnull;
import jakarta.inject.Inject;
import lombok.RequiredArgsConstructor;

/**
 * US5079: SAML Prototype - External Domain
 *
 * IDP Discovery Service Controller
 * 
 * @deprecated This is no longer being used since we only have 1 IDP.  should we remove it?
 *
 * @author 2020
 * @version 1.0
 * @date: 08/4/2015
 *
 */

@Component
@Api(value = "/idps", description = "Controller that handles all IDP Discovery related operations")
@RestController
@RequestMapping(value = "/idps")
@Deprecated
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class IdpDiscoveryController {
    
    @Nonnull
    private IdpDiscoveryService discoveryService;

    /**
     * Resolve the authoritative IDP based off of the IP address supplied as a
     * Request Parameter
     *
     * @param ip
     * @return String - url in the header.
     */
    @ApiOperation("Resolve the authoritative IDP based off of the IP address supplied as a Request Parameter")
    @RequestMapping(value = "/resolve", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> resolveIdpUrl(@RequestParam("ip") String ip) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Location", discoveryService.resolveIdpUrl(ip));
        return new ResponseEntity<>("", headers, HttpStatus.OK);
    }
}
