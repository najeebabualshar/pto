package gov.uspto.pe2e.cpc.ipc.rest.web.jee.listener;

import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TimeZone;

import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;

/**
 * 
 * Loads all the properties in the build manifest into a map and puts it on the
 * app context.
 * 
 * @author 2020
 * @version 1.0
 * @date: 08/4/2015
 *
 */
public class InitAppContextPropertiesListener implements ServletContextListener {

    private static final Logger log = LoggerFactory.getLogger(InitAppContextPropertiesListener.class);

    private static final String CLASSPATH = "class-path";
    private static final String MANIFESTPATH = "/META-INF/MANIFEST.MF";

    public static final String SERVLET_CONTEXT_MANIFEST_KEY = "manifest";
    public static final String SERVLET_CONTEXT_STARTTIME_KEY = "jvmStartTime";

    /**
     * @see jakarta.servlet.ServletContextListener#contextDestroyed(jakarta.servlet.
     *      ServletContextEvent)
     * 
     * @param arg0
     */
    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
        // do nothing
    }

    /**
     * @see jakarta.servlet.ServletContextListener#contextInitialized(jakarta.servlet.
     *      ServletContextEvent)
     * 
     * @param servletContextEvent
     */
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        log.info("Context initializing");

        TimeZone.setDefault(TimeZone.getTimeZone(RestUtils.DEFAULT_TIMEZONE));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        InputStream is = null;

        try {
            ServletContext ctx = servletContextEvent.getServletContext();

            is = ctx.getResourceAsStream(MANIFESTPATH);

            Properties props = new Properties();

            if (is != null) {
                props.load(is);
            }

            Map<String, String> manifest = new HashMap<>();
            if (props != null) {
                for (Entry<Object, Object> prop : props.entrySet()) {
                    try {
                        if (prop != null && prop.getKey() != null && !CLASSPATH.equalsIgnoreCase(prop.getKey().toString())) {
                            manifest.put(prop.getKey().toString(), prop.getValue().toString());
                        }
                    } catch (Exception e) {
                        log.warn("Exception caught settings manifest properties.", e);
                    }
                }
            }
            ctx.setAttribute(SERVLET_CONTEXT_MANIFEST_KEY, manifest);
            ctx.setAttribute(SERVLET_CONTEXT_STARTTIME_KEY, new Date(ManagementFactory.getRuntimeMXBean().getStartTime()));
        } catch (IOException e) {
            log.error("IOException caught reading manifest.", e);
        }
    }

}
