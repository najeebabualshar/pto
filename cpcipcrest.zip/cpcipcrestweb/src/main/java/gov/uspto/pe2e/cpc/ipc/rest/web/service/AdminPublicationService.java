package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.util.Date;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.I18nMessageKey;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ClassificationSchemeStatusRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.SpringI18NMessageSource;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationStatusRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationTreeStatus;
import jakarta.annotation.Nonnull;
import jakarta.annotation.Nullable;
import jakarta.inject.Inject;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

/**
 * An Admin Service for interacting with "Publications". Publications are roughly equivalent to classification_scheme records
 * but are more targeted to the data about dates, versions and status of a tree of symbols on a given date.
 */
@Service
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class AdminPublicationService {
	
	private static final Logger log = LoggerFactory.getLogger(AdminPublicationService.class);

	@Nonnull
	private ClassificationSchemeStatusRepository classificationSchemeStatusRepository;
	
	/**
	 * Updates the published scheme status leveraging the uuid of the published scheme entity
	 * @param uuid fk_change_proposal_guid
	 * @param publicationStatusRequest Request object for rest contract
	 */
	@Transactional
	public void updatePublicationStatus(@Nullable UUID uuid, PublicationStatusRequest publicationStatusRequest, String email) {
		Date now = new Date();
		log.debug("Updating publication_scheme_status {} with status {} and text {}", uuid, publicationStatusRequest.getStatus(), publicationStatusRequest.getFailureText());
	    int updated = classificationSchemeStatusRepository.updateClassificationSchemeStatus(Long.parseLong(GUIDUtils.toDatabaseFormat(uuid)),
				PublicationTreeStatus.valueOf(publicationStatusRequest.getStatus()), publicationStatusRequest.getFailureText(), email, now);
		if (updated != 1) {
			throw new EntityNotFoundException(SpringI18NMessageSource.reloadableResourceBundleMessageSource.getMessage(
					I18nMessageKey.CLASSIFICATION_SCHEME_UPDATE_ERROR.name(), new Object[] { uuid }, LocaleContextHolder.getLocale())
			);
		}
	}
}
