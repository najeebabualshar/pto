package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.I18nMessageKey;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcConcordanceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.web.service.IpcConcordanceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import jakarta.annotation.Nonnull;
import jakarta.inject.Inject;
import lombok.RequiredArgsConstructor;

/**
 * IPC Concordance controller
 * 
 * @author 2020
 * @date Dec 7, 2016
 * @version 1.6
 */

@Component
@Api(value = "/ipcconcordance", description = "Controller for looking up IPC Concordance values")
@Controller
@RequestMapping(value = "/ipcconcordance")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class IpcConcordanceController {
    private static final Integer MIN_SEARCH_LENGTH = 4;

    @Nonnull
    private ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;

    @Nonnull
    private IpcConcordanceService ipcConcordanceService;

    /**
     * Gets a list of symbol names and for each Name returns an IPC Concordance
     * maping
     * 
     * @param symbolNames
     * @return List<IpcConcordanceMapping>
     * @since Dec 7, 2016
     */
    @ResponseBody
    @RequestMapping(value = "/lookup", method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('PROPOSAL_MANAGER_ENABLED') and hasAuthority('IPC_CONCORDANCE_GET')")
    public ResponseEntity<List<IpcConcordanceMapping>> getIPCConcordance(@RequestBody List<String> symbolNames) {
        ResponseEntity<List<IpcConcordanceMapping>> resp = null;
        HttpHeaders headers = RestUtils.buildRestHttpHeaders();
        List<IpcConcordanceMapping> ipcMappings = ipcConcordanceService.resolveIpcConcordanceMappings(symbolNames);
        if (CollectionUtils.isNotEmpty(ipcMappings)) {
            resp = new ResponseEntity<>(ipcMappings, headers, HttpStatus.OK);
        } else {
            resp = new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
        }
        return resp;
    }

    /**
     * Search all IpcSchemeHierarchy records and return list of strings
     * 
     * @param String
     *            symbol name
     * @return List<String> symbol names
     * @since Jan 3, 2017
     */
    @ResponseBody
    @RequestMapping(value = "/search/{ipcSymbolName:.*}", method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('PROPOSAL_MANAGER_ENABLED') and hasAuthority('IPC_CONCORDANCE_SEARCH')")
    public ResponseEntity<List<String>> search(
            @ApiParam(SymbolName.API_DESCRIPTION) @PathVariable("ipcSymbolName") SymbolName ipcSymbolName) {
        ResponseEntity<List<String>> resp = null;
        if (StringUtils.length(ipcSymbolName.getClassificationSymbolCd()) < MIN_SEARCH_LENGTH) {
            throw new IllegalArgumentException(
                    reloadableResourceBundleMessageSource.getMessage(I18nMessageKey.IPC_CONCORDANCE_MIN_SEARCH_LENGTH.name(),
                            new Object[] { ipcSymbolName.getClassificationSymbolCd(), MIN_SEARCH_LENGTH },
                            LocaleContextHolder.getLocale()));
        }
        HttpHeaders headers = RestUtils.buildRestHttpHeaders();
        List<String> ipcMappings = ipcConcordanceService.findSymbolsStartingWith(ipcSymbolName.getClassificationSymbolCd());
        if (CollectionUtils.isNotEmpty(ipcMappings)) {
            resp = new ResponseEntity<>(ipcMappings, headers, HttpStatus.OK);
        } else {
            resp = new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
        }
        return resp;
    }
}
