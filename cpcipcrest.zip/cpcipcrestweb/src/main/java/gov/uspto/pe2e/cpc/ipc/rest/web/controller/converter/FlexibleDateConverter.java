package gov.uspto.pe2e.cpc.ipc.rest.web.controller.converter;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;


/**
 * Date Converter Class
 *
 * @author 2020
 * @version 2.10.0
 * @date: 11/29/2022
 *
 */
public class FlexibleDateConverter implements Converter<String, Date> {
	
	private static final List<String> ACCEPTED_DATE_FORMATS = Arrays.asList("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
			"yyyy-MM-dd",
			"EEE',' dd MMM yyyy HH:mm:ss zzz");

    private static final Logger log = LoggerFactory.getLogger(FlexibleDateConverter.class);

    /**
     * Method to convert Date String to java.util.Date Object
     * 
     * Note: 
     * 		1) this is a flexible date converter designed to be compatible with existing Date 
     * 			formats used in gov.uspto.pe2e.cpc.ipc.rest.wms.controller.WmsTaskController.getAllTasks(Date, Date, String).
     * 			The necessity to support this stupid date format is because we implemented a service that
     * 			accepted the spring default date format EEE, dd MMM yyyy HH:mm:ss zzz as opposed
     * 			to any of the standard ISO8601 date variants
     * 		2) this converter will try the most precise ISO8601 we support (yyyy-MM-dd'T'HH:mm:ss.SSS'Z') 
     * 			before falling back to the less precise yyyy-MM-dd format.  This means that if you send
     * 			2001-01-01T01:19, the parser will pick up the 2001-01-01 part and drop the time.
     * 			This is just for convenience.  Everyone should be using this format: 
     * 			yyyy-MM-dd'T'HH:mm:ss.SSS'Z'
     * 		3) if this fails to parse, it will throw an illegal argument exception which spring will convert
     * 			into HTTP/400
     * 		4) if you pass in null or empty, this parse will return null and rely on the other 
     * 			JSR303 validation annotations applied to the object (such as @NotNull) to make sure
     * 			an empty date is or isn't allowed for a given case 
     *
     * @param dateStr
     * @return java.util.Date
     */
    @Override
    public Date convert(String dateStr) {

        Date thisDate = null;
        if (StringUtils.isNotEmpty(dateStr)) {
            try {
            	thisDate = DateUtils.parseDate(dateStr, 
            			ACCEPTED_DATE_FORMATS.toArray(new String[] {}));
            	
            } catch (Exception e) {
				// Allow this error to bubble up, spring will treat this as 400
				throw new IllegalArgumentException(
						MessageFormat.format(
								"Failed to parse ''{0}'' using any of the accepted Date formats {1}",
								dateStr,
								ACCEPTED_DATE_FORMATS), e);
            }
        }
        return thisDate;
    }
}
