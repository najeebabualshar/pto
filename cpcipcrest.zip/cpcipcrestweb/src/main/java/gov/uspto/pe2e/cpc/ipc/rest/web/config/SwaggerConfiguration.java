package gov.uspto.pe2e.cpc.ipc.rest.web.config;


import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springdoc.webmvc.ui.SwaggerUiHome;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.DelegatingWebMvcConfiguration;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.parameters.Parameter;
import lombok.extern.slf4j.Slf4j;


@Configuration
@ComponentScan(basePackages = {"org.springdoc"}
, excludeFilters = @ComponentScan.Filter(
        type = FilterType.ASSIGNABLE_TYPE,
        classes = {SwaggerUiHome.class})
)
@Import({org.springdoc.core.configuration.SpringDocConfiguration.class,
	     org.springdoc.webmvc.core.configuration.SpringDocWebMvcConfiguration.class,
         org.springdoc.webmvc.ui.SwaggerConfig.class,
         org.springdoc.core.properties.SwaggerUiConfigProperties.class,
         org.springdoc.core.properties.SwaggerUiOAuthProperties.class,
         org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration.class
         
         })
@PropertySource("classpath:application.properties")
@OpenAPIDefinition(
		info = @Info(
				title = "cpcipcrestweb",
				description = "CPC IPC Rest Web services",
				version = "v3.6.2.0"
//				contact = @Contact(
//						name = "",
//						email = "javaguides.net@gmail.com",
//						url = "https://www.javaguides.net"
//				),
//				license = @License(
//						name = "Apache 2.0",
//						url = "https://www.javaguides.net/license"
//				)
		),
		externalDocs = @ExternalDocumentation(
				description = "Spring Boot User Management Documentation",
				url = "https://www.javaguides.net/user_management.html"
		)
)
@Slf4j
public class SwaggerConfiguration 
	extends DelegatingWebMvcConfiguration {

	  @Autowired
	  Jackson2ObjectMapperBuilder jacksonBuilder;
	  
	  @Autowired 
	  ContentNegotiatingViewResolver contentNegotiatingViewResolver;

	  @Override
	  protected void configureMessageConverters(
			  List<HttpMessageConverter<?>> converters) {
//	    var applicationContext = this.getApplicationContext();
//	    if (applicationContext != null) {
//	      jacksonBuilder.applicationContext(applicationContext);
//	    }
//	    
		 
	    converters.add(new MappingJackson2HttpMessageConverter(jacksonBuilder.build()));
	    converters.add(new ByteArrayHttpMessageConverter());
//	    
	    converters.removeIf(c -> c instanceof StringHttpMessageConverter);
		 for (HttpMessageConverter converter: converters) {
			 log.error("converter for type {} for types {}", 
					 converter.getClass().getCanonicalName(), 
					 converter.getSupportedMediaTypes());
		 }
		 //throw new RuntimeException("failing configuration "+ converters);
	  }
	  
//	  <bean
//		class="org.springframework.http.converter.json.MappingJackson2HttpMessageConverter">
//		<property name="objectMapper" ref="jacksonObjectMapper" />
//	</bean>
//	  @Bean(name="mappingJackson2HttpMessageConverter")
//	  public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter(Jackson2ObjectMapperFactoryBean jacksonObjectMapper) {
//		  MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
//		  converter.setObjectMapper(jacksonObjectMapper.getObject());
//		  return converter;
//	  }
//	
//	  
//	  @Bean(name = "jacksonObjectMapper")
//	  public Jackson2ObjectMapperFactoryBean jacksonObjectMapper() {
//		  Jackson2ObjectMapperFactoryBean factory = new Jackson2ObjectMapperFactoryBean();
//		  factory.setSimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
//		  factory.setIndentOutput(true);
//		  factory.setFeaturesToDisable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
//		  return factory;
//	  }
	  
//	  <bean name="jacksonObjectMapper"
//				class="org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean"
//				p:simpleDateFormat="yyyy-MM-dd'T'HH:mm:ssZ" p:indentOutput="true">
//				<property name="featuresToDisable">
//					<array>
//						<util:constant
//							static-field="com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS" />
//
//					</array>
//				</property>
//
//				
//			</bean>
	
	  
//	@Override
//	protected void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
//		configurer.defaultContentType(MediaType.APPLICATION_JSON);
//		configurer.ignoreAcceptHeader(false);
//		super.configureContentNegotiation(configurer);
//		
//	}


//	@Bean
//	  public GroupedOpenApi adminApi() {
//	      return GroupedOpenApi.builder()
//	              .group("springshop-admin")
//	              .pathsToMatch("/**")
//	              
//	              //.addOpenApiMethodFilter(method -> method.isAnnotationPresent(Admin.class))
//	              .build();
//	  }
//	
	
	
	@Bean
	public OperationCustomizer addPublicationProposalHeader() {
	    return (operation, handlermethod) -> operation.addParametersItem(
	            new Parameter()
	                    .in(ParameterIn.HEADER.toString())
	                    .required(false)
	                    .description(RestUtils.SCHEME_PUBLICATION_PROPOSAL)
	                    .name(RestUtils.SCHEME_PUBLICATION_PROPOSAL));
	}
	
	@Bean
	public OperationCustomizer addSchemeDateHeader() {    		
		return (operation, handlermethod) -> operation.addParametersItem(
		   		new Parameter()
	                    .in(ParameterIn.HEADER.toString())
	                    .required(false)
	                    .description(RestUtils.SCHEME_PUBLICATION_DATE_HEADER)
	                    .name(RestUtils.SCHEME_PUBLICATION_DATE_HEADER))
	    	;
	}
	
    
	
//
//    @Bean
//    public ResourceHandlerRegistry swaggerRegistry(ResourceHandlerRegistry registry)
//    {
//        registry.addResourceHandler("/swagger-ui/**")
//        .addResourceLocations("classpath:/META-INF/resources/webjars/swagger-ui/4.14.3/");
//        return registry;
//    }
}
