package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationScheme;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ClassificationSchemeRepository;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import jakarta.annotation.Nonnull;
import jakarta.annotation.Nullable;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import lombok.RequiredArgsConstructor;

/**
 * Service for interacting with "Publications".  Publications are roughly equivilant to classifcation_scheme records
 * but are more targeted to the data about dates, versions and status of a tree of symbols on a given date.
 * 
 * @author 2020
 * @version 1.8
 * @date: 05/31/2017
 *
 */
@Service("publicationService")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class PublicationService {
	
	private static final Logger log = LoggerFactory.getLogger(PublicationService.class);

	@Nonnull
	private ClassificationSchemeRepository classificationSchemeRepository; 

	@Resource(name = "documentAdapterConfig")
    private Map<String, String> documentAdapterConfig;
	
	/**
	 * Gets published scheme versions
	 * @param minDate
	 * @return List<SchemePublicationVersion>
	 */
	public List<SchemePublicationVersion> getPublishedVersions(@Nullable Date minDate) {
		
		log.debug("Getting published versions");
	    if (minDate == null) {
	        minDate = new Date(0); // when null Assume Beginning of time is min!
	    }
	    List<SchemePublicationVersion> versions = new ArrayList<>();
	    List<ClassificationScheme> schemes = classificationSchemeRepository.findPublishedAndDistributedScheme(minDate);
	    
	    if(CollectionUtils.isNotEmpty(schemes)) {
	    	schemes.stream().limit(5).collect(Collectors.toList()).forEach(scheme -> 
	    		versions.add(mapSchemePublicationVersion(scheme)));	    
	    }	    
	    return versions;
	}

    /**
     * Maps the scheme publication version to contract object.
     * @param scheme
     * @return SchemePublicationVersion
     */
	public SchemePublicationVersion mapSchemePublicationVersion(@Nullable ClassificationScheme scheme) {
        SchemePublicationVersion version = null;
        if (scheme != null) {
            version = new SchemePublicationVersion();
            version.setPublicationDate(scheme.getSchemeVersionDate());
            version.setClassificationSchemeId(scheme.getId());
            version.setCpcXsdVersion(scheme.getSchemeXsd().getSchemaVersionId());
            version.setDefinitionXsdVersion(scheme.getDefinitionXsd().getSchemaVersionId());
            version.setDocumentAdapterClass(documentAdapterConfig.get(version.getCpcXsdVersion()));
            version.setCurrentIn(scheme.getCurrentIn());
            if(scheme.getDistributedIn() != null && scheme.getDistributedIn()) {
            	version.setDistributedCopyIn(scheme.getDistributedIn());
            	version.setGoldCopyIn(Boolean.FALSE);            	
            } else {
            	version.setDistributedCopyIn(Boolean.FALSE);
            	version.setGoldCopyIn(Boolean.TRUE);
            }            
        }
        return version;
    }	
}
