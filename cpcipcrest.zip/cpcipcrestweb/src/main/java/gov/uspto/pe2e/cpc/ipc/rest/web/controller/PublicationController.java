package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationStatusRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import gov.uspto.pe2e.cpc.ipc.rest.web.service.AdminPublicationService;
import gov.uspto.pe2e.cpc.ipc.rest.web.service.PublicationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import jakarta.annotation.Nonnull;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

/**
 * Class serves as Publication Controller
 * 
 * @author 2020
 * @date May 10, 2017
 * @version 1.8
 *
 */
@Component
@Api(value = "/publications", description = "Controller for Publications")
@RestController
@RequestMapping(value = "/publications")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class PublicationController {

    @Nonnull
    private PublicationService publicationService;

    @Nonnull
    private AdminPublicationService adminPublicationService;

    @Nonnull
    private SecurityService securityService;

    /**
     * Provide the list of publication versions.
     *
     * @param minDate
     * @return List<SchemePublicationVersion>
     */
    @ApiOperation("Provide list of publications version")
    @RequestMapping(value = "/versions", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<List<SchemePublicationVersion>> listPublicatons(
            @RequestParam(value = "minDate", required = false) Date minDate) {
        HttpStatus status = HttpStatus.OK;
        HttpHeaders headers = RestUtils.buildRestHttpHeaders();
        List<SchemePublicationVersion> publications = publicationService.getPublishedVersions(minDate);
        if (CollectionUtils.isEmpty(publications)) {
            status = HttpStatus.NO_CONTENT;
        }
        return new ResponseEntity<>(publications, headers, status);
    }

    /**
     * Update publication status and failure text for ClassificationSchemeStatus
     * @param proposalGuid Change proposal UUID
     * @param publicationStatusRequest Request contract for status and errorText
     * @return ResponseEntity
     */
    @ApiOperation("Update publication status and failure text")
    @RequestMapping(value = "/{UUID}", method = RequestMethod.PUT)
    @PreAuthorize("hasAuthority('PROPOSAL_MANAGER_ENABLED') and hasAuthority('PROPOSAL_REVISION_SAVE')")
    @ResponseBody
    public ResponseEntity<Void> updatePublicationStatusByGuid(@ApiParam("Change Proposal UUID") @RequestParam(value = "UUID") UUID proposalGuid,
                                                              @Valid @RequestBody PublicationStatusRequest publicationStatusRequest) {
        UsptoAuthenticationToken authToken = securityService
                .mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());

        adminPublicationService.updatePublicationStatus(proposalGuid, publicationStatusRequest, authToken.getEmail());

        return ResponseEntity
                .ok()
                .headers(RestUtils.buildRestHttpHeaders())
                .build();
    }
}