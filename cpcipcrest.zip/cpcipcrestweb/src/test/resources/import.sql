--
-- this is the sql that hibernate runs after executing any required DDL.  It only runs one time per
-- JVM start so make sure it loads sequence values, sets table permissions, etc
DROP SEQUENCE IF EXISTS CLASSIFICATION_SCHEME_SEQ;
create sequence CLASSIFICATION_SCHEME_SEQ increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS COMMENT_ID_SEQ;
create sequence COMMENT_ID_SEQ increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS CHANGE_PROPOSAL_ID_SEQ;
create sequence CHANGE_PROPOSAL_ID_SEQ increment by 1 start with 10000;
-- US324926
-- ALTER SEQUENCE CHANGE_PROPOSAL_VER_ID_SEQ RESTART WITH 10000;
-- US324926
-- ALTER SEQUENCE BATCH_PROCESS_ID_SEQ RESTART WITH 10000;
DROP SEQUENCE IF EXISTS TITLE_REVISION_ID_SEQ;
create sequence TITLE_REVISION_ID_SEQ increment by 1 start with 10000;
-- US324926
-- ALTER SEQUENCE RECLASS_TRANSFER_ID_SEQ RESTART WITH 10000;
DROP SEQUENCE IF EXISTS chng_prpsl_validation_id_seq;
create sequence chng_prpsl_validation_id_seq increment by 1 start with 10000;
DROP SEQUENCE IF EXISTS chng_prpsl_validation_msg_seq;
create sequence chng_prpsl_validation_msg_seq increment by 1 start with 10000;
DROP SEQUENCE IF EXISTS tech_field_hist_id_seq;
create sequence tech_field_hist_id_seq increment by 1 start with 10000;

-- US324926
--ALTER SEQUENCE description_note_id_seq RESTART WITH 10000;

-- US324926
-- ALTER SEQUENCE symbol_revision_id_seq RESTART WITH 10000;
-- ALTER SEQUENCE version_symbol_id_seq RESTART WITH 10000;
-- ALTER SEQUENCE component_revision_id_seq RESTART WITH 10000;

DROP SEQUENCE IF EXISTS note_warning_type_id_seq;
create sequence note_warning_type_id_seq increment by 1 start with 10000;
DROP SEQUENCE IF EXISTS cross_reference_id_seq;
create sequence cross_reference_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS change_proposal_comment_id_seq;
create sequence change_proposal_comment_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS change_proposer_role_id_seq;
create sequence change_proposer_role_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS tech_field_id_seq;
create sequence tech_field_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS task_assignee_group_id_seq;
create sequence task_assignee_group_id_seq increment by 1 start with 10000;
DROP SEQUENCE IF EXISTS state_task_id_seq;
create sequence state_task_id_seq increment by 1 start with 10000;
-- ALTER SEQUENCE change_proposal_scope_id_seq RESTART WITH 1000;
DROP SEQUENCE IF EXISTS change_proposal_subcls_id_seq;
create sequence change_proposal_subcls_id_seq increment by 1 start with 1000;
DROP SEQUENCE IF EXISTS symbol_hierarchy_scope_id_seq;
create sequence symbol_hierarchy_scope_id_seq increment by 1 start with 2000000000;

DROP SEQUENCE IF EXISTS change_proposal_doc_id_seq;
create sequence change_proposal_doc_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS twl_id_seq;
create sequence twl_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS twl_dtl_id_seq;
create sequence twl_dtl_id_seq increment by 1 start with 10000;
DROP SEQUENCE IF EXISTS change_proposal_dtl_id_seq;
create sequence change_proposal_dtl_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS change_proposal_dtl_id_seq;
create sequence change_proposal_dtl_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS change_proposal_alias_id_seq;
create sequence change_proposal_alias_id_seq increment by 1 start with 10000;
DROP SEQUENCE IF EXISTS user_detail_id_seq;
create sequence user_detail_id_seq increment by 1 start with 10000;
DROP SEQUENCE IF EXISTS role_id_seq;
create sequence role_id_seq increment by 1 start with 1000;

DROP SEQUENCE IF EXISTS related_project_id_seq;
create sequence related_project_id_seq increment by 1 start with 1000;
DROP SEQUENCE IF EXISTS related_project_symbol_id_seq;
create sequence related_project_symbol_id_seq increment by 1 start with 1000;

DROP SEQUENCE IF EXISTS pap_score_id_seq;
create sequence pap_score_id_seq increment by 1 start with 10000;

DROP SEQUENCE IF EXISTS eb_checklist_id_seq;
create sequence eb_checklist_id_seq increment by 1 start with 10000;

-- US422846
DROP SEQUENCE IF EXISTS scheme_hierarchy_seq;
create sequence scheme_hierarchy_seq increment by 1 start with 1000000;
DROP SEQUENCE IF EXISTS definition_hierarchy_seq;
create sequence definition_hierarchy_seq increment by 1 start with 1000000;
-- ALTER SEQUENCE definition_hierarchy_seq RESTART WITH 1000000;

DROP SEQUENCE IF EXISTS draft_proposal_number_seq;
create sequence draft_proposal_number_seq increment by 1 start with 1000;

DROP SEQUENCE IF EXISTS sandbox_proposal_number_seq;
create sequence sandbox_proposal_number_seq increment by 1 start with 10;

DROP SEQUENCE IF EXISTS cef_proposal_number_seq;
create sequence cef_proposal_number_seq increment by 1 start with 1000;

-- No entity exists for this table
--CREATE TABLE shedlock(name VARCHAR(64) NOT NULL, lock_until TIMESTAMP NOT NULL, locked_at TIMESTAMP NOT NULL, locked_by VARCHAR(255) NOT NULL, PRIMARY KEY (name));


