package gov.uspto.pe2e.cpc.ipc.rest.web.enumeration;

import org.junit.Assert;
import org.junit.Test;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.StandardField;


public class StandardFieldTest {
  
    @Test
    public void testFromStandardField() {
        String fieldName = StandardField.CREATE_TS.getFieldName();
        Assert.assertEquals("createTs", fieldName);
        
        Object type = StandardField.CREATE_USER_ID.getFieldType();
        Assert.assertEquals(Class.class, type.getClass());
    }

}
