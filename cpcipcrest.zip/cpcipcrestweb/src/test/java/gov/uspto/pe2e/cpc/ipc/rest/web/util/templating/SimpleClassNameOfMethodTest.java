package gov.uspto.pe2e.cpc.ipc.rest.web.util.templating;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import freemarker.template.Configuration;
import freemarker.template.SimpleScalar;
import freemarker.template.TemplateModelException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ApplicationConfigurationException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.SimpleClassNameOfMethod;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.TemplateConfigurationLocator;
public class SimpleClassNameOfMethodTest {
    

    @Test
    public void testExec() throws TemplateModelException {
        
        SimpleClassNameOfMethod method = new SimpleClassNameOfMethod();
        String className = (String)method.exec(Arrays.asList(SimpleScalar.newInstanceOrNull("TEST 90")));
        Assert.assertEquals("String", className);
        
    }

    
    @Test(expected=TemplateModelException.class)
    public void testTooManyArgs() throws TemplateModelException {
        SimpleClassNameOfMethod method = new SimpleClassNameOfMethod();
        method.exec(Arrays.asList("Test", "Test 2", "Test 3"));
    }
    
    @Test
    public void testApplicationConfigurationException () {
			try {
				testApplicationException();
			} catch (ApplicationConfigurationException e) {
				Assert.assertNotNull(e);
				e.printStackTrace();
			}
    }
    
    @Test
    public void testApplicationConfigurationExceptionWithMessage() {
    	try {
    		testApplicationExceptionWithMessage();
		} catch (ApplicationConfigurationException e) {
			Assert.assertEquals("Configuration Error", e.getMessage());
			e.printStackTrace();
		}       
    }
    
    @Test
    public void testApplicationConfigurationExceptionWithThrowable() {
    	try {
    		testApplicationExceptionWithThrowable();
		} catch (ApplicationConfigurationException e) {
			Assert.assertEquals("Error in Configuration", e.getCause().getMessage());
			e.printStackTrace();
		}       
    }
    
    @Test
    public void testApplicationConfigurationExceptionWithMessageAndThrowable() {
    	try {
    		testApplicationExceptionWithThrowableWithMessageAndThrowable();
		} catch (ApplicationConfigurationException e) {
			Assert.assertEquals("Configuration Error", e.getMessage());
			Assert.assertEquals("Error in Configuration", e.getCause().getMessage());
			e.printStackTrace();
		}       
    }
    
    
    @Test
    public void testApplicationConfigurationExceptionWithStackTrace() {
    	try {
    		testApplicationExceptionWithStackTrace();
		} catch (ApplicationConfigurationException e) {
			Assert.assertEquals("Configuration Error", e.getMessage());
			Assert.assertEquals("Error in Configuration", e.getCause().getMessage());
			e.printStackTrace();
		}       
    }
    
    @Before
    public void setup() throws ApplicationConfigurationException {
        Configuration cfg = new TemplateConfigurationLocator().configure(null).getConfiguration();
        
    }
    
    private void testApplicationException() throws ApplicationConfigurationException {
    	throw new ApplicationConfigurationException();
    }
    
    private void testApplicationExceptionWithMessage() throws ApplicationConfigurationException {
    	throw new ApplicationConfigurationException("Configuration Error");
    }
    
    private void testApplicationExceptionWithThrowable() throws ApplicationConfigurationException {
    	throw new ApplicationConfigurationException(new Throwable("Error in Configuration"));
    }
    
    private void testApplicationExceptionWithThrowableWithMessageAndThrowable() throws ApplicationConfigurationException {
    	throw new ApplicationConfigurationException("Configuration Error", new Throwable("Error in Configuration"));
    }
    
    private void testApplicationExceptionWithStackTrace() throws ApplicationConfigurationException {
    	throw new ApplicationConfigurationException("Configuration Error", new Throwable("Error in Configuration"), false, false);
    }
}
