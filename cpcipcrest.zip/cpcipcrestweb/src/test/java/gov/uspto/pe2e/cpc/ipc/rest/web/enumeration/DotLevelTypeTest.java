package gov.uspto.pe2e.cpc.ipc.rest.web.enumeration;

import org.junit.After;
import org.junit.Assert;
import org.junit.Test;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.DotLevelType;


public class DotLevelTypeTest {

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testFromIndentLevel() {
        DotLevelType dlt = DotLevelType.fromIndentLevel(8);
        Assert.assertEquals(DotLevelType.SUBGROUP, dlt);
        Assert.assertEquals("G.Heading",DotLevelType.fromIndentLevel(6).getDisplayValue());
        
        dlt = DotLevelType.fromIndentLevel(1);
        Assert.assertEquals(DotLevelType.SECTION, dlt);

        dlt = DotLevelType.fromIndentLevel(3);
        Assert.assertEquals(DotLevelType.SUBSECTION, dlt);

    }

}
