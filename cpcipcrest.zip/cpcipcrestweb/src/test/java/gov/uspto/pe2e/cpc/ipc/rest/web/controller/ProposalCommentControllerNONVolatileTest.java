package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalComment;
import gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalCommentController;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
/**
 * NOTE: Do not add tests to THIS class if they update the database.
 * all Volatile tests should go in @see ProposalCommentControllerVolatileTest
 * @author myoung3
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
//@Test(suiteName= "nonvolatile")
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalCommentControllerNONVolatileTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalCommentControllerNONVolatileTest.class);
    
    @Inject
    private ProposalCommentController proposalCommentController;
    
    private static Date initDate = null;
    
    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Test
    public void testListNoArgs() {
    	log.debug("Testing no arg list");
    	ResponseEntity<List<ProposalComment>> resp = proposalCommentController.listComments(UUID.randomUUID());
    	Assert.assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
    	log.debug("Comment list ={}", resp.getBody());
    //	Assert.assertTrue(CollectionUtils.isNotEmpty(resp.getBody()));
    	
    	
    	
    }
    @Transactional
    @Test
    public void testListKnownProposal() {
    	log.debug("Testing no arg list");
    	ResponseEntity<List<ProposalComment>> resp = proposalCommentController.listComments(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
    	Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
    	log.debug("Comment list ={}", resp.getBody());
    	Assert.assertTrue(CollectionUtils.isNotEmpty(resp.getBody()));
    	assertEquals(5, resp.getBody().size());
    }
    
    @Before
    public void setUp() throws Exception {
    	log.debug("Running setup() this should only run once for this whole test class");
    	datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test"), 
                		new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    	
    }

}
