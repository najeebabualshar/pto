package gov.uspto.pe2e.cpc.ipc.rest.testingsupport;

public class RestTemplateMockKey {

}
