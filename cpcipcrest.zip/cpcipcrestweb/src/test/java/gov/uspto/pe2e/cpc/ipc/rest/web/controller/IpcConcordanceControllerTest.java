package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.Arrays;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcConcordanceMapping;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class IpcConcordanceControllerTest {
    
	@Inject 
    private IpcConcordanceController ipcConcordanceController;
	
	@Inject
	private DatasetTestingService datasetTestingService;

    /**
     * This should throw exception based on being too small
     * 
     * @since Feb 6, 2017
     */
    @Test(expected=IllegalArgumentException.class)
    public void testSearchWithTooSmallSymbolName() {
        ipcConcordanceController.search(SymbolName.parse("A01"));
    }
    
    @Test
    public void testGetIPCConcordance() {
    	ResponseEntity<List<IpcConcordanceMapping>> resp = ipcConcordanceController.getIPCConcordance(Arrays.asList("A01B"));
    	Assert.assertNotNull(resp);
    	Assert.assertEquals("A01B", resp.getBody().get(0).getSymbolName());
    	Assert.assertEquals(null, resp.getBody().get(0).getGeneratedIpcSymbol());
    	Assert.assertEquals(null, resp.getBody().get(0).getOverrideIpcSymbol());
    	
    	resp = ipcConcordanceController.getIPCConcordance(Arrays.asList("A01F25/00"));
    	Assert.assertNotNull(resp);
    	Assert.assertEquals("A01F25/00", resp.getBody().get(0).getSymbolName());
    	Assert.assertEquals("A01F25/00", resp.getBody().get(0).getGeneratedIpcSymbol().getIpcSymbolName());
    	Assert.assertEquals(null, resp.getBody().get(0).getOverrideIpcSymbol());
    	
    }
    
    @Test
    public void testSearchWithBigSymbolNameWithGreaterThan4Characters() {
    	ResponseEntity<List<String>> resp = ipcConcordanceController.search(SymbolName.parse("A01F25/00"));
    	Assert.assertNotNull(resp);
    	Assert.assertEquals("A01F25/00", resp.getBody().get(0));
    	
    	resp = ipcConcordanceController.search(SymbolName.parse("A01F25/02324"));
    	Assert.assertNotNull(resp);
    	Assert.assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
    }
    
    @Before
	public void setUp() throws Exception {
		
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    	DateTimeZone.setDefault(DateTimeZone.UTC);
    	datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1", "user@user.com",
				Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(token);
		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
		
	}

}
