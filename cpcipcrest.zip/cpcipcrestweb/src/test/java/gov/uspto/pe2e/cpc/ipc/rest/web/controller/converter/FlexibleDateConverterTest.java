package gov.uspto.pe2e.cpc.ipc.rest.web.controller.converter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Date;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Before;
import org.junit.Test;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FlexibleDateConverterTest {

	
	private static FlexibleDateConverter converter = new FlexibleDateConverter();
	
	@Test
	public void testConvert() {
		Date date =  converter.convert("Sun, 09 Oct 2022 13:30:59 GMT");
		assertNotNull(date);
		DateTime dt =  new DateTime(date);
		assertEquals(2022, dt.getYear());
		assertEquals(DateTimeZone.forID("UTC"), dt.getZone());
		assertEquals(10, dt.getMonthOfYear());
		assertEquals(9, dt.getDayOfMonth());
		assertEquals(7, dt.getDayOfWeek());
		assertEquals(13, dt.getHourOfDay());
		assertEquals(30, dt.getMinuteOfHour());
		assertEquals(59, dt.getSecondOfMinute());
		assertEquals(0, dt.getMillisOfSecond());
				
		date =  converter.convert("2021-07-04");
		assertNotNull(date);
		dt =  new DateTime(date);
		assertEquals(2021, dt.getYear());
		assertEquals(7, dt.getMonthOfYear());
		assertEquals(4, dt.getDayOfMonth());
		assertEquals(7, dt.getDayOfWeek());
		assertEquals(0, dt.getHourOfDay());
		assertEquals(0, dt.getMinuteOfHour());
		assertEquals(0, dt.getSecondOfMinute());
		assertEquals(0, dt.getMillisOfSecond());
		assertEquals(DateTimeZone.forID("UTC"), dt.getZone());


		date =  converter.convert("2021-07-04T13:05:55.999Z");
		assertNotNull(date);
		dt =  new DateTime(date);
		assertEquals(2021, dt.getYear());
		assertEquals(7, dt.getMonthOfYear());
		assertEquals(4, dt.getDayOfMonth());
		assertEquals(7, dt.getDayOfWeek());
		assertEquals(13, dt.getHourOfDay());
		assertEquals(5, dt.getMinuteOfHour());
		assertEquals(55, dt.getSecondOfMinute());
		assertEquals(999, dt.getMillisOfSecond());
		assertEquals(DateTimeZone.forID("UTC"), dt.getZone());
		
		date = converter.convert("");
		assertNull(date);
		
		try {
			date =  converter.convert("this is not a date");
			fail("Invalid date parse did not throw illegal argument exception as expected");
		} catch (Exception e) {
			log.debug("exception message = {}",e.getMessage());
			assertTrue(e.getMessage().startsWith("Failed to parse 'this is not a date' using any of the accepted Date formats"));
		}

		


	}
	
	@Before
	public void setUp() throws Exception {
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
	}
}
