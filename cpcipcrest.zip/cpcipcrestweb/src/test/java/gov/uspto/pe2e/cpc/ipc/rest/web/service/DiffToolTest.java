package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

import javax.xml.transform.TransformerException;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.difflib.algorithm.DiffException;
import com.github.fge.jsonpatch.diff.JsonDiff;

import fun.mike.dmp.Diff;
import fun.mike.dmp.DiffMatchPatch;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.web.util.business.CpcDiffTool;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:META-INF/spring/applicationContext.xml", "classpath:META-INF/spring/applicationContext-test.xml"})
public class DiffToolTest {
	private static final Logger log = LoggerFactory.getLogger(DiffToolTest.class);
	
	@Inject
	private TitleService titleService;

	@Inject
	private MockCpcDiffService cpcDiffService;
	
	//TODO Figure out how to mock these tests out
	
	//Uncomment this test case and fix it if you think it is still needed
//	@Test 
	public void testDiffOperation() throws IOException, TransformerException {
		RevisionChangeItemRequest sctRow = new RevisionChangeItemRequest();
		sctRow.setSymbolName("A01N");
		sctRow.setDotLevel("3");
		sctRow.setTitleGrammar("TEST 1; Test 123");
		
		Object o = cpcDiffService.diffAgainstGoldCopy(sctRow);
		assertNotNull(o);
		log.debug("{}", JaxbUtils.marshalToString(o));
		
		log.debug("{}", JsonUtils.toJson(o));
	}
	
	@Test
	public void testGoldCopy() throws GrammarParseException {
		String t1 = "PRESERVATION OF BODIES OF HUMANS OR ANIMALS OR PLANTS OR PARTS THEREOF;BIOCIDES, e.g. AS DISINFECTANTS, AS PESTICIDES, AS HERBICIDES (preparations for medical, dental or toilet purposes ##SYMBOL##A61K##/SYMBOL##; methods or apparatus for disinfection or sterilisation in general, or for deodorising of air ##SYMBOL##A61L##/SYMBOL##);PEST REPELLANTS OR ATTRACTANTS (decoys ##SYMBOL##A01M1/06##/SYMBOL##; medicinal preparations ##SYMBOL##A61K##/SYMBOL##);PLANT GROWTH REGULATORS (compounds in general ##SYMBOL##C01##/SYMBOL##, ##SYMBOL##C07##/SYMBOL##, ##SYMBOL##C08##/SYMBOL##; fertilisers ##SYMBOL##C05##/SYMBOL##; soil conditioners or stabilisers ##SYMBOL##C09K17/00##/SYMBOL##)";
		String t2 = "PRESERVATION OF BODIES OF ##BOLD##HUMANS##/BOLD## OR ANIMALS OR PLANTS OR PARTS THEREOF;BIOCIDES, e.g. AS DISINFECTANTS, AS PESTICIDES, AS HERBICIDES (preparations for medical, dental or toilet purposes ##SYMBOL##A61K##/SYMBOL##; methods or apparatus for disinfection or sterilisation in general, or for deodorising of air ##SYMBOL##A61L##/SYMBOL##);PEST REPELLANTS OR ATTRACTANTS (decoys ##SYMBOL##A01M1/06##/SYMBOL##; medicinal preparations ##SYMBOL##A61K##/SYMBOL##);PLANT GROWTH REGULATORS (compounds in general ##SYMBOL##C01##/SYMBOL##, ##SYMBOL##C07##/SYMBOL##, ##SYMBOL##C08##/SYMBOL##; fertilisers ##SYMBOL##C05##/SYMBOL##; conditioners or stabilisers ##SYMBOL##C09K17/01##/SYMBOL##)";
		TitlePartTree tree1 = titleService.fromGrammar(t1);

		TitlePartTree tree2 = titleService.fromGrammar(t2);

		JsonNode jsonTree1 = CpcDiffTool.DIFF_MAPPER.valueToTree(tree1);
		jsonTree1 = CpcDiffTool.breakTextNodesOnWhiteSpace(jsonTree1);
		JsonNode jsonTree2 = CpcDiffTool.DIFF_MAPPER.valueToTree(tree2);

		jsonTree2 = CpcDiffTool.breakTextNodesOnWhiteSpace(jsonTree2);
		
		JsonNode patch = JsonDiff.asJson(jsonTree1, jsonTree2);
//		Pair<JsonNode,JsonNode> fixedNodePair = CpcDiffTool.realignTextDiffs(jsonTree1, jsonTree2, patch);
//		jsonTree1 = fixedNodePair.getLeft();
//		jsonTree2 = fixedNodePair.getRight();
//		patch = JsonDiff.asJson(jsonTree1, jsonTree2);
		assertNotNull(patch);
		
		log.debug("jsonpatch = {}", patch);
		
//		Iterator<JsonNode> elements = patch.elements();
//		
//		while (elements.hasNext()) {
//			JsonNode patchEl = elements.next();
//			assertEquals("replace",patchEl.get("op").asText());
//			String path = patchEl.get("path").asText();
//			JsonNode node = jsonTree1.at(path);
//			
//			log.debug("Node = {} at path {}", node.getNodeType(), path);
//			
//		}
//		
	}
	
	@Test
	public void test() throws GrammarParseException {
		TitlePartTree tree1 = titleService.fromGrammar("This is a test; test 1; ##SYMBOL##A01N01/1007##/SYMBOL##");

		TitlePartTree tree2 = titleService.fromGrammar("This is a test; test 2; ##SYMBOL##A01N01/1008##/SYMBOL##");

		JsonNode jsonTree1 = CpcDiffTool.DIFF_MAPPER.valueToTree(tree1);
		jsonTree1 = CpcDiffTool.breakTextNodesOnWhiteSpace(jsonTree1);
		JsonNode jsonTree2 = CpcDiffTool.DIFF_MAPPER.valueToTree(tree2);

		jsonTree2 = CpcDiffTool.breakTextNodesOnWhiteSpace(jsonTree2);
		
		JsonNode patch = JsonDiff.asJson(jsonTree1, jsonTree2);
//		Pair<JsonNode,JsonNode> fixedNodePair = CpcDiffTool.realignTextDiffs(jsonTree1, jsonTree2, patch);
//		jsonTree1 = fixedNodePair.getLeft();
//		jsonTree2 = fixedNodePair.getRight();
//		patch = JsonDiff.asJson(jsonTree1, jsonTree2);		
		
		log.debug("jsonpatch = {}", patch);
		
		Iterator<JsonNode> elements = patch.elements();
		
		while (elements.hasNext()) {
			JsonNode patchEl = elements.next();
			assertEquals("replace",patchEl.get("op").asText());
			String path = patchEl.get("path").asText();
			JsonNode node = jsonTree1.at(path);
			
			log.debug("Node = {} at path {}", node.getNodeType(), path);
			
		}
		
//		assertEquals()
//		
	}
	
	@Test
	public void testStringDiff() throws DiffException {
		String s1 = "  test 1 ";
		String s2 = " test 2 ";
		log.debug("Levenshteindiff = {}" , StringUtils.getLevenshteinDistance(s1, s2));
		DiffMatchPatch dmp = new DiffMatchPatch();
	    LinkedList<Diff> diffs = dmp.diff_main(s1,s2);
	    dmp.diff_cleanupSemanticLossless(diffs);
	    log.debug("diffs = {}",diffs);
	    assertNotNull(diffs);
	}
	@Test
	public void testNodeRemoved() throws GrammarParseException {
		ObjectMapper mapper = new ObjectMapper();
		TitlePartTree tree1 = titleService.fromGrammar("This is a test; test 1; ##SYMBOL##A01N01/1007##/SYMBOL##");
		JsonNode jsonTree1 = mapper.valueToTree(tree1);

		TitlePartTree tree2 = titleService.fromGrammar("This is a test; ##SYMBOL##A01N01/1007##/SYMBOL##");
		JsonNode jsonTree2 = mapper.valueToTree(tree2);
	
		JsonNode patch = JsonDiff.asJson(jsonTree1, jsonTree2);
		log.debug("jsonpatch = {}", patch);
		
		Iterator<JsonNode> elements = patch.elements();
		
		while (elements.hasNext()) {
			JsonNode op = elements.next();
			log.debug(op.get("op").asText());
			assertTrue(Arrays.asList("remove","replace","add").contains(op.get("op").asText()));
		}
	}
	@Test
	public void testNodeRemovedAndAnotherChanged() throws GrammarParseException {
		ObjectMapper mapper = new ObjectMapper();
		TitlePartTree tree1 = titleService.fromGrammar("This is a test; test 1; ##SYMBOL##A01N01/1007##/SYMBOL##");
		JsonNode jsonTree1 = mapper.valueToTree(tree1);

		TitlePartTree tree2 = titleService.fromGrammar("This is a test; ##SYMBOL##A01N01/1008##/SYMBOL##");
		JsonNode jsonTree2 = mapper.valueToTree(tree2);
	
		JsonNode patch = JsonDiff.asJson(jsonTree1, jsonTree2);
		log.debug("jsonpatch = {}", patch);
		
		Iterator<JsonNode> elements = patch.elements();
		int i = 0;
		while (elements.hasNext()) {
			
			JsonNode op = elements.next();
			if (i==0) {
				assertEquals("remove",op.get("op").asText());
			} else if (i == 1) {
				assertEquals("replace",op.get("op").asText());
			} else {
				assertEquals("add", op.get("op").asText());
			}
			i++;
		}
		assertEquals(3,i);
	}

	@Test
	public void testNodeRemovedAndAnotherChangedAndInserted() throws GrammarParseException {
		ObjectMapper mapper = new ObjectMapper();
		TitlePartTree tree1 = titleService.fromGrammar("This is a test; test 1; ##SYMBOL##A01N01/1007##/SYMBOL##");
		JsonNode jsonTree1 = mapper.valueToTree(tree1);

		TitlePartTree tree2 = titleService.fromGrammar("This is a test;##BOLD##Testing##/BOLD## ##SYMBOL##A01N01/1008##/SYMBOL##");
		JsonNode jsonTree2 = mapper.valueToTree(tree2);
	
		JsonNode patch = JsonDiff.asJson(jsonTree1, jsonTree2);
		log.debug("jsonpatch = {}", patch);
		
		Iterator<JsonNode> elements = patch.elements();
		
		int i = 0;
		while (elements.hasNext()) {
			
			JsonNode op = elements.next();
			if (i==0) {
				assertEquals("remove",op.get("op").asText());
			} else if (Arrays.asList(1,2).contains(i)) {
				assertEquals("replace",op.get("op").asText());
			} else if (Arrays.asList(3,4,5).contains(i)) {
				assertEquals("add",op.get("op").asText());
			}
			
			i++;
		}
		assertEquals(5,i);
	}
	
	
	
	@Test
	public void testChangeType() throws GrammarParseException {
		ObjectMapper mapper = new ObjectMapper();
		TitlePartTree tree1 = titleService.fromGrammar("This is a test");
		JsonNode jsonTree1 = mapper.valueToTree(tree1);

		TitlePartTree tree2 = titleService.fromGrammar("This##BOLD## is##/BOLD## a test");
		JsonNode jsonTree2 = mapper.valueToTree(tree2);
	
		JsonNode patch = JsonDiff.asJson(jsonTree1, jsonTree2);
		assertNotNull(patch);
		log.debug("jsonpatch = {}", patch);
		
		Iterator<JsonNode> elements = patch.elements();
		
//		int i = 0;
//		while (elements.hasNext()) {
//			
//			JsonNode op = elements.next();
//			if (i==0) {
//				assertEquals("remove",op.get("op").asText());
//			} else if (Arrays.asList(1,2).contains(i)) {
//				assertEquals("replace",op.get("op").asText());
//			} else if (Arrays.asList(3,4,5).contains(i)) {
//				assertEquals("add",op.get("op").asText());
//			}
//			
//			i++;
//		}
//		assertEquals(5,i);
		
	}
	
}
