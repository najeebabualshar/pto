package gov.uspto.pe2e.cpc.ipc.rest.web.service.adapter;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.CloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.LocalTestCloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.S3CloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.UnifiedCloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.CloudResource;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.MetadataKey;
import gov.uspto.pe2e.cpc.ipc.rest.rm.service.ResourceService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class S3CloudResourcePersistenceServiceTest {
	private static final Logger log = LoggerFactory.getLogger(S3CloudResourcePersistenceServiceTest.class);
	
	/**
	 * Injection/wiring candidate selected explicitly in applicationContext-test.xml
	 * Unit test uses local filesystem instead of s3 cloud
	 */
	@Inject
	private CloudResourcePersistenceService cloudResourcePersistenceService;
	
	@Inject
	private ResourceService resourceService;
	
	@Inject 
    private UnifiedCloudResourcePersistenceService unifiedCloudResourcePersistenceService;
    
    @Inject 
    private LocalTestCloudResourcePersistenceService localTestCloudResourcePersistenceService;
	
	/**
	 * This is the real deal Always since we wire by the concrete class instead of interface name
	 */
	@Inject 
	private S3CloudResourcePersistenceService s3CloudResourcePersistenceService;

	@Transactional
	@Test
	public void testPersist() throws IOException {
	    CloudResource res = new CloudResource();
        res.setBytes("<dataset></dataset>".getBytes());
        List<Pair<String,String>> kvpList = Arrays.asList(
                Pair.of(MetadataKey.ORIGINAL_FILENAME.name(), "test1.xml"),
                Pair.of(MetadataKey.CREATE_USERID.name(), "user1"));
        Map<String,String> metadata = new HashMap<>();
        for (Pair<String,String> kvp: kvpList) {
            metadata.put(kvp.getLeft(), kvp.getRight());
        }
        unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));
        res =cloudResourcePersistenceService.persist(resourceService.resolveResourceName(res.getId()), res.getBytes(), metadata, true);
        Assert.assertNotNull(res);
        Assert.assertNotNull(res.getId());
        Assert.assertEquals(19,res.getBytes().length);
        Assert.assertEquals(2, res.getMetadata().size());
	}
	
	@Test
	public void testParseS3Bucket() {
	    S3CloudResourcePersistenceService svc = new S3CloudResourcePersistenceService();
	    String bucket = svc.parseS3Bucket("http://google.com:8080/linux/help/kernel");
	    log.debug("bucket={}",bucket);
	    Assert.assertEquals("linux", bucket);
	    String prefix = svc.parseS3ResourcePathPrefix("http://google.com:8080/linux/help/kernel", bucket);
	    log.debug("prefix={}", prefix);
	    Assert.assertEquals("help/kernel", prefix);

	    bucket = svc.parseS3Bucket("http://google.com:8080/linux/help/kernel/");
        log.debug("bucket={}",bucket);
        Assert.assertEquals("linux", bucket);
        prefix = svc.parseS3ResourcePathPrefix("http://google.com:8080/linux/help/kernel/", bucket);
        log.debug("prefix={}", prefix);
        Assert.assertEquals("help/kernel", prefix);


        bucket = svc.parseS3Bucket("http://google.com:8080/linux/help/kernel///");
        log.debug("bucket={}",bucket);
        Assert.assertEquals("linux", bucket);
        prefix = svc.parseS3ResourcePathPrefix("http://google.com:8080/linux/help/kernel///", bucket);
        log.debug("prefix={}", prefix);
        Assert.assertEquals("help/kernel", prefix);
	    
	}

	
	@Test
	public void testResolveURL() throws MalformedURLException {
	    S3CloudResourcePersistenceService svc = new S3CloudResourcePersistenceService();
	    svc.setS3BaseUrl("https://s3.amazonaws.com/mybigbucket/preflev1/preflev2");

	    svc.init();
	    String uri = svc.resolveResourceName("mypicture.gif");
	    log.debug("uri = {}", uri);
	    Assert.assertEquals("preflev1/preflev2/generated/mypicture.gif", uri);
	    uri = svc.resolveResourceName("help/search_box.html");
	    log.debug("uri = {}", uri);

        Assert.assertEquals("preflev1/preflev2/help/search_box.html", uri);

	}
	
	@Test
	public void testResolveResourceName() {
	    
	    String name = s3CloudResourcePersistenceService.resolveResourceName("/test1");
	    log.debug("uri = {}",name);
	    Assert.assertEquals("test1", name);
	}

	
	@Before
	public void setup() {
		log.debug("CloudResourcePersistenceService impl = {}", cloudResourcePersistenceService.getClass().getCanonicalName() );
	}

}
