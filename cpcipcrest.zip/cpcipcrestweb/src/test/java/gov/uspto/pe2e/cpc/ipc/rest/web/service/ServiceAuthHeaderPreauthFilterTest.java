/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.TimeZone;

import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.chrono.ISOChronology;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.jee.filter.ServiceAuthHeaderPreAuthFilter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.ServiceAuthUserDetailsService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.UsptoSAMLUserDetailsService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author 2020
 * @date Nov 16, 2015 3:22:46 PM
 * @version
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@Slf4j
public class ServiceAuthHeaderPreauthFilterTest {
	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private UsptoSAMLUserDetailsService usptoSAMLUserDetailsService;

	@Inject
	private ServiceAuthUserDetailsService serviceAuthUserDetailsService;

	@Before
	public void setUp() throws Exception {
		datasetTestingService.loadOnce();

	}

	@Test
	public void testFilter() {
		// AuthenticationManager aman = new ProviderManager(new ArrayList<>());
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
		SecurityService svc = new SecurityService(this.usptoSAMLUserDetailsService);
		svc.setServiceAuthClientSecret("Secret123secret123");

		SecurityService mockedSvc = spy(svc);
		when(mockedSvc.getNow()).thenReturn(new DateTime(2019, 1, 7, 11, 55, ISOChronology.getInstance()));

		ServiceAuthHeaderPreAuthFilter filter = new ServiceAuthHeaderPreAuthFilter();
		filter.setSecurityService(mockedSvc);

		MockHttpServletRequest req = (MockHttpServletRequest) WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb",
				"/symbols");

		req.addHeader(ServiceAuthHeaderPreAuthFilter.SERVICE_AUTH_HEADER_NAME, "c2be9f8409d6783daba0133a9ae0adc2");

		PreAuthenticatedAuthenticationToken token = (PreAuthenticatedAuthenticationToken) filter
				.getPreAuthenticatedCredentials(req);

		UserDetails details = serviceAuthUserDetailsService.loadUserDetails(token);
		assertEquals("cpccollaborationsupport@uspto.gov", details.getUsername());

		UserDetails detailsByName = serviceAuthUserDetailsService.loadUserByUsername((String) token.getPrincipal());
		assertEquals(details.getUsername(), detailsByName.getUsername());

		assertTrue(CollectionUtils.isEqualCollection(details.getAuthorities(), detailsByName.getAuthorities()));
//	    	SecurityService svc =  new SecurityService(this.usptoSAMLUserDetailsService);	
//	    	svc.setServiceAuthClientSecret("Secret123secret123");
	    	log.debug("Header for now is {}", svc.getServiceAuthHeader());
//	    	
//	    	    	String header = mockedSvc.getServiceAuthHeader();
//	    	log.debug("header returned={}", header);
//	    	assertEquals("c2be9f8409d6783daba0133a9ae0adc2", header);
//
		// filter.setAuthenticationManager(aman);
	}
	
	@Test
	public void testGenerateCurrentHeader() {
		// AuthenticationManager aman = new ProviderManager(new ArrayList<>());
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
		

	    SecurityService svc =  new SecurityService(this.usptoSAMLUserDetailsService);	
	    svc.setServiceAuthClientSecret("secretsecretsecret");
	    log.debug("Header for now is {}", svc.getServiceAuthHeader());

	}

}
