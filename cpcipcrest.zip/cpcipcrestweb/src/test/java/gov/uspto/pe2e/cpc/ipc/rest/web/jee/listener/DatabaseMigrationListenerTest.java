package gov.uspto.pe2e.cpc.ipc.rest.web.jee.listener;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.mock.web.MockServletContext;

import jakarta.servlet.ServletContextEvent;

public class DatabaseMigrationListenerTest {
    
    @Test
    public void testNOTdoingMigration() {
        DatabaseMigrationListener listener = new DatabaseMigrationListener();
        listener.initProperties();
        Assert.assertFalse(listener.isDoMigration());
        MockServletContext sc = new MockServletContext("");
//        sc.addInitParameter(ContextLoader.CONTEXT_CLASS_PARAM,
//                "org.springframework.web.servlet.SimpleWebApplicationContext");
        ServletContextEvent event = new ServletContextEvent(sc);
        long startMs = System.currentTimeMillis();
        listener.contextInitialized(event);
        long endMs = System.currentTimeMillis();
        
        Assert.assertTrue( (endMs-startMs) < 100); // Time is < 30 sec (standard wait time to kill server if accidental or errant migration is detected)
        
        
        
    }

    @Test
    public void testInitProperties() {
        DatabaseMigrationListener listener = new DatabaseMigrationListener();
        listener.initProperties();
        Assert.assertFalse(listener.isDoMigration());
    }

}
