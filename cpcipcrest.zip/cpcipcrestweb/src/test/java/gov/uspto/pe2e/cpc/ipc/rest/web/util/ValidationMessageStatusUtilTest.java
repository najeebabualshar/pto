package gov.uspto.pe2e.cpc.ipc.rest.web.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;

public class ValidationMessageStatusUtilTest {

    @Test
    public void test() {
        List<ValidationMessage> validationMessages = new ArrayList<>();
        Assert.assertTrue(ValidationMessageStatusUtil.ensureNoErrorLevelMessagesExist(validationMessages));
        
        ValidationMessage msg = new ValidationMessage();
        msg.setLevel(ValidationMessageLevel.WARNING);
        validationMessages.add(msg);
        Assert.assertTrue(ValidationMessageStatusUtil.ensureNoErrorLevelMessagesExist(validationMessages));
        
        ValidationMessage err = new ValidationMessage();
        err.setLevel(ValidationMessageLevel.ERROR);
        validationMessages.add(err);
        Assert.assertFalse(ValidationMessageStatusUtil.ensureNoErrorLevelMessagesExist(validationMessages));
        
    }
    
    
    

}
