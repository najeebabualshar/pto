package gov.uspto.pe2e.cpc.ipc.rest.test.app;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Map;
import java.util.Scanner;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.AdapterUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalDetailsVerificationController;

public class ApiToGoldCopy {
    private File xmlDir;
    private File exportDir;
    
    private OutputStream os;  
    
    private ApplicationContext appContext;
    
    
    
    
    
    public static void main(String[] args) {
        ApiToGoldCopy app = new ApiToGoldCopy();
        app.collectExportConfigDetails();
        app.export();
        app.cleanup();
       
    }

    private void cleanup() {
        // TODO Auto-generated method stub
        System.out.println("Export Complete: "+exportDir.getAbsolutePath());
        String zipName = exportDir.getAbsolutePath()+".zip"; 
        try {
        Path sourceFolderPath = Paths.get(exportDir.getAbsolutePath());
            ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(new File(zipName)));
            Files.walkFileTree(sourceFolderPath, new SimpleFileVisitor<Path>() {
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    zos.putNextEntry(new ZipEntry(sourceFolderPath.relativize(file).toString()));
                    Files.copy(file, zos);
                    zos.closeEntry();
                    return FileVisitResult.CONTINUE;
                }
            });
            zos.close();
            System.out.println("Completed zipping export dir to "+zipName+".  Please send it to business for review.");
        } catch (IOException ioe) {
            System.out.println("Could not zip "+exportDir.getAbsolutePath());
            
        }
            
        
        
    }

    private void export() {
        for (File f:xmlDir.listFiles()) {
            if (f.getName().toLowerCase().endsWith(".xml") && f.isFile()) {
                try {
                    exportFile(f,exportDir);
                } catch (IOException ioe) {
                    System.out.println("IOException found on file "+f.getAbsolutePath());
                    ioe.printStackTrace();
                }
            }
        }
        
    }

    private void exportFile(File f, File exportDir) throws IOException {
       Map<String,String> config = (Map<String,String>)appContext.getBean("documentAdapterConfig");
       DocumentAdapter adapter = AdapterUtils.latest(config);
       TitlePartTree tree = (TitlePartTree)adapter.mapTitleXmlDocument(unwrapTitle(FileUtils.readFileToString(f)));
       ProposalDetailsVerificationController controller = appContext.getBean(ProposalDetailsVerificationController.class);
 //       System.out.println(f.getAbsolutePath());
       FileUtils.writeStringToFile(new File(exportDir.getAbsolutePath()+File.separator+f.getName()), 
               controller.mapToGoldCopy(tree));
    }

    private String unwrapTitle(String xml) {
        String subXml = null;
                SAXReader reader = new SAXReader();
        reader.setIncludeExternalDTDDeclarations(false);
        reader.setIncludeInternalDTDDeclarations(false);
        reader.setValidation(false);
        Document xmlDoc;
        try {
            xmlDoc = reader.read(new StringReader(xml));
            Element e = xmlDoc.getRootElement();
            Element newRoot = (Element)e.elements().iterator().next();
            subXml = newRoot.asXML();
        //    System.out.println(subXml);
            
        } catch (Exception e) {
           e.printStackTrace();   
        }
        return subXml;
    }

    private void collectExportConfigDetails() {
        UUID dir = UUID.randomUUID();
        InputStreamReader isr = null;
        Scanner scanner;
        try {
            isr = new InputStreamReader(System.in);
            scanner = new Scanner(isr);
            do {
                System.out.println("Gold Copy Source Dir: ");
                xmlDir = new File(StringUtils.trim(scanner.nextLine()));
            } while (xmlDir == null || (!xmlDir.isDirectory() && xmlDir.canRead()));
            
            exportDir = new File(xmlDir.getParentFile().getAbsolutePath()+File.separator+dir.toString());
            do {
                System.out.println("Export Dir ["+exportDir.getAbsolutePath()+"]: ");
                String userPath = StringUtils.trim(scanner.nextLine()); 
                if (StringUtils.isNotBlank(userPath) ) {
                    exportDir = new File(userPath);
                    
                }
            } while (exportDir == null || (!exportDir.mkdirs() && !exportDir.isDirectory() && exportDir.canWrite()));
            
             appContext = new ClassPathXmlApplicationContext("META-INF/spring/applicationContext.xml","META-INF/spring/applicationContext-test.xml");

            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            IOUtils.closeQuietly(isr);
        }
    }
    


}
