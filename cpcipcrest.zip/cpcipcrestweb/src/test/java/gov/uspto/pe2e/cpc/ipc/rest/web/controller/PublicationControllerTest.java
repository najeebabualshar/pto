package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationScheme;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ClassificationSchemeRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationStatusRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationTreeStatus;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class PublicationControllerTest {

    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private PublicationController publicationController;

    @Inject
    private ClassificationSchemeRepository classificationSchemeRepository;


    @Test
    public void testListPublications() {
        ResponseEntity<List<SchemePublicationVersion>> resp = publicationController.listPublicatons(null);
       
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(5, resp.getBody().size());
       
        resp = publicationController.listPublicatons(DateTime.parse("2999-12-31").toDate());
        
        Assert.assertNotNull(resp);
        Assert.assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(0, resp.getBody().size());        
        
    }

    @Test
    public void testUpdatePublicationStatusByGuid() {
        String failureMessage = "Unit test - testing failure message";
        ClassificationScheme classificationScheme = classificationSchemeRepository.findPrivate("c960d30a52a847fc8c51b64dfcc0ea85");

        PublicationStatusRequest publicationStatusRequest = new PublicationStatusRequest();
        publicationStatusRequest.setStatus("ERROR");
        publicationStatusRequest.setFailureText(failureMessage);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("justin.smith1@uspto.gov",
                "justin.smith1@uspto.gov", Collections.singletonList(new BasicTestingGrantedAuthority("test")));
        SecurityContextHolder.getContext().setAuthentication(token);

        ResponseEntity<Void> resp = publicationController.updatePublicationStatusByGuid(GUIDUtils.fromDatabaseFormat(classificationScheme.getProposalGuid()),
                publicationStatusRequest);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());

        ClassificationScheme classificationSchemeUpdated = classificationSchemeRepository.findById(classificationScheme.getId()).get();
        assertNotNull(classificationSchemeUpdated);
        assertNotNull(classificationSchemeUpdated.getClassificationSchemeStatus());
        assertEquals(failureMessage, classificationSchemeUpdated.getClassificationSchemeStatus().getFailure());
        assertEquals(PublicationTreeStatus.ERROR, classificationSchemeUpdated.getClassificationSchemeStatus().getStatus());
    }

    @Before
    public void setUp() throws Exception {
        
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1", "user@user.com",
                Arrays.asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/publications/versions")));
    }

}
