package gov.uspto.pe2e.cpc.ipc.rest.web.enumeration;

import org.junit.Assert;
import org.junit.Test;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.FileExtensionType;


public class FileExtensionTypeTest {

	@Test
	public void test() {
		String mimeType = FileExtensionType.JPE.getContentType();
		Assert.assertEquals("image/jpeg", mimeType);
	}

}
