package gov.uspto.pe2e.cpc.ipc.rest.web.util.templating;

import java.util.Arrays;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import freemarker.template.TemplateModelException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.UrlEncodeSymbolNameMethod;

public class UrlEncodeSymbolNameMethodTest {

    private static final Logger log = LoggerFactory.getLogger(DebugMethodTest.class);

    
    @Test (expected=TemplateModelException.class)
    public void testTooManyArgs() throws TemplateModelException {  
        UrlEncodeSymbolNameMethod method = new UrlEncodeSymbolNameMethod();
        method.exec(Arrays.asList("test", "test 2", "test 3"));
    }



}
