/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.util.templating;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import freemarker.template.Configuration;
import freemarker.template.Template;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.TemplateConfigurationLocator;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_0.QNContactDocument;
import gov.uspto.pe2e.cpc.ipc.rest.sn.service.QnDetailService;
import gov.uspto.pe2e.cpc.ipc.rest.sn.service.SymbolService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

/**
 * 
 * @author 2020
 * @date Jan 13, 2016 10:55:25 AM
 * @version 
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class DebugMethodTest {
	private static final Logger log = LoggerFactory.getLogger(DebugMethodTest.class);
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private SymbolService symbolService;

    @Inject
    private QnDetailService qnDetailService;


    
	@Test
	@Transactional
	public void test() {  
		Object model = symbolService.findSymbolByName("A01N", true);
		 OutputStreamWriter writer = null;
	        ByteArrayOutputStream baos = null;
	        String xhtml = "";
	        try {
	            Configuration cfg = new TemplateConfigurationLocator().configure(null).getConfiguration();
	            baos = new ByteArrayOutputStream();
	            writer = new OutputStreamWriter(baos);
	            Template template = cfg.getTemplate("templates/test/debug_method_test.tpl");
	            template.process(model, writer);
	            writer.flush();

	            baos.flush();
	            xhtml = new String(baos.toByteArray());
	        } catch (Exception e) {
	            log.error("Exception caught while processing definition document", e);
	        } finally {
	            IOUtils.closeQuietly(baos);
	            IOUtils.closeQuietly(writer);
	        }
	        Assert.assertEquals("Testing Debug method java.lang.String:\"A01N\"", xhtml);
	}

	@Test
	@Transactional
	public void test1() {  
		QNContactDocument model = qnDetailService.buildContactDocument("A01N");
		log.debug(" {}",model.getTcLeads());
		 OutputStreamWriter writer = null;
	        ByteArrayOutputStream baos = null;
	        String xhtml = "";
	        try {
	            Configuration cfg = new TemplateConfigurationLocator().configure(null).getConfiguration();
	            baos = new ByteArrayOutputStream();
	            writer = new OutputStreamWriter(baos);
	            Template template = cfg.getTemplate("templates/test/debug_method_test2.tpl");
	            template.process(model, writer);
	            writer.flush();

	            baos.flush();
	            xhtml = new String(baos.toByteArray());
	        } catch (Exception e) {
	            log.error("Exception caught while processing definition document", e);
	        } finally {
	            IOUtils.closeQuietly(baos);
	            IOUtils.closeQuietly(writer);
	        }
	        Assert.assertEquals("Testing Debug method gov.uspto.pe2e.cpc.ipc.rest.contract.v1_0.QNContact:{\"id\":2,\"firstName\":\"Ben\",\"lastName\":\"Bowden\",\"email\":\"ben.bowden@uspto.gov\"}", xhtml);
	}


	@Test
	@Transactional
	public void test2() {  
		QNContactDocument model = qnDetailService.buildContactDocument("A01N");
		log.debug(" {}",model.getTcLeads());
		 OutputStreamWriter writer = null;
	        ByteArrayOutputStream baos = null;
	        String xhtml = "";
	        try {
	            Configuration cfg = new TemplateConfigurationLocator().configure(null).getConfiguration();
	            baos = new ByteArrayOutputStream();
	            writer = new OutputStreamWriter(baos);
	            Template template = cfg.getTemplate("templates/test/debug_method_test3.tpl");
	            template.process(model, writer);
	            writer.flush();

	            baos.flush();
	            xhtml = new String(baos.toByteArray());
	        } catch (Exception e) {
	            log.error("Exception caught while processing definition document", e);
	        } finally {
	            IOUtils.closeQuietly(baos);
	            IOUtils.closeQuietly(writer);
	        }
	        Assert.assertEquals("Testing Debug method null", xhtml);
	}



    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }


}
