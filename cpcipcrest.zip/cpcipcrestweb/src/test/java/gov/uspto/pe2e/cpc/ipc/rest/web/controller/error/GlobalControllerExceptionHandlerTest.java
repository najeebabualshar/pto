package gov.uspto.pe2e.cpc.ipc.rest.web.controller.error;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.I18nMessageKey;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ResourceCheckoutFailureReason;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.CustomValidationException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.RequestPublicationVersionVsEntityMismatchException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ResourceCheckoutException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.RestError;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.SerializationStrategyException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.GrammarValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.MismatchedGrammarTokenErrorContext;
import jakarta.inject.Inject;
import jakarta.persistence.EntityNotFoundException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
//@Execution(ExecutionMode.CONCURRENT)
public class GlobalControllerExceptionHandlerTest {
    private static final Logger log = LoggerFactory.getLogger(GlobalControllerExceptionHandler.class);

    @Inject
    private GlobalControllerExceptionHandler globalControllerExceptionHandler;

    @Inject
    private DatasetTestingService datasetTestingService;

    private Date lastInit =  null;

    @Before
    public void setUp() throws Exception {
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        datasetTestingService.loadOnce();
        
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1", "user@user.com",
                Arrays.asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
    }
    
    @Test
    public void testCustomValidationException () {
        List<Pair<String, List<Object>>> errs = new ArrayList<Pair<String, List<Object>>>();
        errs.add(Pair.of("Test", Arrays.asList("Test err")));
        CustomValidationException ex = new CustomValidationException(errs);
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(ex);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        Assert.assertEquals("Validation failed with 1 errors(s):[Unknown error code Test] ", resp.getBody().getMessage());

    }

    @Test
    public void testIOException () {
        
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(new IOException());
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_GATEWAY, resp.getStatusCode());
        Assert.assertEquals("Unexpected error occurred.  Please try again later null", resp.getBody().getMessage());

    }

    @Test
    public void testHandleMissingServletRequestParameterException () {
        
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(new MissingServletRequestParameterException("proposalId",UUID.class.getCanonicalName()));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        Assert.assertEquals("Required Request Parameter named 'proposalId' of type 'java.util.UUID' is missing.", resp.getBody().getMessage());

    }

    
    @Test
    public void testSerializationStrategyException () {
        SerializationStrategyException sse = new SerializationStrategyException("Testing");
       
        
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(sse);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.NOT_IMPLEMENTED, resp.getStatusCode());
        Assert.assertTrue(resp.getBody().getMessage().startsWith("This XML schema does not match any known document adapter.  This is like"));

    }

    
    @Test
    public void testNullPointerException () {
        
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(new NullPointerException());
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, resp.getStatusCode());
        Assert.assertEquals("Unexpected error occurred.  Please try again later Null Pointer Exception", resp.getBody().getMessage());

    }
    
    @Test
    public void testHttpMediaTypeNotSupportedException() {
        HttpMediaTypeNotSupportedException ex = new HttpMediaTypeNotSupportedException("Testing ...");
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(ex);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE, resp.getStatusCode());
        Assert.assertEquals("The media type you requested is not supported by this Service (Testing ...)", resp.getBody().getMessage());

    }

    @Test
    public void testException () {
        
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(new Exception("Test Exception"));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, resp.getStatusCode());
        Assert.assertEquals("Unexpected error occurred.  Please try again later Test Exception", resp.getBody().getMessage());

    }
    
    @Test
    public void testUncheckedIOException() {
        
		ResponseEntity<RestError> resp = globalControllerExceptionHandler
				.handleGlobalException(new UncheckedIOException("Test Exception", new IOException()));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        Assert.assertEquals("Request for Resource could not be satisfied  /cpcipcrestweb/symbols Test Exception", resp.getBody().getMessage());

    }
    
    @Test
    public void testEntityNotFoundException() {
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(new EntityNotFoundException("Test Exception"));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        Assert.assertEquals("The entity you requested was not found (Test Exception)", resp.getBody().getMessage());
    
    }
    
    @Test
    public void testResourceCheckoutException() {
        ResourceCheckoutException rce = new ResourceCheckoutException(123L, "your_mom", DateTime.parse("2017-02-01").toDate(), ResourceCheckoutFailureReason.RESOURCE_ALREADY_LOCKED_BY_OTHER_USER);
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(rce);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.PRECONDITION_FAILED, resp.getStatusCode());
        Assert.assertEquals("Resource checkout failed for id '123' because it does is is locked by your_mom.  Lock expires Feb 1, 2017.", resp.getBody().getMessage());
    
        rce = new ResourceCheckoutException(123L, "your_mom", DateTime.parse("2017-02-01").toDate(), ResourceCheckoutFailureReason.RESOURCE_DOES_NOT_EXIST);
        resp = globalControllerExceptionHandler.handleGlobalException(rce);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.PRECONDITION_FAILED, resp.getStatusCode());
        Assert.assertEquals("Resource checkout failed for id '123' because it does not exist", resp.getBody().getMessage());
        
        rce = new ResourceCheckoutException();
        rce.setResourceId(123L);
        rce.setReason(ResourceCheckoutFailureReason.MAX_LOCKS_ALLOWED_BY_USER);
        rce.setLockExpirationTs( DateTime.parse("2017-04-04").toDate());
        rce.setCurrentLockedUser("user");
        
        resp = globalControllerExceptionHandler.handleGlobalException(rce);
        Assert.assertEquals(HttpStatus.PRECONDITION_FAILED, resp.getStatusCode());
        Assert.assertEquals("Resource checkout failed for unknown reason", resp.getBody().getMessage());
        
        rce = new ResourceCheckoutException("Resource Not Found");
        resp = globalControllerExceptionHandler.handleGlobalException(rce);
        Assert.assertEquals(HttpStatus.PRECONDITION_FAILED, resp.getStatusCode());
        Assert.assertEquals("Resource checkout failed for unknown reason", resp.getBody().getMessage());
        
        rce = new ResourceCheckoutException("Resource Not Found", new Throwable("Not Found"));
        resp = globalControllerExceptionHandler.handleGlobalException(rce);
        Assert.assertEquals(HttpStatus.PRECONDITION_FAILED, resp.getStatusCode());
        Assert.assertEquals("Resource checkout failed for unknown reason", resp.getBody().getMessage());
        
        rce = new ResourceCheckoutException(new Throwable("Not Found"));
        resp = globalControllerExceptionHandler.handleGlobalException(rce);
        Assert.assertEquals(HttpStatus.PRECONDITION_FAILED, resp.getStatusCode());
        Assert.assertEquals("Resource checkout failed for unknown reason", resp.getBody().getMessage());
        
        rce = new ResourceCheckoutException("Not Found", new Throwable("Not Found"), false, false);
        resp = globalControllerExceptionHandler.handleGlobalException(rce);
        Assert.assertEquals(HttpStatus.PRECONDITION_FAILED, resp.getStatusCode());
        Assert.assertEquals("Resource checkout failed for unknown reason", resp.getBody().getMessage());
    
    }
    
    @Test
    public void testMethodArgumentNotValid() {
        SymbolName sn = new SymbolName("A01N");

        BindingResult bindingResult = new BeanPropertyBindingResult(sn, "symbolName");
        //THis is required in order to identify the constructor
        MethodParameter methodParam = null;

        bindingResult.addError(new ObjectError("symbolName", I18nMessageKey.SYMBOL_NAME_STRUCT_CANNOT_BE_NULL.name()));
        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(methodParam, bindingResult);
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(ex);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        Assert.assertEquals("Validation failed with 1 errors(s):[[Error in object 'symbolName': codes []; arguments []; default message [SYMBOL_NAME_STRUCT_CANNOT_BE_NULL]]] ", resp.getBody().getMessage());

        
        bindingResult = new BeanPropertyBindingResult(sn, "symbolName");

        bindingResult.addError(new ObjectError("symbolName",new String[]{I18nMessageKey.SYMBOL_NAME_STRUCT_CANNOT_BE_NULL.name()}, new Object[]{"test", "test"}, "Test default"));
        ex = new MethodArgumentNotValidException(methodParam, bindingResult);
        resp = globalControllerExceptionHandler.handleGlobalException(ex);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        Assert.assertEquals("Validation failed with 1 errors(s):[Symbol Name Structure Cannot Be Null] ", resp.getBody().getMessage());
        
        
        
    }
    
    @Test
    public void testMethodArgumentNotValidWithNoSuchMessageException() {
        SymbolName sn = new SymbolName("A01N");

        BindingResult bindingResult = new BeanPropertyBindingResult(sn, "symbolName");
      //THis is required in order to identify the constructor
        MethodParameter methodParam = null;

        bindingResult.addError(new ObjectError("symbolName", new String[]{"123"}, null, I18nMessageKey.SYMBOL_NAME_STRUCT_CANNOT_BE_NULL.name()));
        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(methodParam, bindingResult);
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(ex);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        Assert.assertEquals("Validation failed with 1 errors(s):[[Error in object 'symbolName': codes [123]; arguments []; default message [SYMBOL_NAME_STRUCT_CANNOT_BE_NULL]]] ", resp.getBody().getMessage());
        
        resp = globalControllerExceptionHandler.handleGlobalException(new HttpMessageNotReadableException("Message Not Readable"));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        
        resp = globalControllerExceptionHandler.handleGlobalException(new IllegalArgumentException("Input is Not Valid"));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        
		resp = globalControllerExceptionHandler
				.handleGlobalException(new org.apache.lucene.queryparser.classic.ParseException("Parse Exception"));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        
        resp = globalControllerExceptionHandler
				.handleGlobalException(new AccessDeniedException("file"));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.FORBIDDEN, resp.getStatusCode());
        
        resp = globalControllerExceptionHandler
				.handleGlobalException(new RequestPublicationVersionVsEntityMismatchException("file"));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
    }
    
    @Test
    public void testHandleGrammarParseException() {
        GrammarParseException gpe = new GrammarParseException();
        GrammarValidationMessage msg = new GrammarValidationMessage();
        msg.setLineNumber(1);
        msg.setCharacterIndex(56);
        msg.setContext(new MismatchedGrammarTokenErrorContext());
        gpe.getValidationMessages().add(msg);
        ResponseEntity<RestError> resp = globalControllerExceptionHandler.handleGlobalException(gpe);
        Assert.assertNotNull(resp);
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        log.debug(resp.getBody().getMessage());
        gpe = new GrammarParseException("Resource Not Found");
        resp = globalControllerExceptionHandler.handleGlobalException(gpe);
        Assert.assertNotNull(resp);
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        gpe = new GrammarParseException("Resource Not Found", new Throwable("Not Found"));
        resp = globalControllerExceptionHandler.handleGlobalException(gpe);
        Assert.assertNotNull(resp);
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        gpe = new GrammarParseException(new Throwable("Not Found"));
        resp = globalControllerExceptionHandler.handleGlobalException(gpe);
        Assert.assertNotNull(resp);
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        gpe = new GrammarParseException("Not Found", new Throwable("Not Found"), false, false);
        resp = globalControllerExceptionHandler.handleGlobalException(gpe);
        Assert.assertNotNull(resp);
        Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
        
    }
}
