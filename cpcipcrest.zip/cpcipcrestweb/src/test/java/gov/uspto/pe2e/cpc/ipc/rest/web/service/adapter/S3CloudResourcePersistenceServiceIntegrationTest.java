package gov.uspto.pe2e.cpc.ipc.rest.web.service.adapter;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.S3CloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.IntegrationTest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.CloudResource;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.MetadataKey;
import gov.uspto.pe2e.cpc.ipc.rest.rm.service.ResourceService;
import jakarta.inject.Inject;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@Category(IntegrationTest.class)
public class S3CloudResourcePersistenceServiceIntegrationTest {
	private static final Logger log = LoggerFactory.getLogger(S3CloudResourcePersistenceServiceIntegrationTest.class);
	
	@Inject
	private ResourceService resourceService;
	
	/**
	 * This is the real deal Always since we wire by the concrete class instead of interface name
	 */
	@Inject 
	private S3CloudResourcePersistenceService s3CloudResourcePersistenceService;

	@Test
	public void testPersist() {
		CloudResource res = new CloudResource();
		res.setBytes("<dataset></dataset>".getBytes());
		List<Pair<String,String>> kvpList = Arrays.asList(
				Pair.of(MetadataKey.ORIGINAL_FILENAME.name(), "test1.xml"),
				Pair.of(MetadataKey.CREATE_USERID.name(), "user1"));
		Map<String,String> metadata = new HashMap<>();
		for (Pair<String,String> kvp: kvpList) {
			metadata.put(kvp.getLeft(), kvp.getRight());
		}
		Assert.assertNotNull(s3CloudResourcePersistenceService.persist(resourceService.resolveResourceName(res.getId()),
				res.getBytes(), metadata, true));
	}
	@Test
	public void testDownload() {
//		CloudResource res = new CloudResource();
//		res.setBytes("<dataset></dataset>".getBytes());
//		List<Pair<String,String>> kvpList = Arrays.asList(
//				Pair.of(MetadataKey.ORIGINAL_FILENAME.name(), "test1.xml"),
//				Pair.of(MetadataKey.CREATE_USERID.name(), "user1"));
//		Map<String,String> metadata = new HashMap<>();
//		for (Pair<String,String> kvp: kvpList) {
//			metadata.put(kvp.getLeft(), kvp.getRight());
//		}
		log.debug("start");
		resourceService.getByResourceName("help/pto-content.html");
		Assert.assertTrue(true);
		log.debug("end");
	}
	
	@Before
	public void setUp() {
		log.debug("CloudResourcePersistenceService impl = {}", s3CloudResourcePersistenceService.getClass().getCanonicalName() );
	}

}
