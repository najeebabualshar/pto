package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ResourceCheckoutException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalLock;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalLockRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.infrastructure.pessimisticlocking.proposal.ProposalLock;
import gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalLockController;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalLockControllerTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalLockControllerTest.class);
    @Inject
    private DatasetTestingService datasetTestingService;
    @Inject
    private ChangeProposalRepository changeProposalRepository;
    @Inject
    private ChangeProposalLockRepository changeProposalLockRepository;
    @Inject 
    private ProposalLockController proposalLockController;

    @Test
    @Transactional
    public void testExtendWithDuration() throws ResourceCheckoutException {
        Date future = new LocalDateTime().plusMinutes(200).toDate();
        ChangeProposal p = changeProposalRepository.findById(1000000001L).get();
        ChangeProposalLock lock = new ChangeProposalLock();
        lock.setChangeProposal(p);
        lock.setId(p.getId());
        Assert.assertNotNull(lock.getId());
        lock.setCreateTs(new Date());
        lock.setCreateUserId("user@user.com");
        lock.setExpirationTs(future);
        lock.setLastModTs(new Date());
        lock.setLastModUserId("user@user.com");
        lock.setLockControl(0);
        lock.setLockedUserId("user@user.com");
        changeProposalLockRepository.save(lock);
 
        long count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(1, count);
        log.debug("find by Guuid {}", changeProposalLockRepository.findAnyExsitngLock("c960d30a52a847fc8c51b64dfcc0ea85"));
        ResponseEntity<ProposalLock> resp  = proposalLockController.extendLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 10);
        Assert.assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
        log.debug("Response {}", resp);
        
        lock = changeProposalLockRepository.findById(1000000001L).get();
        Assert.assertNotNull(lock);
        Assert.assertTrue(new Date().before(lock.getExpirationTs()));
    }

    @Test
    @Transactional
    public void testExtendWithNoDuration() throws InterruptedException, ResourceCheckoutException {
        Date future = new LocalDateTime().plusMillis(500).toDate();
        ChangeProposal p = changeProposalRepository.findById(1000000001L).get();
        ChangeProposalLock lock = new ChangeProposalLock();
        lock.setChangeProposal(p);
        lock.setId(p.getId());
        Assert.assertNotNull(lock.getId());
        lock.setCreateTs(new Date());
        lock.setCreateUserId("user@user.com");
        lock.setExpirationTs(future);
        lock.setLastModTs(new Date());
        lock.setLastModUserId("user@user.com");
        lock.setLockControl(0);
        lock.setLockedUserId("user@user.com");
        changeProposalLockRepository.save(lock);
 
        long count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(1, count);
        log.debug("find by Guuid {}", changeProposalLockRepository.findAnyExsitngLock("c960d30a52a847fc8c51b64dfcc0ea85"));
        ResponseEntity<ProposalLock> resp  = proposalLockController.extendLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null);
        Assert.assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
        log.debug("Response {}", resp);        
        lock = changeProposalLockRepository.findById(1000000001L).get();
        Assert.assertNotNull(lock);
        Assert.assertTrue(new Date().before(lock.getExpirationTs()));
    }

    @Test
    @Transactional
    public void testExtendWithExpired() throws InterruptedException, ResourceCheckoutException {
        createAndSaveLock(1000000001L, "user@user.com", -1);

 
        long count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(1, count);
        log.debug("find by Guuid {}", changeProposalLockRepository.findAnyExsitngLock("c960d30a52a847fc8c51b64dfcc0ea85"));
        ResponseEntity<ProposalLock> resp  = proposalLockController.extendLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null);
        Assert.assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
        log.debug("Response {}", resp);
        ChangeProposalLock lock = changeProposalLockRepository.findById(1000000001L).get();
        Assert.assertNotNull(lock);
        Assert.assertTrue(new Date().before(lock.getExpirationTs()));
    }


    @Test
    @Transactional
    public void testReleaseLock() throws ResourceCheckoutException {
        createAndSaveLock(1000000001L, "user@user.com", 60);

        long count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(1, count);
        log.debug("find by Guuid {}", changeProposalLockRepository.findAnyExsitngLock("c960d30a52a847fc8c51b64dfcc0ea85"));
        ResponseEntity<ProposalLock> resp  = proposalLockController.releaseLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.debug("Response {}", resp);
        count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(0, count);
     }

    @Test(expected=ResourceCheckoutException.class)
    @Transactional
    public void testReleaseLockHeldByOtherUser() throws ResourceCheckoutException {
        createAndSaveLock(1000000001L, "otheruser@user.com", 60);

        long count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(1, count);
        log.debug("find by Guuid {}", changeProposalLockRepository.findAnyExsitngLock("c960d30a52a847fc8c51b64dfcc0ea85"));
        ResponseEntity<ProposalLock> resp  = proposalLockController.releaseLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
     }


    @Test
    @Transactional
    public void testReleaseLockDoesNotExist() throws ResourceCheckoutException {
 
        long count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(0, count);
        ResponseEntity<ProposalLock> resp  = proposalLockController.releaseLock(UUID.randomUUID());
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.debug("Response {}", resp);
        count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(0, count);
     }
    
    @Test
    @Transactional
    public void testListLocks() throws ResourceCheckoutException{
        createAndSaveLock(1000000001L, "user@user.com", 15);
        createAndSaveLock(1000000002L, "user@user.com", 15);
        createAndSaveLock(1000000003L, "otheruser@user.com", 15);
        ResponseEntity<List<ProposalLock>> resp = proposalLockController.listOpenLocks();
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(2, resp.getBody().size());
        
    }

    @Test
    @Transactional
    public void testListLocksNoneExist() throws ResourceCheckoutException{
        createAndSaveLock(1000000001L, "otheruser@user.com", 15);
        createAndSaveLock(1000000002L, "otheruser@user.com", 15);
        createAndSaveLock(1000000003L, "otheruser@user.com", 15);
        ResponseEntity<List<ProposalLock>> resp = proposalLockController.listOpenLocks();
        Assert.assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
        Assert.assertEquals(0, resp.getBody().size());
        
    }

    @Test
    @Transactional
    public void testAcquireLock() throws ResourceCheckoutException{
        ResponseEntity<ProposalLock> resp = proposalLockController.acquireLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
       
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), resp.getBody().getId());
        long count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(1, count);
     
    }
    
    @Test
    @Transactional
    public void testAcquireLockAndVerifyDuration() throws ResourceCheckoutException{
        long now = LocalDateTime.now(DateTimeZone.UTC).toDate().getTime(); 
    	ResponseEntity<ProposalLock> resp = proposalLockController.acquireLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
       
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), resp.getBody().getId());
        long count = changeProposalLockRepository.count();
        log.debug("Default timezone = {}", DateTimeZone.getDefault());
        log.debug("Records exist {} ",count);
        Assert.assertEquals(1, count);
        
        log.debug("start ts = {}", DateFormatUtils.ISO_DATETIME_TIME_ZONE_FORMAT.format(resp.getBody().getLockStartTs()));
        log.debug("expriation ts = {}", DateFormatUtils.ISO_DATETIME_TIME_ZONE_FORMAT.format(resp.getBody().getLockExpirationTs()));
        long expMilli =  resp.getBody().getLockExpirationTs().getTime();
        log.debug("Difference {}", (expMilli-now));
        Assert.assertTrue(21600000 <= (expMilli-now));
     
    }

    @Test(expected=ResourceCheckoutException.class)
    @Transactional
    public void testAcquireLockOwnedBySomeoneElse() throws ResourceCheckoutException{
        createAndSaveLock(1000000001L, "otheruser@user.com", 15);
        ResponseEntity<ProposalLock> resp = proposalLockController.acquireLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
     
    }

    @Test(expected=ResourceCheckoutException.class)
    @Transactional
    public void testAcquireLockProposalDoesNotExist() throws ResourceCheckoutException{
        ResponseEntity<ProposalLock> resp = proposalLockController.acquireLock(UUID.randomUUID());
     
    }

    
    @Test
    @Transactional
    public void testGetLockStatus() throws ResourceCheckoutException{
        createAndSaveLock(1000000001L, "user@user.com", 15);
        createAndSaveLock(1000000002L, "otheruser@user.com", 15);
        ResponseEntity<ProposalLock> resp = proposalLockController.getLockStatusById(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        destroy();
        resp = proposalLockController.getLockStatusById(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        Assert.assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        
    }
    
    @Test
    public void testChangeProposalLockEquals() {
    	
    	ChangeProposalLock cpl = new ChangeProposalLock();
    	cpl.setLockedUserId("user1");		
		ChangeProposal cp = new ChangeProposal();
		cp.setExternalId("1234");
		cpl.setChangeProposal(cp);
		
		ChangeProposalLock cpl1 = new ChangeProposalLock();
		cpl1.setLockedUserId("user2");		
		ChangeProposal cp1 = new ChangeProposal();
		cp1.setExternalId("4546");
		cpl1.setChangeProposal(cp1);
		
		ChangeProposalLock cpl4 = new ChangeProposalLock();
		cpl1.setLockedUserId("user1");		
		ChangeProposal cp3 = new ChangeProposal();
		cp3.setExternalId("4546");
		cpl4.setChangeProposal(cp3);
		
		ChangeProposalLock cpl2 = new ChangeProposalLock();
		cpl2.setLockedUserId("user1");
		ChangeProposal cp2 = new ChangeProposal();
		cp2.setExternalId("1234");
		cpl2.setChangeProposal(cp2);
		
		Assert.assertFalse(cpl.equals(cpl1));
		Assert.assertFalse(cpl1.equals(cpl));
		Assert.assertFalse(cpl.equals(null));
		Assert.assertFalse(cpl.equals(new String()));
		Assert.assertFalse(cpl.equals(cpl4));
		
		ChangeProposalLock cpl3=cpl;
		Assert.assertEquals(cpl, cpl3);
		Assert.assertEquals(cpl3, cpl);		
		Assert.assertEquals(cpl, cpl2);
		Assert.assertEquals(0, cpl.compareTo(cpl3));
    	
    }

    
    private void createAndSaveLock(Long proposalId, String userId, int minToAddToExpiry) {
        Date expiry = new LocalDateTime().plusMinutes(minToAddToExpiry).toDate();
        ChangeProposal p = changeProposalRepository.findById(proposalId).get();
        ChangeProposalLock lock = new ChangeProposalLock();
        lock.setChangeProposal(p);
        lock.setId(p.getId());
        Assert.assertNotNull(lock.getId());
        lock.setCreateTs(new Date());
        lock.setCreateUserId(userId);
        lock.setExpirationTs(expiry);
        lock.setLastModTs(new Date());
        lock.setLastModUserId(userId);
        lock.setLockControl(0);
        lock.setLockedUserId(userId);
        changeProposalLockRepository.save(lock);
     }

    @After
    public void destroy() {
        changeProposalLockRepository.deleteAll();

    }

    @Transactional
    @Before
    public void setUp() throws Exception {
    	TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    	DateTimeZone.setDefault(DateTimeZone.UTC);
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user@user.com", "user@user.com",
                Arrays.asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/locks/proposals")));
    }

}
