package gov.uspto.pe2e.cpc.ipc.rest.web.security;

import org.junit.Assert;
import org.junit.Test;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationRole;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.Tenant;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.UsptoGrantedAuthority;

public class UsptoGrantedAuthorityTest {

    @Test
    public void test() {
        UsptoGrantedAuthority authority = new UsptoGrantedAuthority(Tenant.PTO, ApplicationRole.CPCPROJECTCOORDINATOR, 
                ApplicationPermission.IPC_CONCORDANCE_GET);
        Assert.assertNotNull(authority.getOrg());
        Assert.assertEquals(Tenant.PTO,authority.getOrg());
        Assert.assertEquals(ApplicationRole.CPCPROJECTCOORDINATOR, authority.getRole());
    }

}
