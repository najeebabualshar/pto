package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.StandardComponentPart;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.StandardComponentPartRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.templates.v1_0.DefinitionSectionTemplate;
import gov.uspto.pe2e.cpc.ipc.rest.contract.templates.v1_0.NoteParagraphTemplate;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText;
import jakarta.inject.Inject;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TemplateServiceTest {
    private static final Logger log = LoggerFactory.getLogger(TemplateServiceTest.class);
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private TemplateService templateService;
    
    @Inject 
    private StandardComponentPartRepository standardNoteWarningTypeRepository;

    @Test
    public void testMapNoteTemplate() throws JsonGenerationException, JsonMappingException, IOException {
        StandardComponentPart e = standardNoteWarningTypeRepository.findById(1L).get();
        NoteParagraphTemplate tpl = (NoteParagraphTemplate)templateService.mapCompenentType(e, true);
        Assert.assertNotNull(tpl);
        Assert.assertNotNull(tpl.getNoteItem());
        log.debug("json obj ={}", JsonUtils.toJson(tpl.getNoteItem()));
        Assert.assertEquals("This is note template 1", ((NoteRawText)tpl.getNoteItem().getChildren().get(0)).getContent());
    }

    
    @Test
    public void testFindAvailableNoteTemplateByName() throws JsonGenerationException, JsonMappingException, IOException {
        NoteParagraphTemplate tpl = (NoteParagraphTemplate)templateService.findAvailableTemplateByNameAndType("Note Template 1",ComponentCategory.NOTE);
        Assert.assertNotNull(tpl);
        Assert.assertNotNull(tpl.getNoteItem());
        log.debug("json obj ={}", JsonUtils.toJson(tpl.getNoteItem()));
        Assert.assertEquals("This is note template 1", ((NoteRawText)tpl.getNoteItem().getChildren().get(0)).getContent());
    }
    
    @Test
    public void testFindAvailableNoteTemplateByNameUnknown() throws JsonGenerationException, JsonMappingException, IOException {
        NoteParagraphTemplate tpl = (NoteParagraphTemplate)templateService.findAvailableTemplateByNameAndType("Not present",ComponentCategory.NOTE);
        Assert.assertNull(tpl);       
        
    }
    
    @Test
    public void testFindAvailableNoteTemplateByNameNull() throws JsonGenerationException, JsonMappingException, IOException {
        NoteParagraphTemplate tpl = (NoteParagraphTemplate)templateService.findAvailableTemplateByNameAndType(null,null);
        Assert.assertNull(tpl);       
        
    }
    
    
    //
    
    @Test
    public void testFindAvailableDefinitionSynonyms() throws JsonGenerationException, JsonMappingException, IOException {
    	DefinitionSectionTemplate tpl = (DefinitionSectionTemplate)templateService.findAvailableTemplateByNameAndType("Synonyms",ComponentCategory.DEFINITION);
        Assert.assertNotNull(tpl);
        log.debug("*****************"+tpl.toString());
        Assert.assertNotNull(tpl.getSynonymsKeywords());
        log.debug("json obj ={}", JsonUtils.toJson(tpl.getSynonymsKeywords()));
        //Assert.assertEquals("This is note template 1", ((NoteRawText)tpl.getNoteItem().getChildren().get(0)).getContent());
    }
    
    @Test
    public void testFindAvailableDefinitionStatement() throws JsonGenerationException, JsonMappingException, IOException {
    	DefinitionSectionTemplate tpl = (DefinitionSectionTemplate)templateService.findAvailableTemplateByNameAndType("Definition statement",ComponentCategory.DEFINITION);
        Assert.assertNotNull(tpl);
        log.debug("*****************"+tpl.toString());
        Assert.assertNotNull(tpl.getDefinitionStatement());
        log.debug("json obj ={}", JsonUtils.toJson(tpl.getDefinitionStatement()));
        //Assert.assertEquals("This is note template 1", ((NoteRawText)tpl.getNoteItem().getChildren().get(0)).getContent());
    }
    
    
    
    //Limiting references
    @Test
    public void testFindAvailableDefinitionStatementLimitingRef() throws JsonGenerationException, JsonMappingException, IOException {
    	DefinitionSectionTemplate tpl = (DefinitionSectionTemplate)templateService.findAvailableTemplateByNameAndType("Limiting references",ComponentCategory.DEFINITION);
        Assert.assertNotNull(tpl);
        log.debug("*****************"+tpl.toString());
        Assert.assertNotNull(tpl.getLimitingReferences());
        log.debug("json obj ={}", JsonUtils.toJson(tpl.getLimitingReferences()));
        //Assert.assertEquals("This is note template 1", ((NoteRawText)tpl.getNoteItem().getChildren().get(0)).getContent());
    }

    
    @Before
    public void setUp() throws Exception {
//        IDatabaseConnection conn = datasetTestingService.getConnection();
//        datasetTestingService.emptyTables(conn);
//        datasetTestingService.loadAllDatasets(conn);

    	datasetTestingService.loadOnce();
    }

}
