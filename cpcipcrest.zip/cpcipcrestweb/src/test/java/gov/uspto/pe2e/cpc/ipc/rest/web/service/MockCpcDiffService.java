package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.CpcDiffService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import jakarta.inject.Inject;

/**
 * This service does all the CPC logic of comparing Our business Datamodels to
 * each other and creating a basic json model with no contract
 * 
 * @author 2020
 * @version 1.0
 * @date: 01/06/2016
 *
 */
@Primary
@Service()
public class MockCpcDiffService extends CpcDiffService {

	@Inject
	public MockCpcDiffService(ProposalValidationService proposalValidationService, TitleService titleService) {
		super(proposalValidationService, titleService);
	}
	


	

	private static final Logger log = LoggerFactory.getLogger(CpcDiffService.class);

	/**
	 * This method is separated from the other orchestration to make mocking for
	 * tests easier
	 * 
	 * @return
	 * @throws IOException
	 */
	@Override
	public void perfromDiffUsingDeltaXML(RevisionChangeItemRequest sctRow, File targetFile) throws IOException {
		String symbolName = sctRow.getSymbolName();

		try (InputStream is = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("data/xml/diff/delta_intermediary_result_"
							+StringUtils.remove(symbolName, "/")+".xml")) {
			File out = new File(targetFile.getParentFile().getAbsolutePath() + File.separator + "result.xml");
			log.debug("Writing result file {} from mock data", out.getAbsolutePath());
			FileUtils.writeByteArrayToFile(out, IOUtils.toByteArray(is));

		}

	}

}
