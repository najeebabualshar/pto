/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.jee.filter;

import java.util.List;

import org.apache.http.client.utils.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationScheme;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ClassificationSchemeRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.web.service.PublicationService;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author 2020
 * @date Nov 16, 2015 3:22:46 PM
 * @version 
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@Slf4j
public class RevisionVersionFilterTest {
	   @Inject
	    private DatasetTestingService datasetTestingService;

	    @Inject
	    private ClassificationSchemeRepository classificationSchemeRepository;
	    

	    @Inject
		private PublicationService publicationService;
		//documentAdapterConfig;


	

	@Before
	public void setUp() throws Exception {
	        datasetTestingService.loadOnce();

	}

	@Test
	public void testExistingPubDate() {
		   MockHttpServletRequest request = new MockHttpServletRequest();
	        request.setContextPath("/cpcipcrestweb");
	        request.setServerName("localhost");
	        request.setRequestURI("/cpcipcrestweb/symbols");
	        request.addHeader(HttpHeaders.ACCEPT, RestUtils.CONTENT_TYPE_JSON);
	        
	    request.addHeader(RestUtils.SCHEME_PUBLICATION_DATE_HEADER, "2016-11-01");    
	     
		RevisionVersionFilter filter = new RevisionVersionFilter();
		filter.setClassificationSchemeRepository(classificationSchemeRepository);
		filter.setPublicationService(publicationService);
		List<ClassificationScheme> rows = classificationSchemeRepository.findAll();
		for (ClassificationScheme scheme: rows) {
			log.debug("scheme {} /{} is gold {} is current {} ", scheme.getId(),
					DateUtils.formatDate(scheme.getSchemeVersionDate(), "yyyy-MM-dd"),
					scheme.getSchemeXsd().getSchemaVersionCategory(), 
					scheme.getCurrentIn());
		}
		SchemePublicationVersion vers=filter.getSchemePublicationVersion(request);
		Assert.assertEquals((Long)2L, vers.getClassificationSchemeId());
		Assert.assertEquals("1.7", vers.getCpcXsdVersion());
		Assert.assertEquals("1.0", vers.getDefinitionXsdVersion());
		Assert.assertEquals(DocumentAdapter.class.getCanonicalName(), 
				vers.getDocumentAdapterClass());
		
		
	}

	@Test
	public void testWithoutPubDate() {
		   MockHttpServletRequest request = new MockHttpServletRequest();
	        request.setContextPath("/cpcipcrestweb");
	        request.setServerName("localhost");
	        request.setRequestURI("/cpcipcrestweb/symbols");
	        request.addHeader(HttpHeaders.ACCEPT, RestUtils.CONTENT_TYPE_JSON);
	        
	 //   request.addHeader(SchemePublicationVersion.SCHEME_PUBLICATION_DATE_HEADER, "2015-11-01");    
	     
		RevisionVersionFilter filter = new RevisionVersionFilter();
		filter.setClassificationSchemeRepository(classificationSchemeRepository);
        filter.setPublicationService(publicationService);
		SchemePublicationVersion vers=filter.getSchemePublicationVersion(request);
		Assert.assertEquals((Long)2L, vers.getClassificationSchemeId());
		Assert.assertEquals("1.7", vers.getCpcXsdVersion());
		Assert.assertEquals("1.0", vers.getDefinitionXsdVersion());
		Assert.assertEquals(DocumentAdapter.class.getCanonicalName(), 
				vers.getDocumentAdapterClass());
		
		
	}

	

	@Test
	public void testWithInvalidDateString() {
		   MockHttpServletRequest request = new MockHttpServletRequest();
	        request.setContextPath("/cpcipcrestweb");
	        request.setServerName("localhost");
	        request.setRequestURI("/cpcipcrestweb/symbols");
	        request.addHeader(HttpHeaders.ACCEPT, RestUtils.CONTENT_TYPE_JSON);
	        
	    request.addHeader(RestUtils.SCHEME_PUBLICATION_DATE_HEADER, "2014-02-22");    
	     
		RevisionVersionFilter filter = new RevisionVersionFilter();
		filter.setClassificationSchemeRepository(classificationSchemeRepository);
        filter.setPublicationService(publicationService);
		SchemePublicationVersion vers=filter.getSchemePublicationVersion(request);
		Assert.assertEquals((Long)2L, vers.getClassificationSchemeId());
		Assert.assertEquals("1.7", vers.getCpcXsdVersion());
		Assert.assertEquals("1.0", vers.getDefinitionXsdVersion());
		Assert.assertEquals(DocumentAdapter.class.getCanonicalName(), 
				vers.getDocumentAdapterClass());
		
		
	}

}
