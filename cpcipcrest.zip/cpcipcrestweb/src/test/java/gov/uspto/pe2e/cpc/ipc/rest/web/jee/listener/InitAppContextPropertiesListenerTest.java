package gov.uspto.pe2e.cpc.ipc.rest.web.jee.listener;

import java.util.Date;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.mock.web.MockServletContext;

import jakarta.servlet.ServletContextEvent;

public class InitAppContextPropertiesListenerTest {

    @Test
    public void test() {
        Date starttime = DateTime.now().plusMinutes(-60).toDate();
        MockServletContext sc = new MockServletContext("");
//        sc.addInitParameter(ContextLoader.CONTEXT_CLASS_PARAM,
//                "org.springframework.web.servlet.SimpleWebApplicationContext");
        ServletContextEvent event = new ServletContextEvent(sc);
        InitAppContextPropertiesListener listener = new InitAppContextPropertiesListener();
        listener.contextInitialized(event);
        
        Assert.assertTrue(starttime.before((Date)sc.getAttribute(InitAppContextPropertiesListener.SERVLET_CONTEXT_STARTTIME_KEY)));
    }

}
