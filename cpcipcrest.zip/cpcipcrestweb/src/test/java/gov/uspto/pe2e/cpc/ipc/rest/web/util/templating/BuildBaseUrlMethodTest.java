/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.util.templating;

import java.util.ArrayList;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import freemarker.template.TemplateModelException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.BuildBaseUrlMethod;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import jakarta.inject.Inject;

/**
 * 
 * @author 2020
 * @date Nov 23, 2015 11:31:12 AM
 * @version 
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:META-INF/spring/applicationContext.xml", "classpath:META-INF/spring/applicationContext-test.xml"})
public class BuildBaseUrlMethodTest {
	@Inject
	private DatasetTestingService datasetTestingService;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		datasetTestingService.loadOnce();
		
		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-09-01", 
				DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);
		
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols/14/definition.docx")));
		
	}

	/**
	 * Test method for {@link gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.BuildBaseUrlMethod#exec(java.util.List)}.
	 * @throws TemplateModelException 
	 */
	@Test
	public void testExec() throws TemplateModelException {
		BuildBaseUrlMethod method = new BuildBaseUrlMethod();
		String url = (String)method.exec(new ArrayList());
		Assert.assertEquals("http://localhost:8080/cpcipcrestweb", url);
	}

}
