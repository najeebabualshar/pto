package gov.uspto.pe2e.cpc.ipc.rest.web.controller.error;

import java.util.Arrays;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ExternalServiceException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
//@Execution(ExecutionMode.CONCURRENT)
public class ExternalServiceExceptionTest {
    private static final Logger log = LoggerFactory.getLogger(GlobalControllerExceptionHandler.class);

   
    @Inject
    private DatasetTestingService datasetTestingService;

    
    @Before
    public void setUp() throws Exception {
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        datasetTestingService.loadOnce();
        
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1", "user@user.com",
                Arrays.asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
    }
    
    @Test
    public void testExternalServiceException () {
			try {
				testApplicationException();
			} catch (ExternalServiceException e) {
				Assert.assertNotNull(e);
				e.printStackTrace();
			}
    }
    
    @Test
    public void testExternalServiceExceptionWithMessage() {
    	try {
    		testApplicationExceptionWithMessage();
		} catch (ExternalServiceException e) {
			Assert.assertEquals("Configuration Error", e.getMessage());
			e.printStackTrace();
		}       
    }
    
    @Test
    public void testExternalServiceExceptionWithThrowable() {
    	try {
    		testApplicationExceptionWithThrowable();
		} catch (ExternalServiceException e) {
			Assert.assertEquals("Error in Configuration", e.getCause().getMessage());
			e.printStackTrace();
		}       
    }
    
    @Test
    public void testExternalServiceExceptionWithMessageAndThrowable() {
    	try {
    		testApplicationExceptionWithThrowableWithMessageAndThrowable();
		} catch (ExternalServiceException e) {
			Assert.assertEquals("Configuration Error", e.getMessage());
			Assert.assertEquals("Error in Configuration", e.getCause().getMessage());
			e.printStackTrace();
		}       
    }
    
    
    @Test
    public void testExternalServiceExceptionWithStackTrace() {
    	try {
    		testApplicationExceptionWithStackTrace();
		} catch (ExternalServiceException e) {
			Assert.assertEquals("Configuration Error", e.getMessage());
			Assert.assertEquals("Error in Configuration", e.getCause().getMessage());
			e.printStackTrace();
		}       
    }
    
    private void testApplicationException() throws ExternalServiceException {
    	throw new ExternalServiceException();
    }
    
    private void testApplicationExceptionWithMessage() throws ExternalServiceException {
    	throw new ExternalServiceException("Configuration Error");
    }
    
    private void testApplicationExceptionWithThrowable() throws ExternalServiceException {
    	throw new ExternalServiceException(new Throwable("Error in Configuration"));
    }
    
    private void testApplicationExceptionWithThrowableWithMessageAndThrowable() throws ExternalServiceException {
    	throw new ExternalServiceException("Configuration Error", new Throwable("Error in Configuration"));
    }
    
    private void testApplicationExceptionWithStackTrace() throws ExternalServiceException {
    	throw new ExternalServiceException("Configuration Error", new Throwable("Error in Configuration"), false, false);
    }
}
