package gov.uspto.pe2e.cpc.ipc.rest.testingsupport;

import java.util.Date;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalStateType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalSubphase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskStateDetails;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import jakarta.annotation.Nullable;
import jakarta.inject.Inject;

@Service("wmsTestTransactionalBoundaryService")
public class WmsTestTransactionalBoundaryService {
    @Inject 
    private ProposalService proposalService;

    @Transactional(propagation=Propagation.NOT_SUPPORTED)
    public void proxyTaskUpdate(UUID proposalGuid, String wmsProcessInstanceId, String wmsDefinitionId, @Nullable TaskStateDetails... tasks) {

        proposalService.updateProposalStatus(proposalGuid, 
                 wmsProcessInstanceId, wmsDefinitionId, 
                new Date(), null, 
                ProposalPhase.INTERNAL, ProposalSubphase.POST_PROCESSING, ProposalStateType.ACTIVE, "vkommareddy@uspto.gov", 
                null,tasks);
        
    }
    
}
