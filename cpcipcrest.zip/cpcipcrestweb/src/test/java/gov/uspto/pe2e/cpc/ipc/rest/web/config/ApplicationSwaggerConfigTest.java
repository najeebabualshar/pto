package gov.uspto.pe2e.cpc.ipc.rest.web.config;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:META-INF/spring/applicationContext.xml", "classpath:META-INF/spring/applicationContext-test.xml"})
public class ApplicationSwaggerConfigTest {

	@Test
	public void testApplicationSwaggerConfigEnabled() {
		
//		ApplicationSwaggerConfig applicationSwaggerConfig = new ApplicationSwaggerConfig();
//		Docket docket = applicationSwaggerConfig.api();
//		Assert.assertNotNull(docket);
//		Assert.assertTrue(docket.isEnabled());
	}
}
