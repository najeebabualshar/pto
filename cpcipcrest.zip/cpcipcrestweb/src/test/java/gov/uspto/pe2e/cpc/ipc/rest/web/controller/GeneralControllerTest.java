package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:META-INF/spring/applicationContext.xml", "classpath:META-INF/spring/applicationContext-test.xml"})
public class GeneralControllerTest {

	@Inject 
	private GeneralController generalController;
	@Test
	public void test() {
		String s=generalController.redirectRootUrl().getViewName();
		Assert.assertEquals("redirect:https://dev.cpc-ce.org/",s);
	}

}
