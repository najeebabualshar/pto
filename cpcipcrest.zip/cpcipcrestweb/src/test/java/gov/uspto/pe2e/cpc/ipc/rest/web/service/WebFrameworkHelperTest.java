package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.ObjectError;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.CustomValidationException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.WebFrameworkHelper;
import gov.uspto.pe2e.cpc.ipc.rest.commons.test.model.ReflectionTarget;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class WebFrameworkHelperTest {
    

    @Inject
    private WebFrameworkHelper webFrameworkHelper;

    @Test
    public void test() {
        ObjectError error = new ObjectError("symbolName",new String[]{"Pattern.symbolNameStructure.subGroup"}, 
                new String[]{"XXX","YYY","ZZZ"},"Test test");
        ReflectionTarget targ =  new ReflectionTarget();
        BeanPropertyBindingResult errors = new BeanPropertyBindingResult(targ, "file");
        errors.addError(error);
        CustomValidationException e = webFrameworkHelper.newValidationException(errors);
        Assert.assertNotNull(e);
        Assert.assertEquals("Pattern.symbolNameStructure.subGroup", e.getErrors().get(0).getLeft());
    }

}
