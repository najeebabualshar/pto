package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.templates.v1_0.ComponentTemplate;
import gov.uspto.pe2e.cpc.ipc.rest.contract.templates.v1_0.NoteParagraphTemplate;
import jakarta.inject.Inject;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TemplateControllerTest {
    private static final Logger log = LoggerFactory.getLogger(TemplateControllerTest.class);
    @Inject
    private TemplateController templateController;
    
    @Inject
    private DatasetTestingService datasetTestingService;


    @Test
    public void testGetlist() throws JsonGenerationException, JsonMappingException, IOException {

        ResponseEntity<List<ComponentTemplate>> resp = templateController.listAvailableNoteTemplatesByCategory(ComponentCategory.NOTE, false);
        Assert.assertNotNull(resp);
/*
        Assert.assertEquals(2, resp.getBody().size());
        log.debug("Json = {}", JsonUtils.toJson(resp.getBody().get(0)));
        Assert.assertEquals(Boolean.TRUE, resp.getBody().get(0).isDefaultTemplate());
        Assert.assertEquals(Boolean.FALSE, resp.getBody().get(1).isDefaultTemplate());
        Assert.assertNull(((NoteParagraphTemplate)resp.getBody().get(0)).getNoteItem());
        Assert.assertEquals(ComponentCategory.NOTE, resp.getBody().get(0).getCategory());
        
        resp = templateController.listAvailableNoteTemplatesByCategory(ComponentCategory.WARNING, false);
        Assert.assertNotNull(resp);
        Assert.assertEquals(1, resp.getBody().size());
        
        log.debug("Json = {}", JsonUtils.toJson(resp.getBody().get(0)));
        Assert.assertNull(((NoteParagraphTemplate)resp.getBody().get(0)).getNoteItem());
        Assert.assertEquals(ComponentCategory.WARNING, resp.getBody().get(0).getCategory());
        Assert.assertEquals(Boolean.TRUE, resp.getBody().get(0).isDefaultTemplate());
        
        resp = templateController.listAvailableNoteTemplatesByCategory(null, false);
        Assert.assertNotNull(resp);
        Assert.assertEquals(6, resp.getBody().size());
        Assert.assertEquals(Boolean.TRUE, resp.getBody().get(0).isDefaultTemplate());
        for ( int i = 1 ; i < resp.getBody().size(); i++) {
        	if (i != 2) {
        		assertEquals( i+" default is not false", Boolean.FALSE, resp.getBody().get(i).isDefaultTemplate());
        	} else {
        		assertTrue(resp.getBody().get(i).isDefaultTemplate());
        	}
        }
*/  
  }
    
    @Test
    public void testGetTemplateContent() throws JsonGenerationException, JsonMappingException, IOException {

    	ResponseEntity<ComponentTemplate> resp = templateController.getNoteTemplatesByShortDescriptionAndCategory("Note Template 1",ComponentCategory.NOTE);
        Assert.assertNotNull(resp);
        Assert.assertNotNull(((NoteParagraphTemplate)resp.getBody()).getNoteItem());
        String noteOrWarningType = ((NoteParagraphTemplate)resp.getBody()).getNoteItem().getNoteOrWarningType();
        Assert.assertNull(noteOrWarningType);
        Assert.assertEquals("This is note template 1",
                ((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText)((
                ((NoteParagraphTemplate)resp.getBody()).getNoteItem()).getChildren().get(0))).getContent());
        
    }
    
    @Test
    public void testGetTemplateContentUnknown() throws JsonGenerationException, JsonMappingException, IOException {

        ResponseEntity<ComponentTemplate> resp = templateController.getNoteTemplatesByShortDescriptionAndCategory("This is not present",ComponentCategory.NOTE);
        Assert.assertNotNull(resp);        
        Assert.assertEquals(200,resp.getStatusCode().value());
    }
    
    @Test
    public void testGetTemplateContentNull() throws JsonGenerationException, JsonMappingException, IOException {

        ResponseEntity<ComponentTemplate> resp = templateController.getNoteTemplatesByShortDescriptionAndCategory(null,null);
        Assert.assertNotNull(resp);
        Assert.assertEquals(200,resp.getStatusCode().value());
    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/templates/notes")));
    }


}
