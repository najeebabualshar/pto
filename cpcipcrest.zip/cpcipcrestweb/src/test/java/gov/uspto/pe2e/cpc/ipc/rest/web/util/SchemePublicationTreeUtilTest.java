package gov.uspto.pe2e.cpc.ipc.rest.web.util;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Test;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.RequestPublicationVersionVsEntityMismatchException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationScheme;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.SchemeHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.business.SchemePublicationTreeUtil;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;


public class SchemePublicationTreeUtilTest {

    @Test(expected=RequestPublicationVersionVsEntityMismatchException.class)
    public void testVerifyRequestedDateMatches() throws ParseException {

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate(
                "2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);   
        
        
        
        SchemeHierarchy dbSymbol = new SchemeHierarchy();
        ClassificationScheme classificationScheme = new ClassificationScheme();
        classificationScheme.setSchemeVersionDate(new Date());
        dbSymbol.setClassificationScheme(classificationScheme);
        SchemePublicationTreeUtil.verifyRequestedDateMatches(dbSymbol);
        
    }
    
	@Test
	public void testConvertDotLevelToIndentLevel() {

		int level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("Section");
		Assert.assertEquals(2, level);
		
		level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("Class");
		Assert.assertEquals(4, level);

		level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("subclass");
		Assert.assertEquals(5, level);
		
		level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("0");
		Assert.assertEquals(7, level);

		level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("1");
		Assert.assertEquals(8, level);
		
		level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("12");
		Assert.assertEquals(19, level);
	}
	
	@Test
	public void testVerifyAfterConvert() {
	    String input = "0";
	    int indent = SchemePublicationTreeUtil.convertDotLevelToIndentLevel(input);
	    String output = SchemePublicationTreeUtil.convertIndentLevelToDotLevel(indent);
	    Assert.assertEquals(input, output);
	    
	    input = "5";
        indent = SchemePublicationTreeUtil.convertDotLevelToIndentLevel(input);
        output = SchemePublicationTreeUtil.convertIndentLevelToDotLevel(indent);
        Assert.assertEquals(input, output);
        
        input = "Subclass";
        indent = SchemePublicationTreeUtil.convertDotLevelToIndentLevel(input);
        output = SchemePublicationTreeUtil.convertIndentLevelToDotLevel(indent);
        Assert.assertEquals(input, output);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testConvertDotLevelToIndentLevelTooLow() {
		int level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("-1");
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testConvertDotLevelToIndentLevelTooHigh() {
		int level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("20");
	}

	//This is requried
	@Test(expected=IllegalArgumentException.class)
	public void testConvertDotLevelToIndentLevelInvalidName() {
		int level = SchemePublicationTreeUtil.convertDotLevelToIndentLevel("Himom");
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testConverIndentLevelToDotLevel() {
	    SchemePublicationTreeUtil.convertIndentLevelToDotLevel(3000);
	}

}
