package gov.uspto.pe2e.cpc.ipc.rest.web.controller;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:META-INF/spring/applicationContext.xml", "classpath:META-INF/spring/applicationContext-test.xml"})
public class InfoControllerTest {
	private Logger log = LoggerFactory.getLogger(InfoControllerTest.class);

	@Inject 
	private InfoController infoController;
	@Test
	public void test() throws IOException {
		List<String> allowedDups = Arrays.asList( "org.xmlpull.v1.XmlPullParserException.class",
				"org.xmlpull.v1.XmlPullParser.class","org.w3c.dom.UserDataHandler.class");
		HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/info/classes");
        
		ResponseEntity<Map<String, List<String>>> m = infoController.listDuplicateClassPackageInfo(request);
		log.debug("classes {}", JsonUtils.toJson(m.getBody()) );
		for (Entry<String, List<String>> e: m.getBody().entrySet()) {
			log.debug("{} - {}", e.getKey(), e.getValue());
			assertTrue(allowedDups.contains(e.getKey()));
		}
	}

}
