package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.SchemeHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.Symbol;
import gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalDetailsVerificationController;
import gov.uspto.pe2e.cpc.ipc.rest.sn.service.SymbolService;
import jakarta.inject.Inject;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalDetailsVerificationControllerTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalDetailsVerificationControllerTest.class);
    
    @Inject
    private ProposalDetailsVerificationController proposalDetailsVerificationController;
    
    @Inject
    private SchemeHierarchyRepository schemeHierarchyRepository;
    @Inject
    private SymbolService symbolService;
    
    @Inject
    private DatasetTestingService datasetTestingService;

    @Test
    public void testExportGoldCopyTitles() {    
        
       
    	ResponseEntity<List<Map<String,String>>> resp = proposalDetailsVerificationController.exportTitles(GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56"));
    	Assert.assertTrue(CollectionUtils.isNotEmpty(resp.getBody()));
    	for (Map<String,String> rec: resp.getBody()) {
    	    log.debug("xml fragment {}", rec.get(ProposalDetailsVerificationController.TITLE_XML_FIELD_KEY));
    	}
    }
    
    @Test
    public void testMapGoldCopyTitle() {        

        Object o = symbolService.findSymbolByName("A01N", Boolean.FALSE);
        SchemeHierarchy symbol = schemeHierarchyRepository.findByNameFromLatestSchemeNotIncludingHeadingSymbols("A01N");
        Assert.assertNotNull(o);
        String xml = proposalDetailsVerificationController.mapToGoldCopy(((Symbol)o).getTitlePartTree());
            log.debug("xml fragment {}", xml);
            log.debug("DB title xml = {}", symbol.getTitle());
            
    }

     
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate(
                "2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

}
