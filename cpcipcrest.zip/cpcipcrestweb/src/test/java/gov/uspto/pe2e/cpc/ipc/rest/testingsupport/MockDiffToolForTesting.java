/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.testingsupport;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.InputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;


/**
 * 
 * @author 2020
 * @date Jul 8, 2019
 * @since __INSERT_VERSION__
 * @version __INSERT_VERSION__
 */
public class MockDiffToolForTesting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
		assertEquals(2, args.length);
		String symbol = args[0];
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/xml/diff/"
				+symbol+"_results.xml");
		byte[] diffXml = IOUtils.toByteArray(is);
		String parentDir = StringUtils.substringBeforeLast(args[1], File.separator)+File.separator;
		FileUtils.writeByteArrayToFile(new File(parentDir+"result.xml"), diffXml);
		//cp src/test/data/xml/diff/{0}_results.xml $(dirname "{1}")/result.xml 
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
