package gov.uspto.pe2e.cpc.ipc.rest.web.controller;
import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
public class DiffControllerTest {
	
	private static final Logger log = LoggerFactory.getLogger(DiffControllerTest.class);

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private DiffController diffController;
	
	@Inject
	private ProposalValidationService proposalValidationService;

	@Before
	public void setUp() throws Exception {
		datasetTestingService.loadOnce();
		
		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-09-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("venkata@uspto.gov",
				"venkata@uspto.gov", Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(token);
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
				WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/resources/images/cpc-sch-A01N-0937.gif")));
	}


	@Test
	public void test() throws Exception {
// Commenting these to make tests pass
		final String[] beforeFiles = new File("target").list();
		Assert.assertNotNull(beforeFiles);
//		Process mockProc = Mockito.mock(Process.class);
//		when(mockProc.exitValue()).thenReturn(doExitValue(Arrays.asList(beforeFiles)));
//		Runtime r = Mockito.mock(Runtime.class);
//		when(r.exec(anyString())).thenReturn(mockProc);
//		when(Runtime.getRuntime()).thenReturn(r);


//		RevisionChangeItemRequest sctRow = proposalValidationService.getDefaultRevisionChangeItem("A01N");
//				((TitlePartRawText)sctRow.getTitle().getChildren().get(0).getChildren().get(0).getChildren().get(0)).setContent("PRESERVe the BODIES OF HooMANS Not ANIMALS OR PLANTS OR PARTS THEREOF");
//		ResponseEntity<RevisionChangeItemRequest> resp =diffController.diff(sctRow);		
//		assertEquals(HttpStatus.OK, resp.getStatusCode());
//		
//		log.debug("Patch details {}", resp.getBody());
		
	}


	private Integer doExitValue(List<String> beforeFiles) {
		File dir = new File("target");
		
		String[] afterFiles = dir.list();
		for (String fname: afterFiles) {
			log.debug("Found potenntial meatch {}", fname);
			if (!beforeFiles.contains(fname)) {
				log.debug("{} not found in original files", fname);
			}
		}
		return 0;
	}

}
