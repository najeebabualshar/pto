package gov.uspto.pe2e.cpc.ipc.rest.web.util.templating;

import org.junit.Assert;
import org.junit.Test;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.TemplateConfigurationLocator;

public class TemplateConfigurationLocatorTest {

    @Test
    public void testSetS3BaseUrl() {

        String baseUrl = new TemplateConfigurationLocator().getS3BaseUrl();
        String test = "TEST.....";
        TemplateConfigurationLocator.overrideS3BaseUrl(test);
        String compareTo = new TemplateConfigurationLocator().getS3BaseUrl();
        Assert.assertEquals(test, compareTo);
        new TemplateConfigurationLocator().setS3BaseUrl("Something else");
        Assert.assertEquals(test, compareTo);

        TemplateConfigurationLocator.overrideS3BaseUrl(baseUrl);
    }

    @Test
    public void testSetUiBaseUrl() {

        String baseUrl = new TemplateConfigurationLocator().getUiBaseUrl();
        if (baseUrl == null) {
            String test = "TEST.....";
            new TemplateConfigurationLocator().setUiBaseUrl(test);
            String compareTo = new TemplateConfigurationLocator().getUiBaseUrl();
            Assert.assertEquals(test, compareTo);
        }
    }

}
