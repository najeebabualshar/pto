package gov.uspto.pe2e.cpc.ipc.rest.testingsupport.validation;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
/**
 * This is a simple spring injectable service so we can test and verify framework features
 * 
 * @author 2020
 * @date Jan 22, 2016 10:46:46 AM
 * @version
 */
@Service("sampleInjectableFrameworkService")
@Validated
public class SampleInjectableFrameworkService {
	/**
	 * This method validates that the argument is not null/not empty
	 * @param symbolName
	 * @return
	 */
	public SymbolName doValidationsOnArgument(@NotNull(message="Must be not null") 
		@NotEmpty 
		@Pattern(regexp="^A") String symbolName) {
		return SymbolName.parse(symbolName);
	}

}
