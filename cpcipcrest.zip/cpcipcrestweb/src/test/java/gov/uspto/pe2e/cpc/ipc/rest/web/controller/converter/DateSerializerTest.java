/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.controller.converter;


import org.apache.commons.lang3.time.DateFormatUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 
 * @author 2020
 * @date Nov 17, 2015 5:23:12 PM
 * @version 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class DateSerializerTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		
		String format = DateFormatUtils.ISO_DATETIME_TIME_ZONE_FORMAT.getPattern();
		System.out.println("Our JSon Serializer Date Format should be "+format);
		Assert.assertEquals("yyyy-MM-dd'T'HH:mm:ssZZ", format);
	}

}
