package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
//import org.junit.runner.RunWith;
//import org.junit.Test;
//import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalCommentRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentPartCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalComment;
import gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalCommentController;
import jakarta.inject.Inject;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;
/**
 * NOTE: Do not add tests to THIS class if they update the database.
 * all Volatile tests should go in @see ProposalCommentControllerVolatileTest
 * @author myoung3
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
//@Test(suiteName="volatile")
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalCommentControllerVolatileTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalCommentControllerVolatileTest.class);
    
    @Inject
    private ProposalCommentController proposalCommentController;
    
    @Inject 
    private ChangeProposalCommentRepository changeProposalCommentRepository;
    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Test ()
    @Transactional
    public void testSaveSuccess() {
    	long numExist = changeProposalCommentRepository.findByProposalExternalId("c960d30a52a847fc8c51b64dfcc0ea85").size();
    	
    	log.debug("Testing save success");
    	ProposalComment comment = new ProposalComment();
		comment.setCreateTs(new Date());
		comment.setCreateUserId("myoung@uspto.gov");
		comment.setLastModifyTs(new Date());
		comment.setLastModifyUserId(comment.getCreateUserId());
		comment.setProjectName("XX0026");
		comment.setRevision(1);
		comment.setReferenceContext(ComponentPartCategory.RECLASS_TRANSFER);
		comment.setSymbolName("A01N");
		comment.setCommentText(StringUtils.repeat("X", 4000));
    	ResponseEntity<Void> resp = proposalCommentController.saveComment(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), comment);
    	Assert.assertEquals(HttpStatus.CREATED, resp.getStatusCode());
    	Assert.assertNotNull(resp.getHeaders().getLocation());
    	assertEquals(numExist+1, changeProposalCommentRepository.findByProposalExternalId("c960d30a52a847fc8c51b64dfcc0ea85").size());
    	
    	
    }    

    @Test
    public void testDeleteSuccess() {
    	log.debug("Testing delete");
    	int existing = changeProposalCommentRepository.findByProposalExternalId("c960d30a52a847fc8c51b64dfcc0ea85").size();
    	ResponseEntity<Void> resp = proposalCommentController.deleteComment(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
    			GUIDUtils.fromDatabaseFormat("2a0910f5f241405291488a08da62d80d"));
    	Assert.assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
    	assertEquals(existing -1, changeProposalCommentRepository.findByProposalExternalId("c960d30a52a847fc8c51b64dfcc0ea85").size());
    	
    }
    @Test
    @Transactional
    public void testDeleteDoesNotExist() {
    	log.debug("Testing delete does not exit");
    	try {
    	ResponseEntity<Void> resp = proposalCommentController.deleteComment(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
    			UUID.randomUUID());
    		fail();
    	} catch (Exception e) {
    		if (e.getClass().equals(EntityNotFoundException.class)) {
    			log.debug("found entity not found exception as expected");
    		} else {
    			fail();
    		}
    	}
    	
    }

    @Test
    @Transactional
    public void testDeleteProposalIdDoesNotExist() {
    	log.debug("Testing delete does not exit");
    	try {
    	ResponseEntity<Void> resp = proposalCommentController.deleteComment(
    			UUID.randomUUID(),GUIDUtils.fromDatabaseFormat("2a0910f5f241405291488a08da62d80d"));
    		fail();
    	} catch (Exception e) {
    		if (e.getClass().equals(EntityNotFoundException.class)) {
    			log.debug("found entity not found exception as expected");
    		} else {
    			fail();
    		}
    	}
    	
    }

//    @BeforeClass(dependsOnMethods={"springTestContextPrepareTestInstance"})
//    public void setupParamValidation(){
//        // Test class setup code with autowired classes goes here
//    }
    
    @Before
    public void setUp() throws Exception {
    	
    	log.debug("Running setup() this should only run before each test method");
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test"), 
                		new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

}
