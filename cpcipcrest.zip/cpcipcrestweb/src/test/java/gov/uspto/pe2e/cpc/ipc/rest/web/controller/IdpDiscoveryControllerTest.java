package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jakarta.inject.Inject;

/**
 * 
 * @author 2020
 * @date Dec 03, 2015
 * @version
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class IdpDiscoveryControllerTest {
    private static final Logger log = LoggerFactory.getLogger(IdpDiscoveryControllerTest.class);

    @Inject
    private IdpDiscoveryController idpDiscoveryController;

    @Test
    @Transactional
    public void testResolveIdpUrl() {
        ResponseEntity<String> resp = idpDiscoveryController.resolveIdpUrl("151.207.241.201");
        Assert.assertNotNull(resp);
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(1, resp.getHeaders().size());
        Assert.assertEquals("https://opd-xmltest-a-706.etc.uspto.gov:9443/",
                resp.getHeaders().getLocation().toString());
        log.debug(resp.getHeaders().getLocation().toString());
    }

}
