package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Set;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.QNContactType;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.QnDetail;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.QnDetailRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_0.QNContact;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_0.QNContactDocument;
import gov.uspto.pe2e.cpc.ipc.rest.sn.service.QnDetailService;
import jakarta.inject.Inject;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class QnDetailServiceTest {
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private QnDetailService qnDetailService;


    @Inject
    private QnDetailRepository qnDetailRepository;
    
    @Test
    @Transactional
    public void testFindA01N() throws JsonGenerationException, JsonMappingException, IOException {
        QNContactDocument doc = qnDetailService.buildContactDocument("A01N");
        Assert.assertNotNull(doc);
        Assert.assertEquals(5, doc.getArtUnits().size());
        Assert.assertEquals(1, doc.getSupervisoryPatentExaminers().size());
        Assert.assertEquals(2, doc.getTcLeads().size());
        Assert.assertEquals(2, doc.getEpoQualityNominees().size());
        Assert.assertEquals(4, doc.getQualityNominees().size());

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        mapper.writeValue(baos, doc);
        System.out.println(baos.toString());

    }

    @Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
    }

    @Test
    @Transactional
    public void testbuildContactDocument() {
        QNContactDocument doc = qnDetailService.buildContactDocument("A01N");
        Assert.assertNotNull(doc);
        Assert.assertEquals("A01N", doc.getSymbolName());
        Assert.assertEquals("Bishmeet", doc.getQualityNominees().get(0).getFirstName());
        Assert.assertEquals(5, doc.getArtUnits().size());
        
        for (QNContact ctc: doc.getEpoQualityNominees()) {
        	System.out.println(ctc.getId() +" "+ ctc.getEmail());
        }
        
    }

    @Test
    public void testBuildQNContact() {
        QnDetail qd = new QnDetail();
        qd.setArtUnit("2899");
        qd.setClassificationSymbolCode("A01N");
        qd.setEmail("matthew.young@uspto.gov");
        qd.setFirstName("Matt");
        qd.setId(1L);
        qd.setLastName("Young");
        qd.setQnContactType(QNContactType.SPEQN);

        QNContact qn = qnDetailService.buildQNContact(qd);
        Assert.assertNotNull(qn);
        Assert.assertEquals("Matt", qn.getFirstName());
        Assert.assertEquals("matthew.young@uspto.gov", qn.getEmail());
        Assert.assertEquals((Long) 1L, qn.getId());
    }
    
    @Test
    public void testBuildQNContactAndTestConstraintViolations() {
        QnDetail qd = new QnDetail();
        qd.setArtUnit("2899");
        qd.setClassificationSymbolCode("A01N");
        qd.setEmail("matthew.young@uspto.gov");
        qd.setFirstName("Matt");
        qd.setId(1L);
        qd.setLastName("Young");
        qd.setQnContactType(QNContactType.SPEQN);
        
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<QnDetail>> violations = validator.validate(qd);
        Assert.assertEquals(violations.size(), 0);
        
    }

}
