package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.Arrays;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DirectoryUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.sn.controller.SymbolController;
import gov.uspto.pe2e.cpc.ipc.rest.sn.service.SymbolSearchService;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
public class JunitControllerBootstrapTest {
	private static final Logger log = LoggerFactory.getLogger(JunitControllerBootstrapTest.class);
	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private SymbolSearchService symbolSearchService;

	@Inject
	private SymbolController symbolController;

	public void setUp() throws Exception {
		datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1", "user@user.com",
				Arrays.asList(new BasicTestingGrantedAuthority("test")));

		SecurityContextHolder.getContext().setAuthentication(token);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
		if (symbolSearchService.getLastIndexDate() == null) {
			DirectoryUtils.createTargetDir("cpcipcrestindex");

			symbolSearchService.buildIndex();
		}
	}

	@Test
	@Transactional
	public void testSetup() throws Exception {
		setUp();
		Assert.assertNotNull(datasetTestingService);
	}
}
