package gov.uspto.pe2e.cpc.ipc.rest.web.service;


import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.IdpDiscoveryService;
import jakarta.inject.Inject;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:META-INF/spring/applicationContext.xml", "classpath:META-INF/spring/applicationContext-test.xml"})
public class IdpDiscoveryServiceTest {

	@Inject
	private IdpDiscoveryService idpDiscoverService;
	@Test
	public void test() {
		String idpIdentity=idpDiscoverService.resolveIdpUrl("10.0.0.1");
		Assert.assertEquals("http://idp.ssocircle.com", idpIdentity);
		
		idpIdentity=idpDiscoverService.resolveIdpUrl("151.207.241.201");
		Assert.assertEquals("https://opd-xmltest-a-706.etc.uspto.gov:9443/", idpIdentity);
		
		idpIdentity=idpDiscoverService.resolveIdpUrl("10.244.208.181");
		Assert.assertEquals("www.yahoo.com", idpIdentity);
	}

}
