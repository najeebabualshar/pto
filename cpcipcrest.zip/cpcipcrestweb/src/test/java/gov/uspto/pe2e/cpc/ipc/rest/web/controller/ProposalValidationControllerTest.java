package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
//import org.junit.jupiter.api.Tag;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcConcordanceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.NAWItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassTransfer;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalvalidation.v1_0.ProposalValidationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalvalidation.v1_0.ProposalValidationResponse;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.SubNote;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalValidationController;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalRevisionService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.annotation.XmlType;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@Execution(ExecutionMode.CONCURRENT)
//@Tag("nonvolatile")t p
public class ProposalValidationControllerTest {
	
    private static final Logger log = LoggerFactory.getLogger(ProposalValidationControllerTest.class);
    
    @Inject
    private ProposalValidationController proposalValidationController;
    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    private Date lastInit = null;
    
    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();

    		SchemePublicationVersion version = new SchemePublicationVersion();
    		version.setClassificationSchemeId(1L);
	        version.setCpcXsdVersion("1.7");
	        version.setDefinitionXsdVersion("1.0");
	        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
	        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
	        SchemePublicationVersionContextHolder.setContext(version);
	        
	        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov", "myoung3@uspto.gov", Arrays
	                .asList(new BasicTestingGrantedAuthority("test@uspto.gov")));
	        SecurityContextHolder.getContext().setAuthentication(token);
	        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
	                "/cpcipcrestweb", "/symbols")));
	        lastInit = new Date();
    }

    
    @Test
    public void testValidateGlobalDupCheck() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", "A01N", "CLASS", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", "A01N", "CLASS", null, null, "Administrative transfer to A02N"));
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);

        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(4,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        Assert.assertEquals(4, resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());
        log.debug(JsonUtils.toJson(resp.getBody()));
    }

    @Test
    public void testValidateGlobalDupCHeck_nodupable() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", "", "CLASS", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", "", "CLASS", null, null, "Administrative transfer to A02N"));
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);

        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(2, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        Assert.assertEquals(2, resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());
    }
    
    @Test
    public void testValidateNoContent() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNull(resp.getBody());
        Assert.assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
    }
    
    @Test
    public void testValidateIncompleteNoteEntry() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        
        RevisionChangeItemRequest item = createRevisionChangeItem("M", "", "CLASS", null, null, "Administrative transfer to A02N" );
        NAWItemEditRequest naw = new NAWItemEditRequest();
        naw.setNoteCategory(NoteType.NOTE);
        naw.setChangeType(SCTComponentChangeType.M);
        
        item.getNoteItems().add(naw);
        proposalValidationRequest.getRevisionChangeItems().add(item);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        for (ValidationMessage m: resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()) {
        	log.debug("{}", m.getMessageText());
        }
        Assert.assertEquals(2, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
    }
    
    
    @Test
    public void testValidateOneValidRow() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", "A01B 1/00", "CLASS", null, null, "Administrative transfer to A02N"));
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        Assert.assertEquals(3, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());       
    }

    
    @Test
    public void testValidateNotValidEntryType() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("XX", "A99X", "CLASS", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("XX", "A98X", "CLASS", null, null, "Administrative transfer to A02N"));
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(2, resp.getBody().getRevisionChangeItems().size());        log.debug("messages from index 0 {}", JsonUtils.toJson(resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()));
        log.debug("messages from index 1 {}", JsonUtils.toJson(resp.getBody().getRevisionChangeItems().get(1).getValidationMessages()));

        Assert.assertEquals(3, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        Assert.assertEquals(3, resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());
    }

    @Test
    public void testValidateBothViolateSymbolExistanceRules() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("D", "A99X", "CLASS", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("N", "A01N", "CLASS", null, null, "Administrative transfer to A02N"));
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(2, resp.getBody().getRevisionChangeItems().size());        
        

        
        log.debug("messages from index 0 {}", JsonUtils.toJson(resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()));
        log.debug("messages from index 1 {}", JsonUtils.toJson(resp.getBody().getRevisionChangeItems().get(1).getValidationMessages()));

        Assert.assertEquals(2, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        Assert.assertEquals(2, resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());
        
        Assert.assertEquals("Invalid indent level.",resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("Every entry must have a Title",resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText());       
        
        Assert.assertEquals("Invalid indent level.",resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("Every entry must have a Title",resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().get(1).getMessageText());
    }
    
//    List<RevisionChangeItem> rows = new ArrayList<>();
//    rows.add(ProposalValidationHelperTest.createRevisionChangeItemWithIntelluctualReclassCategory("C", "A01N", "0", "Bold Error ##BOLD##", null));

    
    
    @Test
    public void testMappingRevisionChangeRequestWithTitleGrammarText() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        
        RevisionChangeItemRequest request = createRevisionChangeItem("D", "A99X", "CLASS", null, null, "Administrative transfer to A02N");
        request.setTitleGrammar("Combinations or mixtures of active ingredients covered by classes ##SYMBOL##A01N27/00##/SYMBOL## - ##SYMBOL##A01N65/48##/SYMBOL##");
        proposalValidationRequest.getRevisionChangeItems().add(request);       
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        log.debug("messages from index 0 {}", JsonUtils.toJson(resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()));
    }
    
    
    
    @Test
    public void testMappingRevisionChangeRequestWithIPCTitleGrammarText() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        
        RevisionChangeItemRequest request = createRevisionChangeItem("M", "A01N", "SUBCLASS", null, null, "Administrative transfer to A02N");
        request.setTitleGrammar("Shovels; Rakes;{ Hoes}");
        proposalValidationRequest.getRevisionChangeItems().add(request);       
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        log.debug("messages from index 0 {}", JsonUtils.toJson(resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()));
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
    }
    
    
    @Test
    public void testMappingRevisionChangeRequestWithTitleGrammarTextError() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        
        RevisionChangeItemRequest request = createRevisionChangeItem("D", "A99X", "CLASS", null, null, "Administrative transfer to A02N");
        request.setTitleGrammar("Combinations or mixtures of active ingredients covered by classes ##SYMBOL##A01N27/00##/SYMBOL## - ##SYMBOL##A01N65/48");
        proposalValidationRequest.getRevisionChangeItems().add(request);       
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
    }
    
    
    
    private RevisionChangeItemRequest createRevisionChangeItem(String entryType, String symbolName, String dotLEvel, IpcConcordanceMapping ipcMapping,
            TitlePartTree titlePartTree, String reclassTransferExpression) {
        RevisionChangeItemRequest model = new RevisionChangeItemRequest();
        model.setEntryType(entryType);
        model.setSymbolName(symbolName);
        model.setDotLevel(dotLEvel);
        model.setIpcSymbol(ipcMapping);
        model.setTitle(titlePartTree);
        model.setReclassTransferExpression(reclassTransferExpression);
        //List<ReclassTransfer> reclassTransfers
        return model;
    }
//    
//    private RevisionChangeItemRequest createRevisionChangeItemWithReclass(String entryType, String symbolName, String dotLEvel, IpcConcordanceMapping ipcMapping,
//            TitlePartTree titlePartTree, String reclassTransferExpression, String reclassTransfer) {
//        RevisionChangeItemRequest model = new RevisionChangeItemRequest();
//        model.setEntryType(entryType);
//        model.setSymbolName(symbolName);
//        model.setDotLevel(dotLEvel);
//        model.setIpcSymbol(ipcMapping);
//        model.setTitle(titlePartTree);
//        model.setReclassTransferExpression(reclassTransferExpression);
//        ReclassTransfer rs = new ReclassTransfer();
//        rs.setTargetSymbolName(reclassTransfer);
//        rs.setReclassificationTypeCategory(ReclassificationTypeCategory.ADMIN);
//        model.getReclassTransfers().add(rs);
//        //List<ReclassTransfer> reclassTransfers
//        return model;
//    }
    
    @Test
    @Transactional
    public void testValidateDuplicateMessages() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItemWithReclassHavingBothCategory("M", "A01B1/022", "2", null, null, "Administrative transfer to A02N", new String[] {"D04D 7/00","D04D 7/02","B02B 3/08","C05D 3/02"}));        
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        
        System.err.println("resp.getBody().getRevisionChangeItems():"+resp.getBody().getRevisionChangeItems().toString());
        
        for (RevisionChangeItem item: resp.getBody().getRevisionChangeItems()) {
            for (ValidationMessage msg: item.getValidationMessages()) {
                log.debug("message text {}",msg.getMessageText());
                Assert.assertNotNull(msg.getPhase());
                Assert.assertEquals(ValidationMessageLevel.CRITICAL, msg.getLevel());
            }
        }
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        
        Assert.assertEquals(4,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());        
        log.debug(JsonUtils.toJson(resp.getBody()));
        
        Assert.assertEquals("Type M does not allow Transfer-To target symbol.", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());
//        Assert.assertEquals("Invalid Transfer-to Symbol 'D04D7/00' - it's not in Gold Copy (or) not Type N or Q in this proposal", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText());
//        Assert.assertEquals("Invalid Transfer-to Symbol 'D04D7/02' - it's not in Gold Copy (or) not Type N or Q in this proposal", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(2).getMessageText());
//        Assert.assertEquals("Invalid Transfer-to Symbol 'B02B3/08' - it's not in Gold Copy (or) not Type N or Q in this proposal", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(3).getMessageText());
//        Assert.assertEquals("Invalid Transfer-to Symbol 'C05D3/02' - it's not in Gold Copy (or) not Type N or Q in this proposal", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(4).getMessageText());
//        Assert.assertEquals("Intellectual reclassification is valid on Type C | Q | F only", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(6).getMessageText());
       
        Assert.assertEquals("Intellectual reclassification is valid on Type C | Q | F only", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText());
        Assert.assertEquals("Reclassification can only be Intellectual or Administrative, not both", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(2).getMessageText());
        Assert.assertEquals("Every entry must have a Title", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(3).getMessageText());

    }
    
    @Test
    public void testValidateReclassInContext() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItemWithReclass("C", "A01B1/022", "2", null, null, null, new String[] {"A01B1/022","H04N5/232933","H04N5/232935","H04N5/232939"}));        
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItemWithReclass("N", "H04N 5/232933", "2", null, null, null, null));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItemWithReclass("N", "H04N 5/232935", "2", null, null, null, null));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItemWithReclass("N", "H04N 5/232939", "2", null, null, null, null));
        proposalValidationRequest.setExcludeGlobalValidations(false);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.debug(JsonUtils.toJson(resp.getBody()));
        Assert.assertEquals(1,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());             
        log.debug("List of Messages-->"+resp.getBody().getRevisionChangeItems().get(0).getValidationMessages());
        Assert.assertEquals("Every entry must have a Title", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals(ValidationMessageType.RECORD, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageType());
        Assert.assertEquals(ValidationMessageField.TITLE, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getTriggerField());
    }
    
    
    
    @Test
    public void testPhasedValidaton() throws JsonGenerationException, JsonMappingException, IOException {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        List<RevisionChangeItemRequest> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemWithAdminReclass("C", "A01B1/022", "2", null, null, null, new String[] {"A01B1/00","A01N1/00"}));
        rows.get(0).setTitleGrammar("Title");
        rows.add(createRevisionChangeItemWithReclass("M", "A01B", "2", null, null, null, null));
        proposalValidationRequest.getRevisionChangeItems().addAll(rows);
        proposalValidationRequest.setExcludeGlobalValidations(false);
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.debug(resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().toString());
        log.debug(resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().toString());
        
        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        //Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());

        
        Assert.assertEquals("Invalid indent level.", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals(ValidationPhase.COMPLETENESS,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getPhase());
        
        Assert.assertEquals("Every entry must have a Title", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText());
        Assert.assertEquals(ValidationPhase.COMPLETENESS,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getPhase());
        
        // Fix the second row, and see error list.
        
        ProposalValidationRequest proposalValidationRequest1 = new ProposalValidationRequest();
        List<RevisionChangeItemRequest> rows1 = new ArrayList<>();
        rows1.add(createRevisionChangeItemWithAdminReclass("C", "A01B1/022", "2", null, null, null, new String[] {"A01B1/00","A01N1/00"}));
        rows1.get(0).setTitleGrammar("Title");
        rows1.add(createRevisionChangeItemWithReclass("M", "A01B", "2", null, null, null, null));

        
        rows1.get(1).setDotLevel("Subclass");
        rows1.get(1).setTitleGrammar("Title");
        
        proposalValidationRequest1.getRevisionChangeItems().addAll(rows1);
        proposalValidationRequest1.setExcludeGlobalValidations(false);
        ResponseEntity<ProposalValidationResponse> resp1 = proposalValidationController.validate(proposalValidationRequest1);
        Assert.assertEquals(HttpStatus.OK, resp1.getStatusCode());
        log.debug(resp1.getBody().getRevisionChangeItems().get(0).getValidationMessages().toString());
        log.debug(resp1.getBody().getRevisionChangeItems().get(1).getValidationMessages().toString());
        
        Assert.assertEquals(1,resp1.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        Assert.assertEquals(3,resp1.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());
        
        Assert.assertEquals("C group must transfer to self and at least one other group.", resp1.getBody().getRevisionChangeItems().get(1).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals(ValidationPhase.CONSISTENCY,resp1.getBody().getRevisionChangeItems().get(1).getValidationMessages().get(0).getPhase());
        Assert.assertEquals("C groups may not have administrative transfers. C groups require intellectual reclass.", resp1.getBody().getRevisionChangeItems().get(1).getValidationMessages().get(1).getMessageText());
        Assert.assertEquals(ValidationPhase.CONSISTENCY,resp1.getBody().getRevisionChangeItems().get(1).getValidationMessages().get(1).getPhase());
        

    }
    
    

    private RevisionChangeItemRequest createRevisionChangeItemWithReclass(String entryType, String symbolName, String dotLEvel, IpcConcordanceMapping ipcMapping,
            TitlePartTree titlePartTree, String reclassTransferExpression, String[] reclassTargets) {
        RevisionChangeItemRequest model = new RevisionChangeItemRequest();
        model.setEntryType(entryType);
        model.setSymbolName(symbolName);
        model.setDotLevel(dotLEvel);
        model.setIpcSymbol(ipcMapping);
        model.setTitle(titlePartTree);
        model.setReclassTransferExpression(reclassTransferExpression);
        
        if (reclassTargets != null && reclassTargets.length > 0) {
        	
            for (String targSymbol: reclassTargets) {
                ReclassTransfer xfer = new ReclassTransfer();                
                xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.INTELLECTUAL);                
                xfer.setTargetSymbolName(targSymbol);
                model.getReclassTransfers().add(xfer);
               
            }
            
        }
        
        return model;

    }
    
    private RevisionChangeItemRequest createRevisionChangeItemWithAdminReclass(String entryType, String symbolName, String dotLEvel, IpcConcordanceMapping ipcMapping,
            TitlePartTree titlePartTree, String reclassTransferExpression, String[] reclassTargets) {
        RevisionChangeItemRequest model = new RevisionChangeItemRequest();
        model.setEntryType(entryType);
        model.setSymbolName(symbolName);
        model.setDotLevel(dotLEvel);
        model.setIpcSymbol(ipcMapping);
        model.setTitle(titlePartTree);
        model.setReclassTransferExpression(reclassTransferExpression);
        
        if (reclassTargets != null && reclassTargets.length > 0) {
        	
            for (String targSymbol: reclassTargets) {
                ReclassTransfer xfer = new ReclassTransfer();                
                xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.ADMIN);                
                xfer.setTargetSymbolName(targSymbol);
                model.getReclassTransfers().add(xfer);
               
            }
            
        }
        
        return model;

    }
    
    private RevisionChangeItemRequest createRevisionChangeItemWithReclassHavingBothCategory(String entryType, String symbolName, String dotLEvel, IpcConcordanceMapping ipcMapping,
            TitlePartTree titlePartTree, String reclassTransferExpression, String[] reclassTargets) {
        RevisionChangeItemRequest model = new RevisionChangeItemRequest();
        model.setEntryType(entryType);
        model.setSymbolName(symbolName);
        model.setDotLevel(dotLEvel);
        model.setIpcSymbol(ipcMapping);
        model.setTitle(titlePartTree);
        model.setReclassTransferExpression(reclassTransferExpression);
        
        if (reclassTargets != null && reclassTargets.length > 0) {
        	int i=1;
            for (String targSymbol: reclassTargets) {
                ReclassTransfer xfer = new ReclassTransfer();
                if ( i % 2 == 0 ){
                	xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.ADMIN);
                }else{
                	xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.INTELLECTUAL);
                }
                
                xfer.setTargetSymbolName(targSymbol);
                //xfer.setSourceSymbolName(item.getSymbolName());                
                
                model.getReclassTransfers().add(xfer);
                i++;
            }
            
        }
        
        return model;

    }

    
    @Test
    public void testRowTypeAndSymbolComboCorrectValidator_symbolExistOrNot() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("N", "A01N", "1", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", "A01B100000/09", "1", null, null, "Administrative transfer to A01B"));
        proposalValidationRequest.setExcludeGlobalValidations(Boolean.FALSE);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        
        Assert.assertEquals(2, resp.getBody().getRevisionChangeItems().size());
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());
        //Assert.assertEquals(1,resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());        
		Assert.assertEquals("Symbol 'A01B100000/09' is not well formed and does not meet the required CPC symbol pattern.",
				resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());
		
		
		Assert.assertEquals("Every entry must have a Title",
				resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText());
		
		Assert.assertEquals("Invalid indent level.",
				resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().get(0).getMessageText());
		
		
		Assert.assertEquals("Every entry must have a Title",
				resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().get(1).getMessageText());
    }
    
    
    //partha issue
    @Test
    public void testTypeForDValidator() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        
        
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItemWithAdminReclass("F", "D01B 1/999", "5", null, null, null, new String[] {"D01B 1/999"}));
        proposalValidationRequest.getRevisionChangeItems().get(0).setTitleGrammar("Grammar");
        
        proposalValidationRequest.setExcludeGlobalValidations(Boolean.FALSE);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        
//        Assert.assertEquals(4, resp.getBody().getRevisionChangeItems().size());
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        
  //      Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        log.debug(resp.getBody().getRevisionChangeItems().toString());
        //log.debug(resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText());
        //Assert.assertEquals("Invalid indent level.", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText() );
        //Assert.assertEquals("Entry Type cannot be empty.  It should be one of [C, D, E, F, M, N, Q, U]", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText() );

//        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());
//        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(2).getValidationMessages().size());
//        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(3).getValidationMessages().size());
    }
    
    @Test
    public void testRowTypeAndSymbolComboCorrectValidatorForEmptySymbolOrEntryType() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("", "A01N", "1", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", "", "1", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem(null, "A02N", "1", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", null, "1", null, null, "Administrative transfer to A02N"));
        proposalValidationRequest.setExcludeGlobalValidations(Boolean.FALSE);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        
        Assert.assertEquals(4, resp.getBody().getRevisionChangeItems().size());
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        
        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        log.debug(resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());
        log.debug(resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText());
        Assert.assertEquals("Symbol name cannot be empty", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText() );
        Assert.assertEquals("Every entry must have a Title", resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(1).getMessageText() );

        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(1).getValidationMessages().size());
        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(2).getValidationMessages().size());
        Assert.assertEquals(2,resp.getBody().getRevisionChangeItems().get(3).getValidationMessages().size());
    }
    
    @Test
    public void testValidateOneInValidRow() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.getRevisionChangeItems().add(createRevisionChangeItem("M", "A01B00", "1", null, null, "Administrative transfer to A02N"));
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        //Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        log.debug("revisiotn item size->"+resp.getBody().getRevisionChangeItems().size());
        //Assert.assertEquals(0, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        log.debug("Validation Message Size->"+resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
        log.debug("Message-->"+resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());      
    }

    @Test
    public void tesValidateEmptyContext() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.setExcludeGlobalValidations(Boolean.FALSE);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        
        assertNull(resp.getBody());
        assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
    }
    
    @Test
    public void tesValidateWithOrderedLists() throws IOException {
    	ObjectMapper mapper = new ObjectMapper();
    	try (InputStream is = Thread.currentThread().getContextClassLoader()
    			.getResourceAsStream("data/json/proposal/validation/proposal_validation.json")) {
        ProposalValidationRequest proposalValidationRequest = mapper.readValue(is, ProposalValidationRequest.class);
              
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        
        assertNotNull(resp.getBody());
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals("number",((SubNote)resp.getBody().getRevisionChangeItems().get(0).getNoteItems().get(0).getNoteItem().getChildren().get(1)).getSubnoteType());
        
        
        assertEquals("alpha",((SubNote)resp.getBody().getRevisionChangeItems().get(0).getNoteItems().get(0).getNoteItem().getChildren().get(1).getChildren().get(0).getChildren().get(3)).getSubnoteType());
        
    	}
    }
    
    
    @Test
    public void testValidationForPartha() {
        String title = "Shovels (for snow ##SYMBOL##B65F11/562##/SYMBOL##){; Rakes}(for farm implements{##SYMBOL##B62H11/92##/SYMBOL##})";
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        RevisionChangeItemRequest reqItem =createRevisionChangeItem("M", "A01B1/00", "0", null, null, "Administrative transfer to A02N");
        reqItem.setTitleGrammar(title);
        proposalValidationRequest.getRevisionChangeItems().add(reqItem);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        //TODO: still working on how this should be working.  
        //TODO: We need to document the expectations based on all the validators at present
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());       
        for (ValidationMessage msg: resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()) {
            log.debug("msg = {} created by {} ",msg.getMessageText(), msg.getErrorEventKey());
        }
        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).", 
                resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());       

        
    }
    
    @Test
    public void testValidate3TitleGrammarCasesFromPartha() {
        String title = "title {text;}(ref text ##SYMBOL##H04N##/SYMBOL##)";
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        RevisionChangeItemRequest reqItem =createRevisionChangeItem("M", "A01B1/00", "0", null, null, "Administrative transfer to A02N");
        reqItem.setTitleGrammar(title);
        proposalValidationRequest.getRevisionChangeItems().add(reqItem);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        //TODO: still working on how this should be working.  
        //TODO: We need to document the expectations based on all the validators at present
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());       
        for (ValidationMessage msg: resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()) {
            log.debug("msg = {} created by {} ",msg.getMessageText(), msg.getErrorEventKey());
        }
        Assert.assertEquals("Title part must have title part text that is not within the Reference.", 
                resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());       

        title ="test by swarna ({title for ioc verify} ##SYMBOL##A01B1/00##/SYMBOL##;)";
        proposalValidationRequest = new ProposalValidationRequest();
        reqItem =createRevisionChangeItem("M", "A01B1/00", "0", null, null, "Administrative transfer to A02N");
        reqItem.setTitleGrammar(title);
        proposalValidationRequest.getRevisionChangeItems().add(reqItem);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        //TODO: still working on how this should be working.  
        //TODO: We need to document the expectations based on all the validators at present
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());       
        for (ValidationMessage msg: resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()) {
            log.debug("msg = {} created by {} ",msg.getMessageText(), msg.getErrorEventKey());
        }
        Assert.assertEquals("Title-parts or reference-parts can not be empty.", 
                resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());       

        title ="";
        proposalValidationRequest = new ProposalValidationRequest();
        reqItem =createRevisionChangeItem("M", "A01B1/00", "0", null, null, "Administrative transfer to A02N");
        reqItem.setTitleGrammar(title);
        proposalValidationRequest.getRevisionChangeItems().add(reqItem);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        //TODO: still working on how this should be working.  
        //TODO: We need to document the expectations based on all the validators at present
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());       
        for (ValidationMessage msg: resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()) {
            log.debug("msg = {} created by {} ",msg.getMessageText(), msg.getErrorEventKey());
        }
        Assert.assertEquals("Every entry must have a Title", 
                resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());       
        
    }
    
    @Test
    public void testAnotherDennisUsecase() {
        String title = "first title part (first reference part section ##SYMBOL##H04N##/SYMBOL##; second reference part {##SYMBOL##G03B##/SYMBOL##})";
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        RevisionChangeItemRequest reqItem =createRevisionChangeItem("M", "A01B1/00", "0", null, null, "Administrative transfer to A02N");
        reqItem.setTitleGrammar(title);
        proposalValidationRequest.getRevisionChangeItems().add(reqItem);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        //TODO: still working on how this should be working.  
        //TODO: We need to document the expectations based on all the validators at present
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());       
        for (ValidationMessage msg: resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()) {
            log.debug("msg = {} created by {} ",msg.getMessageText(), msg.getErrorEventKey());
        }
        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).", 
                resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());       

    }
    
    @Test
    public void testDennisReferencePartUsecase() {
        String title = "first title part (first reference part ##SYMBOL##H04N##/SYMBOL##; second reference part {##SYMBOL##H01N##/SYMBOL##})";
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        RevisionChangeItemRequest reqItem =createRevisionChangeItem("M", "A01B1/00", "0", null, null, "Administrative transfer to A02N");
        reqItem.setTitleGrammar(title);
        
        proposalValidationRequest.getRevisionChangeItems().add(reqItem);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
//        Assert.assertTrue(resp.getBody().getGlobalValidationMessages().isEmpty());
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().size());
        //TODO: still working on how this should be working.  
        //TODO: We need to document the expectations based on all the validators at present
        Assert.assertEquals(1, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());       
        for (ValidationMessage msg: resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()) {
            log.debug("msg = {} created by {} ",msg.getMessageText(), msg.getErrorEventKey());
        }
        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).", 
                resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().get(0).getMessageText());       

    }
    
    
    
    
    
    @Test
    public void testAlwaysReturnAllDefItems() {
        ResponseEntity<RevisionChangeItemRequest> resp = proposalValidationController.lookupDefaults(new SymbolName("A01B"));
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals("A01B", resp.getBody().getSymbolName());
        Assert.assertEquals(DefSectionItemEditRequest.class.getAnnotation(XmlType.class).propOrder().length-2, resp.getBody().getDefinitionItems().size());    
        for (DefSectionItemEditRequest def: resp.getBody().getDefinitionItems()) {
            Assert.assertNotNull(def);
            Assert.assertNotNull(def.getSectionType());
        }
    }

    
    @Test
    public void testGetDefault() throws JsonGenerationException, JsonMappingException, IOException {
        ResponseEntity<RevisionChangeItemRequest> resp = proposalValidationController.lookupDefaults(new SymbolName("A01G1/00"));
        
        
    //Default
    //resp = proposalValidationController.lookupDefaults(new SymbolName("A01M1/00"));
    //Assert.assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
    Assert.assertNotNull( resp.getBody());
    log.debug(JsonUtils.toJson(resp.getBody()));
    
    }

    //A01M1/00
    @Test
    public void testGetDefaults() throws JsonGenerationException, JsonMappingException, IOException {
		/*
		 * ResponseEntity<RevisionChangeItemRequest> resp =
		 * proposalValidationController.lookupDefaults(new SymbolName("A01N"));
		 * Assert.assertNotNull(resp.getBody()); Assert.assertEquals("A01N",
		 * resp.getBody().getSymbolName()); assertEquals("Subclass",
		 * resp.getBody().getDotLevel()); assertNotNull(resp.getBody().getTitle());
		 * assertEquals("PRESERVATION OF BODIES OF HUMANS OR ANIMALS OR PLANTS OR PARTS THEREOF;BIOCIDES, e.g. AS DISINFECTANTS, AS PESTICIDES, AS HERBICIDES (preparations for medical, dental or toilet purposes ##SYMBOL####SCHEME##cpc##/SCHEME##A61K##/SYMBOL##; methods or apparatus for disinfection or sterilisation in general, or for deodorising of air ##SYMBOL####SCHEME##cpc##/SCHEME##A61L##/SYMBOL##);PEST REPELLANTS OR ATTRACTANTS (decoys ##SYMBOL####SCHEME##cpc##/SCHEME##A01M1/06##/SYMBOL##; medicinal preparations ##SYMBOL####SCHEME##cpc##/SCHEME##A61K##/SYMBOL##);PLANT GROWTH REGULATORS (compounds in general ##SYMBOL####SCHEME##cpc##/SCHEME##C01##/SYMBOL##, ##SYMBOL####SCHEME##cpc##/SCHEME##C07##/SYMBOL##, ##SYMBOL####SCHEME##cpc##/SCHEME##C08##/SYMBOL##; fertilisers ##SYMBOL####SCHEME##cpc##/SCHEME##C05##/SYMBOL##; soil conditioners or stabilisers ##SYMBOL####SCHEME##cpc##/SCHEME##C09K17/00##/SYMBOL##)"
		 * , resp.getBody().getTitleGrammar()); // Assert.
		 * assertEquals("PRESERVATION OF BODIES OF HUMANS OR ANIMALS OR PLANTS OR PARTS THEREOF;BIOCIDES, e.g. AS DISINFECTANTS, AS PESTICIDES, AS HERBICIDES (preparations for medical, dental or toilet purposes ##SYMBOL####SCHEME##cpc##/SCHEME##A61K##/SYMBOL##; methods or apparatus for disinfection or sterilisation in general, or for deodorising of air ##SYMBOL####SCHEME##cpc##/SCHEME##A61L##/SYMBOL##);PEST REPELLANTS OR ATTRACTANTS (decoys ##SYMBOL####SCHEME##cpc##/SCHEME##A01M1/06##/SYMBOL##; medicinal preparations ##SYMBOL####SCHEME##cpc##/SCHEME##A61K##/SYMBOL##);PLANT GROWTH REGULATORS (compounds in general ##SYMBOL####SCHEME##cpc##/SCHEME##C01##/SYMBOL##, ##SYMBOL####SCHEME##cpc##/SCHEME##C07##/SYMBOL##, ##SYMBOL####SCHEME##cpc##/SCHEME##C08##/SYMBOL##; fertilisers ##SYMBOL####SCHEME##cpc##/SCHEME##C05##/SYMBOL##; soil conditioners or stabilisers ##SYMBOL####SCHEME##cpc##/SCHEME##C09K17/00##/SYMBOL##)"
		 * , // resp.getBody().getTitleGrammar());
		 * Assert.assertNotNull(resp.getBody().getDefinitionItems().get(0)); Assert.
		 * assertEquals("PRESERVATION OF BODIES OF HUMANS OR ANIMALS OR PLANTS OR PARTS THEREOF; BIOCIDES, e.g. AS DISINFECTANTS, AS PESTICIDES, AS HERBICIDES "
		 * ,resp.getBody().getDefinitionItems().get(0).getDefinitionTitle().getChildren(
		 * ).get(0).getValue().substring(0,134));
		 * 
		 * log.debug(JsonUtils.toJson(resp.getBody()));
		 * 
		 * NoteParagraph note = resp.getBody().getNoteItems().get(0).getNoteItem();
		 * Assert.assertNotNull(resp.getBody().getNoteItems().get(0).getNoteCategory());
		 * Assert.assertEquals(NoteType.NOTE,
		 * resp.getBody().getNoteItems().get(0).getNoteCategory());
		 * Assert.assertEquals("This subclass ",
		 * ((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText)(((gov.uspto.pe2e.cpc
		 * .ipc.rest.contract.v1_1.NoteParagraph)
		 * note).getChildren().get(0))).getContent());
		 * 
		 * NoteParagraph warning = resp.getBody().getNoteItems().get(3).getNoteItem();
		 * assertNotNull(warning);
		 * Assert.assertNotNull(resp.getBody().getNoteItems().get(3).getNoteCategory());
		 * Assert.assertEquals(NoteType.WARNING,
		 * resp.getBody().getNoteItems().get(3).getNoteCategory());
		 * Assert.assertEquals("ipc-not-used",
		 * ((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph)
		 * warning).getWarningType());
		 */
        
    	ResponseEntity<RevisionChangeItemRequest> resp = null;
        resp = proposalValidationController.lookupDefaults(new SymbolName("A01G1/00"));
        Assert.assertEquals("A01G1/00", resp.getBody().getSymbolName());
        Assert.assertEquals("0", resp.getBody().getDotLevel());
        Assert.assertNotNull(resp.getBody().getTitle());
//        Assert.assertEquals("Combinations or mixtures of active ingredients covered by classes ##SYMBOL####SCHEME##cpc##/SCHEME##A01N27/00##/SYMBOL## - ##SYMBOL####SCHEME##cpc##/SCHEME##A01N65/48##/SYMBOL## with other active or formulation relevant ingredients, e.g. specific carrier materials or surfactants, covered by classes ##SYMBOL####SCHEME##cpc##/SCHEME##A01N25/00##/SYMBOL## - ##SYMBOL####SCHEME##cpc##/SCHEME##A01N65/48##/SYMBOL##", 
//                resp.getBody().getTitleGrammar());
        assertEquals("Horticulture;Cultivation of vegetables (      labels or name-plates ##SYMBOL####SCHEME##cpc##/SCHEME##G09F3/00##/SYMBOL##, ##SYMBOL####SCHEME##cpc##/SCHEME##G09F7/00##/SYMBOL##          )",
        		resp.getBody().getTitleGrammar());
     

		/*
		 * resp = proposalValidationController.lookupDefaults(new
		 * SymbolName("A01B3/421")); Assert.assertEquals("A01B3/421",
		 * resp.getBody().getSymbolName()); Assert.assertEquals("4",
		 * resp.getBody().getDotLevel());
		 * Assert.assertNotNull(resp.getBody().getTitle());
		 * Assert.assertEquals("with a headstock frame made in one piece",
		 * resp.getBody().getTitleGrammar()); Assert.assertEquals(0,
		 * resp.getBody().getNoteItems().size());
		 */


        
        resp = proposalValidationController.lookupDefaults(new SymbolName("F01B3/421"));
        Assert.assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNull( resp.getBody());
        
		/*
		 * resp = proposalValidationController.lookupDefaults(new SymbolName("A01B"));
		 * Assert.assertNotNull(resp.getBody());
		 * Assert.assertNotNull(resp.getBody().getNoteItems().get(0).getNoteItem());
		 */
        
//        Note warningObj = resp.getBody().getNoteItems().get(1); 
//    	Assert.assertNotNull(warningObj);
//    	String warningTp = warningObj.getNoteOrWarningType();
//    	Assert.assertNotNull(warningTp);
//    	Assert.assertEquals("warning", warningTp);
//		Assert.assertEquals("ipc-not-used",
//				((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph) warningObj
//				.getChildren().get(1)).getWarningType());
//    
        }    
    
    @Test
    public void testGetDefaultsAndOutputNoteFragments() throws JsonGenerationException, JsonMappingException, IOException, JAXBException {
        ResponseEntity<RevisionChangeItemRequest> resp = proposalValidationController.lookupDefaults(new SymbolName("A01G"));
        assertNotNull(resp.getBody());
        Marshaller m = ProposalRevisionService.JAXB_NOTE_CTX.createMarshaller();
        for (NAWItemEditRequest nawEdit: resp.getBody().getNoteItems()) {
            System.out.println("note paragraph xml = ");
            m.marshal(nawEdit.getNoteItem(), System.out);
        }
        

    }
    
	@Test
	public void testGetDefaultsBySchemeId()
			throws JsonGenerationException, JsonMappingException, IOException, JAXBException {
		ResponseEntity<RevisionChangeItemRequest> resp = proposalValidationController
				.lookupDefaultsByVersion(new SymbolName("A01N300/0001"), 4L);
		assertNotNull(resp.getBody());
		String title = resp.getBody().getTitleGrammar();
		assertTrue(title.contains("Evaporation"));

	}
	
	//Test SNV Preview Validations
	@Test
    public void testValidatePrecheckSNVPreviewIncompleteNoteEntry() {
        ProposalValidationRequest proposalValidationRequest = new ProposalValidationRequest();
        proposalValidationRequest.setPreCheckSNVPreviewValidations(true);
        
        RevisionChangeItemRequest item = createRevisionChangeItem("M", "", "CLASS", null, null, "Administrative transfer to A02N" );
        NAWItemEditRequest naw = new NAWItemEditRequest();
        naw.setNoteCategory(NoteType.NOTE);
        naw.setChangeType(SCTComponentChangeType.M);
        
        item.getNoteItems().add(naw);
        proposalValidationRequest.getRevisionChangeItems().add(item);
        Assert.assertNotNull(proposalValidationRequest.isExcludeGlobalValidations());
        Assert.assertFalse(proposalValidationRequest.isExcludeGlobalValidations());
        
        ResponseEntity<ProposalValidationResponse> resp = proposalValidationController.validate(proposalValidationRequest);
        Assert.assertNotNull(resp.getBody());
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        for (ValidationMessage m: resp.getBody().getRevisionChangeItems().get(0).getValidationMessages()) {
        	log.debug("{}", m.getMessageText());
        }
        Assert.assertEquals(3, resp.getBody().getRevisionChangeItems().get(0).getValidationMessages().size());
    }

}
