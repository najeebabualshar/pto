package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalvalidation.v1_0.CpcSymbolValidationResponse;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalValidationServiceTest {
	
	private static final Logger log = LoggerFactory.getLogger(ProposalValidationServiceTest.class);
 
    @Inject
    private ProposalValidationService proposalValidationService;
    
    @Inject
    private DatasetTestingService datasetTestingService;
    	
	@Test
	@Transactional
    public void testValidateCPCSymbolsWithValidTrue() {
       List<String> cpcSymbolNames = Arrays.asList(new String[]{"A01F2009/00","A01K2207/00"});
       List<CpcSymbolValidationResponse> response = proposalValidationService.validateCpcSymbolsFromGoldCopy(cpcSymbolNames);
       Assert.assertNotNull(response);
       Assert.assertEquals(cpcSymbolNames.size(), response.size());
       
       for (int i=0; i< cpcSymbolNames.size(); i++) {
    	   Assert.assertEquals(cpcSymbolNames.get(i), response.get(i).getCpcSymbol());
    	   Assert.assertTrue(response.get(i).isValid()); 
       }
       log.debug("Valid List of Symbols::" + response.toString());
    }
	
	@Test
	@Transactional
    public void testValidateCPCSymbolsWithNoContentWithValidFalse() {
       List<String> cpcSymbolNames = Arrays.asList(new String[]{"C01F25/333"});
       List<CpcSymbolValidationResponse> response = proposalValidationService.validateCpcSymbolsFromGoldCopy(cpcSymbolNames);
       Assert.assertNotNull(response);
       Assert.assertEquals(cpcSymbolNames.size(), response.size());
       Assert.assertEquals(cpcSymbolNames.get(0), response.get(0).getCpcSymbol());
       Assert.assertFalse(response.get(0).isValid()); 
    }
	
	@Test
	public void testMapDefinition() {
	    RevisionChangeItemRequest req = proposalValidationService.getDefaultRevisionChangeItem("A01B");
	    Assert.assertNotNull(req);
	    Assert.assertNotNull(req.getDefinitionItems());
	    log.debug(JaxbUtils.marshalToString(req.getDefinitionItems().get(0)));

	    
	}
	
	@Test
	public void testMapDefinition2() {
		proposalValidationService.mapDefinition(null, null);
	}
	

	
	@Before
    public void setUp() throws Exception {
       datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }
}
