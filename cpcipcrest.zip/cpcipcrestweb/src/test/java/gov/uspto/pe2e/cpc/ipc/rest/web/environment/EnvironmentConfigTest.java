package gov.uspto.pe2e.cpc.ipc.rest.web.environment;

import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.CharEncoding;
import org.junit.Test;
import org.xhtmlrenderer.pdf.ITextRenderer;

import freemarker.template.Configuration;
import freemarker.template.Template;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.TemplateConfigurationLocator;

public class EnvironmentConfigTest {
	
	private static final String DEV_PROPERTIES_PATH="../config/environment/dev/environment.properties";
	private static final String FQT_PROPERTIES_PATH="../config/environment/fqt/environment.properties";
	private static final String PVT_PROPERTIES_PATH="../config/environment/pvt/environment.properties";
	private static final String SIT_PROPERTIES_PATH="../config/environment/sit/environment.properties";
	private static final String PROD_PROPERTIES_PATH="../config/environment/prod/environment.properties";
	private static final String APPLICATION_PROPERTIES_PATH="./src/main/resources/application.properties";

	private static final String APP_PROP_TYPE = "application.properties";

	private static final String ENV_PROP_TYPE = "environment.properties";

    @Test
	public void allEnvironmentPropertiesTest() throws IOException {
			Properties dev = loadProperties(DEV_PROPERTIES_PATH);
			Properties fqt = loadProperties(FQT_PROPERTIES_PATH);
			Properties pvt = loadProperties(PVT_PROPERTIES_PATH);
			Properties sit = loadProperties(SIT_PROPERTIES_PATH);
			Properties prod = loadProperties(PROD_PROPERTIES_PATH);

			Set<String> devProps = dev.stringPropertyNames();
			Set<String> fqtProps = fqt.stringPropertyNames();
			Set<String> pvtProps = pvt.stringPropertyNames();
			Set<String> sitProps = sit.stringPropertyNames();
			Set<String> prodProps = prod.stringPropertyNames();
			
			if(!devProps.equals(fqtProps)) {
				Set<String> tempDevProps = devProps;
				tempDevProps.removeAll(fqtProps);
				fail("Following properties are missing in FQT environment.properties file "+tempDevProps.toString());
			}
			if(!devProps.equals(pvtProps)) {
				Set<String> tempDevProps = devProps;
				tempDevProps.removeAll(pvtProps);
				fail("Following properties are missing in PVT environment.properties file "+tempDevProps.toString());
			}
			if(!devProps.equals(sitProps)) {
				Set<String> tempDevProps = devProps;
				tempDevProps.removeAll(sitProps);
				fail("Following properties are missing in SIT environment.properties file "+tempDevProps.toString());
			}
			if(!devProps.equals(prodProps)) {
				Set<String> tempDevProps = devProps;
				tempDevProps.removeAll(prodProps);
				fail("Following properties are missing in PROD environment.properties file "+tempDevProps.toString());
			}
	}

    @Test
    public void classifyPropertiesTest() throws Exception {
    	Map<String, String> mapOfProperties = new LinkedHashMap<String, String>();
    	
    	Set<String> envProps = loadProperties(DEV_PROPERTIES_PATH).stringPropertyNames();
    	Set<String> appProps = loadProperties(APPLICATION_PROPERTIES_PATH).stringPropertyNames();
    	for(String propName: appProps) {
    		mapOfProperties.put(propName, APP_PROP_TYPE);
    	}
    	for(String propName: envProps) {
    		mapOfProperties.put(propName, ENV_PROP_TYPE);
    	}
    	byte[] pdfBytes = buildPdfForProertiesClassification(mapOfProperties);
    	 try (FileOutputStream os = new FileOutputStream("./src/main/resources/properties_classification.pdf")) {
         	IOUtils.write(pdfBytes, os );

         } finally {
         	
         }
    }
    
	public static Properties loadProperties(String filename1) throws FileNotFoundException, IOException {
		Properties prop = new Properties();
		BufferedReader reader = new BufferedReader(new FileReader(filename1));
		prop.load(reader);
		return prop;
	}
	
	public byte[] buildPdfForProertiesClassification(Map<String, String> mapOfProperties) throws Exception, IOException {
		Map<String, Map<String, String>> root = new HashMap<>();
		root.put("allProps", mapOfProperties);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		OutputStreamWriter writer = new OutputStreamWriter(baos, CharEncoding.UTF_8);

		Configuration cfg = new TemplateConfigurationLocator()
				.configure(null).getConfiguration();
		Template template = null;

		template = cfg.getTemplate("templates/config_properties_classification.tpl");

		template.process(root, writer);
		writer.flush();
		baos.flush();
		String xhtml = baos.toString(CharEncoding.UTF_8);
		
        ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
        ITextRenderer iTextRenderer = new ITextRenderer();

        iTextRenderer.setDocumentFromString(xhtml);
        iTextRenderer.layout();
        iTextRenderer.createPDF(pdfBaos);
        pdfBaos.flush();

		return pdfBaos.toByteArray();
	}
}
