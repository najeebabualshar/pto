/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.jee.filter;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.web.jee.filter.CompressedRequestFilter.GZIPServletInputStream;
import jakarta.servlet.ServletException;

/**
 * 
 * @author 2020
 * @date Nov 16, 2015 3:22:46 PM
 * @version 
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
//        "classpath:META-INF/spring/applicationContext-test.xml" })
public class CompressedRequestFilterTest {
		

	@Before
	public void setUp() throws Exception {
	
	}

	@Test
	public void testDoFilter() throws IOException, ServletException {
		String jsonString =  "{\"name\": \"test\"}";
		   MockHttpServletRequest request = new MockHttpServletRequest();
	        request.setContextPath("/cpcipcrestweb");
	        request.setServerName("localhost");
	        request.setRequestURI("/cpcipcrestweb/symbols");
	        request.addHeader(HttpHeaders.ACCEPT, RestUtils.CONTENT_TYPE_JSON);
	        
	        request.addHeader(HttpHeaders.CONTENT_ENCODING, "gzip");    
	    byte[] gzipBytes = gzip(jsonString);	
	    assertNotEquals(jsonString.getBytes(StandardCharsets.UTF_8).length, gzipBytes.length);
	    request.addHeader(HttpHeaders.CONTENT_TYPE, RestUtils.CONTENT_TYPE_JSON);    
	    request.setContent(gzipBytes);
	    MockHttpServletResponse resp = new MockHttpServletResponse();
	    MockFilterChain chain = new MockFilterChain();
	    
	    CompressedRequestFilter filter = new CompressedRequestFilter();
	    filter.doFilter(request, resp, chain);
	    assertEquals(GZIPServletInputStream.class, chain.getRequest().getInputStream().getClass());
	    assertEquals(jsonString, IOUtils.toString(chain.getRequest().getInputStream()));
		
		
	}
	@Test
	public void testDoFilter_noencoding() throws IOException, ServletException {
		String jsonString =  "{\"name\": \"test\"}";
		   MockHttpServletRequest request = new MockHttpServletRequest();
	        request.setContextPath("/cpcipcrestweb");
	        request.setServerName("localhost");
	        request.setRequestURI("/cpcipcrestweb/symbols");
	        request.addHeader(HttpHeaders.ACCEPT, RestUtils.CONTENT_TYPE_JSON);
	        
	        request.addHeader(HttpHeaders.CONTENT_ENCODING, "non");    
	    byte[] bytes = jsonString.getBytes(StandardCharsets.UTF_8);	
	    request.addHeader(HttpHeaders.CONTENT_TYPE, RestUtils.CONTENT_TYPE_JSON);    
	    request.setContent(bytes);
	    MockHttpServletResponse resp = new MockHttpServletResponse();
	    MockFilterChain chain = new MockFilterChain();
	    
	    CompressedRequestFilter filter = new CompressedRequestFilter();
	    filter.doFilter(request, resp, chain);
	    assertNotEquals(GZIPServletInputStream.class, chain.getRequest().getInputStream().getClass());
	    assertEquals(jsonString, IOUtils.toString(chain.getRequest().getInputStream()));
		
		
	}

	private byte[] gzip(String jsonString) {
		  byte[] compressedData = null;

		    GZIPOutputStream zipStream = null;
		    ByteArrayOutputStream byteStream = null;
		    try
		    {
		      byteStream = new ByteArrayOutputStream();
		      zipStream = new GZIPOutputStream(byteStream);
		      zipStream.write(jsonString.getBytes(StandardCharsets.UTF_8));

		      zipStream.flush();
		      byteStream.flush();
		      IOUtils.closeQuietly(zipStream); // you have to close *before* you attempt to read from it
		      compressedData = byteStream.toByteArray();
		    } catch (Exception e) {
		    	throw new RuntimeException(e);
		    	
		    } finally {
		    	
		    	IOUtils.closeQuietly(byteStream);
		    	
		    	
		    }
		      
		return compressedData;
	}


}
