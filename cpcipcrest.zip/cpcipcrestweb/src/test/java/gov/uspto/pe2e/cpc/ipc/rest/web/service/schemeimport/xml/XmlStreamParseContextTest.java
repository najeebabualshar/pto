package gov.uspto.pe2e.cpc.ipc.rest.web.service.schemeimport.xml;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.junit.Assert;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.XmlStreamParseContext;

public class XmlStreamParseContextTest {

    @Test
    public void test() throws ParserConfigurationException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        
                DocumentBuilder builder = dbf.newDocumentBuilder();
        
                Document doc = builder.newDocument();
        
                
                Element element = doc.createElement("root");
        
                doc.appendChild(element);

        
        XmlStreamParseContext ctx = new XmlStreamParseContext();
        // TODO: Why do we have this property?  We don't use it anywhere.  We need to document 
        // its intended purpose and possibly implement it
        ctx.setXmlNode(element);
        Assert.assertNotNull(ctx.getXmlNode());
    }

}
