package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.IpcSymbolHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcConcordanceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcSymbol;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class IpcConcordanceServiceTest {
	
	private static final Logger log = LoggerFactory.getLogger(IpcConcordanceServiceTest.class);

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private IpcConcordanceService ipcConcordanceService;
    

    @Test
    public void testCPCOnly() {
        IpcConcordanceMapping mapping = ipcConcordanceService.resolveIpcConcordanceMapping("A01F2009/00");
        Assert.assertNotNull(mapping);
        Assert.assertNotNull(mapping.getSymbolName());
        Assert.assertNull(mapping.getGeneratedIpcSymbol());
        Assert.assertNull(mapping.getOverrideIpcSymbol());
        Assert.assertTrue(mapping.isCpcOnly());
    }

    @Test
    public void testTwoThousandSeries() {
        IpcConcordanceMapping mapping = ipcConcordanceService.resolveIpcConcordanceMapping("A01F25/2063");
        Assert.assertNotNull(mapping);
        Assert.assertNotNull(mapping.getSymbolName());
        Assert.assertNull(mapping.getGeneratedIpcSymbol());
        Assert.assertNull(mapping.getOverrideIpcSymbol());
        Assert.assertFalse(mapping.isCpcOnly());
    }

    @Test
    public void testNotFound() {
        IpcConcordanceMapping mapping = ipcConcordanceService.resolveIpcConcordanceMapping("A01G7/06");
        Assert.assertNotNull(mapping);
        Assert.assertNotNull(mapping.getSymbolName());
        Assert.assertNull(mapping.getGeneratedIpcSymbol());
        Assert.assertNull(mapping.getOverrideIpcSymbol());
        Assert.assertFalse(mapping.isCpcOnly());
    }

    @Test
    public void testNotTwoThousandSeriesNoIpcConcordant() {
        IpcConcordanceMapping mapping = ipcConcordanceService.resolveIpcConcordanceMapping("A01F25/2009");
        Assert.assertNotNull(mapping);
        Assert.assertNotNull(mapping.getSymbolName());
        Assert.assertNotNull(mapping.getGeneratedIpcSymbol());
        Assert.assertNull(mapping.getOverrideIpcSymbol());
        Assert.assertFalse(mapping.isCpcOnly());
    }
    
    @Test
    public void testConvertSortKeyToMainGroup() {
        String sortKey = ipcConcordanceService.convertSortKeyToMainCGroup(null);
        Assert.assertNull(sortKey);
        sortKey = ipcConcordanceService.convertSortKeyToMainCGroup(StringUtils.EMPTY);
        Assert.assertEquals(StringUtils.EMPTY, sortKey);
        
        sortKey = ipcConcordanceService.convertSortKeyToMainCGroup("A01N");
        Assert.assertEquals("A01N", sortKey);
       
        sortKey = ipcConcordanceService.convertSortKeyToMainCGroup("A01N/2015");
        Assert.assertEquals("A01N/00", sortKey);
       
    }
    
    @Test
    public void testMapNullIpcSymbol() {
        IpcSymbol maybeNull = ipcConcordanceService.mapIpcSymbol((IpcSymbolHierarchy)null);
        Assert.assertNull(maybeNull);
    }


    @Test
    public void testMappingList() {
       List<String> cpcSymbolNames = Arrays.asList(new String[]{"D01F25/2063","A01G7/06","A01F2009/00"});
       List<IpcConcordanceMapping> mappings = ipcConcordanceService.resolveIpcConcordanceMappings(cpcSymbolNames);
       Assert.assertEquals(cpcSymbolNames.size(), mappings.size() );
       
       for (int i=0; i< cpcSymbolNames.size(); i++) {
           Assert.assertEquals(cpcSymbolNames.get(i), mappings.get(i).getSymbolName());
       }
    }
    
    @Test
    public void testNotFoundTwoThous() {
        IpcConcordanceMapping mapping = ipcConcordanceService.resolveIpcConcordanceMapping("D01F25/2063");
        log.debug("mapping..."+mapping.toString());
        Assert.assertNotNull(mapping);
        Assert.assertNotNull(mapping.getSymbolName());
        Assert.assertNull(mapping.getGeneratedIpcSymbol());
        Assert.assertNull(mapping.getOverrideIpcSymbol());
        Assert.assertFalse(mapping.isCpcOnly());
    }

    @Test
    public void testWithValidIpcConcordant() {
        IpcConcordanceMapping mapping = ipcConcordanceService.resolveIpcConcordanceMapping("A01B63/114");
        Assert.assertNotNull(mapping);
        Assert.assertNotNull(mapping.getSymbolName());
        Assert.assertNotNull(mapping.getGeneratedIpcSymbol());
        Assert.assertNull(mapping.getOverrideIpcSymbol());
        Assert.assertFalse(mapping.isCpcOnly());
    }
    
    @Test
    public void testGetMainGroupIpcSymbolForTwoThousandSeries() {
        
        IpcConcordanceMapping mapping = ipcConcordanceService.resolveIpcConcordanceMapping("A01F2025/2054");
        Assert.assertNotNull(mapping);
        Assert.assertNotNull(mapping.getSymbolName());
        Assert.assertNull(mapping.getGeneratedIpcSymbol());
        Assert.assertNull(mapping.getOverrideIpcSymbol());
        Assert.assertFalse(mapping.isCpcOnly());
    }

    @Before
    public void setUp() throws Exception {

    	datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
