package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.GrammarValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@Execution(ExecutionMode.CONCURRENT)
@Tag("nonvolatile")
public class TitleGrammarControllerTest {
	
    private static final Logger log = LoggerFactory.getLogger(TitleGrammarControllerTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private TitleGrammarController titleGrammarController;
    
    private Date lastInit = null;
    
    @Test
    public void test1() {
        
        ResponseEntity<TitlePartTree> resp = null;
		try {
			resp = titleGrammarController.parse("this is title part 1; title parts 2 ##BOLD## this is bold ##/BOLD## more text; Here isa a Symbol Ref A01N3/27;  I hope that works");
		} catch (GrammarParseException e) {
			
			e.printStackTrace();
		}
        Assert.assertNotNull(resp); 
        Assert.assertFalse(resp.getBody().getChildren().isEmpty());
    }
    
	@Test
	public void testZeroOrOneReferenceInTitlePart1() throws GrammarParseException {

		ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate("sdfaf (dsaf) (dsaf)", null,
				null);
		Assert.assertNotNull(resp);
		Assert.assertTrue(resp.getBody().isEmpty());
	}
	
	@Test
	public void testZeroOrOneReferenceInTitlePart2() throws GrammarParseException {

		ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate("sdfaf (dsaf);sdf (dsaf) (dsaf)", null,
				null);
		Assert.assertNotNull(resp);
		Assert.assertTrue(resp.getBody().isEmpty());
	}
	
	@Test
	public void testZeroOrOneReferenceInTitlePart3() throws GrammarParseException {

		ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate("sdfaf (dsaf);sdf (dsaf)", null,
				null);
		Assert.assertNotNull(resp);
		Assert.assertTrue(resp.getBody().isEmpty());
	}
	
	@Test
	public void testTextShouldNotExistAfterReferenceInTitlePart() throws GrammarParseException {

		ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate("sdfaf (dsaf) sdf", null,
				null);
		Assert.assertNotNull(resp);
		Assert.assertTrue(resp.getBody().isEmpty());
	}
	
	@Test
	public void testTextShouldNotExistAfterReferenceInTitlePart1() throws GrammarParseException {

		ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate("sdfaf (dsaf); sdfaf (dsaf)sdf", null,
				null);
		Assert.assertNotNull(resp);
		Assert.assertTrue(resp.getBody().isEmpty());
	}
    
    @Test
    public void testSemicolonInReference() throws GrammarParseException {
        
		ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
				"PLANTING;SOWING;FERTILISING (combined with general working of soil A01B49/04; parts, details or accessories of agricultural machines or implements, in general A01B51/00 - A01B75/00; {apparatus for spreading sand or salt E01C; sowing and fertilising with aircraft B64D1/16 - B64D1/20})",
				null, null);
        Assert.assertNotNull(resp);
        Assert.assertTrue(resp.getBody().isEmpty());
        
    }
    
    @Test
    public void testTitleShouldNotStartWithReference() throws GrammarParseException {
        
		ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
				"(A01B15/16 takes precedence; bearings therefor A01B71/04); Scrapers for cleaning discs;",
				null, null);
        Assert.assertNotNull(resp);
        Assert.assertFalse(resp.getBody().isEmpty());
        
    }
    
    @Test
    public void testTitleShouldNotHaveAnyTextAfterReferenceWithInTitlePart() throws GrammarParseException {
        
		ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
				"Devices specially (A01B15/16 takes precedence; bearings therefor A01B71/04) Scrapers for cleaning discs;",
				null, null);
        Assert.assertNotNull(resp);
        Assert.assertFalse(resp.getBody().isEmpty());
        
    }
    

    /**
     * TODO: Remove this as soon UI supports non-indexed errors
     * @throws GrammarParseException
     * @since Jul 26, 2017
     */
    @Test
    public void testTitleValidationMessagesShouldHaveIndexes() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
                "Devices specially (A01B15/16 takes precedence;yo ho takes precedence; no way) (more text) this is an error; bearings ",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertTrue(resp.getBody().isEmpty());
        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }
        
    }
    
    
    // I should get only 1 error , but parser shows incorrect results !
    @Test
    public void testTitleValidationEx1() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
                "MAKING TEXTILE FABRICS, e.g. FROM FIBRES OR FILAMENTARY MATERIAL (weaving ##SYMBOL##D03##/SYMBOL##; knitting ##SYMBOL##D04B##/SYMBOL##; braiding {or lace-making } ##SYMBOL##D04C##/SYMBOL##; net-making {or making knotted carpets } ##SYMBOL##D04G##/SYMBOL##; sewing ##SYMBOL##D05B##/SYMBOL##; tufting ##SYMBOL##D05C##/SYMBOL##, {e.g. ##SYMBOL##D05C 15/04##/SYMBOL## }; finishing non-woven fabrics ##SYMBOL##D06##/SYMBOL##);FABRICS MADE BY SUCH PROCESSES OR APPARATUS, e.g. FELTS, NON-WOVEN FABRICS;COTTON-WOOL;WADDING {NON-WOVEN FABRICS FROM STAPLE FIBRES, FILAMENTS OR YARNS, BONDED WITH AT LEAST ONE WEB-LIKE MATERIAL DURING THEIR CONSOLIDATION }(non-woven fabrics having an intermediate or external layer of a different kind, e.g. of woven fabric, ##SYMBOL##B32B##/SYMBOL##;{manufacturing hats ##SYMBOL##A42C##/SYMBOL##; filtering material ##SYMBOL##B01D 39/00##/SYMBOL##; making board or the like from wood fibre ##SYMBOL##B27N##/SYMBOL##; producing shaped articles from mixtures containing fibres ##SYMBOL##B28B 1/52##/SYMBOL##; making layered products from solid layers, at least one of which contains synthetic resin as an essential component ##SYMBOL##B32B 27/00##/SYMBOL##; making or treating glass wool and mineral wool ##SYMBOL##C03B 37/00##/SYMBOL##; compounding ingredients used as fillers for mortars and the like ##SYMBOL##C04B 14/38##/SYMBOL##, ##SYMBOL##C04B 16/06##/SYMBOL##, ##SYMBOL##C04B 20/0048##/SYMBOL##; sintering plastics particles ##SYMBOL##C08J 9/24##/SYMBOL##; manufacturing by extrusion of synthetic filaments and fibres in general ##SYMBOL##D01D##/SYMBOL##; paper ##SYMBOL##D21C##/SYMBOL## - ##SYMBOL##D21H##/SYMBOL##; making shaped articles from liquid suspensions of cellulose fibres ##SYMBOL##D21J##/SYMBOL##})",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertFalse(resp.getBody().isEmpty());
        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }
        
    }
    
    
    @Test
    public void testTitleValidationEx2() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
        		"characterised by a particular shape of the outline of the cross-section of a continuous layer; characterised by a layer with cavities or internal voids {(##SYMBOL##B32B 27/205##/SYMBOL## takes precedence; foam layer ##SYMBOL##B32B 15/08##/SYMBOL##)}; {characterised by an apertured layer}",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertFalse(resp.getBody().isEmpty());
        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }
        
    }
    
    @Test
    public void testTitleValidationEx3() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
        		"{beta-D-Glucans; (beta-1,3)-D-Glucans, e.g. paramylon, coriolan, sclerotan, pachyman, callose, scleroglucan, schizophyllan, laminaran, lentinan or curdlan; (beta-1,6)-D-Glucans, e.g. pustulan; (beta-1,4)-D-Glucans; (beta-1,3)(beta-1,4)-D-Glucans, e.g. lichenan; Derivatives thereof}",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertTrue(resp.getBody().isEmpty());
        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }
        
    }
    
    @Test
    public void testTitleValidationEx4() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
        		"##SUBSCRIPT##with carbamoyl groups {, i.e. -CO-NH2} ##/SUBSCRIPT##",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertFalse(resp.getBody().isEmpty());
        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }
        
    }
    
    @Test
    public void testTitleValidationEx5() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
        		"Preparation of polysaccharides not provided for in groups ##SYMBOL##C08B 1/00##/SYMBOL## - ##SYMBOL##C08B 35/00##/SYMBOL##; Derivatives thereof (cellulose ##SYMBOL##D21##/SYMBOL##; {microbiological processes ##SYMBOL##C12P##/SYMBOL##})",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertFalse(resp.getBody().isEmpty());
        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }       
    }
    
    
    @Test
    public void testTitleValidationEx6() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
        		"SOIL WORKING IN AGRICULTURE OR FORESTRY; PARTS, DETAILS, OR ACCESSORIES OF AGRICULTURAL MACHINES OR IMPLEMENTS, IN GENERAL (making or covering furrows or holes for sowing, planting, or manuring ##SYMBOL##A01C 5/00##/SYMBOL##; soil working for engineering purposes ##SYMBOL##E01##/SYMBOL##, ##SYMBOL##E02##/SYMBOL##, ##SYMBOL##E21##/SYMBOL##; {measuring areas for agricultural purposes ##SYMBOL##G01B##/SYMBOL##})",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertFalse(resp.getBody().isEmpty());
        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }       
    }
    
    @Test
    public void testTitleValidationEx7() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
        		"Hydrogen; Gaseous mixtures containing hydrogen; Separation of hydrogen from mixtures containing it (separation of gases by physical means ##SYMBOL##B01D##/SYMBOL##); Purification of hydrogen (production of water gas or synthesis gas from solid carbonaceous material ##SYMBOL##C10J##/SYMBOL##; purifying or modifying the chemical compositions of combustible technical gases containing carbon monoxide ##SYMBOL##C10K##/SYMBOL##)",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertFalse(resp.getBody().isEmpty());
/*        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }       
*/    }
    
    @Test
    public void testTitleValidationEx8() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
        		"{Reversible uptake of hydrogen by an appropriate medium, i.e. based on physical or chemical sorption phenomena or on reversible chemical reactions, e.g. for hydrogen storage purposes (purification of hydrogen ##SYMBOL##C01B 3/508##/SYMBOL##); Reversible gettering of hydrogen; Reversible uptake of hydrogen by electrodes}",
                null, null);
        Assert.assertNotNull(resp);
        log.debug("here is the bod[{}]", resp.getBody());
        
        Assert.assertFalse(resp.getBody().isEmpty());
//        Assert.assertEquals(1,  resp.getBody().size());
//        log.debug("\n--> {}", resp.getBody().get(0).getErrorEventKey());
//        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).", 
//                resp.getBody().get(0).getMessageText());
        /*List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }*/       
    }
    
    //     C08F 4/086    . . .     {an alkali metal bound to nitrogen, e.g. LiN(C2H5)2} 
    
    // This is non reference paranthesis, shouldnt throw error.
    @Test
    public void testTitleValidationEx9() throws GrammarParseException {
        
        ResponseEntity<List<ValidationMessage>> resp = titleGrammarController.validate(
        		"{an alkali metal bound to nitrogen, e.g. LiN(C##SUBSCRIPT##2##/SUBSCRIPT##H##SUBSCRIPT##5##/SUBSCRIPT##)##SUBSCRIPT##2##/SUBSCRIPT##}",
                null, null);
        Assert.assertNotNull(resp);
        Assert.assertTrue(resp.getBody().isEmpty());
        List<ValidationMessage> msgs = resp.getBody();
        for (ValidationMessage m: msgs) {
            log.debug("{}", m);
            Assert.assertTrue(GrammarValidationMessage.class.isAssignableFrom(m.getClass()));
            log.debug("idx {} - {}",  ((GrammarValidationMessage)m).getCharacterIndex(),m.getMessageText());
            Assert.assertNotNull(((GrammarValidationMessage)m).getCharacterIndex());
        }       
    }
    
    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

}
