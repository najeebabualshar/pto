package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * Enum class for the Batch Process Status.
 * 
 * @author 2020
 * @date: 11/14/2016
 * @version 1.5
 *
 */
public enum BatchProcessStatus {
    COMPLETED,INPROCESS;
}
