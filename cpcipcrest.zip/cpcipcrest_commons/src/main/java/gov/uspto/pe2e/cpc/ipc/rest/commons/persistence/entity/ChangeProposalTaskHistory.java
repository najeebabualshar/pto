package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table
 * change_proposal_task_history primary key column is task_history_guid_id
 * 
 * @author 2022
 * @version 2.10.0
 * @date: October 20, 2022
 *
 */
@Data
@Entity
@Table(name = "change_proposal_task_history")
public class ChangeProposalTaskHistory implements Comparable<ChangeProposalTaskHistory>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Guid
	@Column(name = "task_history_guid_id")
	private String taskHistoryGuid;

	@NotNull
	@Column(name = "change_proposal_alias_cd")
	private String changeProposalAliasCd;

	@NotNull
	@Column(name = "change_proposal_id")
	private Long changeProposalId;

	@NotNull
	@Column(name = "change_proposal_guid_id")
	private String changeProposalGuid;
	
	@Column(name = "change_proposal_ver_guid_id")
	private String changeProposalVerGuid;

	@NotNull
	@Column(name = "project_source_cd")
	private String projectSourceCd;

	@NotNull
	@Column(name = "project_type_cd")
	private String projectTypeCd;

	@NotNull
	@Column(name = "proposal_phase_cd")
	private String projectPhaseCd;

	@NotNull
	@Column(name = "task_id")
	private String taskId;

	@NotNull
	@Column(name = "task_definition_id")
	private String taskDefinitionId;

	@NotNull
	@Column(name = "task_name_tx")
	private String taskName;

	@Column(name = "task_start_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date taskStartTs;

	@Column(name = "task_due_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date taskDueTs;

	@Column(name = "task_end_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date taskEndTs;

	@NotNull
	@Column(name = "action_tx")
	private String actionTx;

	@Column(name = "comment_tx")
	private String commentTx;

	@Column(name = "completed_user_id")
	private String taskCompleteUserId;

	@NotNull
	@Column(name = "task_assignee_office_cd")
	private String taskAssigneeOfficeCd;

	@Column(name = "sdct_version_id")
	private Long sdctVersionId;

	@Column(name = "symbol_count_no")
	private Long symbolCount;

	@Column(name = "definition_count_no")
	private Long definitionCount;

	@Column(name = "family_count_no")
	private Long familyCount;

	@Column(name = "twl_doc_count_no")
	private Long twlDocCount;

	@Column(name = "attached_doc_tx")
	private String attachedDocText;

	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId;

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@SuppressWarnings("CPD-END")
	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	/**
	 * used for hash based collections.
	 */
	@Override
	public int hashCode() {
		final int prime = 37;
		int result = 1;
		result = prime * result + ((this.changeProposalAliasCd == null) ? 0 : this.changeProposalAliasCd.hashCode());
		result = prime * result + ((this.projectSourceCd == null) ? 0 : this.projectSourceCd.hashCode());
		result = prime * result + ((this.taskId == null) ? 0 : this.taskId.hashCode());
		result = prime * result + ((this.taskStartTs == null) ? 0 : this.taskStartTs.hashCode());
		return result;
	}

	/**
	 * Indicates whether some other object is "equal to" this one
	 */
	@Override
	public boolean equals(Object obj) {
		boolean ret = false;

		if (obj != null) {
			if (obj == this) {
				ret = true;
			} else if (ChangeProposalTaskHistory.class.isAssignableFrom(obj.getClass())) {
				ChangeProposalTaskHistory that = (ChangeProposalTaskHistory) obj;
				ret = new EqualsBuilder().append(this.getChangeProposalAliasCd(), that.getChangeProposalAliasCd())
						.append(this.getTaskStartTs(), that.getTaskStartTs()).append(this.getTaskId(), that.getTaskId())
						.isEquals();
			}
		}
		return ret;
	}

	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ChangeProposalTaskHistory other) {
		return new CompareToBuilder().append(this.getProjectSourceCd(), other.getProjectSourceCd())
				.append(this.getTaskStartTs(), other.getTaskStartTs()).append(this.getTaskId(), other.getTaskId())
				.toComparison();
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChangeProposalStateTask [taskId=" + taskId + ", taskName=" + taskName + ", taskStartTs=" + taskStartTs
				+ ", taskDueTs=" + taskDueTs + ", createUserId=" + createUserId + ", createTs=" + createTs
				+ ", lockControl=" + lockControl + "]";
	}
}
