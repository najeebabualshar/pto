package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * This enum defines what type Generic Exorts can be done to Xlsx format
 * 
 * @author 2020
 * @date Oct 27, 2021 10:56:27 AM
 * @version 2.4.0
 */
public enum ExportXlsxReportType {
   
    GPL ("templates/proposal/gpl_export_csv.tpl"),
    TH ("templates/proposal/project_timeline_history_export.tpl"),
    TWL ("templates/twl/twl_xlsx.tpl"), 
    CONSULTATIONS("templates/consultation/consultation_history.tpl");
    
    private String templatePath;

    private ExportXlsxReportType(String templatePath) {
        this.templatePath = templatePath;
    }

    /**
     * @return the templatePath
     */
    public String getTemplatePath() {
        return templatePath;
    }
    
    
}
