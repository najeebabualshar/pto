package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TokenUtils;

/**
 * This is the enum which maps course grained application roles to fine grained
 * permissions. The permissions here are the defaults. They can be overridden at
 * run time by the presence of a classpath properties file configuration
 * (role_permission_mapping.properties) that overrides the permissions
 * associated with a given role. This allows us to have different permission
 * sets in different environments. the format for the properties file is
 * 
 * ApplicationRole_enum_name = comma,separated,list,of,fine,grained,permissions
 * 
 * @author 2020
 * @date Apr 26, 2016
 * @version 1.4
 *
 */
public enum ApplicationRole {
	/**
	 * This is the lowest level role in the app. If a user has no roles in saml
	 * assertions, he is assigned this role so that all our security logic will
	 * work
	 */
	EMPLOYEE(ApplicationPermission.NAVIGATOR_ENABLED, 
	        ApplicationPermission.NAVIGATOR_LIST, 
	        ApplicationPermission.NAVIGATOR_SEARCH, 
	        ApplicationPermission.NAVIGATOR_GET, 
	        ApplicationPermission.NAVIGATOR_GET_FULL, 
			ApplicationPermission.DIFF_ROW,
	        ApplicationPermission.PROPOSAL_LIST, 
	        ApplicationPermission.PROPOSAL_SEARCH, 
	        ApplicationPermission.PROPOSAL_MANAGER_AE_GET, 
	        ApplicationPermission.PROPOSAL_GET, 
	        ApplicationPermission.RESOURCE_GET),
	/**
	 * Classifiers have different permission sets
	 */
	CPCPROJECTCOORDINATOR(ApplicationPermission.NAVIGATOR_ENABLED, 
	        ApplicationPermission.NAVIGATOR_LIST, 
	        ApplicationPermission.NAVIGATOR_SEARCH, 
	        ApplicationPermission.NAVIGATOR_GET, 
	        ApplicationPermission.NAVIGATOR_GET_FULL,
	        ApplicationPermission.PROPOSAL_GET,
	        ApplicationPermission.PROPOSAL_MANAGER_AE_GET,
	        ApplicationPermission.PROPOSAL_MANAGER_ENABLED,
	        ApplicationPermission.PROPOSAL_LOCKS_ENABLED,
			ApplicationPermission.PROPOSAL_LIST, 
			ApplicationPermission.PROPOSAL_SEARCH,
			ApplicationPermission.PROPOSAL_CREATE, 
			ApplicationPermission.PROPOSAL_UPDATE,
			ApplicationPermission.PROPOSAL_REVISION_SAVE,
			ApplicationPermission.PROPOSAL_REVISION_UPDATE,
			ApplicationPermission.IPC_CONCORDANCE_SEARCH,
			ApplicationPermission.IPC_CONCORDANCE_GET,
			ApplicationPermission.NAVIGATOR_ENABLED,
			ApplicationPermission.RESOURCE_SAVE,
			ApplicationPermission.RESOURCE_GET,
			ApplicationPermission.RESOURCE_DELETE,
			ApplicationPermission.RESOURCE_MANAGER_ENABLED,
			ApplicationPermission.DIFF_ROW,
			ApplicationPermission.DASHBOARD_ENABLED,
			ApplicationPermission.COORDINATOR,
			ApplicationPermission.WMS,
			ApplicationPermission.SME_CONSULTATION,
			ApplicationPermission.SME_CONSULTATION_PARTICIPATION,
			ApplicationPermission.SME_RESPONSE, //TODO: Remove this as soon as USXXXXX is completed to allow EPO to provide roles in their saml token
			ApplicationPermission.START_SME_CONSULTATION // this role is special to only PC			
			),
	/**
	 * Set of permissions for CPC WORKFLOW MANAGER. This is temporary now, since WMS is pilot		
	 */
	CPCWORKFLOWMANAGER(ApplicationPermission.WMS),
	
	/**
	 * Set of permissions for CPC Workflow Manager.
	 */
	CLASSIFICATIONPUBLICATIONEDITOR(ApplicationPermission.WMS),
	
	/**
     * Set of permissions for viewing specific EB dashboard link.       
     */
	CPC_EB(ApplicationPermission.EB_ENABLED, ApplicationPermission.EDITORIAL_BOARD),
	
	/**
     * Set of permissions for viewing specific publication team link.       
     */
	CPCPUBLICATIONTEAM(ApplicationPermission.PUBLICATION_BOARD),
	
	/**
	 * There are no use cases defining admin features yet
	 */
	CPC_CE_ADMIN(ApplicationPermission.NAVIGATOR_ENABLED, 
	        ApplicationPermission.NAVIGATOR_LIST, 
	        ApplicationPermission.NAVIGATOR_SEARCH, 
	        ApplicationPermission.NAVIGATOR_GET, 
	        ApplicationPermission.NAVIGATOR_GET_FULL,
	        ApplicationPermission.PROPOSAL_GET,
	        ApplicationPermission.PROPOSAL_MANAGER_AE_GET,
	        ApplicationPermission.PROPOSAL_MANAGER_ENABLED,
	        ApplicationPermission.PROPOSAL_LOCKS_ENABLED,
			ApplicationPermission.PROPOSAL_LIST, 
			ApplicationPermission.PROPOSAL_SEARCH,
			ApplicationPermission.PROPOSAL_CREATE, 
			ApplicationPermission.PROPOSAL_UPDATE,
			ApplicationPermission.PROPOSAL_REVISION_SAVE,
			ApplicationPermission.PROPOSAL_REVISION_UPDATE,
			ApplicationPermission.IPC_CONCORDANCE_SEARCH,
			ApplicationPermission.IPC_CONCORDANCE_GET,
			ApplicationPermission.NAVIGATOR_ENABLED,
			ApplicationPermission.RESOURCE_SAVE,
			ApplicationPermission.RESOURCE_GET,
			ApplicationPermission.RESOURCE_DELETE,
			ApplicationPermission.RESOURCE_MANAGER_ENABLED,
			ApplicationPermission.DIFF_ROW,
			ApplicationPermission.DASHBOARD_ENABLED,
			ApplicationPermission.COORDINATOR,
			ApplicationPermission.PUBLICATION_BOARD,
			ApplicationPermission.WMS,
			ApplicationPermission.EB_ENABLED, 
			ApplicationPermission.EDITORIAL_BOARD,
			ApplicationPermission.CPC_ADMIN
			),
	QN_TECH_EXPERT (ApplicationPermission.SME_RESPONSE, 
			ApplicationPermission.SME_CONSULTATION_PARTICIPATION), // EP SME Role
	
	SCE (ApplicationPermission.SME_RESPONSE, 
			ApplicationPermission.SME_CONSULTATION_PARTICIPATION), // US SME Role
	
	CPC_WAT_MANAGER(ApplicationPermission.WAT_GET),
	
	CPC_WAT_ADMIN(ApplicationPermission.WAT_ADMIN),
	
	CPC_QN(ApplicationPermission.US_QN),
	/**
	 * Permissions for this role are set in the "canned" user object in src/main/resources
	 */
	SERVICE_ACCOUNT();

	private static final String PREFIX = "ROLE_";

	private List<ApplicationPermission> permissions;

	/**
	 * private constructor
	 * 
	 * @param applicationPermissions
	 */
	private ApplicationRole(ApplicationPermission... applicationPermissions) {
		List<ApplicationPermission> myPerms = new ArrayList<>();
		if (applicationPermissions != null) {
		    CollectionUtils.addAll(myPerms, applicationPermissions);
		}
		this.permissions = myPerms;
	}

	/**
	 * Constructs gets a Role by Role name. Note: this also check is the Role is
	 * preceeded by "ROLE_"
	 * 
	 * @param roleName
	 * @return ApplicationRole
	 * @since Apr 26, 2016
	 */
	public static ApplicationRole byRoleName(String roleName) {
		roleName = roleName.replaceAll(TokenUtils.WHITESPACE_REGEX, StringUtils.EMPTY);
		ApplicationRole ret = null;
		if (!StringUtils.isBlank(roleName)) {
			roleName = roleName.toUpperCase().trim();
			for (ApplicationRole role : ApplicationRole.values()) {

				if (role.name().equalsIgnoreCase(roleName) || role.name().equalsIgnoreCase(PREFIX + roleName)) {
					ret = role;
					break;
				}
			}
		}
		return ret;
	}

	/**
	 * get List of permissions (fine grained granted authorities associated with
	 * roles)
	 *  
	 * @return List<ApplicationPermission>
	 * @since Apr 26, 2016
	 */
	public List<ApplicationPermission> getPermissions() {
		return permissions;
	}

}
