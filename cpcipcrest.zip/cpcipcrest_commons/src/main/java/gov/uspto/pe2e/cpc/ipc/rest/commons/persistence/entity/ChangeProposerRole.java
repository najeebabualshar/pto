package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table change_proposer_role
 * primary key column is change_proposer_role_id
 *
 * @author 2020
 * @version 1.11.0
 * @date: 04/05/2018
 *
 */
@Entity
@Table(name = "change_proposer_role", uniqueConstraints = { @UniqueConstraint(columnNames = {
        "change_proposer_role_id", "fk_change_proposal_id", "fk_ipo_cd", "fk_proposer_role_cd" }) })
public class ChangeProposerRole implements Comparable<ChangeProposerRole>, Serializable {

    /**
     * Allowing serialization of datamodel elements 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposer_role_id_seq")
    @SequenceGenerator(name = "change_proposer_role_id_seq", sequenceName = "change_proposer_role_id_seq", allocationSize = 1)
    @Column(name = "change_proposer_role_id")
    private Long id;
    
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
    
    @NotNull
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardIpOffice.class)
//    @JoinColumn(name = "fk_ipo_cd", referencedColumnName = "ipo_cd")

    @Column(name = "fk_ipo_cd")
    @Enumerated(EnumType.STRING)
    private StandardIpOfficeCode standardIpOfficeCode;
    
    @NotNull
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardProposerRole.class)
//    @JoinColumn(name = "fk_proposer_role_cd", referencedColumnName = "proposer_role_cd")
    @Column(name = "fk_proposer_role_cd")
    @Enumerated(EnumType.STRING)
    private OfficeContactType standardProposerRole;
    
    @NotNull
    @Column(name = "cfk_proposer_id")
    private String proposerEmail; // VARCHAR2(320)

    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    /**
     * @return Long id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }
    
    public StandardIpOfficeCode getStandardIpOfficeCode() {
		return standardIpOfficeCode;
	}

	public void setStandardIpOfficeCode(StandardIpOfficeCode standardIpOfficeCode) {
		this.standardIpOfficeCode = standardIpOfficeCode;
	}
    
    /**
	 * @return the standardProposerRole
	 */
	public OfficeContactType getStandardProposerRole() {
		return standardProposerRole;
	}

	/**
	 * @param standardProposerRole the standardProposerRole to set
	 */
	public void setStandardProposerRole(OfficeContactType standardProposerRole) {
		this.standardProposerRole = standardProposerRole;
	}

	/**
     * @return String proposerEmail
     */
    public String getProposerEmail() {
        return proposerEmail;
    }
    
    /**
     * @param String proposerEmail
     */
    public void setProposerEmail(String proposerEmail) {
        this.proposerEmail = proposerEmail;
    }

    /**
     * @return ChangeProposal changeProposal
     */
    public ChangeProposal getChangeProposal() {
        return changeProposal;
    }

    /**
     * @param changeProposal
     */
    public void setChangeProposal(ChangeProposal changeProposal) {
        this.changeProposal = changeProposal;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return String lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return Date lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @return Integer lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ChangeProposerRole other) {
        return new CompareToBuilder().append(this.getChangeProposal()
                .getExternalId(), other.getChangeProposal().getExternalId())
        		.append(this.getStandardIpOfficeCode(), other.getStandardIpOfficeCode())
        		.append(this.getStandardProposerRole(), other.getStandardProposerRole())
        		.append(this.getProposerEmail(), other.getProposerEmail())
        		.toComparison();
    }
    
    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret;
        
        if (obj == null || !(obj instanceof ChangeProposerRole)) {
            ret = false;
        } else if (ChangeProposerRole.class.isAssignableFrom(obj.getClass()) && obj == this) {
            ret = true;
        } else {
        	ChangeProposerRole thatObj = (ChangeProposerRole) obj;
        	
        	String meProposalCode = this.getChangeProposal().getExternalId();
        	String thatProposalCode = thatObj.getChangeProposal().getExternalId();
        	
            Long meId = this.getId();
            Long thatId = thatObj.getId(); 
            
            String meEmail = this.getProposerEmail();
            String thatEmail = thatObj.getProposerEmail();
            
            OfficeContactType meContactType = this.getStandardProposerRole();
            OfficeContactType thatContactType = thatObj.getStandardProposerRole();
            
            StandardIpOfficeCode meOffice = this.getStandardIpOfficeCode();
            StandardIpOfficeCode thatOffice = thatObj.getStandardIpOfficeCode();
            
            ret = meProposalCode.equals(thatProposalCode) && Objects.equals(meId, thatId) && meEmail.equals(thatEmail) 
                    && Objects.equals(meContactType, thatContactType) && Objects.equals(meOffice, thatOffice);
        }
        return ret;
    }

    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        return Objects.hash(this.getChangeProposal().getExternalId(), this.getId(), this.getProposerEmail(),
                this.getStandardProposerRole(), this.getStandardIpOfficeCode());
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ChangeProposalVersion [id=" + id + ", changeProposal=" + ((changeProposal != null) ? changeProposal.getId()
                : "null") + ", IpOffice="+standardIpOfficeCode.name()+", proposerRole="+standardProposerRole.name()+"proposerEmail="+proposerEmail+", createUserId="
                + createUserId + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId
                + ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + "]";
    }

}
