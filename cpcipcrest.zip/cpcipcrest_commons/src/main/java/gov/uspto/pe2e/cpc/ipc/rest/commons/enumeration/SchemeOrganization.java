package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * 
 * enum SchemeOrganization class
 * 
 * @author 2020
 * @version 1.0
 * @date: 08/4/2015
 *
 */
public enum SchemeOrganization {
    /*
     * They are lower-case values because these are string mappings from the
     * database used all over. The DataModelling team used lower case values and
     * by using lower case to match (which is syntactically valid but
     * technically non-standard style), we avoid having to write multiple
     * converters at each level (ORM, service message serialization, etc)
     * 
     */
    cpc, ipc;
}
