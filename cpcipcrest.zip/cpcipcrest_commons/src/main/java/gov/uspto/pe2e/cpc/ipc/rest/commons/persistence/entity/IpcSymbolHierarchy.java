package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Entity of ipc_symbol_hierarchy used to get the generated IPC symbol for the
 * given CPC symbol. The source of the data is from Validity file, populated by
 * a loading script (by EDAD). The Validity files were kept in
 * ipc_xml_file_stage, managed by EDAD.
 * 
 * @author 2020
 * @date Jan 6, 2016 4:52:21 PM
 * @version 1.6
 */

@Entity
@Table(name = "ipc_symbol_hierarchy")
public class IpcSymbolHierarchy implements Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ipc_symbol_id_seq")
    @SequenceGenerator(name = "ipc_symbol_id_seq", sequenceName = "ipc_symbol_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "ipc_symbol_id")
    private Long id;

    @Size(max = 20, min = 1)
    @NotNull
    @Column(name = "ipc_symbol_cd", length = 20, nullable = false)
    private String ipcSymbolCode;

    /**
     * IPC Scheme published version date. Generally once a year IPC scheme will
     * be published.
     */
    @NotNull
    @Column(name = "scheme_version_dt", nullable = false)
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date schemeVersionDate;

    @Size(min = 1, max = 1)
    @NotNull
    @Column(name = "section_cd", length = 1, nullable = false)
    private String sectionCode;

    @Column(name = "class_cd", length = 2)
    private String classCode;

    @Column(name = "subclass_cd", length = 1)
    private String subclassCode;

    @Column(name = "maingroup_cd", length = 4)
    private String mainGroupCode;

    @Column(name = "subgroup_cd", length = 6)
    private String subGroupCode;

    /**
     * "This is a property of the IPC validity object with value in: P=
     * Pre-reform (i.e., existing prior to IPC reform) C= Common (i.e. for
     * symbols valid for BOTH Advanced and Core level classification) O= valid
     * for Core level symbol, Obsolete for the Advanced level (i.e for Core
     * level symbols no longer valid in the Advanced level) A= Advanced level
     * (i.e. for symbols present in Advanced level ONLY) S= Subclass level (i.e.
     * symbols valid only for offices classifying at Subclass level ) Note - For
     * CPC IPC concordance, 'C' and 'A' level code will be considered."
     */
    @Column(name = "classification_level_cd", length = 1)
    private String classificationLevelCode;

    /**
     * This should be an enum. ALSO This is horrible naming. The value is not
     * "ENTERED" by anyone, it is classified by usage therefore this is not
     * entry type value as much as it is a symbol type.
     */
    @NotNull
    @Column(name = "entry_type_cd", length = 1)
    private String entryTypeCode;

    @NotNull
    @Column(name = "validity_from_dt", nullable = false)
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date validityFromDate;

    /**
     * This value is nullable. Null indicates that the symbol is currently valid
     * and there are no plans to change its validity status (indefinite). The
     * validity_to_dt is set to non-null (usually future date) when classifiers
     * decide the symbol will be deprecated, at which point you the
     * validity_to_dt is treated as an expiration for usaged. 
     */
    @Column(name = "validity_to_dt", updatable = false, insertable = false)
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date validityToDate;

    /**
     * This information, used only for classification symbols of the Advanced
     * level, gives the corresponding valid symbol to be used in the Core level
     * classification. This reference is unique and given by the descriptive
     * part of the referenced Core level symbol.
     */
    @Column(name = "predecessor_symbol_cd", length = 50)
    private String predecessorSymbolCode;

    @CreatedBy
    @NotNull
    @Column(name = "create_user_id", length = 100, nullable = false)
    // This should be 255 to accommodate email addresses
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no", nullable = false)
    private Integer lockControl;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the ipcSymbolCode
     */
    public String getIpcSymbolCode() {
        return ipcSymbolCode;
    }

    /**
     * @param ipcSymbolCode
     *            the ipcSymbolCode to set
     */
    public void setIpcSymbolCode(String ipcSymbolCode) {
        this.ipcSymbolCode = ipcSymbolCode;
    }

    /**
     * @return the schemeVersionDate
     */
    public Date getSchemeVersionDate() {
        return schemeVersionDate;
    }

    /**
     * @param schemeVersionDate
     *            the schemeVersionDate to set
     */
    public void setSchemeVersionDate(Date schemeVersionDate) {
        this.schemeVersionDate = schemeVersionDate;
    }

    /**
     * @return the sectionCode
     */
    public String getSectionCode() {
        return sectionCode;
    }

    /**
     * @param sectionCode
     *            the sectionCode to set
     */
    public void setSectionCode(String sectionCode) {
        this.sectionCode = sectionCode;
    }

    /**
     * @return the classCode
     */
    public String getClassCode() {
        return classCode;
    }

    /**
     * @param classCode
     *            the classCode to set
     */
    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    /**
     * @return the subclassCode
     */
    public String getSubclassCode() {
        return subclassCode;
    }

    /**
     * @param subclassCode
     *            the subclassCode to set
     */
    public void setSubclassCode(String subclassCode) {
        this.subclassCode = subclassCode;
    }

    /**
     * @return the mainGroupCode
     */
    public String getMainGroupCode() {
        return mainGroupCode;
    }

    /**
     * @param mainGroupCode
     *            the mainGroupCode to set
     */
    public void setMainGroupCode(String mainGroupCode) {
        this.mainGroupCode = mainGroupCode;
    }

    /**
     * @return the subGroupCode
     */
    public String getSubGroupCode() {
        return subGroupCode;
    }

    /**
     * @param subGroupCode
     *            the subGroupCode to set
     */
    public void setSubGroupCode(String subGroupCode) {
        this.subGroupCode = subGroupCode;
    }

    /**
     * @return the classificationLevelCode
     */
    public String getClassificationLevelCode() {
        return classificationLevelCode;
    }

    /**
     * @param classificationLevelCode
     *            the classificationLevelCode to set
     */
    public void setClassificationLevelCode(String classificationLevelCode) {
        this.classificationLevelCode = classificationLevelCode;
    }

    /**
     * @return the entryTypeCode
     */
    public String getEntryTypeCode() {
        return entryTypeCode;
    }

    /**
     * @param entryTypeCode
     *            the entryTypeCode to set
     */
    public void setEntryTypeCode(String entryTypeCode) {
        this.entryTypeCode = entryTypeCode;
    }

    /**
     * @return the validityFromDate
     */
    public Date getValidityFromDate() {
        return validityFromDate;
    }

    /**
     * @param validityFromDate
     *            the validityFromDate to set
     */
    public void setValidityFromDate(Date validityFromDate) {
        this.validityFromDate = validityFromDate;
    }

    /**
     * @return the validityToDate
     */
    public Date getValidityToDate() {
        return validityToDate;
    }

    /**
     * @param validityToDate
     *            the validityToDate to set
     */
    public void setValidityToDate(Date validityToDate) {
        this.validityToDate = validityToDate;
    }

    /**
     * @return the predecessorSymbolCode
     */
    public String getPredecessorSymbolCode() {
        return predecessorSymbolCode;
    }

    /**
     * @param predecessorSymbolCode
     *            the predecessorSymbolCode to set
     */
    public void setPredecessorSymbolCode(String predecessorSymbolCode) {
        this.predecessorSymbolCode = predecessorSymbolCode;
    }

    /**
     * @return the createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     *            the createUserId to set
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return the createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     *            the createTs to set
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return the lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     *            the lockControl to set
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IpcSymbolHierarchy [id=" + id + ", ipcSymbolCode=" + ipcSymbolCode + ", schemeVersionDate="
				+ schemeVersionDate + ", sectionCode=" + sectionCode + ", classCode=" + classCode + ", subclassCode="
				+ subclassCode + ", mainGroupCode=" + mainGroupCode + ", subGroupCode=" + subGroupCode
				+ ", classificationLevelCode=" + classificationLevelCode + ", entryTypeCode=" + entryTypeCode
				+ ", validityFromDate=" + validityFromDate + ", validityToDate=" + validityToDate
				+ ", predecessorSymbolCode=" + predecessorSymbolCode + ", createUserId=" + createUserId + ", createTs="
				+ createTs + ", lockControl=" + lockControl + "]";
	}
    
    
}
