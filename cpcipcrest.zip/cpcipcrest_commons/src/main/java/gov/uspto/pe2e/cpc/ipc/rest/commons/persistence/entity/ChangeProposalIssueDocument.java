package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.CollectionScanner;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Many-to-Many bridge entity allowing Issues to be linked to Documents 
 * @author myoung3
 *
 */
@Data
@Entity
@Table(name = "change_proposal_issue_doc", uniqueConstraints = { 
	@UniqueConstraint(name = "pk_change_proposal_issue_doc", columnNames = {
        "issue_doc_id" }) 		
})
public class ChangeProposalIssueDocument implements Serializable, Comparable<ChangeProposalIssueDocument> {
    
    private static final long serialVersionUID = 1L;

    //TODO: Change All primary key columns from numeric to guids
    @Id
    @Guid
    @NotNull
    @Column(name = "issue_doc_id", length = 32) 
    private String id; // GUID in db format (32 char UUIDv4 with dashes stripped)  

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalIssue.class)
    @JoinColumn(name = "fk_issue_id", referencedColumnName = "issue_id")
    private ChangeProposalIssue issue;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalDocument.class)
    @JoinColumn(name = "fk_change_proposal_doc_id", referencedColumnName = "change_proposal_doc_id")
    private ChangeProposalDocument document;

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;
    

    @NotNull
    @Column(name = "create_user_id")
    private String createUserId;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    /**
     * @return the changeProposerRoles
     * @since April 07, 2018
     */

    @Override
    public int compareTo(ChangeProposalIssueDocument other) {
        
        return new CompareToBuilder()
                .append(Optional.ofNullable(this.getDocument()).orElse(new ChangeProposalDocument()).getId(), 
                        Optional.ofNullable(other.getDocument()).orElse(new ChangeProposalDocument()).getId())
                .toComparison();
                
    }
	
	@Override
	public int hashCode() {
		return Objects.hash( 
				CollectionScanner.coalesce(document, new ChangeProposalDocument()).getId(), 
				CollectionScanner.coalesce(issue, new ChangeProposalIssue()).getId(),
				createTs, createUserId, id,
				lockControl);
	}
    
    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = false;

        if (obj != null) {
            if (obj == this) {
                ret = true;
            } else if (ChangeProposalIssueDocument.class.isAssignableFrom(obj.getClass())) {
                ChangeProposalIssueDocument that = (ChangeProposalIssueDocument) obj;
                ret = new EqualsBuilder()
                        .append(getId(), that.getId())
                        .append(CollectionScanner.coalesce(getIssue(), new ChangeProposalIssue()).getId(), 
                        		CollectionScanner.coalesce(that.getIssue(), new ChangeProposalIssue()).getId())
                        .append(CollectionScanner.coalesce(getDocument(), new ChangeProposalDocument()).getId(), 
                        		CollectionScanner.coalesce(that.getDocument(), new ChangeProposalDocument()).getId())
                        .isEquals();
            }
        }
        return ret;
    }

	@Override
	public String toString() {
		return "ChangeProposalIssueDocument [id=" + id 
				+ ", issue=" + ((issue != null)?issue.getId():"null") + ", document=" 
				+ ((document != null)?document.getId():"null") 
				+ ", createTs="
				+ createTs + ", createUserId=" + createUserId + ", lockControl=" 
				+ lockControl + "]";
	}
    
    
    
    
}
   
