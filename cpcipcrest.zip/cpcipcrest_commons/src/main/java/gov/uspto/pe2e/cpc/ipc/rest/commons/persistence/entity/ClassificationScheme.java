package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.VarcharBooleanConverter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import lombok.Getter;
import lombok.Setter;

/**
 * Entity Class for handling ORM Persistence for table classification_scheme
 * primary key is classification_scheme_id
 * 
 * 
 * @author 2020
 * @version 1.1
 * @date: 10/16/2015
 *
 */
@Entity
@Getter
@Setter
@Table(name = "classification_scheme", uniqueConstraints =  {
		@UniqueConstraint(name = "ri_cp_cs", columnNames = { "fk_change_proposal_guid" }) })
public class ClassificationScheme implements Serializable {

    /**
     * Allowing serialization of datamodel elements 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "classification_scheme_seq")
    @SequenceGenerator(name = "classification_scheme_seq", 
                sequenceName = "classification_scheme_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "classification_scheme_id")
    private Long id;

    @Column(name = "scheme_version_dt")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date schemeVersionDate;

    @Column(name = "description_tx")
    private String description;

    // We do not use @Guid bc this is allowed to be null
    // This is an unusual case for GUID columns 
    // (as they are usually required) so rather than remove @NottNull 
    // from the @Guid annotation and force developers to remember to add it constantly,
    // I have opted to enforce the Guid constraints without the custom JSR-303 
    // meta-annotation we wrote -- Matt
    // @Pattern(regexp="^[0-9a-f]{8}[0-9a-f]{4}[1-5][0-9a-f]{3}[89ab][0-9a-f]{3}[0-9a-f]{12}$")
    // @Size(min=32, max=32)
    @Guid
	@Column(name = "fk_change_proposal_guid")
    private String proposalGuid;

    
    @Convert(converter = VarcharBooleanConverter.class)
    @Column(name = "current_in", columnDefinition = "varchar2")
    private Boolean currentIn;

    @CreatedBy
    @Column(name = "create_user_id")
    private String createUserId;

    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @Column(name = "last_mod_user_id")
    private String lastModUserId;

    @LastModifiedDate
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    // TODO: change to "lastModifiedTs
    private Date lastModTs;

    @Version
    @Column(name = "lock_control_no")
    private Long lockControlNo;
    
    @Convert(converter = VarcharBooleanConverter.class)
    @Column(name = "distributed_in", columnDefinition = "varchar2")
    private Boolean distributedIn;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = SchemaDefinition.class)
    @JoinColumn(name = "fk_schema_xsd_id", referencedColumnName = "schema_definition_id")
    private SchemaDefinition schemeXsd;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = SchemaDefinition.class)
    @JoinColumn(name = "fk_definition_xsd_id", referencedColumnName = "schema_definition_id")
    private SchemaDefinition definitionXsd;
    
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, 
		   mappedBy = "classificationScheme", targetEntity = ClassificationSchemeStatus.class)
   	private ClassificationSchemeStatus classificationSchemeStatus;

    /**
     * @return Long id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return Date schemeVersionDate
     */
    public Date getSchemeVersionDate() {
        return schemeVersionDate;
    }

    /**
     * @param schemeVersionDate
     */
    public void setSchemeVersionDate(Date schemeVersionDate) {
        this.schemeVersionDate = schemeVersionDate;
    }

    /**
     * @return String description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return Boolean currentYN
     */
    public Boolean getCurrentIn() {
        return currentIn;
    }

    /**
     * @param currentYN
     */
    public void setCurrentIn(Boolean currentIn) {
        this.currentIn = currentIn;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return String lastModUserId
     */
    public String getLastModUserId() {
        return lastModUserId;
    }

    /**
     * @param lastModUserId
     */
    public void setLastModUserId(String lastModUserId) {
        this.lastModUserId = lastModUserId;
    }

    /**
     * @return Date lastModTs
     */
    public Date getLastModTs() {
        return lastModTs;
    }

    /**
     * @param lastModTs
     */
    public void setLastModTs(Date lastModTs) {
        this.lastModTs = lastModTs;
    }

    /**
     * @return Long lockControlNo
     */
    public Long getLockControlNo() {
        return lockControlNo;
    }

    /**
     * @param lockControlNo
     */
    public void setLockControlNo(Long lockControlNo) {
        this.lockControlNo = lockControlNo;
    }

    /**
     * @return schemeXsd
     */
    public SchemaDefinition getSchemeXsd() {
        return schemeXsd;
    }

    /**
     * @param schemeXsd
     */
    public void setSchemeXsd(SchemaDefinition schemeXsd) {
        this.schemeXsd = schemeXsd;
    }

    /**
     * @return definitionXsd
     */
    public SchemaDefinition getDefinitionXsd() {
        return definitionXsd;
    }

    /**
     * @param definitionXsd
     */
    public void setDefinitionXsd(SchemaDefinition definitionXsd) {
        this.definitionXsd = definitionXsd;
    }

	@Override
	public String toString() {
		return "ClassificationScheme [id=" + id + ", schemeVersionDate=" + schemeVersionDate + ", description="
				+ description + ", proposalGuid=" + proposalGuid + ", currentIn=" + currentIn + ", createUserId="
				+ createUserId + ", createTs=" + createTs + ", lastModUserId=" + lastModUserId + ", lastModTs="
				+ lastModTs + ", lockControlNo=" + lockControlNo + ", schemeXsd=" + schemeXsd + ", definitionXsd="
				+ definitionXsd + "]";
	}
    
    

}
