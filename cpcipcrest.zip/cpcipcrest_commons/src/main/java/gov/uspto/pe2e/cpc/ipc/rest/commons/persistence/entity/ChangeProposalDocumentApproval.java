package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table change_proposal primary
 * key is change_proposal_id
 * 
 * @author 2020
 * @version 1.3
 * @date: 03/15/2016
 *
 */
@Entity
@Table(name = "change_proposal_doc_approval", uniqueConstraints = {  
        @UniqueConstraint(columnNames = { "doc_approval_id" }),
        @UniqueConstraint(columnNames = { "guid_id" }),
        @UniqueConstraint(columnNames = { "fk_change_proposal_doc_id",  "fk_ipo_cd", 
                "fk_proposer_role_cd" }) 
        })
@Data
public class ChangeProposalDocumentApproval implements Comparable<ChangeProposalDocumentApproval>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "doc_approval_id_seq")
    @SequenceGenerator(name = "doc_approval_id_seq", sequenceName = "doc_approval_id_seq", initialValue = 1, 
                 allocationSize = 1)
    @Column(name = "doc_approval_id")
    private Long id;

    @Guid
    @NotNull
    @Column(name = "guid_id")
    private String externalId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalDocument.class)
    @JoinColumn(name = "fk_change_proposal_doc_id", referencedColumnName = "change_proposal_doc_id")
    private ChangeProposalDocument changeProposalDocument;
    
    
    @Enumerated(EnumType.STRING)
    @Column(name = "fk_ipo_cd")
    private StandardIpOfficeCode standardIpOfficeCode;
    

    @Enumerated(EnumType.STRING)
    @Column(name = "fk_proposer_role_cd")
    private OfficeContactType approverRole;
    
    
//    @Column(name = "approver_comment_tx", length = 4000)
//    private String approvalComment; // VARCHAR2(500)

    
                              
    @NotNull
    @Convert(converter = YesNoConverter.class)
    @Column(name = "approval_in", columnDefinition = "char(1)")
    private Boolean approved; // archived flag                          
    

    
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
	@OrderBy(value = "create_ts DESC")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "approval", targetEntity = DocApprovalCommentHist.class)
	private Set<DocApprovalCommentHist> comments;
    
    public Set<DocApprovalCommentHist> getComments() {
    	if (this.comments == null) {
    		this.comments = new TreeSet<>();
    	}
    	return this.comments;
    }

        
    /**
     * @return the changeProposerRoles
     * @since April 07, 2018
     */

    @Override
    public int compareTo(ChangeProposalDocumentApproval other) {
        
        return new CompareToBuilder()
                .append(Optional.ofNullable(this.getChangeProposalDocument()).orElse(new ChangeProposalDocument()).getId(), 
                        Optional.ofNullable(other.getChangeProposalDocument()).orElse(new ChangeProposalDocument()).getId())
                .append(this.getStandardIpOfficeCode(), other.getStandardIpOfficeCode())
                .append(this.getApproverRole(), other.getApproverRole())
                .toComparison();
                
    }
    
    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((changeProposalDocument == null) ? 0 : changeProposalDocument.hashCode());
        result = prime * result + ((standardIpOfficeCode == null) ? 0 : standardIpOfficeCode.hashCode());
        result = prime * result + ((approverRole == null) ? 0 : approverRole.hashCode());
        result = prime * result + ((externalId == null) ? 0 : externalId.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((approved == null) ? 0 : approved.hashCode());
        return result;
    }

    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = false;

        if (obj != null) {
            if (obj == this) {
                ret = true;
            } else if (ChangeProposalDocumentApproval.class.isAssignableFrom(obj.getClass())) {
                ChangeProposalDocumentApproval that = (ChangeProposalDocumentApproval) obj;
                ret = new EqualsBuilder()
                        .append(getId(), that.getId())
                        .append(getChangeProposalDocument(), that.getChangeProposalDocument())
                        .append(getStandardIpOfficeCode(), that.getStandardIpOfficeCode())
                        .append(getApproverRole(), that.getApproverRole())
                        .append(getExternalId(), that.getExternalId())
                        .append(getComments(), that.getComments())
                        .append(getApproved(), that.getApproved())
                        .isEquals();
            }
        }
        return ret;
    }
      
    
}
