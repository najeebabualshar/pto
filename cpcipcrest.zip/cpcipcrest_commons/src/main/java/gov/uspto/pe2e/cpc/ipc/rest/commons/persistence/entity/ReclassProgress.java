package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table reclass_progress primary
 * key is reclass_progress_id
 * 
 * @author msingh4
 * @version 1.0
 * @date: 02/04/2022
 *
 */
@Data
@Entity
@Table(name = "reclass_progress", uniqueConstraints = { @UniqueConstraint(columnNames = { "reclass_progress_id" }),
		@UniqueConstraint(columnNames = { "guid_id" }) })
public class ReclassProgress implements Comparable<ReclassProgress>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "reclass_progress_id_seq")
	@SequenceGenerator(name = "reclass_progress_id_seq", sequenceName = "reclass_progress_id_seq", initialValue = 1, allocationSize = 1)
	@Column(name = "reclass_progress_id")
	private Long id;

	@Guid
	@NotNull
	@Column(name = "guid_id")
	private String externalId;
	
	@NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
	
	@NotNull
	@Column(name = "load_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date loadTs;
	
	@NotNull
	@Column(name = "us_admin_xfr_pending_no")
	private Integer usAdminPendingCount;
	
	@NotNull
	@Column(name = "ep_admin_xfr_pending_no")
	private Integer epAdminPendingCount;
	
	@NotNull
	@Column(name = "no_admin_xfr_pending_no")
	private Integer noAdminPendingCount;
	
	@NotNull
	@Column(name = "us_intellct_xfr_pending_no")
	private Integer usIntelPendingCount;
	
	@NotNull
	@Column(name = "ep_intellct_xfr_pending_no")
	private Integer epIntelPendingCount;
	
	@NotNull
	@Column(name = "no_intellct_xfr_pending_no")
	private Integer noIntelPendingCount;
	
	@NotNull
	@Column(name = "total_admin_xfr_pending_no")
	private Integer totalAdminPendingCount;
	
	@NotNull
	@Column(name = "total_intellct_xfr_pending_no")
	private Integer totalIntelPendingCount;

	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	@Override
	public int compareTo(ReclassProgress o) {
		return new CompareToBuilder().append(this.getId(), o.getId())
				.append(this.getExternalId(), o.getExternalId()).toComparison();
	}
}
