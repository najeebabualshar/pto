package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity class for handling CEF Project process data
 * 
 * @author Maximus
 * @date September 10, 2021
 * @version 1.0
 *
 */

@Entity
@Table(name = "cef_project_process_log", uniqueConstraints = { @UniqueConstraint(columnNames = { "cef_project_cd" })})
public class CefProjectProcessLog implements Comparable<CefProjectProcessLog>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
    
    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "project_process_log_id_seq")
    @SequenceGenerator(name = "project_process_log_id_seq", sequenceName = "project_process_log_id_seq", initialValue = 1, 
                 allocationSize = 1)
    @Column(name = "project_process_log_id")
    private Long id;
    
    @NotNull
	@Column(name ="cef_project_cd")
    private String cefProjectCode;
    
    
	@Column(name ="change_proposal_cd")
    private String changeProposalCode;    
	
	@Column(name ="change_proposal_guid_id")
    private String changeProposalExternalId;
    
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name ="status_ct")
    private CefMigrationStatus status;
    
	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCefProjectCode() {
		return cefProjectCode;
	}

	public void setCefProjectCode(String cefProjectCode) {
		this.cefProjectCode = cefProjectCode;
	}

	public String getChangeProposalCode() {
		return changeProposalCode;
	}

	public void setChangeProposalCode(String changeProposalCode) {
		this.changeProposalCode = changeProposalCode;
	}

	public String getChangeProposalExternalId() {
		return changeProposalExternalId;
	}

	public void setChangeProposalExternalId(String changeProposalExternalId) {
		this.changeProposalExternalId = changeProposalExternalId;
	}

	public CefMigrationStatus getStatus() {
		return status;
	}

	public void setStatus(CefMigrationStatus status) {
		this.status = status;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	public Integer getLockControl() {
		return lockControl;
	}

	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}
	
	/**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(CefProjectProcessLog other) {
        return new CompareToBuilder().append(this.getId(), other.getId())
                .append(this.getChangeProposalExternalId(), other.getChangeProposalExternalId())
                .append(this.getCefProjectCode(), other.getCefProjectCode())
                .append(this.getChangeProposalCode(), other.getChangeProposalCode())
                .append(this.getStatus(), other.getStatus()).toComparison();
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cefProjectCode == null) ? 0 : cefProjectCode.hashCode());
		result = prime * result + ((changeProposalCode == null) ? 0 : changeProposalCode.hashCode());
		result = prime * result + ((changeProposalExternalId == null) ? 0 : changeProposalExternalId.hashCode());
		result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
		result = prime * result + ((createUserId == null) ? 0 : createUserId.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastModifiedTs == null) ? 0 : lastModifiedTs.hashCode());
		result = prime * result + ((lastModifiedUserId == null) ? 0 : lastModifiedUserId.hashCode());
		result = prime * result + ((lockControl == null) ? 0 : lockControl.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CefProjectProcessLog other = (CefProjectProcessLog) obj;
		if (cefProjectCode == null) {
			if (other.cefProjectCode != null)
				return false;
		} else if (!cefProjectCode.equals(other.cefProjectCode))
			return false;
		if (changeProposalCode == null) {
			if (other.changeProposalCode != null)
				return false;
		} else if (!changeProposalCode.equals(other.changeProposalCode))
			return false;
		if (changeProposalExternalId == null) {
			if (other.changeProposalExternalId != null)
				return false;
		} else if (!changeProposalExternalId.equals(other.changeProposalExternalId))
			return false;
		if (createTs == null) {
			if (other.createTs != null)
				return false;
		} else if (!createTs.equals(other.createTs))
			return false;
		if (createUserId == null) {
			if (other.createUserId != null)
				return false;
		} else if (!createUserId.equals(other.createUserId))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastModifiedTs == null) {
			if (other.lastModifiedTs != null)
				return false;
		} else if (!lastModifiedTs.equals(other.lastModifiedTs))
			return false;
		if (lastModifiedUserId == null) {
			if (other.lastModifiedUserId != null)
				return false;
		} else if (!lastModifiedUserId.equals(other.lastModifiedUserId))
			return false;
		if (lockControl == null) {
			if (other.lockControl != null)
				return false;
		} else if (!lockControl.equals(other.lockControl))
			return false;
		if (status != other.status)
			return false;
		return true;
	}
	
}
