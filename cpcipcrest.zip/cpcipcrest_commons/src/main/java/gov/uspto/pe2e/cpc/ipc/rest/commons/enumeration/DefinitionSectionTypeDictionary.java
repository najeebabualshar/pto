package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import lombok.Getter;

/**
 * The purpose of this Enum is to map the 
 * @see gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType 
 * to the field names (using javabean convention) for which to set each value
 * The target bean for which we are setting values is 
 * @see gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem
 * 
 * Note:  All references are actually a child of <references> tag so the children have to be cognizant to create
 * the parent references object if necessary.
 * 
 * @author myoung3
 *
 */
public enum DefinitionSectionTypeDictionary {
	DEFINITION_TITLE ("definitionTitle"),
    DEFINITION_STATEMENT ("definitionStatement"),
    RELATIONSHIP ("relationship"),
    LIMITING_REFERENCES ("references.limitingReferences"),
    APPLICATION_REFERENCES ("references.applicationReferences"),
    RESIDUAL_REFERENCES ("references.residualReferences"),
    INFORMATIVE_REFERENCES ("references.informativeReferences"),
    SPECIAL_RULES ("specialRules"),
    GLOSSARY_OF_TERMS ("glossaryOfTerms"),
    SYNONYMS_AND_KEYWORDS ("synonymsKeywords");
	
	@Getter
	private String fieldPath;
	private DefinitionSectionTypeDictionary (String fieldPath) {
		this.fieldPath = fieldPath;
	}

}
