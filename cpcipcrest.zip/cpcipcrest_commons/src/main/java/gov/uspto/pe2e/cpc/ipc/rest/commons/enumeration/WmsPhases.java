package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * This enum defines what type of WMS Phases is being supported 
 * 
 * @author Maximus
 * @date Jun 23, 2021
 * @version 2.2
 */
public enum WmsPhases {
    I ("Internal Request Phase"), 
    E ("Pre Bilateral Phase"), 
    Q ("Bilateral Request Phase"), 
    A ("Bilateral Active Phase"),
    C ("Completed Phase"),
    R ("Reclass Phase"),
    U ("Cleanup (after Reclass phase)"),
    F ("Finalization Phase"),
    PI ("Publication Phase (Initial)"),
    DI ("Distribution Phase (Initial)"),    
    PF ("Publication Phase (Final)"),
    DF ("Distribution Phase (Final)"),
    P ("Publication Phase"),
    D ("Distribution Phase");
    
    private String phaseName;

    private WmsPhases(String phaseName) {
        this.phaseName = phaseName;
    }

    /**
     * @return the phaseName
     */
    public String getPhaseName() {
        return phaseName;
    }
    
    
}

