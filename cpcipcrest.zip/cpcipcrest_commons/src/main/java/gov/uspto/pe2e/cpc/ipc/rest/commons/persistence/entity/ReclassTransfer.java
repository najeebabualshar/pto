package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CompareToUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeTargetClassifiationCategory;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Transient;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table reclass_transfer primary
 * key column is reclass_transfer_id
 * 
 * @author 2020
 * @version 1.6
 * @date: 03/08/2017
 *
 *        NOTE: When reclassificationTypeCategory = ADMIN then
 *        TargetClassificationValueCode = I or A When
 *        reclassificationTypeCategory = INTELLECTUAL then
 *        TargetClassificationValueCode = NULL
 */
@Data
@Entity
@Table(name = "reclass_transfer", uniqueConstraints = {
       // @UniqueConstraint(columnNames = { "source_version_symbol_id", "target_version_symbol_id" })//,
       // @UniqueConstraint(columnNames = { "guid_id" }) })
	})
public class ReclassTransfer implements Comparable<ReclassTransfer>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "reclass_transfer_id_seq")
//    @SequenceGenerator(name = "reclass_transfer_id_seq", sequenceName = "reclass_transfer_id_seq", allocationSize = 1)
//    @Column(name = "reclass_transfer_id")
//    private Long id;
    @Guid
	@NotNull
    @Column(name = "guid_id", length = 32)
    private String externalId;

    @NotNull
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = VersionSymbol.class)
    @JoinColumn(name = "source_version_symbol_id", referencedColumnName = "guid_id")
    private VersionSymbol sourceVersionSymbol;

//    @NotNull
//    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = VersionSymbol.class)
//    @JoinColumn(name = "target_version_symbol_id", referencedColumnName = "guid_id")
//    private VersionSymbol targetVersionSymbol;
//    
    @Column(name="target_full_symbol_tx")
    private String targetSymbolName;

    @Enumerated(EnumType.STRING)
    @Column(name = "target_classification_value_cd")
    private ReclassificationTypeTargetClassifiationCategory targetClassificationValueCode; // VARCHAR2(1)
    // A - Additive, I - Inventive
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "reclsfcn_type_ct")
    private ReclassificationTypeCategory reclassificationTypeCategory; // VARCHAR2(20)
                                                                       // ADMIN,
                                                                       // INTELLECTUAL

    @NotNull
    @Column(name = "create_user_id")
    @CreatedBy
    private String createUserId; // VARCHAR2(100)

    @NotNull
    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @NotNull
    @LastModifiedBy
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @NotNull
    @LastModifiedDate
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;

    /**
     * @return Long id
     */
    @Transient
    public UUID getId() {
        return GUIDUtils.fromDatabaseFormat(getExternalId());
    }

    /**
     * @param id
     */
    public void setId(UUID id) {
        this.externalId = GUIDUtils.toDatabaseFormat(id);
    }

    /**
     * @return String externalId
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * @param externalId
     */
    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    /**
     * @return VersionSymbol sourceVersionSymbol
     */
    public VersionSymbol getSourceVersionSymbol() {
        return sourceVersionSymbol;
    }

    /**
     * @param sourceVersionSymbol
     */
    public void setSourceVersionSymbol(VersionSymbol sourceVersionSymbol) {
        this.sourceVersionSymbol = sourceVersionSymbol;
    }

    
    /**
     * @return TargetClassificationValueCode targetClassificationValueCode
     */
    public ReclassificationTypeTargetClassifiationCategory getTargetClassificationValueCode() {
        return targetClassificationValueCode;
    }

    /**
     * @param targetClassificationValueCode
     */
    public void setTargetClassificationValueCode(
            ReclassificationTypeTargetClassifiationCategory targetClassificationValueCode) {
        this.targetClassificationValueCode = targetClassificationValueCode;
    }

    /**
     * @return the reclassificationTypeCategory
     */
    public ReclassificationTypeCategory getReclassificationTypeCategory() {
        return reclassificationTypeCategory;
    }

    /**
     * @param reclassificationTypeCategory
     *            the reclassificationTypeCategory to set
     */
    public void setReclassificationTypeCategory(ReclassificationTypeCategory reclassificationTypeCategory) {
        this.reclassificationTypeCategory = reclassificationTypeCategory;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return String lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return Date lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @return Integer lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ReclassTransfer other) {
        int ret = CompareToUtils.THIS_IS_GREATER;
        if (other != null) {
            ret = new CompareToBuilder()
                    .append(this.getSourceVersionSymbol().getSymbolName(),
                            other.getSourceVersionSymbol().getSymbolName())
                    .append(this.getTargetSymbolName(),
                            other.getTargetSymbolName())
                    .append(this.getExternalId(), other.getExternalId()).toComparison();
        }
        return ret;
    }

    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret;
        if (obj == null || !ReclassTransfer.class.isAssignableFrom(obj.getClass())) {
            ret = false;
        } else if (ReclassTransfer.class.isAssignableFrom(obj.getClass()) && obj == this) {
            ret = true;
        } else {
            ReclassTransfer thatObj = (ReclassTransfer) obj;
            String meSource = this.getSourceVersionSymbol().getSymbolName();
            String thatSource = thatObj.getSourceVersionSymbol().getSymbolName();
            String meTarget = this.getTargetSymbolName();
            String thatTarget = thatObj.getTargetSymbolName();
            String meExternalId = this.getExternalId();
            String thatExternalId = thatObj.getExternalId();
            ret = StringUtils.equals(meSource, thatSource) && StringUtils.equals(meTarget, thatTarget)
                    && StringUtils.equals(meExternalId, thatExternalId);
        }
        return ret;
    }

    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + this.getSourceVersionSymbol().getSymbolName().hashCode()
                + Objects.hash(this.getTargetSymbolName())
                + this.getExternalId().hashCode();
        return result;
    }

	@Override
	public String toString() {
		return "ReclassTransfer [externalId=" + externalId + ", sourceVersionSymbol=" + sourceVersionSymbol.getId()
				+ ", targetSymbolName=" + targetSymbolName + ", targetClassificationValueCode="
				+ targetClassificationValueCode + ", reclassificationTypeCategory=" + reclassificationTypeCategory
				+ ", createUserId=" + createUserId + ", createTs=" + createTs + ", lastModifiedUserId="
				+ lastModifiedUserId + ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + "]";
	}
    
    
}
