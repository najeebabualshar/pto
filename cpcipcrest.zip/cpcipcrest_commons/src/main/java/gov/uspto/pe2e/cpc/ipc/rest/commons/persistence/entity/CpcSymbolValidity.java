package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Entity of cpc_symbol_validity used to get the generated CPC symbol for the
 * given CPC symbol. The source of the data is from Validity file, populated by
 * a loading script (by EDAD). The Validity files were kept in
 * cpc_xml_file_stage, managed by EDAD.
 * 
 * @author 2020
 * @date April 8, 2019 4:52:21 PM
 * @version 1.16.0
 */

@Entity
@Table(name = "cpc_symbol_validity")
public class CpcSymbolValidity implements Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cpc_symbol_validity_id_seq")
    @SequenceGenerator(name = "cpc_symbol_validity_id_seq", sequenceName = "cpc_symbol_validity_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "cpc_symbol_validity_id")
    private Long id;

    @Size(max = 50, min = 1)
    @NotNull
    @Column(name = "cpc_symbol_cd", length = 50, nullable = false)
    private String cpcSymbolCode;

    /**
     * CPC Scheme published version date. Generally once a year CPC scheme will
     * be published.
     */
    @NotNull
    @Column(name = "scheme_version_dt", nullable = false)
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date schemeVersionDate;
    
    @NotNull
    @Column(name = "validity_from_dt", nullable = false)
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date validityFromDate;

    /**
     * This value is nullable. Null indicates that the symbol is currently valid
     * and there are no plans to change its validity status (indefinite). The
     * validity_to_dt is set to non-null (usually future date) when classifiers
     * decide the symbol will be deprecated, at which point you the
     * validity_to_dt is treated as an expiration for usaged. 
     */
    @Column(name = "validity_to_dt")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date validityToDate;
    
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id", length = 100, nullable = false)
    // This should be 255 to accommodate email addresses
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;
    
    @NotNull
    @LastModifiedBy
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @NotNull
    @LastModifiedDate
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;
    
    @NotNull
    @Version
    @Column(name = "lock_control_no", nullable = false)
    private Integer lockControl;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }
    
    /**
     * @return the cpcSymbolCode
     */
    public String getCpcSymbolCode() {
        return cpcSymbolCode;
    }

    /**
     * @param cpcSymbolCode
     *            the cpcSymbolCode to set
     */
    public void setCpcSymbolCode(String cpcSymbolCode) {
        this.cpcSymbolCode = cpcSymbolCode;
    }

    /**
     * @return the schemeVersionDate
     */
    public Date getSchemeVersionDate() {
        return schemeVersionDate;
    }

    /**
     * @param schemeVersionDate
     *            the schemeVersionDate to set
     */
    public void setSchemeVersionDate(Date schemeVersionDate) {
        this.schemeVersionDate = schemeVersionDate;
    }

    /**
     * @return the validityFromDate
     */
    public Date getValidityFromDate() {
        return validityFromDate;
    }

    /**
     * @param validityFromDate
     *            the validityFromDate to set
     */
    public void setValidityFromDate(Date validityFromDate) {
        this.validityFromDate = validityFromDate;
    }

    /**
     * @return the validityToDate
     */
    public Date getValidityToDate() {
        return validityToDate;
    }

    /**
     * @param validityToDate
     *            the validityToDate to set
     */
    public void setValidityToDate(Date validityToDate) {
        this.validityToDate = validityToDate;
    }

    /**
     * @return the createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     *            the createUserId to set
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return the createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     *            the createTs to set
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs; 
    }
    
    /**
     * @return String lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return Date lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @return the lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     *            the lockControl to set
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }
}
