package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
@Entity
@Table(name = "doc_approval_comment_hist", uniqueConstraints={ 
//        @UniqueConstraint(
//            name="pk_wf_sme_consult_comment", 
//            columnNames = { "sme_consult_comment_guid_id"})        
})
public class DocApprovalCommentHist  implements Comparable<DocApprovalCommentHist>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Guid
    @NotNull
    @Column(name = "comment_hist_guid_id")
    private String id;
    
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalDocumentApproval.class)
    @JoinColumn(name = "fk_doc_approval_id", referencedColumnName = "doc_approval_id")
    private ChangeProposalDocumentApproval approval;
	
    @Column(name = "approver_comment_tx", length = 4000)
	private String comment;// VARCHAR2(4000)
    
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

//    @LastModifiedBy
//    @NotNull
//    @Column(name = "last_mod_user_id")
//    private String lastModifiedUserId; // VARCHAR2(100)
//
//    @LastModifiedDate
//    @NotNull
//    @Column(name = "last_mod_ts")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
//    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;

  
    @SuppressWarnings("CPD-END")
    
    

    @Override
    public int compareTo(DocApprovalCommentHist other) {
        
        return new CompareToBuilder()
                .append(Optional.ofNullable(this.getApproval()).orElse(new ChangeProposalDocumentApproval()).getId(), 
                        Optional.ofNullable(other.getApproval()).orElse(new ChangeProposalDocumentApproval()).getId())
                .append(this.getCreateTs(), other.getCreateTs())
                .append(this.getId(), other.getId())
                .toComparison();
                
    }
    
   


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocApprovalCommentHist other = (DocApprovalCommentHist) obj;
		return approval == other.getApproval() && Objects.equals(comment, other.comment)
				&& Objects.equals(createTs, other.createTs) 
				&& Objects.equals(createUserId, other.createUserId)
				&& Objects.equals(id, other.id) 
				&& Objects.equals(lockControl, other.lockControl);
	}


	@Override
	public int hashCode() {
		return Objects.hash(approval, comment, createTs, createUserId, id,
				lockControl);
	}




	@Override
	public String toString() {
		return "DocApprovalCommentHist [id=" + id 
				+ ", approval=" + ((approval != null)?approval.getExternalId():"null" )+ ", comment=" + comment 
				+ ", createUserId=" + createUserId + ", createTs=" + createTs + ", lockControl="
				+ lockControl + "]";
	}
  
    
}
