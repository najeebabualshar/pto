package gov.uspto.pe2e.cpc.ipc.rest.commons.adapter.export;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.relationships.Relationship;
import org.docx4j.wml.Hdr;
import org.docx4j.wml.JcEnumeration;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.Docx4jUtils;

public class RCLExportLayoutAdapter implements ExportLayoutAdapter {
	private static final String RCL_HEADER_TITLE = "REVISION CONCORDANCE LIST";
	
	/* (non-Javadoc)
     * @see gov.uspto.pe2e.cpc.ipc.rest.web.service.export.ExportLayoutAdapter#applyCoversheetHeader
     * (java.lang.String, org.docx4j.wml.Hdr)
     */
	@Override
	public void applyCoversheetHeader(String projectCd, Hdr coverHdr) {
		coverHdr.getContent().add(Docx4jUtils.makeParagraph(RCL_HEADER_TITLE, JcEnumeration.CENTER));
		coverHdr.getContent().add(Docx4jUtils.makeParagraph(projectCd, JcEnumeration.CENTER));

	}
	
	/* (non-Javadoc)
     * @see gov.uspto.pe2e.cpc.ipc.rest.web.service.export.ExportLayoutAdapter#applyContentHeader
     * (java.lang.String, org.docx4j.wml.Hdr)
     */
	@Override
	public void applyContentHeader(String proposalCode, Hdr contentHdr) {
		  contentHdr.getContent().add(Docx4jUtils.makeParagraph(RCL_HEADER_TITLE, JcEnumeration.CENTER));
          contentHdr.getContent().add(Docx4jUtils.makeParagraph(proposalCode, JcEnumeration.CENTER));

	}
	
	/* (non-Javadoc)
     * @see gov.uspto.pe2e.cpc.ipc.rest.web.service.export.ExportLayoutAdapter#applyCoversheetFooter
     * (org.docx4j.openpackaging.packages.WordprocessingMLPackage)
     */
	@Override
	public Relationship applyCoversheetFooter(WordprocessingMLPackage doc) {
		try {
			return Docx4jUtils.applyFooter(doc, ExportLayoutAdapterFactory.COVERSHEET_TEMPLATE_PATH, 
					ExportLayoutAdapterFactory.V2_FOOTER_TITLE);
		} catch (Exception e) {
			throw new IllegalArgumentException("Failed to apply content footer", e);
		}

	}
	
	/* (non-Javadoc)
     * @see gov.uspto.pe2e.cpc.ipc.rest.web.service.export.ExportLayoutAdapter#applyContentFooter
     * (org.docx4j.openpackaging.packages.WordprocessingMLPackage)
     */
	@Override
	public Relationship applyContentFooter(WordprocessingMLPackage doc) {
		try {
			return Docx4jUtils.applyFooter(doc, ExportLayoutAdapterFactory.CONTENT_TEMPLATE_PATH, 
					ExportLayoutAdapterFactory.V2_FOOTER_TITLE);
		} catch (Exception e) {
			throw new IllegalArgumentException("Failed to apply content footer", e);
		}
	}
}
