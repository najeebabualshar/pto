package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.CollectionScanner;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table version_symbol primary
 * key is guid_id
 * 
 * @author 2020
 * @version 1.5
 * @date: 09/12/2016
 *
 */

@Entity
@Table(name = "sct_track_change", uniqueConstraints = {
       // @UniqueConstraint(columnNames = { "sct_track_change_id" }, name = "uk1_version_symbol")
	})
@Data
public class SctTrackChange implements Comparable<SctTrackChange>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @Column(name = "sct_track_change_id", length = 40)
    private String id;

   
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalVersion.class)
    @JoinColumn(name = "fk_change_proposal_ver_id", referencedColumnName = "guid_id")
    private ChangeProposalVersion changeProposalVersion;
    
    @Lob
    @Column(name = "track_change_data_tx", columnDefinition = "clob")
    private String data;

	@Column(name = "delete_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date deleteTs;
    
    @SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;	
	@SuppressWarnings("CPD-END")
	
	@Override
	public String toString() {
		return "SctTrackChange [id=" + id + ", changeProposalVersion=" 
				+ ((changeProposalVersion != null)?changeProposalVersion.getExternalId(): "null")
				+ ", data=" + data
				+ ", createUserId=" + createUserId + ", createTs=" + createTs 
				+ ", lastModifiedUserId="
				+ lastModifiedUserId + ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" 
				+ lockControl + "]";
	}
	
	@Override
	public int compareTo(SctTrackChange other) {
		 return new CompareToBuilder()
	        		.append(CollectionScanner.coalesce(this.getChangeProposalVersion(), 
	        					new ChangeProposalVersion()).getExternalId(), 
	        				CollectionScanner.coalesce(other.getChangeProposalVersion(), 
		        					new ChangeProposalVersion()).getExternalId())
	                .append(this.getId(), 
	                		other.getId())
	                .append(this.getCreateTs(), 
	                		other.getCreateTs())
	                .toComparison();

	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SctTrackChange other = (SctTrackChange) obj;
		return Objects.equals(
				CollectionScanner.coalesce(changeProposalVersion, new ChangeProposalVersion()).getExternalId(),
				CollectionScanner.coalesce(other.changeProposalVersion, new ChangeProposalVersion()).getExternalId())
				&& Objects.equals(createTs, other.createTs) 
				&& Objects.equals(createUserId, other.createUserId)
				&& Objects.equals(data, other.data) 
				&& Objects.equals(id, other.id)
				&& Objects.equals(lastModifiedTs, other.lastModifiedTs)
				&& Objects.equals(lastModifiedUserId, other.lastModifiedUserId)
				&& Objects.equals(lockControl, other.lockControl);
	}

	@Override
	public int hashCode() {
		return Objects.hash(CollectionScanner.coalesce(changeProposalVersion, 
					new ChangeProposalVersion()).getExternalId()  , 
				createTs, createUserId, data, id, lastModifiedTs, 
				lastModifiedUserId,
				lockControl);
	}

	
	
	
}
