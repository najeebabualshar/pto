package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.crt.v1_0.ChangeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
/**
 * The persistent class for the crpt_other_project_crl database table.
 * @author Maximus
 *
 */
 
@Entity
@Table(name = "crpt_other_project_crl", uniqueConstraints = {
		@UniqueConstraint(columnNames = { "other_project_crl_id" }) })
@Data
public class CrptOtherProjectCrl implements Comparable<CrptOtherProjectCrl>, Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "other_project_crl_id_seq")
	@SequenceGenerator(name = "other_project_crl_id_seq", sequenceName = "other_project_crl_id_seq", initialValue = 1, allocationSize = 1)
	@Column(name = "other_project_crl_id")
	private Long id;

	@Guid
	@Column(name = "guid_id")
	@NotNull
	private String guid;
	
	@NotNull
	@Column(name="source_proposal_id")
	private Long sourceProposalId;

	@Guid
	@Column(name="source_proposal_guid_id")
	private String sourceProposalGuidId;

	@NotNull
	@Column(name="source_project_cd")
	private String sourceProjectCd;
	
	@NotNull
	@Column(name="source_symbol_tx")
	private String sourceSymbolTx;
	
	@NotNull
	@Column(name="source_crl_symbol_tx")
	private String sourceCrlSymbolTx;
	
	@Guid
	@NotNull
	@Column(name="version_symbol_guid_id")
	private String versionSymbolGuid;
	
	@NotNull
	@Column(name="other_proposal_id")
	private Long otherProposalId;

	@Guid
	@Column(name="other_proposal_guid_id")
	private String otherProposalGuidId;

	@NotNull
	@Column(name="other_project_cd")
	private String otherProjectCd;
	
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "title_change_in", columnDefinition = "char(1)")
	private ChangeType titleChangeIndicator;
	
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "notes_change_in", columnDefinition = "char(1)")
	private ChangeType notesChangeIndicator;
	
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "warn_change_in", columnDefinition = "char(1)")
	private ChangeType warnChangeIndicator;
	
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "definition_change_in", columnDefinition = "char(1)")
	private ChangeType definitionChangeIndicator;
	
	@Lob
	@Column(name="crl_title_tx", columnDefinition = "clob")
	private String crlTitleText;
	
	@Lob
	@Column(name="crl_note_tx", columnDefinition = "clob")
	private String crlNoteText;
	
	@Lob
	@Column(name="crl_warning_tx", columnDefinition = "clob")
	private String crlWarningText;
	
	@Lob
	@Column(name="crl_definition_tx", columnDefinition = "clob")
	private String crlDefinitionText;

	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	
	@NotNull
	@OneToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "source_proposal_id", referencedColumnName = "change_proposal_id", updatable = false, insertable = false)
	private ChangeProposal sourceProjectChangeProposal;

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "other_proposal_id", referencedColumnName = "change_proposal_id", updatable = false, insertable = false)
	private ChangeProposal otherProjectChangeProposal;

	@Override
	public int compareTo(CrptOtherProjectCrl o) {
		return new CompareToBuilder().append(this.getSourceProposalId(), o.getSourceProposalId())
		.append(this.getSourceSymbolTx(), o.getSourceSymbolTx())
		.append(this.getSourceCrlSymbolTx(), o.getSourceCrlSymbolTx()).toComparison();
	}

	@Override
	public String toString() {
		return "CrptOtherProjectCrl [guid=" + guid + ", sourceProposalId=" + sourceProposalId + ", sourceProposalGuidId="
				+ sourceProposalGuidId + ", sourceProjectCd=" + sourceProjectCd + ", sourceSymbolTx=" + sourceSymbolTx
				+ ", sourceCrlSymbolTx=" + sourceCrlSymbolTx + ", versionSymbolGuid=" + versionSymbolGuid
				+ ", otherProposalId=" + otherProposalId + ", otherProposalGuidId=" + otherProposalGuidId
				+ ", otherProjectCd=" + otherProjectCd + ", titleChangeIndicator=" + titleChangeIndicator
				+ ", notesChangeIndicator=" + notesChangeIndicator + ", warnChangeIndicator=" + warnChangeIndicator
				+ ", definitionChangeIndicator=" + definitionChangeIndicator + ", crlTitleText=" + crlTitleText
				+ ", crlNoteText=" + crlNoteText + ", crlWarningText=" + crlWarningText + ", crlDefinitionText="
				+ crlDefinitionText + "]";
	}
}