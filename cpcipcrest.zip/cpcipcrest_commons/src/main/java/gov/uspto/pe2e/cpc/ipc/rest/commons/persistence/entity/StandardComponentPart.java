package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentPartCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;


/**
 * Entity class for Standard Note Warning Type
 * 
 *     NOTE:  This is not a pure lookup table like the other stnd_* tables.  This tables is also responsible 
 *     for storing templates.
 * 
 * @author 2020
 * @version 1.8
 * @date: 08/23/2016
 *
 */
@Entity
@Table(name = "stnd_component_part")
public class StandardComponentPart implements Serializable {
    
    
    /**
     * Allowing serialization of datamodel elements 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "component_part_id_seq")
    @SequenceGenerator(name = "component_part_id_seq", sequenceName = "component_part_id_seq", initialValue = 1,
            allocationSize = 1)
    @Column(name = "component_part_id")
    private Long id;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "component_ct")
    private ComponentCategory category;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "component_part_ct")
    private ComponentPartCategory partCategory;
    
    @Column(name = "short_description_tx")
    private String shortDescription;

    @NotNull
    @Lob
    @Column(name = "template_tx", columnDefinition = "clob")
    private String template;
   
    @Column(name = "hint_tx")
    private String hint; 
    
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;
    
    @NotNull
    @Column(name = "begin_effective_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date beginEffectiveDate; 
      
    @Column(name = "end_effective_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date endEffectiveDate;
    
    @NotNull
    @Convert(converter = YesNoConverter.class)
    @Column(name = "default_in", columnDefinition = "char(1)")
    private Boolean defaultIndicator;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }
   
    /**
     * @return the category
     */
    public ComponentCategory getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(ComponentCategory category) {
        this.category = category;
    }

    /**
     * @return the partCategory
     */
    public ComponentPartCategory getPartCategory() {
        return partCategory;
    }

    /**
     * @param partCategory the partCategory to set
     */
    public void setPartCategory(ComponentPartCategory partCategory) {
        this.partCategory = partCategory;
    }

    /**
     * @return the template
     */
    public String getTemplate() {
        return template;
    }

    /**
     * @param template the template to set
     */
    public void setTemplate(String template) {
        this.template = template;
    }

    /**
     * @return the hint
     */
    public String getHint() {
        return hint;
    }

    /**
     * @param hint the hint to set
     */
    public void setHint(String hint) {
        this.hint = hint;
    }

    /**
     * @return the beginEffectiveDate
     * @since Aug 23, 2016
     */
    public Date getBeginEffectiveDate() {
        return beginEffectiveDate;
    }

    /**
     * @param beginEffectiveDate the beginEffectiveDate to set
     * @since Aug 23, 2016
     */
    public void setBeginEffectiveDate(Date beginEffectiveDate) {
        this.beginEffectiveDate = beginEffectiveDate;
    }

    /**
     * @return the endEffectiveDate
     * @since Aug 23, 2016
     */
    public Date getEndEffectiveDate() {
        return endEffectiveDate;
    }

    /**
     * @param endEffectiveDate the endEffectiveDate to set
     * @since Aug 23, 2016
     */
    public void setEndEffectiveDate(Date endEffectiveDate) {
        this.endEffectiveDate = endEffectiveDate;
    }

    /**
     * @return the createUserId
     * @since Aug 23, 2016
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId the createUserId to set
     * @since Aug 23, 2016
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return the createTs
     * @since Aug 23, 2016
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs the createTs to set
     * @since Aug 23, 2016
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return the shortDescription
     */
    public String getShortDescription() {
        return shortDescription;
    }

    /**
     * @param shortDescription the shortDescription to set
     */
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

	/**
	 * @return the defaultIndicator
	 */
	public Boolean getDefaultIndicator() {
		return defaultIndicator;
	}

	/**
	 * @param defaultIndicator the defaultIndicator to set
	 */
	public void setDefaultIndicator(Boolean defaultIndicator) {
		this.defaultIndicator = defaultIndicator;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "StandardComponentPart [id=" + id + ", category=" + category + ", partCategory=" + partCategory
				+ ", shortDescription=" + shortDescription + ", hint=" + hint + ", createUserId=" + createUserId
				+ ", createTs=" + createTs + ", beginEffectiveDate=" + beginEffectiveDate + ", endEffectiveDate="
				+ endEffectiveDate + ", defaultIndicator=" + defaultIndicator + "]";
	}    
    
	
}
