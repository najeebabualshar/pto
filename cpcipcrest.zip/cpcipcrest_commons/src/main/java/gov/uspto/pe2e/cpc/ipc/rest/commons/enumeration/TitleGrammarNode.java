package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;
/**
 * Enum used to identify different parts of Grammar node without using string literals
 * @author 2020
 * @date Mar 30, 2017
 * @version 1.7 
 */
public enum TitleGrammarNode {
        
         TITLEPART ("titlepart"),
         UNDERLINE ("underline"),
         BOLD ("bold"),
         SUBSCRIPT ("subscript"),
         SUPERSCRIPT ("superscript"),
         ANYTEXT ("anytext"),
         ANYCHAR("anychar"), 
         CPCSPECIFICTEXT ("cpcspecifictext"),
         REFERENCETEXT ("referencetext"),
         IMAGE ("image");
         
         private String value;
         
         /**
          *  private constructor required by Enums with instantiation params
          */
         private TitleGrammarNode(String value) {
             this.value = value;
         }

         /**
          * Gets the string name associated with the enum value for use with toString() and error messages
          * @return the value
          */
         public String getValue() {
             return value;
         }
         /**
          * Identifies which node it belongs to based on string value
          * @param value
          * @return
          * @since Mar 30, 2017
          */
         public static TitleGrammarNode fromValue(String value) {
             TitleGrammarNode node = null;
             for (TitleGrammarNode item: TitleGrammarNode.values() ) {
                 if (item.getValue().equals(value)) {
                     node = item;
                     break ;
                 }
             }
             return node;
         }
         
     }
     
