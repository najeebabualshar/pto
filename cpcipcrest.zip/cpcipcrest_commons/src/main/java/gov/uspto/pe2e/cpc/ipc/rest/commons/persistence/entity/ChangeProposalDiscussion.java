package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity class for database table change_proposal_discussion
 * 
 * @author msingh4
 * @version 1.0
 * @date 09/27/2022
 *
 */

@Data
@Entity
@Table(name = "change_proposal_discussion", uniqueConstraints={ 
        @UniqueConstraint(
            name="pk_change_proposal_discussion", 
            columnNames = { "discussion_id"})        
})
public class ChangeProposalDiscussion  implements Comparable<ChangeProposalDiscussion>, Serializable {

    /**
     * Allowing serialization of data model elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "discussion_id_seq")
	@SequenceGenerator(name = "discussion_id_seq", sequenceName = "discussion_id_seq", initialValue = 1001, allocationSize = 1)
    @Column(name = "discussion_id")
    private Long id;
    
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
    
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardDiscussionTag.class)
    @JoinColumn(name = "fk_tag_cd", referencedColumnName = "tag_cd")
    private StandardDiscussionTag standardDiscussionTag;


    @Guid
    @NotNull
    @Column(name = "guid_id")
    private String discussionGuid;
    
    @NotNull
    @Column(name="discussion_order_no")
    private Long orderNum;
   
    @Column(name = "parent_discussion_id")
    private String parentDiscussionId;

    @NotNull
    @Column(name="discussion_tx")
    private String message;
    
    @NotNull
	@Convert(converter = YesNoConverter.class)
	@Column(name = "deleted_in", columnDefinition = "char(1)")
	private Boolean isDeleted;    
   
    @Column(name = "given_nm")
    private String firstName;
   
    @Column(name = "family_nm")
    private String lastName;
    
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;

	@Override
	public int compareTo(ChangeProposalDiscussion o) {
		return new CompareToBuilder().append(this.getId(), o.getId())
				.append(this.getChangeProposal().getExternalId(), o.getChangeProposal().getExternalId()).toComparison();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChangeProposalDiscussion other = (ChangeProposalDiscussion) obj;
		return Objects.equals(changeProposal, other.changeProposal) 
				&& Objects.equals(standardDiscussionTag, other.standardDiscussionTag)
				&& Objects.equals(createTs, other.createTs)
				&& Objects.equals(createUserId, other.createUserId)
				&& Objects.equals(discussionGuid, other.discussionGuid) && Objects.equals(id, other.id)
				&& Objects.equals(isDeleted, other.isDeleted) && Objects.equals(lastModifiedTs, other.lastModifiedTs)
				&& Objects.equals(lastModifiedUserId, other.lastModifiedUserId)
				&& Objects.equals(lockControl, other.lockControl) && Objects.equals(message, other.message)
				&& Objects.equals(orderNum, other.orderNum)
				&& Objects.equals(parentDiscussionId, other.parentDiscussionId);
	}

	@Override
	public int hashCode() {
		return Objects.hash(standardDiscussionTag,changeProposal, createTs, createUserId, discussionGuid, id, isDeleted, lastModifiedTs,
				lastModifiedUserId, lockControl, message, orderNum, parentDiscussionId);
	}
    
	
}
