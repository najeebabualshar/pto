package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
/**
 * US448708 - Reasons need to be delivered as a service
 * @author myoung3
 *
 */
@Data
@Entity
@Table(name = "stnd_pat_adjust_reason")
public class StandardPATAdjustReason implements Serializable{
    /**
     *  Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
 
    @Id
    @Column(name = "adjust_reason_id")
    private Long id;
     
    @Column(name = "adjust_reason_tx")
    private String reason;
    
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId;

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

}