package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table change_proposal_state
 * primary key column is fk_change_proposal_id
 * 
 * @author 2020
 * @version 1.14.0
 * @date: October 20, 2018
 *
 */
@Entity
@Table(name = "change_proposal_subclass")
public class ChangeProposalSubclass implements Comparable<ChangeProposalSubclass>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_subcls_id_seq")
    @SequenceGenerator(name = "change_proposal_subcls_id_seq", 
                  sequenceName = "change_proposal_subcls_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "change_proposal_subcls_id")
    private Long id;    

    @NotNull
    @Column(name = "subclass_cd")
    private String subclassCode;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;

    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;
    
    @SuppressWarnings("CPD-END")
    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    
    /**
     * @return Long id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

	/**
	 * @return the subclassCode
	 */
	public String getSubclassCode() {
		return subclassCode;
	}

	/**
	 * @param subclassCode the subclassCode to set
	 */
	public void setSubclassCode(String subclassCode) {
		this.subclassCode = subclassCode;
	}

	/**
     * @return ChangeProposal
     */
    public ChangeProposal getChangeProposal() {
        return changeProposal;
    }

    /**
     * @param ChangeProposal
     */
    public void setChangeProposal(ChangeProposal changeProposal) {
        this.changeProposal = changeProposal;
    }
    
    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param String
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param Date
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }


    /**
     * @return Integer lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param Integer
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }

    /**
     * Used in Hashbased collections
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 37;
		int result = 1;
		result = prime * result + ((changeProposal == null) ? 0 : changeProposal.hashCode());
		result = prime * result + ((subclassCode == null) ? 0 : subclassCode.hashCode());
		result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
		result = prime * result + ((createUserId == null) ? 0 : createUserId.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lockControl == null) ? 0 : lockControl.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {		
		boolean ret = false;
		if (obj != null)
		if (this == obj) {
			ret =true;
		} else if (ChangeProposalSubclass.class.isAssignableFrom(obj.getClass())) {
			ChangeProposalSubclass other = (ChangeProposalSubclass)obj;
			ret = new EqualsBuilder()
					.append(this.getChangeProposal(), other.getChangeProposal())
					.append(this.getSubclassCode(), other.getSubclassCode())
					.build();
					
		}
		return ret;
	}
    
    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ChangeProposalSubclass other) {
        return new CompareToBuilder().append(this.getId(), other.getId())
                .append(this.getCreateTs(), other.getCreateTs())

                .toComparison();

    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChangeProposalSubclass [id=" + id + ", changeProposal=" 
				+ ((changeProposal != null)?changeProposal.getId():"null")
				+ ", createUserId=" + createUserId + ", createTs=" + createTs + ", lockControl="
				+ lockControl + "]";
	}

}
