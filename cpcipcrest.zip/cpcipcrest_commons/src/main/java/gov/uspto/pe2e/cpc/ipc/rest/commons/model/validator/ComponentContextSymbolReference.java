package gov.uspto.pe2e.cpc.ipc.rest.commons.model.validator;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.SchemeOrganization;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.ClassSymbolNameComparator;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.CollectionScanner;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;
import jakarta.annotation.Nullable;

/**
 * Component Context Symbol Reference 
 * 
 * @author 2020
 * @date Sep 6, 2019
 * @since 1.7
 * @version 1.7
 */
public class ComponentContextSymbolReference implements Comparable<ComponentContextSymbolReference> {
	
    private SchemeOrganization orgClassifier;
	private String componentType;
	private String referencedSymbol;
	private String rowSymbol;
	private SchemeChangeType schemeChangeType;
	/**
	 * 0 based index of row in the SCT (absolute posiition in the array 0 based) for the record
	 */
	@Nullable
	private Integer sctIndex;

	public ComponentContextSymbolReference() {
		super();
	}

    public ComponentContextSymbolReference(String referencedSymbol, SchemeOrganization orgClassifier,
            String componentType, String rowSymbol, SchemeChangeType schemeChangeType, Integer sctIndex) {
        super();
        this.referencedSymbol = referencedSymbol;
        this.orgClassifier = orgClassifier;
        this.componentType = componentType;
        this.rowSymbol = rowSymbol;
        this.schemeChangeType = schemeChangeType;
        this.sctIndex = sctIndex;
    }

	/**
	 * @return the orgClassifier
	 */
	public SchemeOrganization getOrgClassifier() {
		return orgClassifier;
	}

	/**
	 * @param orgClassifier the orgClassifier to set
	 */
	public void setOrgClassifier(SchemeOrganization orgClassifier) {
		this.orgClassifier = orgClassifier;
	}

	/**
	 * @return the schemeChangeType
	 */
	public SchemeChangeType getSchemeChangeType() {
		return schemeChangeType;
	}

	/**
	 * @param schemeChangeType the schemeChangeType to set
	 */
	
	public void setSchemeChangeType(SchemeChangeType schemeChangeType) {
		this.schemeChangeType = schemeChangeType;
	}

	/**
	 * @return the componentType
	 */
	public String getComponentType() {
		return componentType;
	}

	/**
	 * @param componentType the componentType to set
	 */
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}

	/**
	 * @return the sctIndex
	 */
	public Integer getSctIndex() {
		return sctIndex;
	}

	/**
	 * @param sctIndex the sctIndex to set
	 */
	public void setSctIndex(Integer sctIndex) {
		this.sctIndex = sctIndex;
	}

	/**
	 * @return the referencedSymbol
	 */
	public String getReferencedSymbol() {
		return referencedSymbol;
	}

	/**
	 * @param referencedSymbol the referencedSymbol to set
	 */
	public void setReferencedSymbol(String referencedSymbol) {
		this.referencedSymbol = referencedSymbol;
	}

	/**
	 * @return the rowSymbol
	 */
	public String getRowSymbol() {
		return rowSymbol;
	}

	/**
	 * @param rowSymbol the rowSymbol to set
	 */
	public void setRowSymbol(String rowSymbol) {
		this.rowSymbol = rowSymbol;
	}


	
	/** 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 43;
		int result = 1;
		result = prime * result + ((componentType == null) ? 0 : componentType.hashCode());
		result = prime * result + ((orgClassifier == null) ? 0 : orgClassifier.hashCode());
		result = prime * result + ((referencedSymbol == null) ? 0 : referencedSymbol.hashCode());
		result = prime * result + ((rowSymbol == null) ? 0 : rowSymbol.hashCode());
		result = prime * result + ((schemeChangeType == null) ? 0 : schemeChangeType.hashCode());
		result = prime * result + ((sctIndex == null) ? 0 : sctIndex.hashCode());
		return result;
	}
	
	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ComponentContextSymbolReference)) {
			return false;
		}
		ComponentContextSymbolReference other = (ComponentContextSymbolReference) obj;
		return new EqualsBuilder()
				.append(this.getOrgClassifier(), other.getOrgClassifier())
				.append(this.getComponentType(), other.getComponentType())
				.append(SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(
						CollectionScanner.coalesce(this.getReferencedSymbol(), StringUtils.EMPTY)), 
						SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(
								CollectionScanner.coalesce(other.getRowSymbol(), StringUtils.EMPTY)))
				.append(SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(
						CollectionScanner.coalesce(this.getReferencedSymbol(), StringUtils.EMPTY)), 
						SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(
								CollectionScanner.coalesce(other.getRowSymbol(), StringUtils.EMPTY)))
				.append(this.getSchemeChangeType(), this.getSchemeChangeType())
				.append(this.getSctIndex(), other.getSctIndex())
				.build();
				
	}
	


	/**
	 * 
	 */
	@Override
	public int compareTo(ComponentContextSymbolReference other) {
		return new CompareToBuilder()
				.append(this.getOrgClassifier(), other.getOrgClassifier())
				.append(this.getComponentType(), other.getComponentType())
				.append(this.getReferencedSymbol(), other.getReferencedSymbol(), new ClassSymbolNameComparator())
				.append(this.getRowSymbol(), other.getRowSymbol(), new ClassSymbolNameComparator())
				.append(this.getSchemeChangeType(), this.getSchemeChangeType())
				.append(this.getSctIndex(), this.getSctIndex())
				.toComparison();
				
	}
	
	/**
     * Get Component Key
     */
	public String toKey() {
		String key = componentType;
		if (SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(referencedSymbol)
				.compareTo(SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(rowSymbol)) < 0) {
			key +=":"+SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(referencedSymbol);
			key +=":"+SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(rowSymbol);
		} else {
			key +=":"+SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(rowSymbol);
			key +=":"+SymbolName.createSortableSymbolNameAllowInvalidSymbolNames(referencedSymbol);
			
		}
		return key;
	}

}
