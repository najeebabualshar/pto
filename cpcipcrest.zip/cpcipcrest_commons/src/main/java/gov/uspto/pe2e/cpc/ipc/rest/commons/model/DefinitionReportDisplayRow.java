package gov.uspto.pe2e.cpc.ipc.rest.commons.model;

import java.util.ArrayList;
import java.util.List;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;

/**
 * Model for Export Definition Report Display Row
 * 
 * @author 2020
 * @version 1.16.0
 * @date: 03/26/2019
 *
 */
//TODO: Move this to Contract project (XSD definition)
public class DefinitionReportDisplayRow {
    
    private String changeType;
    private String subclass;
    private List<RevisionChangeItem> revisionChangeItems;
    
    /**
     * @return String changeType
     */
    public String getChangeType() {
        return changeType;
    }
    
    /**
     * @param changeType
     */
    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }
    
    /**
     * @return String subclass
     */
    public String getSubclass() {
        return subclass;
    }
    
    /**
     * @param subclass
     */
    public void setSubclass(String subclass) {
        this.subclass = subclass;
    }
    
    /**
     * @return List<RevisionChangeItem> revisionChangeItems
     */
    public List<RevisionChangeItem> getRevisionChangeItems() {
        if (revisionChangeItems == null) {
            revisionChangeItems = new ArrayList<>();
        }
        return this.revisionChangeItems;
    }
    
    /**
     * @param revisionChangeItems
     */
    public void setRevisionChangeItems(List<RevisionChangeItem> revisionChangeItems) {       
        this.revisionChangeItems = revisionChangeItems;
    }

}
