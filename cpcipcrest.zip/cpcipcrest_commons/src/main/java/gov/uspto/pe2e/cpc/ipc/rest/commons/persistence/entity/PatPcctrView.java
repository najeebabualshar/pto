package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * PAT_PCCTR_V
 * 
 * @author myoung3
 *
 */
@Entity
@Table(name = "pat_pcctr_v")
@Data
public class PatPcctrView {
	

	@Id
	@Column(name ="guid_id")
	@Guid
	private String id; // This is the db guid format
	
	/**
	 * cfk stands for "cross-functional key".  
	 * this is EDAD nomenclature for a natural key shared across systems 
	 */
	@Column(name ="cfk_pc_nm") 
	private String pcEmail;
	
	@Column(name ="pc_first_nm")
	private String pcFirstName;  

	@Column(name ="pc_last_nm")
	private String pcLastName;  
	
	@Column(name ="art_unit_cd")
	private String artUnitCode;  
	
	@Column(name ="employee_id")
	private String employeeId;
	
	@Column(name ="pay_period_id")
	private Long payPeriodId;	
	
	@Column(name ="pay_period_begin_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date payPeriodBegin;	
	
	@Column(name ="pay_period_end_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date payPeriodEnd;	

	@Column(name ="pay_period_qtr_cd")
	private String payPeriodQuarterCode;   

	@Column(name ="pay_period_fy_no")
	private Long payPeriodFiscalYear;   
	
	@Column(name ="change_proposal_id")
	private Long changeProposalId; 
	
	@Column(name ="change_proposal_guid_id")
	@NotNull
	@Guid
	private String changeProposalExternalId; 

	@Column(name ="change_proposal_alias_cd")
	private String changeProposalAlias;  
	
	@Column(name ="project_type_cd")
	private String projectTypeCode;  

	@Column(name ="project_source_cd")
	private String projectSourceCode;  
	
	/**
	 * this is called task_definition_id but this is not correct.  This is actually the 
	 * task Definition key!  the difference is, the id is assigned when the record is 
	 * persisted for the first time.  whereas, the key is known to the business before they
	 * even have the task defined and submitted for implementation
	 */
	@Column(name ="task_definition_id")
	private String taskDefinitionKey; // Ex: BAT01, PBT05  

	
	@Column(name ="pap_task_cd")
	private String papTaskCode;  

	
	@Column(name ="proposal_phase_cd")
	private String proposalPhaseCode;  
	
//	ACTION_TX	VARCHAR2(20)
	@Column(name ="action_tx")
	private String action;  
	
	@Column(name ="no_of_repeats_no")
	private Integer numberOfRepeats;  

	@Column(name ="task_submitted_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date taskSubmitted;  
	
	

	/**
	 * This is the number (1, 2, 3, etc) of the revision within the proposal
	 */
	@Column(name ="sdct_version_id")
	private Integer sctVersionId; 
	
	@Column(name ="change_proposal_ver_guid_id")
	@Guid
	private String changeProposalVersionExternalId; 
		
	@Column(name ="symbol_count_no")
	private Integer symbolCount;	
	
	@Column(name ="symbol_attribute_hr_no")
	private Integer symbolAttributeHour;	
	
	@Column(name ="definition_count_no")
	private Integer definitionCount;	
	
	@Column(name ="definition_attribute_hr_no")
	private Integer definitionAttributeHour;	
	
	@Column(name ="family_count_no")
	private Integer familyCount;	
	
	@Column(name ="family_count_attribute_hr_no")
	private Integer familyCountAttributeHour;	
	
	@Column(name ="twl_doc_count_no")
	private Integer twlDocumentCount;	

	@Column(name ="twl_attribute_hr_no")
	private Integer twlAttributeHour;	

	@Column(name ="total_attribute_hr_no")
	private Integer totalAttributeHour;	
	
	@Column(name ="project_type_hr_no")
	private Integer projectTypeHour;	
	
	@Column(name ="repeat_adj_factor_no", scale = 2, precision=10)
	private BigDecimal repeatAdjustmentFactor;	

	@Column(name ="repeat_adj_proj_type_hr_no", scale = 2, precision=10)
	private BigDecimal repeatAdjustmentProjectTypeHour;

	@Column(name ="base_hr_no", scale = 2, precision=10)
	private BigDecimal baseHour;
	
	@Column(name ="addtl_adj_hrs_no", scale = 2, precision=10)
	private BigDecimal additionalAdjustmentHours;
	
	@Column(name ="credit_prod_hrs_no", scale = 2, precision=10)
	private BigDecimal creditProductionHours;
	

}
