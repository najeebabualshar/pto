/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.commons.error;

/**
 * @author Maximus
 * @date Nov 02,2021
 */
public class ExternalServiceException extends Exception {

	
	private static final long serialVersionUID = 1L;

	public ExternalServiceException() {
		super();
	}

	public ExternalServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);		
	}

	public ExternalServiceException(String message, Throwable cause) {
		super(message, cause);		
	}

	public ExternalServiceException(String message) {
		super(message);		
	}

	public ExternalServiceException(Throwable cause) {
		super(cause);		
	}
}
