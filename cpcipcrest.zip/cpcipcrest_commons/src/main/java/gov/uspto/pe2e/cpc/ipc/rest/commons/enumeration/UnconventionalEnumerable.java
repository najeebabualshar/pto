package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * This Interface provides the most basic functionality of for allowing the
 * non-JAVA compatible enums to be used by instantiating an enum with the string
 * and using that string as the result of getValue(). non-java enumerable
 * strings are not trimmed, chopped or CASE-insensitve
 * 
 * @author myoung3
 * @date Nov 22, 2019
 * @since 0.0.1
 * @version 0.0.1
 */
public interface UnconventionalEnumerable {
    /**
     * This is the value that SHOULD BE unique for a given enum but it is not
     * constrained in any way 
     * 
     * WARNING: it is on YOU to ensure the value strings are
     * not dup'd on enums
     * 
     * @return String -  Unconventional (NON-JAVA) string to be treated as Unique
     */
    String getValue();

}
