package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalOfficeRoleCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table change_proposal_office
 * primary key column is change_proposal_office_id
 *
 * @author 2020
 * @version 1.11.0
 * @date: 04/05/2018
 *
 */
@Entity
@Table(name = "change_proposal_office", uniqueConstraints = { @UniqueConstraint(columnNames = {
        "change_proposal_office_id", "fk_change_proposal_id", "fk_ipo_cd", "office_role_ct" }) })
public class ChangeProposalOffice implements Comparable<ChangeProposalOffice>, Serializable {

    /**
     * Allowing serialization of datamodel elements 
     */
    private static final long serialVersionUID = 1L;
    

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_office_id_seq")
    @SequenceGenerator(name = "change_proposal_office_id_seq", sequenceName = "change_proposal_office_id_seq", allocationSize = 1)
    @Column(name = "change_proposal_office_id")
    private Long id;
    
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "office_role_ct")
    private ProposalOfficeRoleCategory proposalOfficeRoleCategory; 
    
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
    
    @NotNull
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardIpOffice.class)
//    @JoinColumn(name = "fk_ipo_cd", referencedColumnName = "ipo_cd")

    @Enumerated(EnumType.STRING)
    @Column(name = "fk_ipo_cd")
    private StandardIpOfficeCode standardIpOfficeCode;

    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")

    /**
     * @return Long id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }
    
    /**
     * @return proposalOfficeRoleCategory
     */
    public ProposalOfficeRoleCategory getProposalOfficeRoleCategory() {
        return proposalOfficeRoleCategory;
    }
    
    /**
     * @param proposalOfficeRoleCategory
     */
    public void setProposalOfficeRoleCategory(ProposalOfficeRoleCategory proposalOfficeRoleCategory) {
        this.proposalOfficeRoleCategory = proposalOfficeRoleCategory;
    }
    
    /**
     * @return StandardIpOffice
     */
    public StandardIpOfficeCode getStandardIpOfficeCode() {
        return standardIpOfficeCode;
    }
    
    /**
     * @param standardIpOffice
     */
    public void setStandardIpOfficeCode(StandardIpOfficeCode standardIpOffice) {
        this.standardIpOfficeCode = standardIpOffice;
    }

    /**
     * @return ChangeProposal changeProposal
     */
    public ChangeProposal getChangeProposal() {
        return changeProposal;
    }

    /**
     * @param changeProposal
     */
    public void setChangeProposal(ChangeProposal changeProposal) {
        this.changeProposal = changeProposal;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return String lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return Date lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @return Integer lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ChangeProposalOffice other) {
        return new CompareToBuilder().append(this.getId(), other.getId())
        		.append(this.getChangeProposal()
                .getExternalId(), other.getChangeProposal().getExternalId())
        		.append(this.getStandardIpOfficeCode(), other.getStandardIpOfficeCode())
        		.append(this.getProposalOfficeRoleCategory(), other.getProposalOfficeRoleCategory()).toComparison();
    }
    
    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret;
        
        if (obj == null || !(obj instanceof ChangeProposalOffice)) {
            ret = false;
        } else if (ChangeProposalOffice.class.isAssignableFrom(obj.getClass()) && obj == this) {
            ret = true;
        } else {
        	ChangeProposalOffice thatObj = (ChangeProposalOffice) obj;
        	
        	String meProposalCode = this.getChangeProposal().getExternalId();
        	String thatProposalCode = thatObj.getChangeProposal().getExternalId();
        	
            Long meId = this.getId();
            Long thatId = thatObj.getId();   
            
            ProposalOfficeRoleCategory meRoleCt = this.getProposalOfficeRoleCategory();
            ProposalOfficeRoleCategory thatRoleCt = thatObj.getProposalOfficeRoleCategory();
            
            StandardIpOfficeCode meIpOffice = this.getStandardIpOfficeCode();
            StandardIpOfficeCode thatIpOffice = thatObj.getStandardIpOfficeCode();
            
            String meExId = this.getChangeProposal().getExternalId();
            String thatExId = thatObj.getChangeProposal().getExternalId();
            
            ret = meProposalCode.equals(thatProposalCode) && Objects.equals(meId,thatId) && meRoleCt.equals(thatRoleCt) && meIpOffice.equals(thatIpOffice) && meExId.equals(thatExId);
        }
        return ret;
    }

    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
    	
    	return Objects.hash(this.getChangeProposal().getExternalId(), this.getProposalOfficeRoleCategory(), this.getStandardIpOfficeCode());

        
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ChangeProposalVersion [id=" + id + ", changeProposal=" + ((changeProposal != null) ? changeProposal.getId()
                : "null")
                +", proposerOfficeRoleCategory="+proposalOfficeRoleCategory
                +", standardIpOfficeCode="+standardIpOfficeCode                
                + ", createUserId="
                + createUserId + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId
                + ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + "]";
    }

}
