package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DocumentPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentVersionClassificationCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationPhase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Publication Detail View for Global Publication List Module
 * @author msingh4
 * @date: 09/22/2022
 *
 */
@Entity
@Table(name = "publication_dtl_v")
@Data
public class PublicationDetailView implements Comparable<PublicationDetailView>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

    @NotNull
	@ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
	private ChangeProposal changeProposal;
	
    @NotNull
    @Column(name = "change_proposal_alias_cd", length=20)
    private String changeProposalAliasCd;
	
	@Column(name = "project_type_ct")
	private String projectType; 

    @Id
	@Column(name = "change_proposal_doc_id")
	private Long changeProposalDocId;

//	@Id
//	@Column(name = "fk_change_proposal_id", updatable = false, insertable = false)
//	private Long id;

	@Guid
	@NotNull
	@Column(name = "change_proposal_doc_guid_id")
	private String docExternalId;

	@Column(name = "anx_no")
	private Integer anxNum;

	@Column(name = "document_nm")
	private String docName;
	
	@NotNull
	@Column(name = "document_id") // Also known as a resource path in S3
	private String resourceId;  
	
    @Enumerated(EnumType.STRING)
    @Column(name = "doc_type_cd")
    private ProposalDocumentTypeCode typeCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "doc_version_cd")
    private ProposalDocumentVersionClassificationCode docVersionCode;

    @Column(name = "upload_comment_tx", length = 4000)
    private String uploadComment; // VARCHAR2(500)    
                              
    @Enumerated(EnumType.STRING)
    @Column(name = "doc_phase_ct")
    private DocumentPhase docPhase;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "pub_phase_ct")
    private PublicationPhase pubPhase;
    
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;
    
    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "ipo_cd")
    private StandardIpOfficeCode standardIpOfficeCode;
    
    @Column(name = "uspc_approval_in", columnDefinition = "char(1)")
    private String uspcApproval; 
    
    @Column(name = "eppc_approval_in", columnDefinition = "char(1)")
    private String eppcApproval; 
    
    @Column(name = "useb_approval_in", columnDefinition = "char(1)")
    private String usebApproval; 
    
    @Column(name = "epeb_approval_in", columnDefinition = "char(1)")
    private String epebApproval; 
    
    @Column(name = "uspub_mgr_approval_in", columnDefinition = "char(1)")
    private String uspubApproval; 
    
    @Column(name = "pub_writer_editor_nm")
    private String pubWriterEditor; 
    
    @Column(name = "pub_specialist_nm")
    private String pubSpecialist; 
    
    @Column(name = "pi_pub_dt")
    private String piPubDate; 
    
    @Column(name = "pf_pub_dt")
    private String pfPubDate; 
    
    @Column(name = "scheme_release_month_tx")
//    @Temporal(TemporalType.TIMESTAMP)
//    @DateTimeFormat(pattern = "yyyy-MM")
    private String schemeReleaseMonth; 

	@Override
	public int compareTo(PublicationDetailView o) {
		return new CompareToBuilder().append(this.changeProposal, o.changeProposal)
				.append(this.docExternalId, o.docExternalId).toComparison();
	}

	@Override
	public String toString() {
		return "PublicationDetailView [changeProposalAliasCd=" + changeProposalAliasCd + ", projectType=" + projectType
				+ ", changeProposalDocId=" + changeProposalDocId + ", docExternalId=" + docExternalId + ", anxNum="
				+ anxNum + ", docName=" + docName + ", resourceId=" + resourceId + ", typeCode=" + typeCode
				+ ", docVersionCode=" + docVersionCode + ", uploadComment=" + uploadComment + ", docPhase=" + docPhase
				+ ", pubPhase=" + pubPhase + ", createTs=" + createTs + ", uspcApproval=" + uspcApproval
				+ ", eppcApproval=" + eppcApproval + ", usebApproval=" + usebApproval + ", epebApproval=" + epebApproval
				+ ", uspubApproval=" + uspubApproval + ", pubWriterEditor=" + pubWriterEditor + ", pubSpecialist="
				+ pubSpecialist + ", piPubDate=" + piPubDate + ", pfPubDate=" + pfPubDate + ", schemeReleaseMonth="
				+ schemeReleaseMonth + "]";
	}

}
