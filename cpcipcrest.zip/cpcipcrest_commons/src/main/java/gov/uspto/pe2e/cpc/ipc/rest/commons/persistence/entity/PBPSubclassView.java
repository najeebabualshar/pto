package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.hibernate.type.YesNoConverter;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExternalSystemCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalTypeCode;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * PBP Subclass View for Push Button Publication
 * @author msingh4
 * @date: 08/08/2023
 *
 */
@Entity
@Table(name = "pbp_subclass_view_v")
@Data
public class PBPSubclassView implements Comparable<PBPSubclassView>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;
	
    @Id
	@Column(name = "subcalss_view_id")
	private Long id;

    @NotNull
	@ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
	@JoinColumn(name = "change_proposal_id", referencedColumnName = "change_proposal_id", insertable = false, updatable = false)
	private ChangeProposal changeProposal;
    
    @Column(name = "change_proposal_id")
	private Long changeProposalId;
	
    @NotNull
    @Column(name = "change_proposal_alias_cd", length=20)
    private String changeProposalAliasCd;
    
    @Guid
	@NotNull
	@Column(name = "change_proposal_guid_id")
	private String changeProposalGuidId;
	
    @Enumerated(EnumType.STRING)
	@Column(name = "project_type_ct")
	private ProposalTypeCode projectType; 
	
    //View has string value coming from PD form
	@Column(name = "project_source_cd")
	private String projectSource; 
	
    @Enumerated(EnumType.STRING)
	@Column(name = "source_system_ct")
	private ExternalSystemCategory sourceSystem; 
	
    @Enumerated(EnumType.STRING)
	@Column(name = "proposal_phase_tx")
	private ProposalPhase proposalPhase; 
	
	@Column(name = "ipc_tech_tx")
	private String ipcTechnology; 
	
	@Column(name = "us_tech_tx")
	private String usTechnology;
	
	@Column(name = "ep_tech_tx")
	private String epTechnology;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "rapp_office_cd")
	private StandardIpOfficeCode rappOffice;
	
	@Column(name = "us_pc_nm")
	private String usPc;
	
	@Column(name = "ep_pc_nm")
	private String epPc;
	
	@Column(name = "us_sce_nm")
	private String usSce;
	
	@Column(name = "us_backup_sce_nm")
	private String usBackupSce;
	
	@Column(name = "us_backup_sce2_nm")
	private String usBackupSce2;
	
	@Column(name = "us_backup_sce3_nm")
	private String usBackupSce3;
	
	@Column(name = "us_eb_nm")
	private String usEb;
	
	@Column(name = "ep_eb_nm")
	private String epEb;
	
	@Column(name = "us_scespe_nm")
	private String usSceSpe;
	
	@Column(name = "us_spc_nm")
	private String usSpc;
	
	@Column(name = "ep_qn_nm")
	private String epQn;
	
	@Column(name = "ep_gerant_nm")
	private String epGerant;
	
	@Column(name = "ep_cpbm_nm")
	private String epCpbm;
	
	@Column(name = "us_reclass_mgr_nm")
	private String usReclassManager;
	
	@Column(name = "ep_reclass_mgr_nm")
	private String epReclassManager;
	
	@Column(name = "pub_writer_editor_nm")
	private String pubWriterEditor;
	
	@Column(name = "pub_specialist_nm")
	private String pubSpecialist;
	
	@Column(name = "pub_mgr_nm")
	private String pubManager;
	
	@Column(name = "spe_qn_nm")
	private String speQnName;
	
	@Column(name = "examiner_qn_nm")
	private String examinerQnName;
	
	@Column(name = "examiner_qn1_nm")
	private String examinerQnName1;
	
	@Column(name = "examiner_qn2_nm")
	private String examinerQnName2;
    
    @Column(name = "subclass_cd")
	private String subclassCd;
    
    @Column(name = "section_cd")
   	private String sectionCd;
    
    @Column(name = "version_id")
   	private Long versionId;
    
    @Guid
	@NotNull
	@Column(name = "version_symbol_guid_id")
	private String versionSymbolGuidId;
    
   	@NotNull
   	@Column(name = "sort_order_no")
   	private Long sortOrder;
    
    @Column(name = "entry_type_cd", columnDefinition = "char(1)")
   	private String entryType;
    
    @Column(name = "full_symbol_tx")
   	private String fullSymbol;

	@Lob
	@Column(name="new_title_tx", columnDefinition = "clob")
	private String newTitle;
	
	@Lob
	@Column(name="new_note_tx", columnDefinition = "clob")
	private String newNote;
	
	@Lob
	@Column(name="new_warning_tx", columnDefinition = "clob")
	private String newWarning;
	
	@Lob
	@Column(name="new_definition_tx", columnDefinition = "clob")
	private String newDefinition;
    
    @Column(name = "scheme_release_dt")
    @Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date schemeReleaseDate;
    
    @Column(name="scheme_version_tx")
	private String schemeVersion;
 
    @Column(name="main_group_cd")
    private String mainGroupCd;
 
	@Convert(converter = YesNoConverter.class)
	@Column(name = "scheme_change_in", columnDefinition = "char(1)")
	private Boolean schemeChangeIndicator;
    
	@Convert(converter = YesNoConverter.class)
	@Column(name = "definition_change_in", columnDefinition = "char(1)")
	private Boolean definitionChangeIndicator;
 	  
	@Override
	public int compareTo(PBPSubclassView o) {
		return new CompareToBuilder().append(this.getSubclassCd(), o.getSubclassCd()).toComparison();
	}

	@Override
	public String toString() {
		return "PBPSubclassView [id=" + id + ", changeProposalId=" + changeProposalId + ", changeProposalAliasCd="
				+ changeProposalAliasCd + ", changeProposalGuidId=" + changeProposalGuidId + ", projectType="
				+ projectType + ", projectSource=" + projectSource + ", sourceSystem=" + sourceSystem
				+ ", proposalPhase=" + proposalPhase + ", ipcTechnology=" + ipcTechnology + ", usTechnology="
				+ usTechnology + ", epTechnology=" + epTechnology + ", rappOffice=" + rappOffice + ", usPc=" + usPc
				+ ", epPc=" + epPc + ", usSce=" + usSce + ", usBackupSce=" + usBackupSce + ", usBackupSce2="
				+ usBackupSce2 + ", usBackupSce3=" + usBackupSce3 + ", usEb=" + usEb + ", epEb=" + epEb + ", usSceSpe="
				+ usSceSpe + ", usSpc=" + usSpc + ", epQn=" + epQn + ", epGerant=" + epGerant + ", epCpbm=" + epCpbm
				+ ", usReclassManager=" + usReclassManager + ", epReclassManager=" + epReclassManager
				+ ", pubWriterEditor=" + pubWriterEditor + ", pubSpecialist=" + pubSpecialist + ", pubManager="
				+ pubManager + ", speQnName=" + speQnName + ", examinerQnName=" + examinerQnName + ", examinerQnName1="
				+ examinerQnName1 + ", examinerQnName2=" + examinerQnName2 + ", subclassCd=" + subclassCd
				+ ", sectionCd=" + sectionCd + ", versionId=" + versionId + ", versionSymbolGuidId="
				+ versionSymbolGuidId + ", sortOrder=" + sortOrder + ", entryType=" + entryType + ", fullSymbol="
				+ fullSymbol + ", newTitle=" + newTitle + ", newNote=" + newNote + ", newWarning=" + newWarning
				+ ", newDefinition=" + newDefinition + ", schemeReleaseDate=" + schemeReleaseDate + ", schemeVersion="
				+ schemeVersion + ", mainGroupCd=" + mainGroupCd + ", schemeChangeIndicator=" + schemeChangeIndicator
				+ ", definitionChangeIndicator=" + definitionChangeIndicator + "]";
	}

	
}
