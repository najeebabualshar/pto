package gov.uspto.pe2e.cpc.ipc.rest.commons.model;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import jakarta.annotation.Nonnull;

/**
 * US4295 - Scheme Navigator - CPC Titles - Full - DATA & SERVICES Simple ID
 * class for use with spring application converters
 * 
 * @author 2020
 * @version 1.0
 * @date: 08/4/2015
 *
 */
public class SymbolName implements Serializable {
    
    private static final Logger log = LoggerFactory.getLogger(SymbolName.class);

    /**
     * This description is used by annotations for documentation purposes.
     * Because this string needs to be initialized before the class is
     * initialized and because Swagger does not support properties files for
     * these strings, We have to initialize them as static final variable or we
     * are forced to copy string literals into each annotation.
     */
    public static final String API_DESCRIPTION = "Symbol Name (AKA Classification Symbol Code)"
            + "\nNote: If the symbol contains a slash, the slash must be URL encoded as \"%252F\"";
    
    public static final String Y_SERIES_PREFIX = "Y";

    public static final String SLASH = "/";
    public static final String SUBGROUP_FOR_MAINGROUP_IDENT_VALUE = "00";

    public static final String SYMBOL_FIELDS_CAPTURE_REGEX = 
                            "^([A-H,Y])(\\d{2}){0,1}([A-Z]){0,1}(\\d+){0,1}(\\/){0,1}(\\d+){0,1}$";

    // Regular Expression =
    // ^([A-H,Y])?([0-9][1-9]|[1-9][0-9])?([A-HJ-NP-Z]){0,1}?$
    public static final String SYMBOL_SUBCLASS_REGEX = 
                            "^([A-H,Y])([0-9][1-9]|[1-9][0-9])?([A-HJ-NP-Z]){0,1}?$";

	public static final int SUBGROUP_START_IDX = 5;

    // Regular Expressio =
    // ^[A-H,Y]?([0-9][1-9]|[1-9][0-9])?([A-HJ-NP-Z])+([1-9][0-9]{0,2}|[1-9][0-9]{2}|[0-9]{2}[1-9])+(\/)+([0-9]{2,6})$
    // ^[A-H,Y]([0-9][1-9]|[1-9][0-9])([A-HJ-NP-Z])([1-9][0-9]{0,3}|[1-9][0-9]{3}|[0-9]{2}[1-9])(\/)([0-9]{2,6})$
    private static final String FULL_SYMBOL_REGEX = 
            "^[A-H,Y]([0-9][1-9]|[1-9][0-9])([A-HJ-NP-Z])(\\s*[1-9][0-9]{0,3}|[1-9][0-9]{3}|[0-9]{2}[1-9])(/)([0-9]{2,6})$";

    private static final long serialVersionUID = 1L;

    private static final Integer FOUR = 4;
    private static final Integer TWO = 2;
    private static final Integer ZERO = 0;
    private static final Integer TWO_THOUSAND = 2000;
    private static final Integer ONE = 1;

    private String classificationSymbolCd;

    /**
     * Default Constructor
     */
    public SymbolName() {
        super();
    }

    /**
     * Parameterized Constructor for SchemeHierarchyId Class
     * 
     * @param classificationSymbolCd
     */
    public SymbolName(String classificationSymbolCd) {
        super();
        this.classificationSymbolCd = classificationSymbolCd;
    }

    /**
     * @return String ClassificationSymbolCd
     */
    public String getClassificationSymbolCd() {
        return classificationSymbolCd;
    }

    /**
     * Provide standardized utility method for converting Symbol name into
     * Section name. Come back and change this to Use REGEX so the individual
     * parts can be extracted (not just section) symbol name
     * 
     * @param symbolName
     * @return
     */
    public String getSection() {
        return getSubField(SymbolNameSubfield.SECTION);
    }

    /**
     * @return String - Symbol Class
     */
    public String getSymbolClass() {
        return getSubField(SymbolNameSubfield.CLASS);
    }

    /**
     * @return String - Sub Class
     */
    public String getSubClass() {
        return getSubField(SymbolNameSubfield.SUBCLASS);
    }

    /**
     * @return String - Main Group
     */
    public String getMainGroup() {
        return getSubField(SymbolNameSubfield.MAINGROUP);
    }

    /**
     * @return String - Sub Group
     */
    public String getSubGroup() {
        return getSubField(SymbolNameSubfield.SUBGROUP);
    }

    /**
     * @param classificationSymbolCode
     * @return SymbolName
     */
    public static SymbolName parse(String classificationSymbolCode) {
        SymbolName sn = new SymbolName(normalize(classificationSymbolCode));
        return sn;
    }

    /**
     * Does common work of matching and capturing using regex
     * 
     * @param fld
     * @return subfld
     */
    private String getSubField(SymbolNameSubfield fld) {
        String subfld = null;
        if (classificationSymbolCd != null) {
            Pattern parser = Pattern.compile(SYMBOL_FIELDS_CAPTURE_REGEX);
            Matcher m = parser.matcher(classificationSymbolCd);
            if (m.matches()) {
                subfld = m.group(fld.ordinal() + 1); // offset because index 0
                                                     // captures whole
                                                     // matching string
            }
        }
        return subfld;
    }

    /**
     * Checks to see if the symbol matches the expected regex
     * 
     * @return isValid
     */
    public boolean isValidSymbol() {
        boolean isValid = false;
        if (StringUtils.isNotEmpty(classificationSymbolCd)) {
            Pattern parser = Pattern.compile(SYMBOL_FIELDS_CAPTURE_REGEX);
            Matcher m = parser.matcher(classificationSymbolCd);
            if (m.matches()) {
                isValid = true;
            }
        }
        return isValid;
    }
    
    public boolean isYSeriesOrTwoThousandSeries() {
    	return isValidSymbol() && (isYSeries() || isThis2000SeriesSymbol());
    }

    /**
     * Checks to see if the CPC symbol matches the expected regex. Per Virginia,
     * regex for CPC is different from Reclass/Reference symbols.
     * 
     * @return boolean
     */
    public boolean isValidCpcSymbol() {

        boolean isValidCpcSymbol = false;
        if (classificationSymbolCd != null && StringUtils.countMatches(classificationSymbolCd, SLASH) > ONE) {
            isValidCpcSymbol = false;
        } else if (classificationSymbolCd != null && classificationSymbolCd.contains(SLASH)) {
            isValidCpcSymbol = isCpcSymbolAtMainGroupOrSubGroupLevel();
        } else if (classificationSymbolCd != null && !classificationSymbolCd.contains(SLASH)) {
            isValidCpcSymbol = isCpcSymbolAtSubClassLevel();
        }
        return isValidCpcSymbol;
    }

    /**
     * Checks if the CPC symbol is at subclass level or not
     * 
     * @return boolean
     */
    public boolean isCpcSymbolAtSubClassLevel() {

        boolean isCpcSymbolAtSubClassLevel = false;
        if (StringUtils.isNotEmpty(classificationSymbolCd)  && !classificationSymbolCd.contains(SLASH)) {
            Pattern parser = Pattern.compile(SYMBOL_SUBCLASS_REGEX);
            Matcher m = parser.matcher(classificationSymbolCd);
            if (m.matches()) {
                isCpcSymbolAtSubClassLevel = true;
            }
        }
        return isCpcSymbolAtSubClassLevel;
    }

    /**
     * Checks if the CPC symbol is at Main group level or at sub group level
     * 
     * @return boolean
     */
    public boolean isCpcSymbolAtMainGroupOrSubGroupLevel() {

        boolean isCpcSymbolAtMainGroupOrSubGroupLevel = false;
        if (classificationSymbolCd != null && classificationSymbolCd.contains(SLASH)) {
            Pattern parser = Pattern.compile(FULL_SYMBOL_REGEX);
            Matcher m = parser.matcher(classificationSymbolCd);
            if (m.matches()) {
                String[] parts = classificationSymbolCd.split(SLASH);
                String symbolWithMainGroup = parts[ZERO];
                String mainGroup = symbolWithMainGroup.substring(FOUR);
                int sortKeyNumber = Integer.parseInt(mainGroup.trim()) - TWO_THOUSAND;
                String subGroup = parts[ONE];

                // 2000 is not allowed.
                if (sortKeyNumber != ZERO) {
                    isCpcSymbolAtMainGroupOrSubGroupLevel = true;
                }
                // For subgroup portion, cannot have ending 0 except
                // if there are only two digits (e.g. H01L1/20 or for main
                // groups B65D3/00)
                // Group part can be 1-3 digits (no left padded zeros)
                if ((subGroup.length() > TWO && subGroup.endsWith(ZERO.toString()))
                        || (mainGroup.length() > ZERO && mainGroup.startsWith(ZERO.toString()))
                        || (mainGroup.length() == FOUR && !mainGroup.startsWith(TWO.toString()))) {
                    isCpcSymbolAtMainGroupOrSubGroupLevel = false;
                }

            }
        }
        return isCpcSymbolAtMainGroupOrSubGroupLevel;
    }

    /**
     * Identify sort key number
     * 
     * @param classificationSymbolCd
     * @return Integer
     */
    private Integer identifySortKeyNumber(String classificationSymbolCd) {
        String[] parts = classificationSymbolCd.split(SLASH);
        String symbolWithMainGroup = parts[ZERO];
        String mainGroup = symbolWithMainGroup.substring(FOUR);
        return Integer.parseInt(mainGroup) - TWO_THOUSAND;

    }

    /**
     * Gets sort key for the given symbol
     * 
     * @return sortKey
     */
    public String getSortKey() {
        String sortKey = null;
        if (this.isValidCpcSymbol()) {
            sortKey = classificationSymbolCd;
            if (this.isThis2000SeriesSymbol()) {

                String[] parts = classificationSymbolCd.split(SLASH);
                String symbolWithMainGroup = parts[ZERO];
                String subGroup = parts[ONE];
                String mainGroup = symbolWithMainGroup.substring(FOUR);
                int sortKeyNumber = Integer.parseInt(mainGroup) - TWO_THOUSAND;
                // full symbol = Concatenate Subclass + sort key + forward slash
                // + sub group
                sortKey = symbolWithMainGroup.substring(ZERO, FOUR).concat(Integer.toString(sortKeyNumber))
                        .concat(SLASH).concat(subGroup);
            }
        }
        return sortKey;
    }

    /**
     * Finds out if the given symbol is 2000 series
     * 
     * @return boolean
     */
    public boolean isThis2000SeriesSymbol() {

        boolean isThis2000SeriesSymbol = false;

        if (classificationSymbolCd != null && classificationSymbolCd.contains(SLASH)) {
            Pattern parser = Pattern.compile(FULL_SYMBOL_REGEX);
            Matcher m = parser.matcher(classificationSymbolCd);
            if (m.matches()) {
                int sortKeyNumber = identifySortKeyNumber(classificationSymbolCd);
                if (sortKeyNumber > ZERO) {
                    isThis2000SeriesSymbol = true;
                }
            }
        }
        return isThis2000SeriesSymbol;
    }
    /**
     * Finds out if the given symbol is 2000 series
     * 
     * @return boolean
     */
    public boolean isYSeries() {
    	return StringUtils.startsWith(classificationSymbolCd, Y_SERIES_PREFIX);
    }

    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((classificationSymbolCd == null) ? 0 : classificationSymbolCd.hashCode());
        return result;
    }

    /**
     * Executes equals by testing each field of the symbol name
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        boolean eq = Boolean.FALSE;
        if(obj == null || !(obj instanceof SymbolName)) {
        	return eq;
        } else if (this.getClass().isAssignableFrom(obj.getClass())) {
            SymbolName that = (SymbolName) obj;
            eq = new EqualsBuilder().append(SymbolName.createSortableSymbolName(this.getClassificationSymbolCd()),
                    SymbolName.createSortableSymbolName(that.getClassificationSymbolCd())).build();
        }
        return eq;
    }

    /**
     * Formats the the symbol name in sortable format!!!!
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return SymbolName.createSortableSymbolName(this.getClassificationSymbolCd());
    }

    /**
     * This method does the heavy lifting of taking symbol names from different
     * parts of the tree and constructing string representations that are
     * alphabetically sortable
     * 
     * Samples: A01B35/06 becomes "A01B 35/000000006" A becomes "A " A01N becomes
     * "A01N "
     * TODO: Come back and lower the Cyclomatic complexity on this method
     * @param symbolName
     * @return
     */
    public static String createSortableSymbolName(String symbolName) {
        
        String ret = StringUtils.EMPTY;
        if(StringUtils.isNotEmpty(symbolName)) {
        	symbolName = normalize(symbolName);
            String section = StringUtils.substring(symbolName, SymbolNameSubfield.SECTION.getBegin(),
                    SymbolNameSubfield.SECTION.getEnd());
            String symbolclass = StringUtils.leftPad(StringUtils.EMPTY, SymbolNameSubfield.CLASS.getPackedLength());
            if (symbolName.length() > SymbolNameSubfield.CLASS.getBegin()) {
                symbolclass = StringUtils.substring(symbolName, SymbolNameSubfield.CLASS.getBegin(),
                        SymbolNameSubfield.CLASS.getEnd());
            }
            String subclass = StringUtils.SPACE;
            if (symbolName.length() > SymbolNameSubfield.SUBCLASS.getBegin()) {
                subclass = StringUtils.substring(symbolName, SymbolNameSubfield.SUBCLASS.getBegin(),
                        SymbolNameSubfield.SUBCLASS.getEnd());
            }
            String maingroup = StringUtils.leftPad(StringUtils.EMPTY, SymbolNameSubfield.MAINGROUP.getPackedLength(),'0');
            if (symbolName.length() > SymbolNameSubfield.MAINGROUP.getBegin()) {
                int slashIndex = symbolName.indexOf(SLASH);
                if (!symbolName.contains(SLASH)) {
                    slashIndex = symbolName.length();
                }
                maingroup = StringUtils.leftPad(
                        Integer.toString(Integer.parseInt(
                                StringUtils.substring(symbolName, SymbolNameSubfield.MAINGROUP.getBegin(), slashIndex))),
                        SymbolNameSubfield.MAINGROUP.getPackedLength(),'0');
            }
            String subgroup = StringUtils.rightPad(StringUtils.EMPTY, SymbolNameSubfield.SUBGROUP.getPackedLength(),'0');
            String separator = SLASH;
            if (symbolName.contains(SLASH)) {
                int slashIndex = symbolName.indexOf(SLASH);
                subgroup = StringUtils.rightPad(
                        StringUtils.substring(symbolName, slashIndex + SymbolNameSubfield.SEPARATOR.getPackedLength()),
                        SymbolNameSubfield.SUBGROUP.getPackedLength(),'0');
            }
    
            ret = section + symbolclass + subclass + maingroup + separator + subgroup;
            //log.debug("greated sortable name {}", ret);
          }
        return ret;
    }
    
    /**
     * This method does the heavy lifting of taking symbol names from different
     * parts of the tree and constructing string representations that are
     * alphabetically sortable and allows invalid symbols
     * 
     * Samples: A01B35/06 becomes "A01B 35/000000006" A becomes "A " A01N becomes
     * "A01N "
     * TODO: Come back and lower the Cyclomatic complexity on this method
     * @param symbolName
     * @return String
     */
    public static String createSortableSymbolNameAllowInvalidSymbolNames(String symbolName) {
        String ret = StringUtils.EMPTY;
        symbolName =  normalize(symbolName);
        try {
            ret =  createSortableSymbolName(symbolName);
        } catch (Exception e) {
            log.debug("ecountered invalid pattern. {}  attempting more permissive logic ", symbolName);
        }
        if (StringUtils.isEmpty(ret) && StringUtils.isNotEmpty(symbolName)) {
            String section = StringUtils.substring(symbolName, SymbolNameSubfield.SECTION.getBegin(),
                    SymbolNameSubfield.SECTION.getEnd());
            String symbolclass = StringUtils.leftPad(StringUtils.EMPTY, SymbolNameSubfield.CLASS.getPackedLength());
            if (symbolName.length() > SymbolNameSubfield.CLASS.getBegin()) {
                symbolclass = StringUtils.substring(symbolName, SymbolNameSubfield.CLASS.getBegin(),
                        SymbolNameSubfield.CLASS.getEnd());
            }
            String subclass = StringUtils.SPACE;
            if (symbolName.length() > SymbolNameSubfield.SUBCLASS.getBegin()) {
                subclass = StringUtils.substring(symbolName, SymbolNameSubfield.SUBCLASS.getBegin(),
                        SymbolNameSubfield.SUBCLASS.getEnd());
            }
            String maingroup = StringUtils.leftPad(StringUtils.EMPTY, SymbolNameSubfield.MAINGROUP.getPackedLength());
            if (symbolName.length() > SymbolNameSubfield.MAINGROUP.getBegin()) {
                int slashIndex = symbolName.indexOf(SLASH);
                if (!symbolName.contains(SLASH)) {
                    slashIndex = symbolName.length();
                }
                maingroup = StringUtils.leftPad(
                        
                                StringUtils.substring(symbolName, SymbolNameSubfield.MAINGROUP.getBegin(), slashIndex),
                        SymbolNameSubfield.MAINGROUP.getPackedLength());
            }
            String subgroup = StringUtils.leftPad(StringUtils.EMPTY, SymbolNameSubfield.SUBGROUP.getPackedLength());
            String separator = StringUtils.SPACE;
            if (symbolName.contains(SLASH)) {
                int slashIndex = symbolName.indexOf(SLASH);
                subgroup = StringUtils.leftPad(
                        StringUtils.substring(symbolName, slashIndex + SymbolNameSubfield.SEPARATOR.getPackedLength()),
                        SymbolNameSubfield.SUBGROUP.getPackedLength(),'0');
                separator = SLASH;
            }
            ret = section + symbolclass + subclass + maingroup + separator + subgroup;
        }
        return ret;
    }

    /**
     * This enum outlines the indexes for begin/end markers for the fields of
     * symbol name
     * 
     * @author 2020
     * @date Oct 27, 2015 3:10:17 PM
     * @version
     */
    public enum SymbolNameSubfield {
        SECTION(0, 1, 1), CLASS(1, 3, 2), SUBCLASS(3, 4, 1), MAINGROUP(4, 8, 4), SEPARATOR(8, 9, 1), SUBGROUP(9, 20, 10);
        private int begin;
        private int end;
        private int packedLength;

        /**
         * Private Constructor for SymbolNameSubfield.
         * 
         * @param begin
         * @param end
         * @param packedLength
         */
        private SymbolNameSubfield(int begin, int end, int packedLength) {
            this.begin = begin;
            this.end = end;
            this.packedLength = packedLength;
        }

        /**
         * @return the begin
         */
        public int getBegin() {
            return begin;
        }

        /**
         * @return the end
         */
        public int getEnd() {
            return end;
        }

        /**
         * @return the packedLength
         */
        public int getPackedLength() {
            return packedLength;
        }

    }

    /** 
     * This method takes a string and converts it to a unique form of the symbol name.  All whitespace is
     * removed and all chars are folded to upper case.  This method does no kind of validation or parsing.
     * this is only a general utility method for taking a string that might be a symbol name and cleaning
     * it up for all the parsing rules.
     * @param symbolName
     * @return String
     */
	public static String normalize(@Nonnull String symbolName) {
		
		return StringUtils.trimToEmpty(StringUtils.upperCase(StringUtils.deleteWhitespace(symbolName)));
	}
	
	/**
	 * this method should take the symbol (if valid) and format the string for display so as 
	 * to avoid semantic equels vs String equals() issues.  
	 * For example below are the following 
	 * 
	 * @return
	 */
	public String toDisplayFormat() {
		return this.getClassificationSymbolCd();
	}

	public String getSubclassSymbolName() {
		String symbolName = StringUtils.EMPTY;
		if (isValidSymbol()) {
			symbolName = this.getSection()+this.getSymbolClass()+this.getSubClass();
		} else {
			throw new IllegalArgumentException(this.getClassificationSymbolCd()+" does not appear to be valid symbol");
		}
		return symbolName;
	}

	public static String deriveSortKey(String symbolName) {

		symbolName = normalize(symbolName);
		String retValue = symbolName;
		if (StringUtils.length(symbolName) > 4) {
			String subclass = null;
			int end = StringUtils.length(symbolName);
			if (StringUtils.contains(symbolName, SLASH)) {
				end = StringUtils.indexOf(symbolName, SLASH);
				subclass = StringUtils.substring(symbolName, end + 1);
			}
			String mainGroup = StringUtils.substring(symbolName, 4, end);
			
			if (Integer.parseInt(mainGroup) >= 2000) {
				mainGroup = (Integer.parseInt(mainGroup) - 2000)+"";
			}
			//if (StringUtils.length(mainGroup) <2) {
//				mainGroup = StringUtils.leftPad(mainGroup, 2, "0");
			//}
			retValue = StringUtils.substring(symbolName, 0, 4)+mainGroup;
			if (subclass != null) {
				retValue += SLASH+subclass;
			}
		} 
		return retValue;
	}
}
