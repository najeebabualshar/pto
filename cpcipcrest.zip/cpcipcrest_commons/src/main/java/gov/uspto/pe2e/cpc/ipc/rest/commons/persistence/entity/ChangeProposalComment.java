package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentPartCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CommentVisibility;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table change_proposal_comment
 * primary key column is change_proposal_comment_id
 * 
 * 
 * @author 2020
 * @version 1.8
 * @date: June 20, 2016
 *
 */
@Data
@Entity
@Table(name = "change_proposal_comment", uniqueConstraints = {
		@UniqueConstraint(columnNames = { "fk_change_proposal_id", "full_symbol_tx", 
				"component_part_ct", "submit_ts" }),
		@UniqueConstraint(columnNames = { "guid_id" }) })
public class ChangeProposalComment implements Comparable<ChangeProposalComment>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_comment_id_seq")
	@SequenceGenerator(name = "change_proposal_comment_id_seq", 
		sequenceName = "change_proposal_comment_id_seq", allocationSize = 1)
	@Column(name = "change_proposal_comment_id")
	private Long id;

	@NotNull
	@Guid
	@Column(name = "guid_id")
	private String externalId;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
	@JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
	private ChangeProposal changeProposal;

//	@NotNull
//	@ManyToOne(fetch = FetchType.LAZY, targetEntity = ClassificationSymbol.class)
//	@JoinColumn(name = "fk_symbol_id", referencedColumnName = "symbol_id")
//	private ClassificationSymbol classificationSymbol;
//	
	@NotEmpty
	@Column(name = "full_symbol_tx")
	private String symbolName;
	   
	@NotNull
	@Column(name = "version_created_no")
	private Integer revisionNumber;

	@Column(name = "comment_tx",  columnDefinition="CLOB")
	private String comment;// VARCHAR2(4000)

	@Enumerated(EnumType.STRING)
	@Column(name = "component_part_ct")
	private ComponentPartCategory componentPartCategory;

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "access_ct")
	private CommentVisibility accessType;

	@Column(name = "delete_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date deleteTs;

	@CreatedBy
	@NotNull
	@Column(name = "submitter_user_id")
	private String submitterUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "submit_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date submitTs;

	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@SuppressWarnings("CPD-END")
	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	/**
	 * @return Long id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the externalId
	 */
	public String getExternalId() {
		return externalId;
	}

	/**
	 * @param externalId
	 *            the externalId to set
	 */
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	/**
	 * @return ChangeProposal changeProposal
	 */
	public ChangeProposal getChangeProposal() {
		return changeProposal;
	}

	/**
	 * @param changeProposal
	 */
	public void setChangeProposal(ChangeProposal changeProposal) {
		this.changeProposal = changeProposal;
	}

	/**
	 * @return String createUserId
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/**
	 * @param createUserId
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/**
	 * @return Date createTs
	 */
	public Date getCreateTs() {
		return createTs;
	}

	/**
	 * @param createTs
	 */
	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	/**
	 * @return String lastModifiedUserId
	 */
	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	/**
	 * @param lastModifiedUserId
	 */
	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	/**
	 * @return Date lastModifiedTs
	 */
	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	/**
	 * @param lastModifiedTs
	 */
	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	/**
	 * @return Integer lockControl
	 */
	public Integer getLockControl() {
		return lockControl;
	}

	/**
	 * @param lockControl
	 */
	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}

	

	/**
	 * @return the revisionNumber
	 */
	public Integer getRevisionNumber() {
		return revisionNumber;
	}

	/**
	 * @param revisionNumber
	 *            the revisionNumber to set
	 */
	public void setRevisionNumber(Integer revisionNumber) {
		this.revisionNumber = revisionNumber;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment
	 *            the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the componentPartCategory
	 */
	public ComponentPartCategory getComponentPartCategory() {
		return componentPartCategory;
	}

	/**
	 * @param componentPartCategory
	 *            the componentPartCategory to set
	 */
	public void setComponentPartCategory(ComponentPartCategory componentPartCategory) {
		this.componentPartCategory = componentPartCategory;
	}

	/**
	 * @return the accessType
	 */
	public CommentVisibility getAccessType() {
		return accessType;
	}

	/**
	 * @param accessType
	 *            the accessType to set
	 */
	public void setAccessType(CommentVisibility accessType) {
		this.accessType = accessType;
	}

	/**
	 * @return the deleteTs
	 */
	public Date getDeleteTs() {
		return deleteTs;
	}

	/**
	 * @param deleteTs
	 *            the deleteTs to set
	 */
	public void setDeleteTs(Date deleteTs) {
		this.deleteTs = deleteTs;
	}

	/**
	 * @return the submitterUserId
	 */
	public String getSubmitterUserId() {
		return submitterUserId;
	}

	/**
	 * @param submitterUserId
	 *            the submitterUserId to set
	 */
	public void setSubmitterUserId(String submitterUserId) {
		this.submitterUserId = submitterUserId;
	}

	/**
	 * @return the submitTs
	 */
	public Date getSubmitTs() {
		return submitTs;
	}

	/**
	 * @param submitTs
	 *            the submitTs to set
	 */
	public void setSubmitTs(Date submitTs) {
		this.submitTs = submitTs;
	}

	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ChangeProposalComment other) {
		return new CompareToBuilder().append(this.getId(), other.getId())
				.append(((this.getChangeProposal() != null
						&& StringUtils.isNotEmpty(this.getChangeProposal().getExternalId()))
								? this.getChangeProposal().getExternalId()
								: StringUtils.EMPTY),
						((other.getChangeProposal() != null
								&& StringUtils.isNotEmpty(other.getChangeProposal().getExternalId()))
										? other.getChangeProposal().getExternalId()
										: StringUtils.EMPTY))
				.append((( StringUtils.isNotEmpty(this.getSymbolName()))
								? SymbolName
										.createSortableSymbolName(this.getSymbolName())
								: StringUtils.EMPTY),
						((StringUtils.isNotEmpty(other.getSymbolName()))
										? SymbolName.createSortableSymbolName(
												other.getSymbolName())
										: StringUtils.EMPTY))
				.append(this.getComponentPartCategory(), other.getComponentPartCategory())
				.append(this.getExternalId(), other.getExternalId()).toComparison();
	}

	/**
	 * used for hash based collections.
	 */
	@Override
	public int hashCode() {
		return Objects.hash(((this.getChangeProposal() != null
				&& StringUtils.isNotEmpty(this.getChangeProposal().getExternalId()))
						? this.getChangeProposal().getExternalId()
						: StringUtils.EMPTY),
				this.getExternalId());
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		boolean ret = false;

		if (obj != null) {
			if (obj == this) {
				ret = true;
			} else if (ChangeProposalComment.class.isAssignableFrom(obj.getClass())) {
				ChangeProposalComment thatObj = (ChangeProposalComment) obj;

				String meProposalCode = this.getChangeProposal().getExternalId();
				String thatProposalCode = thatObj.getChangeProposal().getExternalId();

				String meComment = this.getComment();
				String thatComment = thatObj.getComment();

				Long meId = this.getId();
				Long thatId = thatObj.getId();

				String meExternalId = this.getExternalId();
				String thatExternalId = thatObj.getExternalId();

				ret = StringUtils.equals(meProposalCode, thatProposalCode) && StringUtils.equals(meComment, thatComment)
						&& Objects.equals(meExternalId, thatExternalId) && Objects.equals(meId, thatId);
			}
		}
		return ret;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChangeProposalComment [id=" + id + ", externalId=" + externalId + ", changeProposal=" + changeProposal
				+ ", classificationSymbol=" + symbolName + ", revisionNumber=" + revisionNumber + ", comment="
				+ comment + ", componentPartCategory=" + componentPartCategory + ", accessType=" + accessType
				+ ", deleteTs=" + deleteTs + ", submitterUserId=" + submitterUserId + ", submitTs=" + submitTs
				+ ", createUserId=" + createUserId + ", createTs=" + createTs + ", lastModifiedUserId="
				+ lastModifiedUserId + ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + "]";
	}

}
