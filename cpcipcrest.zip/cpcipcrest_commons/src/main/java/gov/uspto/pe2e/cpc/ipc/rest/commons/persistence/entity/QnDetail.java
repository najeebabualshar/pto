package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.QNContactType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;

/**
 * 
 * @author 2020
 * @date Jan 6, 2016 4:52:21 PM
 * @version 1.5
 */

@Entity
@Table(name = "temp_qn_detail")
public class QnDetail implements Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "temp_qn_detail_seq")
    @SequenceGenerator(name = "temp_qn_detail_seq", sequenceName = "temp_qn_detail_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "temp_qn_detail_id")
    private Long id;

    @Column(name = "classification_symbol_cd")
    private String classificationSymbolCode;

    @Pattern(regexp = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
    @Column(name = "email_address_tx")
    private String email;
    @Column(name = "given_nm")
    private String firstName;
    @Column(name = "family_nm")
    private String lastName;

    @Column(name = "art_unit")
    private String artUnit;

    @Enumerated(EnumType.STRING)
    @Column(name = "role_nm")
    private QNContactType qnContactType;

    /**
     * @return id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return classificationSymbolCode
     */
    public String getClassificationSymbolCode() {
        return classificationSymbolCode;
    }

    /**
     * @param classificationSymbolCode
     */
    public void setClassificationSymbolCode(String classificationSymbolCode) {
        this.classificationSymbolCode = classificationSymbolCode;
    }

    /**
     * @return email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return artUnit
     */
    public String getArtUnit() {
        return artUnit;
    }

    /**
     * @param artUnit
     */
    public void setArtUnit(String artUnit) {
        this.artUnit = artUnit;
    }

    /**
     * @return qnContactType
     */
    public QNContactType getQnContactType() {
        return qnContactType;
    }

    /**
     * @param qnContactType
     */
    public void setQnContactType(QNContactType qnContactType) {
        this.qnContactType = qnContactType;
    }

}
