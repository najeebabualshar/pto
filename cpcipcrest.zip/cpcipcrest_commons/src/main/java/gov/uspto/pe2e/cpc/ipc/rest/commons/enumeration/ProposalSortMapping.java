package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.GplSortBy;
import lombok.Getter;

/**
 * This class is responsible for mapping GplSortOrder to the field names in the
 * DB
 * 
 * @author msingh4
 *
 */
@Getter
public enum ProposalSortMapping {
	PROJECT(GplSortBy.PROJECT, "projectDetailView.projectSortNum"), 
	CREATE_TS(GplSortBy.CREATE_TS, "createTs"),
	CREATE_BY(GplSortBy.CREATE_BY, "createUserId"),
	US_COORDINATOR(GplSortBy.US_COORDINATOR, "projectDetailView.usCoordinator"),
	EP_COORDINATOR(GplSortBy.EP_COORDINATOR, "projectDetailView.epCoordinator"),
	PHASE(GplSortBy.PHASE, "projectDetailView.proposalPhaseSortNum"),
	TC_DIR(GplSortBy.TC_DIR, "projectDetailView.tcDir"),
	ART_UNIT(GplSortBy.ART_UNIT, "projectDetailView.artUnit"),
    TC_RANK(GplSortBy.TC_RANK, "projectDetailView.tcRankDirNum"),
    TC_PRIORITY(GplSortBy.TC_PRIORITY, "projectDetailView.tcPrioritySortNum"),
    EXPEDITED_REQUEST(GplSortBy.EXPEDITED_REQUEST, "projectDetailView.expeditedRequest"),
    SUBJECT(GplSortBy.SUBJECT, "projectDetailView.subject"),
    CPC_SCOPE(GplSortBy.CPC_SCOPE, "projectDetailView.cpcScope"),
    PREFERENCE_FOR_SUBCLASS(GplSortBy.PREFERENCE_FOR_SUBCLASS, "projectDetailView.subclassList"),
	FAMILY_COUNT(GplSortBy.FAMILY_COUNT, "projectDetailView.familyCount"),
	PI_SCHEME_RELEASE_DT(GplSortBy.PI_SCHEME_RELEASE_DT, "projectDetailView.piSchemeReleaseDt"),
	PF_SCHEME_PUBLISH_DT(GplSortBy.PF_SCHEME_PUBLISH_DT, "projectDetailView.pfSchemeReleaseDt"),
	PROJECT_CREATED_DT(GplSortBy.PROJECT_CREATED_DT, "projectDetailView.projectCreatedDT");
	

	private GplSortBy sortBy;
	private String entityGraphFieldPath;

	private ProposalSortMapping(GplSortBy sortBy, String entityGraphFieldPath) {
		this.sortBy = sortBy;
		this.entityGraphFieldPath = entityGraphFieldPath;
	}

	public static ProposalSortMapping bySortByRequest(GplSortBy sortByReq) {
		ProposalSortMapping mapping = null;

		for (ProposalSortMapping maybe : ProposalSortMapping.values()) {
			if (Objects.equals(maybe.getSortBy(), sortByReq) || StringUtils.equals(maybe.name(), sortByReq.name())) {
				mapping = maybe;
				break;
			}
		}
		return mapping;
	}
}
