package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table stnd_holiday
 * 
 * @author 2021
 * @date: 03/05/2021
 *
 */
@Entity
@Table(name = "stnd_holiday")
public class StandardHoliday implements Serializable {

	/**
	 *  Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Column(name = "holiday_id")
	private Long holidayId; // TODO: Change this to id.  This violates our standard

	@NotNull
	@Column(name = "holiday_dt")
	@Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date holidayDate;

	@NotNull
	@Column(name = "holiday_nm")
	private String holidayName;// VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@NotNull
	@CreatedBy
	@Column(name = "create_user_id")
	private String createUserId;

	@CreatedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	/**
	 * @return holidayId
	 */
	public Long getHolidayId() {
		return holidayId;
	}

	/**
	 * @param holidayId
	 */
	public void setHolidayId(Long holidayId) {
		this.holidayId = holidayId;
	}

	/**
	 * @return Date holidayDate
	 */
	public Date getHolidayDate() {
		return holidayDate;
	}

	/**
	 * @param holidayDate
	 */
	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}

	/**
	 * @return String holidayName
	 */
	public String getHolidayName() {
		return holidayName;
	}

	/**
	 * @param holidayName
	 */
	public void setHolidayName(String holidayName) {
		this.holidayName = holidayName;
	}

	/**
	 * @return Date createTs
	 */
	public Date getCreateTs() {
		return createTs;
	}

	/**
	 * @param createTs
	 */
	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	/**
	 * @return String createUserId
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/**
	 * @param createUserId
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/**
	 * @return Date lastModifiedTs
	 */
	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	/**
	 * @param lastModifiedTs
	 */
	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	/**
	 * @return String lastModifiedUserId
	 */
	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	/**
	 * @param lastModifiedTs
	 */
	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	/**
	 * @return Integer lockControl
	 */
	public Integer getLockControl() {
		return lockControl;
	}

	/**
	 * @param lockControl
	 */
	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}

	 /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "StandardHoliday [holidayId=" + holidayId + ", holidayDate=" + holidayDate
                + ", holidayName=" + holidayName + ", createTs=" + createTs + ", createUserId="
                + createUserId + ", , lastModifiedTs=" + lastModifiedTs + ",lastModifiedUserId=" + lastModifiedUserId
                + " ,lockControl=" + lockControl + "]";
    }

}
