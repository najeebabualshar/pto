
package gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * NoOpValidator is required so that @Guid has correct annotations
 * (specifically @Constraint) are honorred by Hibernate/JSR303 for constraint
 * validation
 */
public class NoOpGuidValidator implements ConstraintValidator<Guid, String> {

    /**
     * impl requires override
     */
    @Override
    public void initialize(Guid constraintAnnotation) {
        // impl requires override
    }

    /**
     * Returns true just to be valid
     */
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return true;
    }

}