package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

public enum ContextFileType {

}
