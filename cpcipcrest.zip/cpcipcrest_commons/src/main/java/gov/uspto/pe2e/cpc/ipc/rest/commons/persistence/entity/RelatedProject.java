package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
@Entity
@Table(name = "related_project", uniqueConstraints={ 
        @UniqueConstraint(
            name="pk_related_project", 
            columnNames = { "related_project_id"}),
        @UniqueConstraint(columnNames = { "source_project_guid","target_project_guid" })
        
})
public class RelatedProject  implements Comparable<RelatedProject>, Serializable {
	

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "related_project_id_seq")
    @SequenceGenerator(name = "related_project_id_seq", 
                  sequenceName = "related_project_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "related_project_id")
    private Long id;    

    @NotNull
    @Column(name = "source_project_cd", length=10)
    private String sourceProjectCode;

    @Guid
	@NotNull
    @Column(name = "source_project_guid")
    private String sourceChangeProposalExternalId;
    
    @NotNull
    @Column(name = "target_project_cd", length=10)
    private String targetProjectCode;

    @Guid
	@NotNull
    @Column(name = "target_project_guid")
    private String targetChangeProposalExternalId;
    
    @NotNull
    @Column(name = "subject_tx", length=2000)
    private String subject;
    

    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    // NOT SURE WHY we have a lock control on a record that cant be updated
    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    
    @OrderBy("id")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, 
                        mappedBy = "relatedProject", targetEntity = RelatedProjectSymbol.class,
                        orphanRemoval = true) // If this object is deleted, this objects in this set are deleted as well
    private Set<RelatedProjectSymbol> relatedProjectSymbols; 
    
    /**
     * @return the details list
     * 
     */
    public Set<RelatedProjectSymbol> getRelatedProjectSymbols() {
        if (this.relatedProjectSymbols == null) {
            this.relatedProjectSymbols = new TreeSet<>();
        }
        return relatedProjectSymbols;
    }
    /**
     * @return the changeProposerRoles
     * @since April 07, 2018
     */

    @Override
    public int compareTo(RelatedProject other) {
        
        return new CompareToBuilder()
                .append(this.getSourceProjectCode(),other.getSourceProjectCode())
                .append(this.getTargetProjectCode(), other.getTargetProjectCode())
                .append(this.getId(), other.getId())
                .toComparison();
                
    }
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof RelatedProject))
			return false;
		RelatedProject other = (RelatedProject) obj;
		return Objects.equals(createTs, other.createTs) && Objects.equals(createUserId, other.createUserId)
				&& Objects.equals(id, other.id) && Objects.equals(lockControl, other.lockControl)
				&& Objects.equals(sourceProjectCode, other.sourceProjectCode) && Objects.equals(subject, other.subject)
				&& Objects.equals(targetProjectCode, other.targetProjectCode);
	}
	@Override
	public int hashCode() {
		return Objects.hash(createTs, createUserId, id, lockControl, sourceProjectCode, subject, targetProjectCode);
	}

   
   
    
    
    
}
