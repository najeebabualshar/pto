package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExternalSystemCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class Aliases
 * @author 2020
 * @version 1.16.0
 * @date: Feb 9, 2019
 *
 */
@Entity
@Table(name = "change_proposal_alias", uniqueConstraints={ 
		@UniqueConstraint(
			// NOTE: This index is backwards.  it should be category then name as there will always be more
			// categories than names (otherwise you create a tree of X first level branches 
			//	  and N number of leaves for each branch where N represents one of 5 categories).
			// Leaving the index this way requires the ORM/query engine to properly re-order the where clause
			// which is sometimes problematic when you start including functions.  This may be an issue in the
			// future but we need to get this out.  IF you have performance issues updating aliases 
			//	by category and name re-order this index and it create a second index on name alone.	
			name="uk_change_proposal_alias", 
			columnNames = { "change_proposal_alias_cd", "source_system_ct"}) 
		
})
public class ChangeProposalAlias implements Comparable<ChangeProposalAlias>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_alias_id_seq")
    @SequenceGenerator(name = "change_proposal_alias_id_seq", 
                  sequenceName = "change_proposal_alias_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "change_proposal_alias_id")
    private Long id;    

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;

    @NotNull
    @Column(name = "change_proposal_alias_cd", length=20)
    private String name;
    
    @Enumerated(EnumType.STRING)
    @NotNull
    @Column(name = "source_system_ct", length=20)
    private ExternalSystemCategory systemCategory;

    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)  REALL?  We had this fixed

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;    
    @SuppressWarnings("CPD-END") 
   
	/**
     * Indicates whether some other object is "equal to" this one
     */
	@Override
    public boolean equals(Object obj) {
        boolean ret = true;
        if (obj == null) {
            ret = false;
        } else if (!ChangeProposalAlias.class.isAssignableFrom(obj.getClass())) {
            ret = false;
        } else if (obj == this) {
            ret = true;
        } else {
            ChangeProposalAlias thatObj = (ChangeProposalAlias) obj;  
            ret = new EqualsBuilder().append(this.getSystemCategory(), thatObj.getSystemCategory())
            		.append(this.getName(), thatObj.getName()).build();
        }
        return ret;
    }
    
    /**
   	 * @see java.lang.Object#hashCode()
   	 */
   	@Override
   	public int hashCode() {
   		final int prime = 37;
   		int result = 1;
   		result = prime * result + ((changeProposal == null) ? 0 : changeProposal.hashCode());
   		result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
   		result = prime * result + ((createUserId == null) ? 0 : createUserId.hashCode());
   		result = prime * result + ((id == null) ? 0 : id.hashCode());
   		result = prime * result + ((lastModifiedTs == null) ? 0 : lastModifiedTs.hashCode());
   		result = prime * result + ((lastModifiedUserId == null) ? 0 : lastModifiedUserId.hashCode());
   		result = prime * result + ((lockControl == null) ? 0 : lockControl.hashCode());
   		result = prime * result + ((name == null) ? 0 : name.hashCode());
   		result = prime * result + ((systemCategory == null) ? 0 : systemCategory.hashCode());
   		return result;
   	}

    
    /**
     * order by last mod then id
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ChangeProposalAlias other) {
        return new CompareToBuilder()
                .append(this.getLastModifiedTs(), other.getLastModifiedTs())
                .append(this.getCreateTs(), other.getCreateTs())
                .append(this.getId(), other.getId())
                .append(this.getName(), other.getName()).toComparison();
    }
    
    

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChangeProposalAlias [id=" + id + ", changeProposal=" 
				+ (changeProposal!=null?changeProposal.getId():"null") + ", name=" + name
				+ ", systemCategory=" + systemCategory + ", createUserId=" + createUserId + ", createTs=" + createTs
				+ ", lastModifiedUserId=" + lastModifiedUserId + ", lastModifiedTs=" + lastModifiedTs + ", lockControl="
				+ lockControl + "]";
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the changeProposal
	 */
	public ChangeProposal getChangeProposal() {
		return changeProposal;
	}

	/**
	 * @param changeProposal the changeProposal to set
	 */
	public void setChangeProposal(ChangeProposal changeProposal) {
		this.changeProposal = changeProposal;
	}

	/**
	 * @return the name
	 * 
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the systemCategory
	 */
	public ExternalSystemCategory getSystemCategory() {
		return systemCategory;
	}

	/**
	 * @param systemCategory the systemCategory to set
	 */
	public void setSystemCategory(ExternalSystemCategory systemCategory) {
		this.systemCategory = systemCategory;
	}

	/**
	 * @return the createUserId
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/**
	 * @param createUserId the createUserId to set
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/**
	 * @return the createTs
	 */
	public Date getCreateTs() {
		return createTs;
	}

	/**
	 * @param createTs the createTs to set
	 */
	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	/**
	 * @return the lastModifiedUserId
	 */
	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	/**
	 * @param lastModifiedUserId the lastModifiedUserId to set
	 */
	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	/**
	 * @return the lastModifiedTs
	 */
	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	/**
	 * @param lastModifiedTs the lastModifiedTs to set
	 */
	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	/**
	 * @return the lockControl
	 */
	public Integer getLockControl() {
		return lockControl;
	}

	/**
	 * @param lockControl the lockControl to set
	 */
	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}
}
