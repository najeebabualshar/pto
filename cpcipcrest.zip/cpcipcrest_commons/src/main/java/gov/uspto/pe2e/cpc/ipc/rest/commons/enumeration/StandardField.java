package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import java.util.Date;

/**
 * Enum class for the Standard Field.
 * 
 * @author 2020
 * @date: 11/14/2016
 * @version 1.5
 */
public enum StandardField {
	ID("id", Long.class), CREATE_TS("createTs", Date.class), CREATE_USER_ID("createUserId",
			String.class), 
	LAST_MOD_TS("lastModTs", Date.class), 
	LAST_MODIFIED_TS("lastModifiedTs", Date.class), 
	LAST_MODIFIED_USER_ID("lastModUserId", String.class);

	private String fieldName;
	private Class fieldType;

	/**
	 * 
	 * @param fieldName
	 * @param fieldType
	 */
	private StandardField(String fieldName, Class fieldType) {
		this.fieldName = fieldName;
		this.fieldType = fieldType;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @return the fieldType
	 */
	public Class getFieldType() {
		return fieldType;
	}

}
