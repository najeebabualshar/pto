package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.util.Date;

import org.hibernate.type.YesNoConverter;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * PAT_OTHER_PROJECT_V
 * 
 * @author msingh4
 *
 */
@Entity
@Table(name = "pat_other_project_v")
@Data
public class PatOtherProjectView {

	@Id
	@Column(name ="guid_id")
	@Guid
	private String id; // This is the db guid format
	
	/**
	 * cfk stands for "cross-functional key".  
	 * this is EDAD nomenclature for a natural key shared across systems 
	 */
	@Column(name ="cfk_pc_nm") 
	private String pcEmail; 
	
	@Column(name ="pay_period_id")
	private Long payPeriodId;	
	
	@Column(name ="pay_period_begin_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date payPeriodBegin;	
	
	@Column(name ="pay_period_end_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date payPeriodEnd;	

	@Column(name ="pay_period_qtr_cd")
	private String payPeriodQuarterCode;   

	@Column(name ="pay_period_fy_no")
	private Long payPeriodFiscalYear;   
	
	@Column(name ="change_proposal_id")
	private Long changeProposalId; 
	
	@Column(name ="change_proposal_guid_id")
	@NotNull
	@Guid
	private String changeProposalExternalId; 

	@Column(name ="change_proposal_alias_cd")
	private String changeProposalAlias;  
	
	@Column(name ="project_type_cd")
	private String projectTypeCode;  

	@Column(name ="project_source_cd")
	private String projectSourceCode;  
	
	/**
	 * this is called task_definition_id but this is not correct.  This is actually the 
	 * task Definition key!  the difference is, the id is assigned when the record is 
	 * persisted for the first time.  whereas, the key is known to the business before they
	 * even have the task defined and submitted for implementation
	 */
	@Column(name ="task_definition_id")
	private String taskDefinitionKey; // Ex: BAT01, PBT05  

	@Column(name ="proposal_phase_cd")
	private String proposalPhaseCode;  
	
//	ACTION_TX	VARCHAR2(20)
	@Column(name ="action_tx")
	private String action;  
	
	@Column(name ="no_of_repeats_no")
	private Integer numberOfRepeats;  

	@Column(name ="task_submitted_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date taskSubmitted;  

	@NotNull
	@Convert(converter = YesNoConverter.class)
	@Column(name = "doc_attached_in", columnDefinition = "char(1)")
	private Boolean docAttached;  
		
	@Column(name ="no_of_attached_doc_no")
	private Integer attachedDocsCount;	
	
	@Column(name ="attached_doc_type_tx")
	private String attachedDocType;		

}
