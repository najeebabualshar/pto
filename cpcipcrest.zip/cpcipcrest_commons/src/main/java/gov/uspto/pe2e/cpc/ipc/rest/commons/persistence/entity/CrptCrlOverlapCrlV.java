package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;


/**
 * The persistent class for the CRPT_CRL_OVERLAP_CRL_V database table.
 * 
 */
@Entity
@Table(name="crpt_crl_overlap_crl_v")
@Data
public class CrptCrlOverlapCrlV implements Comparable<CrptCrlOverlapCrlV>, Serializable {
	
    private static final long serialVersionUID = 1L;
    
    @Id
    @Guid
    @Column(name="GUID_ID")
	private String guidId;
    
	@Column(name="CRL_OVERLAP_SDCT_CHANGE_PROPOSAL_ID")
	private Long crlOverlapSdctChangeProposalId;

	@Column(name="CRL_OVERLAP_SDCT_GUID_ID")
	private String crlOverlapSdctGuidId;

	@Column(name="CRL_OVERLAP_SDCT_PROJECT_CD")
	private String crlOverlapSdctProjectCd;

	@Column(name="DEF_CHANGE_TYPE_CD")
	private String defChangeTypeCd;

	@Column(name="FULL_SYMBOL_TX")
	private String fullSymbolTx;

	@Column(name="NO_OF_PROJECTS_IMPACT_NO")
	private Long noOfProjectsImpactNo;

	@Column(name="PROJECT_TYPE_CT")
	private String projectTypeCt;
	
	@Column(name = "SCHEME_VERSION_TX")
	private String schemeVersionTx;

	@Column(name="PROPOSAL_PHASE_TX")
	private String proposalPhaseTx;
	 
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@Column(name="SCHEME_RELEASE_DT")
	private Date schemeReleaseDt;

	@Column(name="SOURCE_GUID_ID")
	private String sourceGuidId;

	@Column(name="SOURCE_PROJECT_CD")
	private String sourceProjectCd;

	@Column(name="SOURCE_PROPOSAL_ID")
	private Long sourceProposalId;

	@Column(name="SOURCE_SYMBOL_TX")
	private String sourceSymbolTx;

	@Column(name="SYM_CHANGE_TYPE_CD")
	private String symChangeTypeCd;

	@Column(name="VERSION_SYMBOL_GUID_ID")
	private String versionSymbolGuidId;
	
	@Column(name="source_crl_symbol_tx")
	private String sourceCrlSymbolTx;
	
	@Override
	public int compareTo(CrptCrlOverlapCrlV o) {
		return new CompareToBuilder().append(this.sourceGuidId, o.sourceGuidId)
				.append(this.sourceSymbolTx, o.sourceSymbolTx).append(this.crlOverlapSdctProjectCd, o.crlOverlapSdctProjectCd).toComparison();
	}

	@Override
	public String toString() {
		return "CrptCrlOverlapCrlV [guidId=" + guidId + ", crlOverlapSdctChangeProposalId="
				+ crlOverlapSdctChangeProposalId + ", crlOverlapSdctGuidId=" + crlOverlapSdctGuidId
				+ ", crlOverlapSdctProjectCd=" + crlOverlapSdctProjectCd + ", defChangeTypeCd=" + defChangeTypeCd
				+ ", fullSymbolTx=" + fullSymbolTx + ", noOfProjectsImpactNo=" + noOfProjectsImpactNo
				+ ", projectTypeCt=" + projectTypeCt + ", proposalPhaseTx=" + proposalPhaseTx + ", schemeReleaseDt="
				+ schemeReleaseDt + ", sourceGuidId=" + sourceGuidId + ", sourceProjectCd=" + sourceProjectCd
				+ ", sourceProposalId=" + sourceProposalId + ", sourceSymbolTx=" + sourceSymbolTx + ", symChangeTypeCd="
				+ symChangeTypeCd + ", versionSymbolGuidId=" + versionSymbolGuidId + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		CrptCrlOverlapCrlV other = (CrptCrlOverlapCrlV) obj;
		return Objects.equals(this.sourceProjectCd, other.sourceProjectCd)
				&& Objects.equals(this.sourceSymbolTx, other.sourceSymbolTx)
				&& Objects.equals(this.sourceCrlSymbolTx, other.sourceCrlSymbolTx)
				&& Objects.equals(this.crlOverlapSdctProjectCd, other.crlOverlapSdctProjectCd);
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.sourceProjectCd, this.sourceSymbolTx, this.sourceCrlSymbolTx,
				this.crlOverlapSdctProjectCd);
	}
}