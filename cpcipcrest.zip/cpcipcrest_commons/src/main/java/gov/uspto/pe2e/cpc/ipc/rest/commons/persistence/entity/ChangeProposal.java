package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.comparators.ReverseComparator;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.hibernate.annotations.Where;
import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.StandardField;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.business.ModelSymbolNameComparator;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.NullableFieldChooseLeftIfEqualsComparator;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProjectSizeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalUsage;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table change_proposal primary
 * key is change_proposal_id
 * 
 * @author 2020
 * @version 1.3
 * @date: 03/15/2016
 *
 */
@Data
@Entity
@Table(name = "change_proposal", uniqueConstraints = { @UniqueConstraint(columnNames = { "change_proposal_cd" }),
		@UniqueConstraint(columnNames = { "guid_id" }),
		/** There is another constraint that is conditionally applied to
		 * the global_project_release_nm only if global_project_in = Y
		 */
		})
public class ChangeProposal implements Comparable<ChangeProposal>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_id_seq")
	@SequenceGenerator(name = "change_proposal_id_seq", sequenceName = "change_proposal_id_seq", initialValue = 1, allocationSize = 1)
	@Column(name = "change_proposal_id")
	private Long id;

	@Guid
	@Column(name = "guid_id")
	@NotNull
	private String externalId;

	/**
	 * WARNING: This is junk data forced on the model be EDAD. There must be a
	 * unique value in this field to satisfy the contraints but it cannot be
	 * replied upon. This field should not be part of any hashcode(), equals()
	 * or compareTo() method
	 */
	@Deprecated
	@NotNull
	@Column(name = "change_proposal_cd")
	private String changeProposalCode; // VARCHAR2(10)

	@Column(name = "business_case_tx")
	private String businessCase; // VARCHAR2(4000)

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "est_project_size_ct")
	private ProjectSizeCategory projectSizeCategory;

	@Enumerated(EnumType.STRING)
	@Column(name = "fk_proposal_type_cd")
	private ProposalTypeCode proposalType;
	
	@NotNull
	@Convert(converter= YesNoConverter.class)
	@Column(name = "archive_in", columnDefinition = "char(1)")
	private Boolean archived; // Number
	
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "proposal_status_ct")
	private ProposalStatus proposalStatus;
	
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "proposal_usage_ct")
	private ProposalUsage proposalUsage;
	
	@NotNull
	@Convert(converter= YesNoConverter.class)
	@Column(name = "share_in", columnDefinition = "char(1)")
	private Boolean shared;	

	@NotNull
	@Convert(converter= YesNoConverter.class)
	@Column(name = "global_project_in", columnDefinition = "char(1)")
	private Boolean globalProject;
	
	@Column(name = "global_project_release_nm")
	private String globalProjectReleaseName; // format yyyyMMdd

	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	@SuppressWarnings("CPD-END")

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalState.class)
	private ChangeProposalState state;

	@OrderBy("version_id")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalVersion.class)
	private Set<ChangeProposalVersion> revisions;

	@OrderBy("change_proposal_office_id")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalOffice.class)
	private Set<ChangeProposalOffice> changeProposalOffices;

	@OrderBy("change_proposer_role_id")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposerRole.class)
	private Set<ChangeProposerRole> changeProposerRoles;

//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalTechField.class)
//	private Set<ChangeProposalTechField> changeProposalTechnologies;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalDetail.class)
	private Set<ChangeProposalDetail> changeProposalDetail;

	// Subclass and scope have different order by (symbol name vs id
	// respectively) because the data
	// stored in each is different and sorting mechanism for each is not
	// comparable
	// subclass ONLY ever stores the 4 letter symbol name of the main group.
	// This means
	// it doesn't matter how it stored it can be sorted aphabetically and
	// produce a business friendly
	// order. scope symbols on the otherhand contain a mix of symbols at various
	// levels meaning they
	// cannot be sorted aphabetically by name. We sort by Id and and rely on the
	// saving logic to sort
	// prior to save(). This is all necessary do the shear size difference as
	// well
	@OrderBy("subclass_cd")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalSubclass.class)
	private Set<ChangeProposalSubclass> changeProposalSubclasses;

	@OrderBy("change_proposal_scope_id")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalSymbolScope.class)
	private Set<ChangeProposalSymbolScope> changeProposalScopeSymbols;

	@OrderBy(value = "last_mod_ts DESC")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ChangeProposalAlias.class)
	private Set<ChangeProposalAlias> aliases;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = ProjectDetailView.class)
	private ProjectDetailView projectDetailView;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = MyTaskView.class)
	private MyTaskView myTaskView;
	
	/**
	 * Fetch only final docs
	 */
	@OrderBy("anx_no")
	@Where(clause = "UPPER(doc_version_cd)='FINAL'")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposal", targetEntity = PublicationDetailView.class)
	private List<PublicationDetailView> publicationDetailView;

	/**
	 * Get the revisions list
	 * 
	 * @return
	 * @since Mar 28, 2016
	 */
	public Set<ChangeProposalVersion> getRevisions() {
		if (this.revisions == null) {
			this.revisions = new TreeSet<>();
		}
		return revisions;
	}

	/**
	 * Adds ChangeProposalVersion to the list
	 * 
	 * @param child
	 */
	public void add(ChangeProposalVersion child) {
		getRevisions().add(child);
	}

	/**
	 * Sets the revisions list
	 * 
	 * @param revisions
	 * @since Mar 28, 2016
	 */
	public void setRevisions(Set<ChangeProposalVersion> revisions) {
		this.revisions = revisions;
	}

	/**
	 * @return the changeProposalOffices
	 * @since April 07, 2018
	 */
	public Set<ChangeProposalOffice> getChangeProposalOffices() {
		if (this.changeProposalOffices == null) {
			this.changeProposalOffices = new TreeSet<>();
		}
		return changeProposalOffices;
	}

	/**
	 * Adds Change Proposal Office
	 * 
	 * @param child
	 */
	public void add(ChangeProposalOffice child) {
		getChangeProposalOffices().add(child);
	}

	/**
	 * @param changeProposalOffice
	 *            the changeProposalOffice to set
	 * @since April 07, 2018
	 */
	public void setChangeProposalOffices(Set<ChangeProposalOffice> changeProposalOfficeSet) {
		this.changeProposalOffices = changeProposalOfficeSet;
	}

	/**
	 * @return the changeProposerRoles
	 * @since April 07, 2018
	 */
	public Set<ChangeProposerRole> getChangeProposerRoles() {
		if (this.changeProposerRoles == null) {
			this.changeProposerRoles = new TreeSet<>();
		}
		return changeProposerRoles;
	}

	/**
	 * Adds Change Proposer Role
	 * 
	 * @param child
	 */
	public void add(ChangeProposerRole child) {
		getChangeProposerRoles().add(child);
	}

	/**
	 * @param changeProposerRole
	 *            the changeProposerRoles to set
	 * @since April 07, 2018
	 */
	public void setChangeProposerRoles(Set<ChangeProposerRole> changeProposerRoleSet) {
		this.changeProposerRoles = changeProposerRoleSet;
	}
	/**
	 * Adds Change Proposal Technology
	 * 
	 * @param child
	 * @since Aug 13, 2018
	 */
	/* US334351 - ChangeProposalTechField table is removed as part fo this story
	 * public void add(ChangeProposalTechField child) {
	 * getChangeProposalTechnologies().add(child); }
	 */


	/**
	 * @return the aliases
	 */
	public Set<ChangeProposalAlias> getAliases() {
		if (this.aliases == null) {
			this.aliases = new TreeSet<>(new ReverseComparator(new BeanComparator(
					StandardField.LAST_MODIFIED_TS.getFieldName(), new NullableFieldChooseLeftIfEqualsComparator())));
			// new
			// BeanComparator(StandardField.LAST_MODIFIED_TS.getFieldName())));
		}
		return aliases;
	}

	/**
	 * @return the changeProposalSubclasses
	 */
	public Set<ChangeProposalSubclass> getChangeProposalSubclasses() {
		if (this.changeProposalSubclasses == null) {
			this.changeProposalSubclasses = new TreeSet<>();
		}
		return changeProposalSubclasses;
	}


	/**
	 * @return the changeProposalScopeSymbols
	 */
	public Set<ChangeProposalSymbolScope> getChangeProposalScopeSymbols() {
		if (this.changeProposalScopeSymbols == null) {
			this.changeProposalScopeSymbols = new TreeSet<>(
					new ModelSymbolNameComparator<>("classificationSymbolCode"));
		}
		return changeProposalScopeSymbols;
	}


	
	
	public List<PublicationDetailView> getPublicationDetailView() {
		if(publicationDetailView == null) {
			publicationDetailView = new ArrayList<>();
		}
		return publicationDetailView;
	}

	@Override
	public String toString() {
		return "ChangeProposal [id=" + id + ", externalId=" + externalId + ", changeProposalCode=" + changeProposalCode
				+ ", businessCase=" + businessCase + ", projectSizeCategory=" + projectSizeCategory + ", proposalType="
				+ proposalType + ", archived=" + archived + ", proposalStatus=" + proposalStatus + ", createUserId="
				+ createUserId + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId
				+ ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + ", state=" + state
				+ ", revisions=" + revisions + ", changeProposalOffices=" + changeProposalOffices
				+ ", changeProposerRoles=" + changeProposerRoles + ", changeProposalDetail=" + changeProposalDetail
				+ ", changeProposalSubclasses=" + changeProposalSubclasses + ", changeProposalScopeSymbols="
				+ changeProposalScopeSymbols + ", aliases=" + aliases + ", projectDetailView=" + projectDetailView
				+ "]";
	}

	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ChangeProposal other) {
		return new CompareToBuilder().append(this.getId(), other.getId())
				.append(this.getExternalId(), other.getExternalId()).toComparison();
	}

	/**
	 * Indicates whether some other object is "equal to" this one
	 */
	@Override
	public boolean equals(Object obj) {
		boolean ret;
		if (obj == null || !ChangeProposal.class.isAssignableFrom(obj.getClass())) {
			ret = false;
		} else if (ChangeProposal.class.isAssignableFrom(obj.getClass()) && obj == this) {
			ret = true;
		} else {
			ChangeProposal thatObj = (ChangeProposal) obj;
			ret = StringUtils.equals(this.getExternalId(), thatObj.getExternalId());
		}
		return ret;
	}

	/**
	 * used for hash based collections.
	 */
	@Override
	public int hashCode() {

		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((externalId == null) ? 0 : externalId.hashCode());
		return result;

	}

	/**
	 * @return the changeProposalCode
	 */
	@Deprecated
	public String getChangeProposalCode() {
		return changeProposalCode;
	}

	/**
	 * @param changeProposalCode
	 *            the changeProposalCode to set
	 */
	public void setChangeProposalCode(String changeProposalCode) {
		this.changeProposalCode = changeProposalCode;
	}


	public Set<ChangeProposalDetail> getChangeProposalDetail() {
		if(changeProposalDetail==null) {
			this.changeProposalDetail = new TreeSet<>();
		}
		return changeProposalDetail;
	}

}
