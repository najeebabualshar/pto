package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name = "crpt_scheme_version_v")
public class CrossReferenceToolsSchemeFilterList implements Serializable {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@NotNull
    @Column(name = "scheme_release_id")
	private Long scheme_release_id;
	

	@NotNull
    @Column(name = "scheme_version_tx")
    private String schemeVersion; // VARCHAR2(320)

  
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "scheme_release_dt")
    private Date schemeReleaseDate; // VARCHAR2(100)
     
     

}
