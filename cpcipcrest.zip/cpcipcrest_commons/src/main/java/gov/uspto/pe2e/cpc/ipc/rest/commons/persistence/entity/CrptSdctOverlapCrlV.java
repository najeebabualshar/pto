package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;

import org.apache.commons.lang3.builder.CompareToBuilder;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


/**
 * The persistent class for the CRPT_SDCT_OVERLAP_CRL_V view.
 * 
 */
@Entity
@Table(name="crpt_sdct_overlap_crl_v")
@Data
public class CrptSdctOverlapCrlV implements Comparable<CrptSdctOverlapCrlV>, Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
    @Guid
	@Column(name="GUID_ID")
	private String guidId;
	
	@Column(name = "NO_OF_PROJECTS_IMPACT_NO")
	private Long noOfProjectsImpactNo;

	@Column(name = "SDCT_OVERLAP_CRL_CHANGE_PROPOSAL_ID")
	private Long sdctOverlapCrlChangeProposalId;

	@Column(name = "SDCT_OVERLAP_CRL_GUID_ID")
	private String sdctOverlapCrlGuidId;

	@Column(name = "SDCT_OVERLAP_CRL_PROJECT_CD")
	private String sdctOverlapCrlProjectCd;

	@Column(name = "SOURCE_GUID_ID")
	private String sourceGuidId;

	@Column(name = "SOURCE_PROJECT_CD")
	private String sourceProjectCd;

	@Column(name = "SOURCE_PROPOSAL_ID")
	private Long sourceProposalId;

	@Column(name = "SOURCE_SYMBOL_TX")
	private String sourceSymbolTx;
	
	@Column(name = "SCHEME_VERSION_TX")
	private String schemeVersionTx;
	
	@Column(name = "PROJECT_TYPE_CT")
	private String projectTypeCt;

	@Override
	public int compareTo(CrptSdctOverlapCrlV o) {
		return new CompareToBuilder().append(this.sourceGuidId, o.sourceGuidId)
				.append(this.sourceSymbolTx, o.sourceSymbolTx).append(this.sdctOverlapCrlProjectCd, o.sdctOverlapCrlProjectCd).toComparison();
	}

	@Override
	public String toString() {
		return "CrptSdctOverlapCrlV [guidId=" + guidId + ", noOfProjectsImpactNo=" + noOfProjectsImpactNo
				+ ", sdctOverlapCrlChangeProposalId=" + sdctOverlapCrlChangeProposalId + ", sdctOverlapCrlGuidId="
				+ sdctOverlapCrlGuidId + ", sdctOverlapCrlProjectCd=" + sdctOverlapCrlProjectCd + ", sourceGuidId="
				+ sourceGuidId + ", sourceProjectCd=" + sourceProjectCd + ", sourceProposalId=" + sourceProposalId
				+ ", sourceSymbolTx=" + sourceSymbolTx + "]";
	}

	
}