package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * This enum is used to detrmine workflow status 
 * @author eweldearegay1-etc
 *
 */
public enum WorkFlowStatus {
	ON_TIME("On Time"),
	DELAYED("Delayed");
	
	
	private WorkFlowStatus(String value) {
		this.value = value;
	}
	private String value;

	public String getValue() {
		return value;
	}

	

	
	
}
