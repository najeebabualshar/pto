package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;


@Entity
@Table(name = "application_config")
public class ApplicationConfig implements Comparable<ApplicationConfig>, Serializable  {

	 /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
    
    @Id
    @NotNull
    @Column(name = "application_config_id")
    private Long id;
    
    @NotNull
	@Column(name ="parameter_tx")
    private String parameterTx;
    
    @NotNull
	@Column(name ="value_tx")
    private String valueTx;
    
	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getParameterTx() {
		return parameterTx;
	}

	public void setParameterTx(String parameterTx) {
		this.parameterTx = parameterTx;
	}

	public String getValueTx() {
		return valueTx;
	}

	public void setValueTx(String valueTx) {
		this.valueTx = valueTx;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}


	@Override
	public int compareTo(ApplicationConfig o) {
		return new CompareToBuilder().append(this.getId(), o.getId())
                .append(this.getParameterTx(), o.getParameterTx())
                .append(this.getValueTx(), o.getValueTx()).toComparison();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
		result = prime * result + ((createUserId == null) ? 0 : createUserId.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((parameterTx == null) ? 0 : parameterTx.hashCode());
		result = prime * result + ((valueTx == null) ? 0 : valueTx.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplicationConfig other = (ApplicationConfig) obj;
		if (createTs == null) {
			if (other.createTs != null)
				return false;
		} else if (!createTs.equals(other.createTs))
			return false;
		if (createUserId == null) {
			if (other.createUserId != null)
				return false;
		} else if (!createUserId.equals(other.createUserId))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (parameterTx == null) {
			if (other.parameterTx != null)
				return false;
		} else if (!parameterTx.equals(other.parameterTx))
			return false;
		if (valueTx == null) {
			if (other.valueTx != null)
				return false;
		} else if (!valueTx.equals(other.valueTx))
			return false;
		return true;
	}
	
}
