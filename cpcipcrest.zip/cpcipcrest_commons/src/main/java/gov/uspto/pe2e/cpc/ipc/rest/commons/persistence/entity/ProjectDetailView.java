package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExternalSystemCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalStateType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Project Detail View
 * @author Maximus
 * @date: 11/01/2021
 *
 */
@Entity
@Table(name = "project_dtl_v")
@Data
public class ProjectDetailView implements Comparable<ProjectDetailView>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@NotNull
	@Convert(converter = YesNoConverter.class)
	@Column(name = "archive_in", columnDefinition = "char(1)")
	private Boolean archived;

	@Column(name = "cef_project_cd")
	private String cefProjectCode;
	
	@Column(name = "project_type_ct")
	private String projectType;
	
	@Column(name = "project_source_cd")
	private String projectSource;

    @NotNull
	@OneToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
	private ChangeProposal changeProposal;
	
    @NotNull
    @Column(name = "change_proposal_alias_cd", length=20)
    private String changeProposalAliasCd;
	
	@Column(name = "cpc_scope_manual_cd")
	private String cpcScope; 

	@Column(name = "ep_tech_tx")
	private String epTechnology;

	@Id
	@Column(name = "fk_change_proposal_id", updatable = false, insertable = false)
	private Long id;

	@Column(name = "ipc_tech_tx")
	private String ipcTechnology;

	@Column(name = "rapp_office_cd")
	private String rappertourOfficeCd;

	@Column(name = "subject_tx")
	private String subject;

	@Enumerated(EnumType.STRING)
    @NotNull
    @Column(name = "source_system_ct", length=20)
    private ExternalSystemCategory systemCategory;
	
	@Column(name = "us_pc_nm")
	private String usCoordinator;
	
	@Column(name = "ep_pc_nm")
	private String epCoordinator;
	
	@Column(name = "us_sce_nm")
	private String usSCE;
	
	@Column(name = "us_backup_sce_nm")
	private String usBackupSCE;
 
	@Column(name = "us_eb_nm")
	private String usEditorialBoard;

	@Column(name = "ep_eb_nm")
	private String epEditorialBoard;
	
	@Column(name = "us_scespe_nm")
	private String usSupervisoryClassificationOrPatentExaminer;
					
	@Column(name = "us_spc_nm")
	private String usSupervisoryPatentClassifier;

	@Column(name = "ep_qn_nm")
	private String epQNExpert;
	
	@Column(name = "ep_gerant_nm")
	private String epGerant;
	
	@Column(name = "ep_cpbm_nm")
	private String epClassificationBoardMember;
			
	@Column(name = "us_reclass_mgr_nm")
	private String usReclassManager;

	@Column(name = "ep_reclass_mgr_nm")
	private String epReclassManager;
	
	@Column(name = "pub_writer_editor_nm")
	private String publicationWriterEditor;
	
	@Column(name = "pub_specialist_nm")
	private String publicationSpecialist;
	
	@Column(name = "pub_mgr_nm")
	private String publicationManager;	
	
	@Column(name = "us_tech_tx")
	private String usTechnology;
	
	@Enumerated(EnumType.STRING)
	@Column(name="proposal_phase_tx")
	private ProposalPhase phase;
	
	@Enumerated(EnumType.STRING)
	@Column(name="proposal_state_ct")
	private ProposalStateType proposalState;
	
	@Column(name="project_sort_no")
	private Long projectSortNum;
	
	@Column(name="proposal_phase_sort_no")
	private Long proposalPhaseSortNum;
		
	@Column(name = "twl_status_ct")
	private String twlStatus;
	
	@Column(name = "hp_hx_status_ct")
	private String hpHxStatus;
	
	@Column(name = "tc_dir_no")
	private String tcDir;
	
	@Column(name = "reclass_office_cd")
	private String reclassOfficeCd;
	
	@Column(name = "art_unit_no")
	private String artUnit;
	
	@Column(name = "sme_consult_status_cd")
	private String smeConsultStatusCd;
	
	@Column(name ="rank_tc_dir_no")
	private Long tcRankDirNum;
	
	@Column(name ="priority_tc_sort_no")
	private Long tcPrioritySortNum;
	
	@Column(name="expedited_request_ct")
	private String expeditedRequest;
	
	@Column(name = "examiner_qn_nm")
	private String examinerQnNm;
	
	@Column(name = "examiner_qn1_nm")
	private String examinerQn1Nm;
	
	@Column(name = "examiner_qn2_nm")
	private String examinerQn2Nm;
	
	@Column(name = "spe_qn_nm")
	private String speQnNm;
	
	
	@Column(name = "subclass_list")
	private String subclassList;

	@LastModifiedDate
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@Column(name = "us_pc_last_mod_ts")
	private Date usPcLastModifiedDate;
	
	@Column(name = "scheme_release_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date schemeReleaseDt;
	
	@Column(name = "pi_pub_dt")
    private String piSchemeReleaseDt;
	
	@Column(name = "pf_pub_dt")
    private String pfSchemeReleaseDt;
	
	@Column(name = "family_count_no")
	private Integer familyCount;

 	@Column(name = "project_created_dt")
 	@Temporal(TemporalType.DATE)
 	@DateTimeFormat(pattern = "yyyy-MM-dd")
 	private Date projectCreatedDT;
	
	@Override
	public int compareTo(ProjectDetailView o) {
		return new CompareToBuilder().append(this.changeProposal, o.changeProposal)
				.toComparison();
	}

	@Override
	public String toString() {
		ReflectionToStringBuilder builder = new ReflectionToStringBuilder(this);
		builder.append("archived", archived);
		builder.append("cefProjectCode", cefProjectCode);
		builder.append("projectType", projectType);
		builder.append("projectSource", projectSource);
		builder.append("changeProposal", changeProposal);
		builder.append("changeProposalAliasCd", changeProposalAliasCd);
		builder.append("cpcScope", cpcScope);
		builder.append("epTechnology", epTechnology);
		builder.append("id", id);
		builder.append("ipcTechnology", ipcTechnology);
		builder.append("rappertourOfficeCd", rappertourOfficeCd);
		builder.append("subject", subject);
		builder.append("systemCategory", systemCategory);
		builder.append("usCoordinator", usCoordinator);
		builder.append("epCoordinator", epCoordinator);
		builder.append("usSCE", usSCE);
		builder.append("usBackupSCE", usBackupSCE);
		builder.append("usEditorialBoard", usEditorialBoard);
		builder.append("epEditorialBoard", epEditorialBoard);
		builder.append("usSupervisoryClassificationOrPatentExaminer", usSupervisoryClassificationOrPatentExaminer);
		builder.append("usSupervisoryPatentClassifier", usSupervisoryPatentClassifier);
		builder.append("epQNExpert", epQNExpert);
		builder.append("epGerant", epGerant);
		builder.append("epClassificationBoardMember", epClassificationBoardMember);
		builder.append("usReclassManager", usReclassManager);
		builder.append("epReclassManager", epReclassManager);
		builder.append("publicationWriterEditor", publicationWriterEditor);
		builder.append("publicationSpecialist", publicationSpecialist);
		builder.append("publicationManager", publicationManager);
		builder.append("usTechnology", usTechnology);
		builder.append("phase", phase);
		builder.append("proposalState", proposalState);
		builder.append("projectSortNum", projectSortNum);
		builder.append("proposalPhaseSortNum", proposalPhaseSortNum);
		builder.append("twlStatus", twlStatus);
		builder.append("hpHxStatus", hpHxStatus);
		builder.append("tcDir", tcDir);
		builder.append("reclassOfficeCd", reclassOfficeCd);
		builder.append("artUnit", artUnit);
		builder.append("smeConsultStatusCd", smeConsultStatusCd);
		builder.append("tcRankDirNum", tcRankDirNum);
		builder.append("tcPrioritySortNum", tcPrioritySortNum);
		builder.append("expeditedRequest", expeditedRequest);
		builder.append("examinerQnNm", examinerQnNm);
		builder.append("examinerQn1Nm", examinerQn1Nm);
		builder.append("examinerQn2Nm", examinerQn2Nm);
		builder.append("speQnNm", speQnNm);
		builder.append("subclassList", subclassList);
		builder.append("usPcLastModifiedDate", usPcLastModifiedDate);
		builder.append("schemeReleaseDt", schemeReleaseDt);
		builder.append("piSchemeReleaseDt", piSchemeReleaseDt);
		builder.append("pfSchemeReleaseDt", pfSchemeReleaseDt);
		builder.append("familyCount", familyCount);
		builder.append("projectCreatedDT", projectCreatedDT);
		return builder.toString();
	}
	
	

	
	
	
}
