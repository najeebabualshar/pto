package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.CollectionScanner;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ChangeProposalIssueStatus;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name = "change_proposal_issue", uniqueConstraints = { 
		@UniqueConstraint(name = "pk_issue_id", columnNames = {
        "issue_id" }),
		@UniqueConstraint(name="uk_change_proposal_issue",columnNames = { "guid_id" }) })
public class ChangeProposalIssue implements Serializable {
    
    private static final long serialVersionUID = 1L;
    //TODO: Change All primary key columns from numeric to guids
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "issue_id_seq")
    @SequenceGenerator(name = "issue_id_seq", sequenceName = "issue_id_seq", initialValue = 1,
            allocationSize = 1)
    @Column(name = "issue_id") 
    private Long id;  

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
    
    @Guid
    @NotNull
    @Column(name = "guid_id")
    private String externalId;
   
    @NotNull
    @Column(name = "sort_order_no")
    private Integer sortOrder;

    @NotNull
    @Column(name = "description_tx")
    private String description;


    @Enumerated(EnumType.STRING)
    @Column(name = "status_ct")
    private ChangeProposalIssueStatus issueStatus;
    

    @Column(name = "action_tx")
    private String action;

    @NotNull
    @Convert(converter = YesNoConverter.class)
    @Column(name = "delete_in", columnDefinition = "char(1)")
    private Boolean deleted;

    @Column(name = "category_tx")
    private String category;

    @Column(name = "priority_no")
    private Integer priority;

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @NotNull
    @Column(name = "create_user_id")
    private String createUserId;

    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModTs;

    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModUserId;

    @NotNull
    @Column(name = "lock_control_no")
    @Version
    private Integer lockControlNo;
    

    @OrderBy("create_ts asc")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "issue", targetEntity = ChangeProposalIssueDocument.class)
	private Set<ChangeProposalIssueDocument> referencedDocuments;
	

	public Set<ChangeProposalIssueDocument> getReferencedDocuments() {
		if (this.referencedDocuments == null) {
			this.referencedDocuments = new TreeSet<>();
		}
		return this.referencedDocuments;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChangeProposalIssue other = (ChangeProposalIssue) obj;
		return Objects.equals(action, other.action) && Objects.equals(category, other.category)
				&& Objects.equals(changeProposal, other.changeProposal) 
				&& Objects.equals(createTs, other.createTs)
				&& Objects.equals(createUserId, other.createUserId) 
				&& Objects.equals(deleted, other.deleted)
				&& Objects.equals(description, other.description) 
				&& Objects.equals(externalId, other.externalId)
				&& Objects.equals(id, other.id) 
				&& issueStatus == other.issueStatus
				&& Objects.equals(lastModTs, other.lastModTs) 
				&& Objects.equals(lastModUserId, other.lastModUserId)
				&& Objects.equals(lockControlNo, other.lockControlNo) 
				&& Objects.equals(priority, other.priority)
				//&& Objects.equals(referencedDocuments, other.referencedDocuments)
				&& Objects.equals(sortOrder, other.sortOrder);
	}


	@Override
	public int hashCode() {
		return Objects.hash(action, category, 
				CollectionScanner.coalesce(changeProposal, new ChangeProposal()).getExternalId(), 
				createTs, createUserId, deleted, description, externalId,
				id, issueStatus, lastModTs, lastModUserId, lockControlNo, priority, 
				//referencedDocuments, 
				sortOrder);
	}


	@Override
	public String toString() {
		return "ChangeProposalIssue [id=" + id + ", changeProposal=" 
				+ ((changeProposal != null)?changeProposal.getId():"null") 
				+ ", externalId=" + externalId
				+ ", sortOrder=" + sortOrder + ", description=" + description 
				+ ", issueStatus=" + issueStatus
				+ ", action=" + action + ", deleted=" + deleted + ", category=" + category 
				+ ", priority=" + priority
				+ ", createTs=" + createTs + ", createUserId=" + createUserId + ", lastModTs=" 
				+ lastModTs
				+ ", lastModUserId=" + lastModUserId + ", lockControlNo=" + lockControlNo 
				+ ", referencedDocuments="
				+ referencedDocuments + "]";
	}
	
	
	
	


}