package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.VarcharBooleanConverter;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.hibernate.validator.constraints.Length;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.ClassSymbolNameComparator;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CompareToUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.CollectionScanner;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.SymbolStatusCode;
import jakarta.annotation.Nonnull;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;

/**
 * Class for use with spring application converters and JPA
 * 
 * @author 2020
 * @version 1.1
 * @date: 08/4/2015
 *
 */
@Entity
@Table(name = "scheme_hierarchy")
public class SchemeHierarchy implements Comparable<SchemeHierarchy>, Serializable {

    /**
     * Allowing serialization of data model elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "scheme_hierarchy_seq")
    @SequenceGenerator(name = "scheme_hierarchy_seq", 
                        sequenceName = "scheme_hierarchy_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "scheme_hierarchy_id")
    private Long id;

    @Column(name = "classification_symbol_cd")
    @NotNull
    private String classificationSymbolCode;

    @Column(name = "indent_level_no")
    @NotNull
    private Integer indentLevel;

    @Column(name = "sort_key")
    @NotNull
    private String sortKey;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ClassificationScheme.class)
    @JoinColumn(name = "fk_classification_scheme_id", referencedColumnName = "classification_scheme_id")
    private ClassificationScheme classificationScheme;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = SchemeHierarchy.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_parent_scheme_hierarchy_id", referencedColumnName = "scheme_hierarchy_id")
    private SchemeHierarchy parent;

    @Lob
    @Column(name = "title_tx", columnDefinition = "clob")
    private String title;

    @Lob
    @Column(name = "note_warning_tx", columnDefinition = "clob")
    private String notesAndWarnings;

    @OrderBy("sortKey")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "parent", targetEntity = SchemeHierarchy.class)
    private Set<SchemeHierarchy> children;

    @Convert(converter = VarcharBooleanConverter.class)
    @Column(name = "breakdown_code_in", columnDefinition = "varchar2")
    @NotNull
    private Boolean breakdownCode; // NUMBER
    
    @Convert(converter = VarcharBooleanConverter.class)
    @Column(name = "not_allocatable_in", columnDefinition = "varchar2")
    @NotNull
    private Boolean notAllocatable; // NUMBER

    @Convert(converter = VarcharBooleanConverter.class)
    @Column(name = "additional_only_in", columnDefinition = "varchar2")
    @NotNull
    private Boolean additionalOnly;

    @Convert(converter = VarcharBooleanConverter.class)
    @NotNull
    @Column(name = "definiton_exists_in", columnDefinition = "varchar2")
    private Boolean definitionExists;

    @Convert(converter = VarcharBooleanConverter.class)
    @NotNull
    @Column(name = "heading_in", columnDefinition = "varchar2")
    private Boolean heading;

    @Convert(converter = VarcharBooleanConverter.class)
    @Column(name = "c_set_base_allowed_in", columnDefinition = "varchar2")
    private Boolean cSetBaseAllowed;
                                  
	@Convert(converter = VarcharBooleanConverter.class)
	@Column(name = "c_set_subsequent_allowed_in", columnDefinition = "varchar2")
	private Boolean cSetSubsequentAllowed;


    @Convert(converter = VarcharBooleanConverter.class)
    @NotNull
    @Column(name = "two_thousand_symbol_in", columnDefinition = "varchar2")
    private Boolean twoThousandSymbol;

    // This should be an ENUM.
    @Column(name = "ipc_concordant_cd")
    private String ipcConcordantCode; // VARCHAR2(10)
    @Enumerated(EnumType.STRING)
    @Column(name = "status_cd")
    private SymbolStatusCode statusCode; // VARCHAR2(20)

    @NotNull
    @Column(name = "symbol_revision_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date symbolRevisionDt;

    @Column(name = "section_cd")
    @NotNull
    private String sectionCode;

    @Column(name = "class_cd")
    private String classCode;

    @Column(name = "subclass_cd", length=1)
    @Length(max = 1)
    private String subClassCode;

    @Column(name = "maingroup_cd")
    private String mainGroupCode;

    @Column(name = "subgroup_cd")
    private String subGroupCode;
    
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;


    @OrderBy("id")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, 
                        mappedBy = "schemeHierarchy", targetEntity = DefinitionHierarchy.class)
    private Set<DefinitionHierarchy> definitionHierarchies;

    /**
     * @return Long id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return String classificationSymbolCode
     */
    public String getClassificationSymbolCode() {
        return classificationSymbolCode;
    }

    /**
     * @param classificationSymbolCode
     */
    public void setClassificationSymbolCode(String classificationSymbolCode) {
        this.classificationSymbolCode = classificationSymbolCode;
    }

    /**
     * @return String title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return String notesAndWarnings
     */
    public String getNotesAndWarnings() {
        return notesAndWarnings;
    }

    /**
     * @param notesAndWarnings
     */
    public void setNotesAndWarnings(String notesAndWarnings) {
        this.notesAndWarnings = notesAndWarnings;
    }

    /**
     * @return String ipcConcordantCode
     */
    public String getIpcConcordantCode() {
        return ipcConcordantCode;
    }

    /**
     * @param ipcConcordantCode
     */
    public void setIpcConcordantCode(String ipcConcordantCode) {
        this.ipcConcordantCode = ipcConcordantCode;
    }

    /**
     * @return SymbolStatusCode statusCode
     */
    public SymbolStatusCode getStatusCode() {
        return statusCode;
    }

    /**
     * @param statusCode
     */
    public void setStatusCode(SymbolStatusCode statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * This is the sort key used to sort child lists of a parent symbol
     * 
     * @see gov.uspto.pe2e.cpc.ipc.rest.commons.util.ClassSymbolNameComparator
     * @return String sortKey
     */
    public String getSortKey() {
        return sortKey;
    }

    /**
     * @return Integer indentLevel
     */
    public Integer getIndentLevel() {
        return indentLevel;
    }

    /**
     * @param indentLevel
     */
    public void setIndentLevel(Integer indentLevel) {
        this.indentLevel = indentLevel;
    }

    /**
     * @param sortKey
     */
    public void setSortKey(String sortKey) {
        this.sortKey = sortKey;
    }

    /**
     * Lazy fetched Parent symbol
     * 
     * @return SchemeHierarchy parent
     */
    public SchemeHierarchy getParent() {
        return parent;
    }

    /**
     * @param parent
     */
    public void setParent(SchemeHierarchy parent) {
        this.parent = parent;
    }

    /**
     * Returns a Set of SchemeHierarhy children. If the set is null, instantiate
     * the set as an empty TreeSet.
     * 
     * @return Set<SchemeHierarchy> children
     */
    public @Nonnull Set<SchemeHierarchy> getChildren() {
        if (children == null) {
            children = new TreeSet<>();
        }
        return children;
    }

    /**
     * @param children
     */
    public void setChildren(Set<SchemeHierarchy> children) {
        this.children = children;
    }

    /**
     * @return Boolean breakdownCode
     */
    public Boolean getBreakdownCode() {
        return breakdownCode;
    }

    /**
     * @param breakdownCode
     */
    public void setBreakdownCode(Boolean breakdownCode) {
        this.breakdownCode = breakdownCode;
    }

    /**
     * @return Boolean heading
     */
    public Boolean getHeading() {
        return heading;
    }

    /**
     * @param heading
     */
    public void setHeading(Boolean heading) {
        this.heading = heading;
    }

    
    /**
	 * @return the cSetBaseAllowed
	 */
	public Boolean getcSetBaseAllowed() {
		return cSetBaseAllowed;
	}

	/**
	 * @param cSetBaseAllowed the cSetBaseAllowed to set
	 */
	public void setcSetBaseAllowed(Boolean cSetBaseAllowed) {
		this.cSetBaseAllowed = cSetBaseAllowed;
	}

	/**
	 * @return the cSetSubsequentAllowed
	 */
	public Boolean getcSetSubsequentAllowed() {
		return cSetSubsequentAllowed;
	}

	/**
	 * @param cSetSubsequentAllowed the cSetSubsequentAllowed to set
	 */
	public void setcSetSubsequentAllowed(Boolean cSetSubsequentAllowed) {
		this.cSetSubsequentAllowed = cSetSubsequentAllowed;
	}

	/**
     * @return Boolean notAllocatable
     */
    public Boolean getNotAllocatable() {
        return notAllocatable;
    }

    /**
     * 
     * @param notAllocatable
     */
    public void setNotAllocatable(Boolean notAllocatable) {
        this.notAllocatable = notAllocatable;
    }

    /**
     * @return Boolean additionalOnly
     */
    public Boolean getAdditionalOnly() {
        return additionalOnly;
    }

    /**
     * @param additionalOnly
     */
    public void setAdditionalOnly(Boolean additionalOnly) {
        this.additionalOnly = additionalOnly;
    }

    /**
     * @return Boolean definitionExists
     */
    public Boolean getDefinitionExists() {
        return definitionExists;
    }

    /**
     * @param definitionExists
     */
    public void setDefinitionExists(Boolean definitionExists) {
        this.definitionExists = definitionExists;
    }

    /**
     * @return the twoThousandSymbol
     */
    public Boolean getTwoThousandSymbol() {
        return twoThousandSymbol;
    }

    /**
     * @param twoThousandSymbol
     *            the twoThousandSymbol to set
     */
    public void setTwoThousandSymbol(Boolean twoThousandSymbol) {
        this.twoThousandSymbol = twoThousandSymbol;
    }

    /**
     * Lazy fetched ClassificationScheme
     * 
     * @return ClassificationScheme classificationSchme
     */
    public ClassificationScheme getClassificationScheme() {
        return classificationScheme;
    }

    /**
     * @param classificationScheme
     */
    public void setClassificationScheme(ClassificationScheme classificationScheme) {
        this.classificationScheme = classificationScheme;
    }

    /**
     * 
     * @return DefinitionHierarchy Set
     */
    public Set<DefinitionHierarchy> getDefinitionHierarchies() {
        if (definitionHierarchies == null) {
            definitionHierarchies = new TreeSet<>();
        }
        return definitionHierarchies;
    }

    /**
     * 
     * @param definitionHierarchies
     */
    public void setDefinitionHierarchies(Set<DefinitionHierarchy> definitionHierarchies) {
        this.definitionHierarchies = definitionHierarchies;
    }

    /**
     * 
     * @return java.util.Date
     */
    public Date getSymbolRevisionDt() {
        return symbolRevisionDt;
    }

    /**
     * 
     * @param symbolRevisionDt
     */
    public void setSymbolRevisionDt(Date symbolRevisionDt) {
        this.symbolRevisionDt = symbolRevisionDt;
    }

    public String getSectionCode() {
        return sectionCode;
    }

    public void setSectionCode(String sectionCode) {
        this.sectionCode = sectionCode;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public String getSubClassCode() {
        return subClassCode;
    }

    public void setSubClassCode(String subClassCode) {
        this.subClassCode = subClassCode;
    }

    public String getMainGroupCode() {
        return mainGroupCode;
    }

    public void setMainGroupCode(String mainGroupCode) {
        this.mainGroupCode = mainGroupCode;
    }

    public String getSubGroupCode() {
        return subGroupCode;
    }

    public void setSubGroupCode(String subGroupCode) {
        this.subGroupCode = subGroupCode;
    }

    /**
     * toString() returns a string representation of the symbol careful not to
     * walk the graph accidentally causing lazy load exceptions NOTE: do not use
     * the generated toString() method without sanitizing relations to other
     * entity types.
     */
    @Override
    public String toString() {
        return "Symbol [id=" + id + ", classificationSymolCode=" + classificationSymbolCode + ", indentLevel="
                + indentLevel + ", sortKey=" + sortKey + ", parent=(" + ((parent != null) ? parent.getId() : "null")
                + "), titleXml=" + title + ", children=[" + ((children != null) ? children.size() : "null")
                + "], breakdownCode=" + breakdownCode + ", notAllocatable=" + notAllocatable + ", additionalOnly="
                + additionalOnly + ", definitionExists=" + definitionExists + ", ipcConcordantCode=" + ipcConcordantCode
                + ", statusCode=" + statusCode + ", symbolRevisionDt="+ symbolRevisionDt +"]";
    }

    /**
     * Compares this SchemeHierarchy to another (that). The comparison takes
     * compares either the sortKey (if available) or the
     * classificationSymbolCode if sortKey is null.
     * 
     * @see gov.uspto.pe2e.cpc.ipc.rest.commons.util.ClassSymbolNameComparator
     */
    @Override
    public int compareTo(SchemeHierarchy that) {
    	
    	int ret = CompareToUtils.THIS_IS_GREATER;

        if (that != null) {
            String thisSymbolString = CollectionScanner.coalesce(this.getSortKey(), this.getClassificationSymbolCode());
            String thatSymbolString = CollectionScanner.coalesce(that.getSortKey(), that.getClassificationSymbolCode());
            ret = new ClassSymbolNameComparator().compare(thisSymbolString, thatSymbolString);
        }
        return ret;
    }

    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        if (this.getClassificationScheme() != null && this.getClassificationScheme().getSchemeVersionDate() != null) {
            result = prime * result + this.getClassificationScheme().getSchemeVersionDate().hashCode();
        }
        result = prime * result + (classificationSymbolCode == null ? 0 : classificationSymbolCode.hashCode());
        result = prime * result + (sortKey == null ? 0 : sortKey.hashCode());
        return result;
    }

    /**
     * Performs equals by comparing SchemeVersionDate (from
     * classificationScheme) + classificationSymbolCode + SortKey
     * 
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = true;
        if (obj == null || !SchemeHierarchy.class.isAssignableFrom(obj.getClass())) {
            ret = false;
        } else {
            SchemeHierarchy thatObj = (SchemeHierarchy) obj;
            String me = serializeForComparison(this);
            String that = serializeForComparison(thatObj);
            ret = me.equals(that);
        }
        return ret;
    }
    
    

    public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	/**
     * This method creates "standard" serialization so that you can check
     * equals() on these objects This string is not to be confused with the
     * symbol name sorter which actually uses symbol name to sort
     * 
     * @param symbol
     * @return String
     */
    private String serializeForComparison(SchemeHierarchy symbol) {
        return "["
                + ((symbol.getClassificationScheme() != null)
                        ? new DateTime(symbol.getClassificationScheme().getSchemeVersionDate())
                                .toString(DateFormatUtils.ISO_DATE_FORMAT.getPattern())
                        : "null")
                + "].[" + symbol.getClassificationSymbolCode() + "].[" + symbol.getSortKey() + "]";

    }

}
