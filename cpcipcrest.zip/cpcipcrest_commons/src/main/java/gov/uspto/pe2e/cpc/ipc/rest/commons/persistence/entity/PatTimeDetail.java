package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for table pat_time_detail
 * 
 * @author msingh4
 * @version 1.0
 */
@Data
@Entity
@Table(name = "pat_time_detail")
public class PatTimeDetail implements Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Guid
	@Column(name = "guid_id")
	private String id;

	@NotNull
	@Column(name = "art_unit_cd")
	private String artUnit;

	@NotNull
	@Column(name = "cfk_pc_nm")
	private String coordinatorEmail;

	@NotNull
	@Column(name = "pc_first_nm")
	private String coordinatorFirstName;

	@NotNull
	@Column(name = "pc_last_nm")
	private String coordinatorLastName;

	@NotNull
	@Column(name = "ipo_cd")
	private String ipOfficeCode;

	@NotNull
	@Column(name = "employee_id")
	private String empId;

	@ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardPayPeriod.class)
	@JoinColumn(name = "pay_period_id", referencedColumnName = "pay_period_id", updatable = false, insertable = false)
	private StandardPayPeriod payPeriod;
	
	@NotNull
	@Column(name = "pay_period_id")
	private Long payPeriodId;
	
	@NotNull
	@Column(name = "leave_hrs_no", scale = 2, precision=10)
	private BigDecimal leaveHours ;
	
	@NotNull
	@Column(name = "excused_absence_hrs_no", scale = 2, precision=10)
	private BigDecimal excusedAbsenseHours;
	
	@NotNull
	@Column(name = "holiday_hrs_no", scale = 2, precision=10)
	private BigDecimal holidayHours;
	
	@NotNull
	@Column(name = "other_hrs_no", scale = 2, precision=10)
	private BigDecimal otherHours;
	
	@NotNull
	@Column(name = "detail_hrs_no", scale = 2, precision=10)
	private BigDecimal detailHours;
	
	@NotNull
	@Column(name = "non_assign_hrs_no", scale = 2, precision=10)
	private BigDecimal nonAssignHours;
	
	@NotNull
	@Column(name = "reg_clsfcn_hrs_no", scale = 2, precision=10)
	private BigDecimal regularClassHours;
	
	@NotNull
	@Column(name = "overtime_clsfcn_hrs_no", scale = 2, precision=10)
	private BigDecimal overtimeClassHours;
	
	@NotNull
	@Column(name = "comptime_earned_hrs_no", scale = 2, precision=10)
	private BigDecimal comptimeEarnedHours;
	
	@NotNull
	@Column(name = "comptime_used_hrs_no", scale = 2, precision=10)
	private BigDecimal comptimeUsedHours;
	
	@NotNull
	@Column(name = "ipc_ip5_hrs_no", scale = 2, precision=10)
	private BigDecimal ipcIp5WorkHours;
	
	@NotNull
	@Column(name = "hp_hx_hrs_no", scale = 2, precision=10)
	private BigDecimal hpHxWorkHours;

	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId;

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;
	
	
	
	public void init() {
		this.comptimeEarnedHours = BigDecimal.ZERO;
		this.comptimeUsedHours = BigDecimal.ZERO;
		this.detailHours = BigDecimal.ZERO;
		this.excusedAbsenseHours = BigDecimal.ZERO;
		this.holidayHours = BigDecimal.ZERO;
		this.leaveHours = BigDecimal.ZERO;
		this.nonAssignHours = BigDecimal.ZERO;
		this.otherHours = BigDecimal.ZERO;
		this.overtimeClassHours = BigDecimal.ZERO;
		this.regularClassHours = BigDecimal.ZERO;
		this.ipcIp5WorkHours = BigDecimal.ZERO;
		this.hpHxWorkHours = BigDecimal.ZERO;
		
	}

}
