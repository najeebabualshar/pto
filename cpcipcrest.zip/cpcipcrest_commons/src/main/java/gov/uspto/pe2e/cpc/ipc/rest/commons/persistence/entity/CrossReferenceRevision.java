package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table cross_reference_revision
 * key is cross_reference_rvsn_id
 * 
 * @author 2020
 * @version 1.12.0
 * @date: 05/09/2018
 */
@Entity
@Table(name = "cross_reference_revision", uniqueConstraints = {
		@UniqueConstraint(columnNames = { "fk_version_symbol_id", "fk_cross_reference_id" })
		 })
public class CrossReferenceRevision implements Comparable<CrossReferenceRevision>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cross_reference_rvsn_id_seq")
	@SequenceGenerator(name = "cross_reference_rvsn_id_seq", sequenceName = "cross_reference_rvsn_id_seq", allocationSize = 1)
	@Column(name = "cross_reference_rvsn_id")
	private Long id;
	
	@NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = VersionSymbol.class)
    @JoinColumn(name = "fk_version_symbol_id", referencedColumnName = "guid_id")
    private VersionSymbol versionSymbol;	
	
	@NotNull
	@ManyToOne(//cascade = CascadeType.ALL, 
		fetch = FetchType.LAZY, targetEntity = CrossReference.class)
	@JoinColumn(name = "fk_cross_reference_id", referencedColumnName = "cross_reference_id")
	private CrossReference crossReference;
	
	@Lob
	@NotNull
	@Column(name = "old_cross_reference_tx", columnDefinition = "clob")
	private String oldCrossReferenceText;
	
	@Lob
	@NotNull
    @Column(name = "new_cross_reference_tx", columnDefinition = "clob")
    private String newCrossReferenceText;

	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;
	@SuppressWarnings("CPD-END")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}	

	public VersionSymbol getVersionSymbol() {
        return versionSymbol;
    }

    public void setVersionSymbol(VersionSymbol versionSymbol) {
        this.versionSymbol = versionSymbol;
    }

    public CrossReference getCrossReference() {
        return crossReference;
    }

    public void setCrossReference(CrossReference crossReference) {
        this.crossReference = crossReference;
    }

    public String getOldCrossReferenceText() {
        return oldCrossReferenceText;
    }

    public void setOldCrossReferenceText(String oldCrossReferenceText) {
        this.oldCrossReferenceText = oldCrossReferenceText;
    }

    public String getNewCrossReferenceText() {
        return newCrossReferenceText;
    }

    public void setNewCrossReferenceText(String newCrossReferenceText) {
        this.newCrossReferenceText = newCrossReferenceText;
    }

    public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	public Integer getLockControl() {
		return lockControl;
	}

	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}
	
	 /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
	@Override
	public int compareTo(CrossReferenceRevision other) {
        return new CompareToBuilder()
        		.append(this.getOldCrossReferenceText(), 
        				other.getOldCrossReferenceText())
                .append(this.getNewCrossReferenceText(), 
                		other.getNewCrossReferenceText())
                .append(this.getCrossReference(), 
                		other.getCrossReference())
                .append(this.getVersionSymbol().getExternalId(), other.getVersionSymbol().getExternalId())
                .append(this.getCrossReference().getComponentPartCategory(),
                        other.getCrossReference().getComponentPartCategory())
                .toComparison();

	}
	
	/**
     * used for hash based collections.
     */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result 
				+ Objects.hashCode(this.getOldCrossReferenceText())
		        + Objects.hashCode(this.getNewCrossReferenceText()) 
		        + ((this.getVersionSymbol() ==  null)?0:Objects.hashCode(this.getVersionSymbol().getExternalId()))
		        + ((this.getCrossReference() == null)?0:Objects.hashCode(this.getCrossReference().getComponentPartCategory()));      
		return result;
	}
	
	
	/**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = true;
        if (obj == null) {
            ret = false;
        } else if (!CrossReferenceRevision.class.isAssignableFrom(obj.getClass())) {
            ret = false;
        } else if (obj == this) {
            ret = true;
        } else {
            CrossReferenceRevision thatObj = (CrossReferenceRevision) obj;
            String meOldReference = this.getOldCrossReferenceText();
            String thatOldReference = thatObj.getOldCrossReferenceText();
            String meNewReference = this.getNewCrossReferenceText();
            String thatNewReference = thatObj.getNewCrossReferenceText();          
            String meExternalId = this.getVersionSymbol().getExternalId();
            String thatExternalId = thatObj.getVersionSymbol().getExternalId();
            String meComponent = this.getCrossReference().getComponentPartCategory().name();
            String thatComponent = thatObj.getCrossReference().getComponentPartCategory().name();
            ret =  Objects.equals(meOldReference, thatOldReference) && Objects.equals(meNewReference, thatNewReference)
                    && Objects.equals(meExternalId, thatExternalId) && Objects.equals(meComponent, thatComponent);
        }
        return ret;
    }

	@Override
	public String toString() {
		return "CrossReferenceRevision [id=" + id + ", versionSymbol=" + versionSymbol + ", crossReference="
				+ crossReference + ", oldCrossReferenceText=" + oldCrossReferenceText + ", newCrossReferenceText="
				+ newCrossReferenceText + "]";
	}
}
