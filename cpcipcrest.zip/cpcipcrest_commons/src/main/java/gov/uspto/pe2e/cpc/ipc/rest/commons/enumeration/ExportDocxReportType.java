package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * This enum defines what type of proposal revision report is being exported. At the time of the
 * this writing, 2 valid types are SCT and CICL
 * 
 * @author 2020
 * @date Dec 20, 2016 10:56:27 AM
 * @version 1.6
 */
public enum ExportDocxReportType {
    SCT ("templates/proposal/proposal_revision_sct_xhtml.tpl"), 
    CICL ("templates/proposal/proposal_revision_cicl_xhtml.tpl"), 
    RCL ("templates/proposal/proposal_revision_rcl_xhtml.tpl"), 
    DEF ("templates/proposal/proposal_revision_def_xhtml.tpl"),
    CRL ("templates/proposal/proposal_revision_crl_xhtml.tpl"),
    STATISTICS ("templates/proposal/proposal_revision_statistics_xhtml.tpl"),
    PCS ("templates/proposal/proposal_cover_sheet_xhtml.tpl"),
    VALIDATION ("templates/proposal/proposal_validation_report_xhtml.tpl");
    
    private String templatePath;

    private ExportDocxReportType(String templatePath) {
        this.templatePath = templatePath;
    }

    /**
     * @return the templatePath
     */
    public String getTemplatePath() {
        return templatePath;
    }
    
    
}
