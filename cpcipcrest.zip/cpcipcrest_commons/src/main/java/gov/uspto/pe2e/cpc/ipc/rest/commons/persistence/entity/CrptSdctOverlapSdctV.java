package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;

import org.apache.commons.lang3.builder.CompareToBuilder;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


/**
 * The persistent class for the CRPT_SDCT_OVERLAP_SDCT_V view.
 * 
 */
@Entity
@Table(name="crpt_sdct_overlap_sdct_v")
@Data
public class CrptSdctOverlapSdctV implements Comparable<CrptSdctOverlapSdctV>, Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
    @Guid
    @Column(name="GUID_ID")
	private String guidId;
		
	@Column(name = "NO_OF_PROJECTS_IMPACT_NO")
	private Long noOfProjectsImpactNo;

	@Column(name = "SDCT_OVERLAP_SDCT_CHANGE_PROPOSAL_ID")
	private Long sdctOverlapSdctChangeProposalId;

	@Column(name = "SDCT_OVERLAP_SDCT_GUID_ID")
	private String sdctOverlapSdctGuidId;

	@Column(name = "SDCT_OVERLAP_SDCT_PROJECT_CD")
	private String sdctOverlapSdctProjectCd;

	@Column(name = "SOURCE_GUID_ID")
	private String sourceGuidId;

	@Column(name = "SOURCE_PROJECT_CD")
	private String sourceProjectCd;

	@Column(name = "SOURCE_PROPOSAL_ID")
	private Long sourceProposalId;
	
	@Column(name = "SOURCE_SYMBOL_TX")
	private String sourceSymbolTx;
	
	@Column(name = "SCHEME_VERSION_TX")
	private String schemeVersionTx;
	
	@Column(name = "PROJECT_TYPE_CT")
	private String projectTypeCt;

	@Override
	public int compareTo(CrptSdctOverlapSdctV o) {
		return new CompareToBuilder().append(this.sourceGuidId, o.sourceGuidId)
				.append(this.sourceSymbolTx, o.sourceSymbolTx).append(this.sdctOverlapSdctProjectCd, o.sdctOverlapSdctProjectCd).toComparison();
	}

	@Override
	public String toString() {
		return "CrptSdctOverlapSdctV [guidId=" + guidId + ", noOfProjectsImpactNo=" + noOfProjectsImpactNo
				+ ", sdctOverlapSdctChangeProposalId=" + sdctOverlapSdctChangeProposalId + ", sdctOverlapSdctGuidId="
				+ sdctOverlapSdctGuidId + ", sdctOverlapSdctProjectCd=" + sdctOverlapSdctProjectCd + ", sourceGuidId="
				+ sourceGuidId + ", sourceProjectCd=" + sourceProjectCd + ", sourceProposalId=" + sourceProposalId
				+ ", sourceSymbolTx=" + sourceSymbolTx + "]";
	}

}