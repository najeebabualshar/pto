package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table
 * change_proposal_assignee_group primary key column is task_assignee_group_id
 * 
 * 
 * @author 2020
 * @version 1.14.0
 * @date: October 1, 2018
 *
 */
@Entity
@Table(name = "change_proposal_assignee_group")
public class ChangeProposalAssigneeGroup implements Comparable<ChangeProposalAssigneeGroup>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
 
    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "task_assignee_group_id_seq")
    @SequenceGenerator(name = "task_assignee_group_id_seq", sequenceName = "task_assignee_group_id_seq", allocationSize = 1)
    @Column(name = "task_assignee_group_id")
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalStateTask.class)
    @JoinColumn(name = "fk_state_task_id", referencedColumnName = "state_task_id")
    private ChangeProposalStateTask task;

    @NotNull
    @Column(name = "fk_assignee_role_cd")
    @Enumerated(EnumType.STRING)
    private OfficeContactType role;

    @NotNull
    @Column(name = "fk_assignee_ipo_cd")
    @Enumerated(EnumType.STRING)
    private StandardIpOfficeCode ipOfficeCode;

    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    /**
     * @return Long id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return ChangeProposalStateTask task
     */
    public ChangeProposalStateTask getTask() {
        return task;
    }

    /**
     * @param task
     *            the task to set
     */
    public void setTask(ChangeProposalStateTask task) {
        this.task = task;
    }

    /**
     * @return OfficeContactType role
     */
    public OfficeContactType getRole() {
        return role;
    }

    /**
     * @param role
     *            the role to set
     */
    public void setRole(OfficeContactType role) {
        this.role = role;
    }

    /**
     * @return StandardIpOfficeCode ipOfficeCode
     */
    public StandardIpOfficeCode getIpOfficeCode() {
        return ipOfficeCode;
    }

    /**
     * @param ipOfficeCode
     *            the ipOfficeCode to set
     */
    public void setIpOfficeCode(StandardIpOfficeCode ipOfficeCode) {
        this.ipOfficeCode = ipOfficeCode;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     *            the createUserId to set
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     *            the createTs to set
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
        result = prime * result + ((createUserId == null) ? 0 : createUserId.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((ipOfficeCode == null) ? 0 : ipOfficeCode.hashCode());
        result = prime * result + ((role == null) ? 0 : role.hashCode());
        result = prime * result + ((task == null) ? 0 : task.hashCode());
        return result;
    }

    /**
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = false;
        if (obj != null) {
            if (obj == this) {
                ret = true;
            } else if (ChangeProposalAssigneeGroup.class.isAssignableFrom(obj.getClass())) {
                ChangeProposalAssigneeGroup that = (ChangeProposalAssigneeGroup) obj;
                ret = new EqualsBuilder().append(getTask(), that.getTask())
                        .append(getIpOfficeCode(), that.getIpOfficeCode()).append(getRole(), that.getRole()).isEquals();
            }
        }
        return ret;
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ChangeProposalAssigneeGroup other) {
        return new CompareToBuilder().append(this.getTask(), other.getTask())
                .append(this.getIpOfficeCode(), other.getIpOfficeCode()).append(this.getRole(), other.getRole())
                .toComparison();
    }

	@Override
	public String toString() {
		return "ChangeProposalAssigneeGroup [id=" + id + ", task=" 
				+ ((task != null)?task.getTaskDefinitionKey():"null") 
				+ ", role=" + ((role != null)?role.name():"null") 
				+", assignee="+((task != null)?task.getAssignee():"null") 
				+ ", ipOfficeCode="
				+ ipOfficeCode + ", createUserId=" + createUserId + ", createTs=" + createTs + "]";
	}
    
    
    
}
