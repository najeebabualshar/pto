
package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import jakarta.xml.bind.annotation.XmlEnum;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ExternalSystemCategory.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ExternalSystemCategory"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CE"/&gt;
 *     &lt;enumeration value="CEF"/&gt;
 *     &lt;enumeration value="CPC"/&gt;
 *     &lt;enumeration value="IP5"/&gt;
 *     &lt;enumeration value="IPC"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ExternalSystemCategory")
@XmlEnum
public enum ExternalSystemCategory {


    /**
     * CE is the Alias category for THIS APPLCIATION.  This is the 
     *                     only category for which we can generate our own aliases as opposed to  have them 
     *                     entered or added by users/workflow input
     * 
     */
    CE,
    CEF,
    CPC,
    IP5,
    IPC,
    USER_DEFINED;


    public static ExternalSystemCategory fromValue(String v) {
    	return valueOf(v);
    }

}
