package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * 
 * Enum class for the Tenant.
 * This is need for RBAC - Granted Authorities
 * 
 * @author 2020
 * @date Jan 15, 2016 12:49:57 PM
 * @version 
 */
public enum Tenant {
	PTO("US"),
	EPO("EP");
	private String ipOfficeCode;

	private Tenant(String ipOfficeCode) {
		this.ipOfficeCode = ipOfficeCode;
	}

	public String getIpOfficeCode() {
		return ipOfficeCode;
	}
	
}
