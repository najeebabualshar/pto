package gov.uspto.pe2e.cpc.ipc.rest.commons.model.validator;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.I18nMessageKey;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SymbolNameStructure;

/**
 * do all the Symbol Name Structure validation here
 * 
 * @TODO when time permits, come back and figure out if you can force spring to
 *       layer validators IE: 1) bean validator 2) method validator .... This
 *       would allow custom validations to be chained and run without polluting
 *       the web code with framework responsibilities
 * 
 *       for more details about custom spring validators, see here for examples:
 *       http://www.journaldev.com/2668/spring-mvc-form-validation-example-using
 *       -annotation-and-custom-validator-implementation
 *       http://copyrightdev.tumblr.com/post/92560458673/tips-tricks-having-fun-
 *       with-spring-validators
 *       http://stackoverflow.com/questions/19425221/spring-validated-in-service
 *       -layer
 * 
 * @author 2020
 * @date Mar 14, 2016
 * @version
 *
 */
@Component
public class SymbolNameStructureValidator implements Validator {
	private static final Logger log = LoggerFactory.getLogger(SymbolNameStructureValidator.class);

	/**
	 * Returns true if class is assignable to SymbolNameStructure
	 * 
	 * @see org.springframework.validation.Validator.supports(Class<?>)
	 */
	@Override
	public boolean supports(Class<?> symbolNameStructure) {
		return SymbolNameStructure.class.isAssignableFrom(symbolNameStructure.getClass());
	}

	/**
	 * validates the symbolnamestructure object
	 * 
	 * @see org.springframework.validation.Validator.validate(Object, Errors)
	 */
	@Override
	public void validate(Object symbolNameStructObj, Errors errors) {
		try {
			if (symbolNameStructObj == null) {
				errors.reject(I18nMessageKey.SYMBOL_NAME_STRUCT_CANNOT_BE_NULL.name());
			} else {
				SymbolNameStructure struct = (SymbolNameStructure) symbolNameStructObj;
				rejectIfAnyEmpty(errors, struct);
			}

		} catch (Exception e) {
			if (ClassCastException.class.isAssignableFrom(e.getClass())) {
				log.error("Really unexpected error", e);
			}
			errors.reject(I18nMessageKey.SYMBOL_NAME_STRUCT_INVALID_TYPE.name());
		}

	}

	/**
	 * NOTE THIS RELIES HEAVILY ON ORDERING OF FIELDS IN XSD. VERY DIRTY!
	 * 
	 * @param errors
	 * @param struct
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	private void rejectIfAnyEmpty(Errors errors, SymbolNameStructure struct)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		Field[] fields = removeStatics(SymbolNameStructure.class.getDeclaredFields());
		// Skipping the first field and last field in the class since that is the
		// fullSymbolName, sortKey which are not validated
		for (int i = fields.length - 2; i > 0; i--) {
			if (!StringUtils.isBlank((String) PropertyUtils.getProperty(struct, fields[i].getName()))) {
				for (int j = i - 1; j > 0; j--) {
					if (StringUtils.isBlank((String) PropertyUtils.getProperty(struct, fields[j].getName()))) {
						errors.rejectValue(fields[j].getName(),
								I18nMessageKey.SYMBOL_NAME_STRUCT_DEPENDANT_FIELD_MISSING.name(),
								new Object[] { fields[j].getName() },
								I18nMessageKey.SYMBOL_NAME_STRUCT_DEPENDANT_FIELD_MISSING.name());
					}

				}
			}
		}
		log.debug("Arrays {} = {}", fields.length, fields);
	}

	/**
	 * Eliminates static fields which are not instance data (such as the serialVersionUID field)
	 * from the list
	 * @param declaredFields
	 * @return
	 * @since Sep 25, 2017
	 */
    private Field[] removeStatics(Field[] declaredFields) {
        List<Field> flds = new ArrayList<>();
        for (Field f: declaredFields) {
            if (!Modifier.isStatic(f.getModifiers())) {
                flds.add(f);
            }
        }
        return flds.toArray(new Field[]{});
    }

}
