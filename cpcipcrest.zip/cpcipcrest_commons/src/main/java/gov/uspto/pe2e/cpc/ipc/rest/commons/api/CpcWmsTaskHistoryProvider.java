package gov.uspto.pe2e.cpc.ipc.rest.commons.api;

import java.util.List;
import java.util.UUID;

import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskStateDetails;

public interface CpcWmsTaskHistoryProvider {
	/**
	 * returns a List of TaskStateDetails objects representing completed tasks 
	 * for a given proposal 
	 * in completeTs Descending order
	 * 
	 */
	public List<TaskStateDetails> fetchTaskHistory(UUID id);
}
