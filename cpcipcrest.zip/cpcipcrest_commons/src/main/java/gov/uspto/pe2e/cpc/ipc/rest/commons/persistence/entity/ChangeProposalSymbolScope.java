package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * updated to match view rather than real table.  This view constructs the scope on the fly
 * with data in the SCT rows and reclass_transfer table
 * 
 * @author 2020
 * @version 1.14.0
 * @date: October 20, 2018
 *
 */
@Entity
@Table(name = "change_proposal_symbol_scope_v")
public class ChangeProposalSymbolScope implements Comparable<ChangeProposalSymbolScope>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Guid 
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_scope_id_seq")
//	@SequenceGenerator(name = "change_proposal_scope_id_seq", sequenceName = "change_proposal_scope_id_seq", initialValue = 1, allocationSize = 1)
	@Column(name = "change_proposal_scope_id" , updatable = false, insertable = false)
	private String id; // this is a random guid column just to trick hibernate into thinking it has a real ID

	@NotNull
	@Column(name = "classification_symbol_cd")
	private String classificationSymbolCode;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
	@JoinColumn(name = "change_proposal_id", referencedColumnName = "change_proposal_id")
	private ChangeProposal changeProposal;

	@ManyToOne(fetch = FetchType.LAZY, targetEntity = ClassificationScheme.class)
	@JoinColumn(name = "fk_classification_scheme_id", referencedColumnName = "classification_scheme_id")
	private ClassificationScheme classificationScheme;

	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	@SuppressWarnings("CPD-END")

	/**
	 * @return Long id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the classificationSymbolCode
	 */
	public String getClassificationSymbolCode() {
		return classificationSymbolCode;
	}

	/**
	 * @param classificationSymbolCode
	 *            the classificationSymbolCode to set
	 */
	public void setClassificationSymbolCode(String classificationSymbolCode) {
		this.classificationSymbolCode = classificationSymbolCode;
	}

	/**
	 * @return ChangeProposal
	 */
	public ChangeProposal getChangeProposal() {
		return changeProposal;
	}

	/**
	 * @param ChangeProposal
	 */
	public void setChangeProposal(ChangeProposal changeProposal) {
		this.changeProposal = changeProposal;
	}

	/**
	 * @return String createUserId
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/**
	 * @param String
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/**
	 * @return Date createTs
	 */
	public Date getCreateTs() {
		return createTs;
	}

	/**
	 * @param Date
	 */
	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	/**
	 * @return Integer lockControl
	 */
	public Integer getLockControl() {
		return lockControl;
	}

	/**
	 * @param Integer
	 */
	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}

	/**
	 * used for hash based collections.
	 */
	@Override
	public int hashCode() {
		final int prime = 37;
		int result = 1;
		result = prime * result + ((this.getId() != null) ? this.getId().hashCode() : 0)
				+ this.getChangeProposal().getExternalId().hashCode() + this.getClassificationSymbolCode().hashCode();
		return result;
	}

	/**
	 * Indicates whether some other object is "equal to" this one
	 */
	@Override
	public boolean equals(Object obj) {
		boolean ret = true;
		if (obj == null) {
			ret = false;
		} else if (!ChangeProposalSymbolScope.class.isAssignableFrom(obj.getClass())) {
			ret = false;
		} else if (obj == this) {
			ret = true;
		} else {
			ChangeProposalSymbolScope thatObj = (ChangeProposalSymbolScope) obj;
			String meChangeProposal = this.getChangeProposal().getExternalId();
			String thatChangeProposal = thatObj.getChangeProposal().getExternalId();
			String meSymbolCode = this.getClassificationSymbolCode();
			String thatSymbolCode = thatObj.getClassificationSymbolCode();
			ret = Objects.equals(meChangeProposal, thatChangeProposal) && Objects.equals(meSymbolCode, thatSymbolCode);
		}
		return ret;
	}

	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ChangeProposalSymbolScope other) {
		return new CompareToBuilder().append(this.getId(), other.getId())
				.append(this.getCreateTs(), other.getCreateTs()).toComparison();
	}

	/**
	 * @return the classificationScheme
	 */
	public ClassificationScheme getClassificationScheme() {
		return classificationScheme;
	}

	/**
	 * @param classificationScheme
	 *            the classificationScheme to set
	 */
	public void setClassificationScheme(ClassificationScheme classificationScheme) {
		this.classificationScheme = classificationScheme;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChangeProposalSymbolScope [id=" + id + ", changeProposal="
				+ ((changeProposal != null) ? changeProposal.getId() : "null") + ", classificationScheme="
				+ ((classificationScheme != null) ? classificationScheme.getId() : "null") + ", createUserId="
				+ createUserId + ", createTs=" + createTs + ", lockControl=" + lockControl + "]";
	}

}
