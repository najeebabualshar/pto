package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;


/**
 * Entity Class for handling ORM Persistence for table stnd_ip_office primary
 * key is ipo_cd
 * 
 * 
 * @author 2020
 * @version 1.3
 * @date: 03/10/2016
 *
 */
@Entity
@Table(name = "stnd_ip_office")
public class StandardIpOffice implements Serializable{

    /**
     * Allowing serialization of datamodel elements 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Enumerated(EnumType.STRING)
    @NotNull
    @Column(name = "ipo_cd")
    private StandardIpOfficeCode ipoCode; // VARCHAR2(2)

    @NotNull
    @Column(name = "ipo_nm", unique = true)
    private String ipoName; // VARCHAR2(25)

    @Column(name = "description_tx")
    private String description; // VARCHAR2(500)

    @NotNull
    @Column(name = "begin_effective_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date beginEffectiveDt;

    @Column(name = "end_effective_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date endEffectiveDt;

    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    
    @LastModifiedBy 
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate   
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    /**
     * @return StandardIpOfficeCode ipoCode
     */
    public StandardIpOfficeCode getIpoCode() {
        return ipoCode;
    }

    /**
     * @param ipoCode
     */
    public void setIpoCode(StandardIpOfficeCode ipoCode) {
        this.ipoCode = ipoCode;
    }

    /**
     * @return String ipoName
     */
    public String getIpoName() {
        return ipoName;
    }

    /**
     * @param ipoName
     */
    public void setIpoName(String ipoName) {
        this.ipoName = ipoName;
    }

    /**
     * @return String description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return Date beginEffectiveDt
     */
    public Date getBeginEffectiveDt() {
        return beginEffectiveDt;
    }

    /**
     * @param beginEffectiveDt
     */
    public void setBeginEffectiveDt(Date beginEffectiveDt) {
        this.beginEffectiveDt = beginEffectiveDt;
    }

    /**
     * @return Date endEffectiveDt
     */
    public Date getEndEffectiveDt() {
        return endEffectiveDt;
    }

    /**
     * @param endEffectiveDt
     */
    public void setEndEffectiveDt(Date endEffectiveDt) {
        this.endEffectiveDt = endEffectiveDt;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }    

    /**
     * @return String lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return Date lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @return Integer lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }
}
