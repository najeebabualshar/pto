package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * This enum defines list of resource checkout failure reasons
 * 
 * @author 2020
 * @date Dec 20, 2016 10:56:27 AM
 * @version 1.6
 */
public enum ResourceCheckoutFailureReason {
    RESOURCE_DOES_NOT_EXIST,
    RESOURCE_ALREADY_LOCKED_BY_OTHER_USER,
    MAX_LOCKS_ALLOWED_BY_USER;
}
