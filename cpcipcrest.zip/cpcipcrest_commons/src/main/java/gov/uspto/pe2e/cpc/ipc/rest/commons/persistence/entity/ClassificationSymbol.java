package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.CollectionScanner;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table classification_symbol
 * primary key is symbol_id
 * 
 * 
 * @author 2020
 * @version 1.5
 * @date: 09/12/2016
 *
 */
@Deprecated // All refererences to this table were removed as part of US334243
@Entity
@Table(name = "classification_symbol", uniqueConstraints = {
        @UniqueConstraint(columnNames = { "symbol_id", "full_symbol_tx" }) })
public class ClassificationSymbol implements Comparable<ClassificationSymbol>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "classification_symbol_id_seq")
    @SequenceGenerator(name = "classification_symbol_id_seq", 
                    sequenceName = "classification_symbol_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "symbol_id")
    private Long id;

    @NotNull
    @Column(name = "full_symbol_tx", length = 50)
    private String fullSymbolName; // VARCHAR2(50)

    @Column(name = "section_cd", insertable = false, updatable = false)
    private String sectionCode; // VARCHAR2(4)

    @Column(name = "class_cd", insertable = false, updatable = false)
    private String classCode; // VARCHAR2(8)

    @Column(name = "subclass_cd", insertable = false, updatable = false)
    private String subClassCode; // VARCHAR2(4)

    @Column(name = "maingroup_cd", insertable = false, updatable = false)
    private String mainGroupCode; // VARCHAR2(184)

    @Column(name = "subgroup_cd", insertable = false, updatable = false)
    private String subGroupCode; // VARCHAR2(200)

    @NotNull
    @Column(name = "symbol_add_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date symbolAddDt;

    @Column(name = "symbol_delete_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date symbolDeleteDt;

    @NotNull
    @Convert(converter = YesNoConverter.class)
    @Column(name = "dummy_in", columnDefinition = "char(1)")
    private Boolean dummy; // Number

    @NotNull
    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @NotNull
    @CreatedBy
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @NotNull
    @LastModifiedDate
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @LastModifiedBy
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;

    /**
     * @return the id
     * @since May 18, 2016
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     * @since May 18, 2016
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return String fullSymbol
     */
    public String getFullSymbolName() {
        return fullSymbolName;
    }

    /**
     * @param fullSymbol
     */
    public void setFullSymbolName(String fullSymbolName) {
        this.fullSymbolName = fullSymbolName;
    }

    /**
     * @return String sectionCode
     */
    public String getSectionCode() {
        return sectionCode;
    }

    /**
     * @param sectionCode
     */
    public void setSectionCode(String sectionCode) {
        this.sectionCode = sectionCode;
    }

    /**
     * @return String classCode
     */
    public String getClassCode() {
        return classCode;
    }

    /**
     * @param classCode
     */
    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    /**
     * @return String subClassCode
     */
    public String getSubClassCode() {
        return subClassCode;
    }

    /**
     * @param subClassCode
     */
    public void setSubClassCode(String subClassCode) {
        this.subClassCode = subClassCode;
    }

    /**
     * @return String mainGroupCode
     */
    public String getMainGroupCode() {
        return mainGroupCode;
    }

    /**
     * @param mainGroupCode
     */
    public void setMainGroupCode(String mainGroupCode) {
        this.mainGroupCode = mainGroupCode;
    }

    /**
     * @return String subGroupCode
     */
    public String getSubGroupCode() {
        return subGroupCode;
    }

    /**
     * @param subGroupCode
     */
    public void setSubGroupCode(String subGroupCode) {
        this.subGroupCode = subGroupCode;
    }

    /**
     * @return Date symbolAddDt
     */
    public Date getSymbolAddDt() {
        return symbolAddDt;
    }

    /**
     * @param symbolAddDt
     */
    public void setSymbolAddDt(Date symbolAddDt) {
        this.symbolAddDt = symbolAddDt;
    }

    /**
     * @return Date symbolDeleteDt
     */
    public Date getSymbolDeleteDt() {
        return symbolDeleteDt;
    }

    /**
     * @param symbolDeleteDt
     */
    public void setSymbolDeleteDt(Date symbolDeleteDt) {
        this.symbolDeleteDt = symbolDeleteDt;
    }

    /**
     * @return Boolean dummy
     */
    public Boolean getDummy() {
        return dummy;
    }

    /**
     * @param dummy
     */
    public void setDummy(Boolean dummy) {
        this.dummy = dummy;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @return String lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return Integer lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ClassificationSymbol other) {
        return new CompareToBuilder().append(this.getId(), other.getId())
                .append(this.getFullSymbolName(), other.getFullSymbolName()).append(this.getDummy(), other.getDummy())
                .toComparison();
    }

    /**
     * The only 2 fields that would be relevant to a hash code (assuming not
     * used as key) would be ID and full symbolname
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((fullSymbolName == null) ? 0 : fullSymbolName.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    /**
     * Check equality of 2 different classification Symbols (for right now Only
     * tests symbol name)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        boolean eq = Boolean.FALSE;
        if(obj == null || !(obj instanceof ClassificationSymbol)) {
        	eq = false;         
        } else if (ClassificationSymbol.class.isAssignableFrom(obj.getClass()) && obj == this){
        	eq = true; 
        } else  {
            ClassificationSymbol that = (ClassificationSymbol) obj;
            String[] symbolNamesToCompare = new String[] { this.getFullSymbolName(), that.getFullSymbolName() };
            if (CollectionScanner.countNonNull(symbolNamesToCompare) == symbolNamesToCompare.length) {
                SymbolName thisName = new SymbolName(this.getFullSymbolName());
                SymbolName thatName = new SymbolName(that.getFullSymbolName());
                if (thisName.equals(thatName) && Objects.equals(this.getId(), that.getId())) {
                    eq = true;
                }
            }
        }
        return eq;
    }

    @Override
    public String toString() {
        return "ClassificationSymbol [id=" + id + ", fullSymbolName=" + fullSymbolName + ", symbolAddDt=" + symbolAddDt
                + ", symbolDeleteDt=" + symbolDeleteDt + ", dummy=" + dummy + ", createTs=" + createTs
                + ", createUserId=" + createUserId + "]";
    }

}
