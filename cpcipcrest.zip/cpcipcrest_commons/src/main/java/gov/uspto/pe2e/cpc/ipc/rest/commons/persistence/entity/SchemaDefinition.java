package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.SchemaDefinitionPublicationCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

/**
 * Entity Class for handling ORM Persistence for table scheme_definition primary
 * key column is scheme_definition_id
 * 
 * 
 * @author 2020
 * @version 1.1
 * @date: 11/12/2015
 *
 */
@Entity
@Table(name = "schema_definition")
public class SchemaDefinition implements Serializable {

    /**
     * Allowing serialization of data model elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "schema_definition_seq")
    @SequenceGenerator(name = "schema_definition_seq", 
                sequenceName = "schema_definition_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "schema_definition_id")
    private Long id;

    @Column(name = "schema_version_id")
    private String schemaVersionId;

    @Column(name = "description_tx")
    private String description;

    @Column(name = "schema_version_ct")
    private String schemaVersionCategory;

    @Enumerated(EnumType.STRING)
    @Column(name = "schema_definition_ct", columnDefinition = "varchar2")
    private SchemaDefinitionPublicationCategory schemaDefinitionCategory;

    @CreatedBy
    @Column(name = "create_user_id")
    private String createUserId;

    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    /**
     * @return Long id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return String description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return
     */
    public String getSchemaVersionId() {
        return schemaVersionId;
    }

    /**
     * @param schemaVersionId
     */
    public void setSchemaVersionId(String schemaVersionId) {
        this.schemaVersionId = schemaVersionId;
    }

    /**
     * @return
     */
    public String getSchemaVersionCategory() {
        return schemaVersionCategory;
    }

    /**
     * @param schemeVersionCategory
     */
    public void setSchemaVersionCategory(String schemaVersionCategory) {
        this.schemaVersionCategory = schemaVersionCategory;
    }

    /**
     * @return
     */
    public SchemaDefinitionPublicationCategory getSchemaDefinitionCategory() {
        return schemaDefinitionCategory;
    }

    /**
     * @param schemeDefinitionCategory
     */
    public void setSchemaDefinitionCategory(SchemaDefinitionPublicationCategory schemaDefinitionCategory) {
        this.schemaDefinitionCategory = schemaDefinitionCategory;
    }
}
