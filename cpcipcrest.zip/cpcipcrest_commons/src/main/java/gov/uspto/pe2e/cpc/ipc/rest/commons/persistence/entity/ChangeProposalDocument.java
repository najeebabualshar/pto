package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DocumentPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentVersionClassificationCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationPhase;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table change_proposal_doc primary
 * key is change_proposal_doc_id
 * 
 * @author 2020
 * @version 2.0.0
 * @date: 01/26/2021
 *
 */
@Entity
@Table(name = "change_proposal_doc", uniqueConstraints = {  
        @UniqueConstraint(columnNames = { "change_proposal_doc_id" }),
        @UniqueConstraint(columnNames = { "guid_id" }),
        @UniqueConstraint(columnNames = { "fk_change_proposal_id",  "anx_no" }) 
        })
@Data
//TODO: Develop  real Equals() and hashcode Methods
//@EqualsAndHashCode
public class ChangeProposalDocument implements Comparable<ChangeProposalDocument>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_doc_id_seq")
    @SequenceGenerator(name = "change_proposal_doc_id_seq", sequenceName = "change_proposal_doc_id_seq", initialValue = 1, 
                 allocationSize = 1)
    @Column(name = "change_proposal_doc_id")
    private Long id;

    
    @Guid
    @NotNull
    @Column(name = "guid_id")
    private String externalId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
    
    
    @NotNull
    @Column(name = "anx_no")
    private Integer anxNumber; // VARCHAR2(500)
    
    @NotNull
    @Column(name = "document_nm")
    private String name; // VARCHAR2(500)    
    
    @NotNull
    @Column(name = "document_id") // Also known as a folder path with file name in S3
    private String documentId;
    
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "fk_doc_type_cd")
    private ProposalDocumentTypeCode typeCode;
  
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "fk_doc_version_cd")
    private ProposalDocumentVersionClassificationCode versionCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "fk_ipo_cd")
    private StandardIpOfficeCode standardIpOfficeCode;
    
    @Column(name = "upload_comment_tx", length = 4000)
    private String uploadComment; // VARCHAR2(500)    
                              
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "doc_phase_ct")
    private DocumentPhase phase;
    
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "pub_phase_ct")
    private PublicationPhase pubPhase;

    @NotNull
    @Convert(converter = YesNoConverter.class)
    @Column(name = "delete_in", columnDefinition = "char(1)")
    private Boolean deleted; // archived flag   
    
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    @OrderBy("id")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, 
                        mappedBy = "changeProposalDocument", targetEntity = ChangeProposalDocumentApproval.class)
    private Set<ChangeProposalDocumentApproval> approvals; // At most, none should ever have more than 4 of these
    


    @OrderBy("create_ts asc")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "document", targetEntity = ChangeProposalIssueDocument.class)
	private Set<ChangeProposalIssueDocument> referencedIssues;
	
	public Set<ChangeProposalIssueDocument> getReferencedIssues() {
		if (this.referencedIssues == null) {
			this.referencedIssues = new TreeSet<>();
		}
		return this.referencedIssues;
	}
    
    /**
     * Adds ChangeProposalVersion to the list
     * 
     * @param child
     */
    public void add(ChangeProposalDocumentApproval child) {
        getApprovals().add(child);
    }
    
    /**
     * @return the changeProposalOffices
     * @since April 07, 2018
     */
    public Set<ChangeProposalDocumentApproval> getApprovals() {
        if (this.approvals == null) {
            this.approvals = new TreeSet<>();
        }
        return approvals;
    }
    
    /**
     * @return the changeProposerRoles
     * @since April 07, 2018
     */

    @Override
    public int compareTo(ChangeProposalDocument other) {
        
        return new CompareToBuilder()
                .append(Optional.ofNullable(this.getChangeProposal()).orElse(new ChangeProposal()).getId(), 
                        Optional.ofNullable(other.getChangeProposal()).orElse(new ChangeProposal()).getId())
                .append(this.getAnxNumber(), other.getAnxNumber())
                .toComparison();
                
    }

   
    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((changeProposal == null) ? 0 : changeProposal.hashCode());
        result = prime * result + ((anxNumber == null) ? 0 : anxNumber.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((documentId == null) ? 0 : documentId.hashCode());
        result = prime * result + ((uploadComment == null) ? 0 : uploadComment.hashCode());
        result = prime * result + ((versionCode == null) ? 0 : versionCode.hashCode());
        result = prime * result + ((deleted == null) ? 0 : deleted.hashCode());
        result = prime * result + ((standardIpOfficeCode == null) ? 0 : standardIpOfficeCode.hashCode());
        result = prime * result + ((phase == null) ? 0 : phase.hashCode());
        return result;
    }

    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = false;

        if (obj != null) {
            if (obj == this) {
                ret = true;
            } else if (ChangeProposalDocument.class.isAssignableFrom(obj.getClass())) {
                ChangeProposalDocument that = (ChangeProposalDocument) obj;
                ret = new EqualsBuilder()
                        .append(getId(), that.getId())
                        .append(getChangeProposal(), that.getChangeProposal())
                        .append(getExternalId(), that.getExternalId())
                        .append(getAnxNumber(), that.getAnxNumber())
                        .append(getName(), that.getName())
                        .append(getDocumentId(), that.getDocumentId())
                        .append(getVersionCode(), that.getVersionCode())
                        .append(getDeleted(), that.getDeleted())
                        .append(getPhase(), that.getPhase())
                        .isEquals();
            }
        }
        return ret;
    }

	@Override
	public String toString() {
		return "ChangeProposalDocument [id=" + id + ", externalId=" + externalId + ", changeProposal=" 
				+ ((changeProposal != null)?changeProposal.getId():"null")
				+ ", anxNumber=" + anxNumber + ", name=" + name + ", documentId=" + documentId + ", typeCode="
				+ typeCode + ", versionCode=" + versionCode + ", standardIpOfficeCode=" + standardIpOfficeCode
				+ ", uploadComment=" + uploadComment + ", phase=" + phase + ", pubPhase=" + pubPhase + ", deleted="
				+ deleted + ", createUserId=" + createUserId + ", createTs=" + createTs + ", lastModifiedUserId="
				+ lastModifiedUserId + ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl
				+ ", approvals=" + approvals + ", referencedIssues=" + referencedIssues + "]";
	}
    
    
    
    
    
    
}
