package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;

import org.apache.commons.lang3.builder.CompareToBuilder;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * My Task View - This view as current assigned task users info
 * @author msingh4
 *
 */
@Entity
@Table(name = "my_task_v")
@Data
public class MyTaskView implements Comparable<MyTaskView>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

    @NotNull
	@OneToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
	private ChangeProposal changeProposal;
    
    @NotNull
    @Column(name = "change_proposal_alias_cd", length=20)
    private String changeProposalAliasCd;
    
    @Guid
    @NotNull
	@Column(name = "guid_id")
	private String guidId;

	@Id
	@Column(name = "fk_change_proposal_id", updatable = false, insertable = false)
	private Long id;
    
    @Column(name = "cfk_task_assignee_role_tx")
	private String taskAssigneeRoles; 

	@Column(name = "us_pc_nm")
	private String usCoordinator;
	
	@Column(name = "ep_pc_nm")
	private String epCoordinator;
	
	@Column(name = "us_sce_nm")
	private String usSCE;
	
	@Column(name = "us_backup_sce_nm")
	private String usBackupSCE;
 
	@Column(name = "us_eb_nm")
	private String usEditorialBoard;

	@Column(name = "ep_eb_nm")
	private String epEditorialBoard;
	
	@Column(name = "us_scespe_nm")
	private String usSupervisoryClassificationOrPatentExaminer;
					
	@Column(name = "us_spc_nm")
	private String usSupervisoryPatentClassifier;
	
	@Column(name = "ep_gerant_nm")
	private String epGerant;
	
	@Column(name = "ep_cbm_nm")
	private String epClassificationBoardMember;
			
	@Column(name = "us_reclass_mgr_nm")
	private String usReclassManager;

	@Column(name = "ep_reclass_mgr_nm")
	private String epReclassManager;
	
	@Column(name = "pub_writer_editor_nm")
	private String publicationWriterEditor;
	
	@Column(name = "pub_specialist_nm")
	private String publicationSpecialist;
	
	@Column(name = "pub_mgr_nm")
	private String publicationManager;	
	
	@Override
	public int compareTo(MyTaskView o) {
		return new CompareToBuilder().append(this.changeProposal, o.changeProposal).toComparison();
	}

	@Override
	public String toString() {
		return "MyTaskView [changeProposal=" + 
				((changeProposal != null)?changeProposal.getId():"null") + ", changeProposalAliasCd=" + changeProposalAliasCd
				+ ", guidId=" + guidId + ", id=" + id + ", taskAssigneeRoles=" + taskAssigneeRoles + ", usCoordinator="
				+ usCoordinator + ", epCoordinator=" + epCoordinator + ", usSCE=" + usSCE + ", usBackupSCE="
				+ usBackupSCE + ", usEditorialBoard=" + usEditorialBoard + ", epEditorialBoard=" + epEditorialBoard
				+ ", usSupervisoryClassificationOrPatentExaminer=" + usSupervisoryClassificationOrPatentExaminer
				+ ", usSupervisoryPatentClassifier=" + usSupervisoryPatentClassifier + ", epGerant=" + epGerant
				+ ", epClassificationBoardMember=" + epClassificationBoardMember + ", usReclassManager="
				+ usReclassManager + ", epReclassManager=" + epReclassManager + ", publicationWriterEditor="
				+ publicationWriterEditor + ", publicationSpecialist=" + publicationSpecialist + ", publicationManager="
				+ publicationManager + "]";
	}
	
	
}
