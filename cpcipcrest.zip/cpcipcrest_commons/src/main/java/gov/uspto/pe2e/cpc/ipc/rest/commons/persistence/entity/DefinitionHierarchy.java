package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Optional;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table definition_hierarchy
 * primary key is definition_hierarchy_id
 * 
 * @author 2020
 * @date Nov 13, 2015 9:44:51 AM
 * @version 1.5
 */

@Entity
@Table(name = "definition_hierarchy", 
	uniqueConstraints = { @UniqueConstraint(name="uk_definition_hierarchy", 
		columnNames = { "fk_scheme_hierarchy_id" } // DE62931
	)})
public class DefinitionHierarchy implements Serializable, Comparable<DefinitionHierarchy> {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "definition_hierarchy_seq")
    @SequenceGenerator(name = "definition_hierarchy_seq", 
                sequenceName = "definition_hierarchy_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "definition_hierarchy_id")
    private Long id;

    @Column(name = "classification_symbol_cd")
    private String classificationSymbolCode;

    @NotNull
    @Lob
    @Column(name = "definition_tx", columnDefinition = "clob")
    private String definition;

    @CreatedBy
    @Column(name = "create_user_id")
    private String createUserId;

    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = SchemeHierarchy.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_scheme_hierarchy_id", referencedColumnName = "scheme_hierarchy_id")
    private SchemeHierarchy schemeHierarchy;

    /**
     * @return Long
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return String
     */
    public String getClassificationSymbolCode() {
        return classificationSymbolCode;
    }

    /**
     * @param classificationSymbolCode
     */
    public void setClassificationSymbolCode(String classificationSymbolCode) {
        this.classificationSymbolCode = classificationSymbolCode;
    }

    /**
     * @return String
     */
    public String getDefinition() {
        return definition;
    }

    /**
     * @param definition
     */
    public void setDefinition(String definition) {
        this.definition = definition;
    }

    /**
     * @return String
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return SchemeHierarchy
     */
    public SchemeHierarchy getSchemeHierarchy() {
        return schemeHierarchy;
    }

    /**
     * @param schemeHierarchy
     */
    public void setSchemeHierarchy(SchemeHierarchy schemeHierarchy) {
        this.schemeHierarchy = schemeHierarchy;
    }

	@Override
	public int compareTo(DefinitionHierarchy other) {
		  return new CompareToBuilder()
	                .append(Optional.ofNullable(this.getSchemeHierarchy()).orElse(new SchemeHierarchy()).getId(), 
	                        Optional.ofNullable(other.getSchemeHierarchy()).orElse(new SchemeHierarchy()).getId())
	                .append(this.getClassificationSymbolCode(), other.getClassificationSymbolCode())
	                .append(this.getCreateTs(), other.getCreateTs())
	                .append(this.getId(), other.getId())
	                .toComparison();
	}

}
