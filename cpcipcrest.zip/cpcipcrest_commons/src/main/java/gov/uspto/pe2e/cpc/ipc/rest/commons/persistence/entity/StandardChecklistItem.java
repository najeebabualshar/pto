package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ChecklistItemType;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;

/**
 * Standard table to maintain the EB checklist items
 * 
 * @author msingh4
 *
 */
@Entity
@Table(name = "stnd_checklist_item")
public class StandardChecklistItem implements Comparable<StandardChecklistItem>, Serializable {
	
	 /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
    
    @Id
    @NotNull
    @Column(name = "checklist_item_id")
    private Long id;
       
    @NotNull
    @Column(name = "checklist_item_order_no")
    private Long checklistOrderNum;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "checklist_item_type_ct")
    private ChecklistItemType checklistItemType;
    
    @NotNull
    @Column(name = "checklist_item_tx")
    private String checklistItemTx;
    
    @NotNull
    @Column(name = "begin_effective_dt")
    @Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date beginEffectiveDate;
    
    @Column(name = "end_effective_dt")
    @Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date endEffectiveDate;
    
	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;
	
	@OrderBy("id")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, 
                        mappedBy = "standardChecklistItem", targetEntity = ChangeProposalEBChecklist.class)
    private Set<ChangeProposalEBChecklist> checkList;
    
	/**
     * Adds ChangeProposalEBChecklist to the list
     * 
     * @param child
     */
    public void add(ChangeProposalEBChecklist child) {
    	getCheckList().add(child);
    }
    
    /**
     * @return the checkList
     * @since November 24, 2021
     */
    public Set<ChangeProposalEBChecklist> getCheckList() {
        if (this.checkList == null) {
            this.checkList = new TreeSet<>();
        }
        return checkList;
    }
    
	@Override
	public int compareTo(StandardChecklistItem o) {
		return new CompareToBuilder().append(this.getId(), o.getId()).toComparison();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getChecklistOrderNum() {
		return checklistOrderNum;
	}

	public void setChecklistOrderNum(Long checklistOrderNum) {
		this.checklistOrderNum = checklistOrderNum;
	}

	public ChecklistItemType getChecklistItemType() {
		return checklistItemType;
	}

	public void setChecklistItemType(ChecklistItemType checklistItemType) {
		this.checklistItemType = checklistItemType;
	}

	public String getChecklistItemTx() {
		return checklistItemTx;
	}

	public void setChecklistItemTx(String checklistItemTx) {
		this.checklistItemTx = checklistItemTx;
	}

	public Date getBeginEffectiveDate() {
		return beginEffectiveDate;
	}

	public void setBeginEffectiveDate(Date beginEffectiveDate) {
		this.beginEffectiveDate = beginEffectiveDate;
	}

	public Date getEndEffectiveDate() {
		return endEffectiveDate;
	}

	public void setEndEffectiveDate(Date endEffectiveDate) {
		this.endEffectiveDate = endEffectiveDate;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	@Override
	public String toString() {
		return "StndChecklistItem [id=" + id + ", checklistOrderNum=" + checklistOrderNum + ", checklistItemType="
				+ checklistItemType + ", checklistItemTx=" + checklistItemTx + ", beginEffectiveDate="
				+ beginEffectiveDate + ", endEffectiveDate=" + endEffectiveDate + ", createUserId=" + createUserId
				+ ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId + ", lastModifiedTs="
				+ lastModifiedTs + "]";
	}
}
