package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
@Entity
@Table(name = "stnd_pap_score", uniqueConstraints={ 
//        @UniqueConstraint(
//            name="no_constraint", 
//            columnNames = { "no_column"})        
})
public class StandardPAPScore  implements Comparable<StandardPAPScore>, Serializable {

    @Id
    @Column(name = "pap_score_id")
    private Long id;
    
    
    @NotNull
   	@ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardWfTaskConfig.class)
       @JoinColumn(name = "fk_task_id", referencedColumnName = "task_id")
   	private StandardWfTaskConfig taskConfig;
    

    @Column(name="begin_range_avg_days_no")
    private BigDecimal rangeBegin;

    @Column(name="end_range_avg_days_no")
    private BigDecimal rangeEnd; // nullable
    
    @Column(name="pap_score_no")
    private Integer score;
    
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    	
    @Override
    public int compareTo(StandardPAPScore other) {
        
        return new CompareToBuilder()
        		.append(this.getRangeBegin(), other.getRangeBegin())
     //      		.append(this.getRangeEnd(), other.getRangeEnd())
           	    .append(this.getId(), other.getId())  
                .toComparison();
                
    }
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StandardPAPScore other = (StandardPAPScore) obj;
		return Objects.equals(rangeBegin, other.rangeBegin)
				&& Objects.equals(rangeEnd, other.rangeEnd)
				&& Objects.equals(score, other.score)
				&& Objects.equals(createTs, other.createTs)
				&& Objects.equals(createUserId, other.createUserId) 
				&& Objects.equals(id, other.id)
				&& Objects.equals(lastModifiedTs, other.lastModifiedTs)
				&& Objects.equals(lastModifiedUserId, other.lastModifiedUserId)
				&& Objects.equals(lockControl, other.lockControl) 
				;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id,rangeBegin, rangeEnd,
				score, taskConfig,
				createTs, createUserId,
				lastModifiedTs, lastModifiedUserId, lockControl);
	}
}
