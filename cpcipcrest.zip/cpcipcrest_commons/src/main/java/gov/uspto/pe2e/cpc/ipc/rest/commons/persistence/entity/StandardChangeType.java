package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table stnd_change_type primary
 * key is change_type_cd
 *
 * @author 2020
 * @version 1.10.0
 * @date: 12/12/2017
 *
 */
@Entity
@Table(name = "stnd_change_type")
public class StandardChangeType implements Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @Column(name = "change_type_cd")
    private String changeTypeCode;

    @Column(name = "description_tx")
    private String description;

    @NotNull
    @Column(name = "begin_effective_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date beginEffectiveDt;

    @Column(name = "end_effective_dt")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date endEffectiveDt;

    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;
    @SuppressWarnings("CPD-END")

    /**
     * @return String changeTypeCode
     */
    public String getChangeTypeCode() {
        return changeTypeCode;
    }

    /**
     * @param changeTypeCode
     */
    public void setChangeTypeCode(String changeTypeCode) {
        this.changeTypeCode = changeTypeCode;
    }

    /**
     * @return String description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return Date beginEffectiveDt
     */
    public Date getBeginEffectiveDt() {
        return beginEffectiveDt;
    }

    /**
     * @param beginEffectiveDt
     */
    public void setBeginEffectiveDt(Date beginEffectiveDt) {
        this.beginEffectiveDt = beginEffectiveDt;
    }

    /**
     * @return Date endEffectiveDt
     */
    public Date getEndEffectiveDt() {
        return endEffectiveDt;
    }

    /**
     * @param endEffectiveDt
     */
    public void setEndEffectiveDt(Date endEffectiveDt) {
        this.endEffectiveDt = endEffectiveDt;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return String lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return Date lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "StandardChangeType [changeTypeCode=" + changeTypeCode + ", description=" + description
                + ", beginEffectiveDt=" + beginEffectiveDt + ", endEffectiveDt=" + endEffectiveDt + ", createUserId="
                + createUserId + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId
                + ", lastModifiedTs=" + lastModifiedTs + "]";
    }

}
