package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalFormType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
@Entity
@Table(name = "change_proposal_dtl", uniqueConstraints={ 
        @UniqueConstraint(
            name="pk_change_proposal_dtl", 
            columnNames = { "change_proposal_dtl_id"}),
        @UniqueConstraint(columnNames = { "guid_id" })
        
})
public class ChangeProposalDetail  implements Comparable<ChangeProposalDetail>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
	public static final String CEF_ALIAS_KEY = "cefProject_PD";
	public static final String USERDEFINED_ALIAS_KEY = "projectAlias_PD"; 
	public static final List<String> ALIAS_KEYS = Arrays.asList(CEF_ALIAS_KEY,USERDEFINED_ALIAS_KEY);


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_dtl_id_seq")
    @SequenceGenerator(name = "change_proposal_dtl_id_seq", 
                  sequenceName = "change_proposal_dtl_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "change_proposal_dtl_id")
    private Long id;    

    @NotNull
    @Guid
    @Column(name = "guid_id")
    private String externalId;
    
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
    
//  FORM_TYPE_CT              VARCHAR2(30)      NOT NULL
//  CONSTRAINT CK_FORM_TYPE_CT CHECK (FORM_TYPE_CT IN ('INTERNAL_REQUEST','PROJECT_DETAIL')),
    @Enumerated(EnumType.STRING)
    @Column(name = "form_type_ct")
    private ProposalFormType formType;
    
    @Column(name = "item_tx", length = 100)
    private String itemName; 
    
    @Column(name = "detail_tx", length = 4000)
    private String details; 
    
    @Enumerated(EnumType.STRING)
    @Column(name = "fk_proposal_phase_cd")
    private ProposalPhase proposalPhaseCode;
    
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    /**
     * @return the changeProposerRoles
     * @since April 07, 2018
     */
    @Override
    public int compareTo(ChangeProposalDetail other) {
        
        return new CompareToBuilder()
                .append(Optional.ofNullable(this.getChangeProposal()).orElse(new ChangeProposal()).getId(), 
                        Optional.ofNullable(other.getChangeProposal()).orElse(new ChangeProposal()).getId())
                .append(this.getId(), other.getId())
                .toComparison();
                
    }
   
    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 37;
        int result = 1;
        result = prime * result + ((changeProposal == null) ? 0 : changeProposal.hashCode());
        result = prime * result + ((externalId == null) ? 0 : externalId.hashCode());
        
        result = prime * result + ((formType == null) ? 0 : formType.hashCode());
        result = prime * result + ((itemName == null) ? 0 : itemName.hashCode());
        result = prime * result + ((details == null) ? 0 : details.hashCode());
        result = prime * result + ((proposalPhaseCode == null) ? 0 : proposalPhaseCode.hashCode());
        return result;
    }

    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = false;

        if (obj != null) {
            if (obj == this) {
                ret = true;
            } else if (ChangeProposalDetail.class.isAssignableFrom(obj.getClass())) {
                ChangeProposalDetail that = (ChangeProposalDetail) obj;
                ret = new EqualsBuilder()
                        .append(getId(), that.getId())
                        .append(getChangeProposal(), that.getChangeProposal())
                        .append(getExternalId(), that.getExternalId())
                        .append(getFormType(), that.getFormType())
                        .append(getItemName(), that.getItemName())
                        .append(getDetails(), that.getDetails())
                        .append(getProposalPhaseCode(), that.getProposalPhaseCode())

                        .isEquals();
            }
        }
        return ret;
    }
    
}
