package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CompareToUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentPartCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table cross_reference
 * key is cross_reference_id
 * 
 * @author 2020
 * @version 1.11.0
 * @date: 03/15/2018
 */
@Entity
@Table(name = "cross_reference", uniqueConstraints = {
		@UniqueConstraint(columnNames = { "referencing_symbol_id", "referenced_symbol_id", "component_part_ct" })
		 })
public class CrossReference implements Comparable<CrossReference>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cross_reference_id_seq")
	@SequenceGenerator(name = "cross_reference_id_seq", sequenceName = "cross_reference_id_seq", allocationSize = 1)
	@Column(name = "cross_reference_id")
	private Long id;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, targetEntity = SchemeHierarchy.class)
	@JoinColumn(name = "referenced_symbol_id", referencedColumnName = "scheme_hierarchy_id")
	private SchemeHierarchy referencedClassificationSymbol;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, targetEntity = SchemeHierarchy.class)
	@JoinColumn(name = "referencing_symbol_id", referencedColumnName = "scheme_hierarchy_id")
	private SchemeHierarchy referencingClassificationSymbol;

	@Enumerated(EnumType.STRING)
	@Column(name = "component_part_ct")
	private ComponentPartCategory componentPartCategory;

	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;
	@SuppressWarnings("CPD-END")
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public SchemeHierarchy getReferencedClassificationSymbol() {
		return referencedClassificationSymbol;
	}

	public void setReferencedClassificationSymbol(SchemeHierarchy referencedClassificationSymbol) {
		this.referencedClassificationSymbol = referencedClassificationSymbol;
	}

	public SchemeHierarchy getReferencingClassificationSymbol() {
		return referencingClassificationSymbol;
	}

	public void setReferencingClassificationSymbol(SchemeHierarchy referencingClassificationSymbol) {
		this.referencingClassificationSymbol = referencingClassificationSymbol;
	}

	public ComponentPartCategory getComponentPartCategory() {
		return componentPartCategory;
	}

	public void setComponentPartCategory(ComponentPartCategory componentPartCategory) {
		this.componentPartCategory = componentPartCategory;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	public Integer getLockControl() {
		return lockControl;
	}

	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}
	
	 /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
	@Override
	public int compareTo(CrossReference other) {
        return new CompareToBuilder()
        		.append(this.getReferencedClassificationSymbol().getClassificationSymbolCode(), 
        				other.getReferencedClassificationSymbol().getClassificationSymbolCode())
                .append(this.getReferencingClassificationSymbol().getClassificationSymbolCode(), 
                		other.getReferencingClassificationSymbol().getClassificationSymbolCode())
                .append(this.getComponentPartCategory(), 
                		other.getComponentPartCategory())
                .toComparison();

	}
	
	/**
     * used for hash based collections.
     */
	@Override
	public int hashCode() {
		final int prime = 37;
		int result = 1;
		result = prime * result + ((referencedClassificationSymbol == null) ? 0 : referencedClassificationSymbol.hashCode());
		result = prime * result
				+ ((referencingClassificationSymbol == null) ? 0 : referencingClassificationSymbol.hashCode());
		result = prime * result + ((componentPartCategory == null) ? 0 : componentPartCategory.hashCode());
		return result;
	}
	
	/**
     * Indicates whether some other object is "equal to" this one
     * 
     * TODO: Worst equals method ever!  Multiple returns, no curly brackets cyclomatic complexity is off the chain!
     */
	@Override
	public boolean equals(Object obj) {
		boolean ret = false;
		if (this == obj ) {
			ret = true;
		} else if (obj != null && getClass().equals(obj.getClass())) {
			
		CrossReference other = (CrossReference) obj;
		ret = new CompareToBuilder()
				.append(this.getComponentPartCategory(), other.getComponentPartCategory())
				.append(
					((this.getReferencingClassificationSymbol()!=null)?
							StringUtils.trimToEmpty(this.getReferencingClassificationSymbol().getClassificationSymbolCode()):
								StringUtils.EMPTY), 
						((other.getReferencingClassificationSymbol()!=null)?StringUtils.trimToEmpty(other.getReferencingClassificationSymbol().getClassificationSymbolCode()):StringUtils.EMPTY))
				.append(
						((this.getReferencedClassificationSymbol()!=null)?
								StringUtils.trimToEmpty(this.getReferencedClassificationSymbol().getClassificationSymbolCode()):
									StringUtils.EMPTY), 
							((other.getReferencedClassificationSymbol()!=null)?StringUtils.trimToEmpty(other.getReferencedClassificationSymbol().getClassificationSymbolCode()):
								StringUtils.EMPTY))
				.toComparison() == CompareToUtils.BOTH_ARE_EQUAL;
		}
		return ret;
	}	
}
