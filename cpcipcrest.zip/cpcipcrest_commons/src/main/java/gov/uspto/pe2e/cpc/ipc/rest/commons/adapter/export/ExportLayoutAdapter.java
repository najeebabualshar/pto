package gov.uspto.pe2e.cpc.ipc.rest.commons.adapter.export;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.relationships.Relationship;
import org.docx4j.wml.Hdr;

/**
 * The export layout adapter is responsible for doing certain business and
 * template logic for different Document exports. In this case it doesn't matter
 * whether XML, docx, PDF etc, this adapter is designed to handle the differents
 * in DATA (sorting, collating, grouping munging etc) and differences in layout
 * (custom footers, headers, paging etc) agnostic of the final file extension
 * 
 * @author 2020
 * @date May 30, 2019
 * @since May 30, 2019
 * @version 1.7
 */
public interface ExportLayoutAdapter {

    public void applyCoversheetHeader(String proposalCode, Hdr coverHeader);

    public void applyContentHeader(String proposalCode, Hdr contentHeader);

    public Relationship applyCoversheetFooter(WordprocessingMLPackage doc);

    public Relationship applyContentFooter(WordprocessingMLPackage doc);

}
