package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

/**
 * Entity Class for handling ORM Persistence for table change_proposal_lock
 * 
 * 
 * @author 2020
 * @version 1.6
 * @date: 10/28/2016
 *
 */

@Entity
@Table(name = "change_proposal_lock", uniqueConstraints = {})
public class ChangeProposalLock implements Comparable<ChangeProposalLock>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "fk_change_proposal_id", unique = true)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;

    @NotNull
    @Column(name = "locked_user_id", length = 100)
    private String lockedUserId; // VARCHAR2(100)

    @NotNull
    @Column(name = "expiration_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(iso = ISO.DATE_TIME)
    private Date expirationTs;

    @SuppressWarnings("CPD-START")
    @Column(name = "create_user_id", length = 100, nullable = false)
    @CreatedBy
    private String createUserId; // VARCHAR2(100)

    @NotNull
    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(iso = ISO.DATE_TIME)
    private Date createTs;

    @Column(name = "last_mod_user_id", length = 100, nullable = false)
    @LastModifiedBy
    private String lastModUserId; // VARCHAR2(100)

    @NotNull
    @CreatedDate
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(iso = ISO.DATE_TIME)
    // TODO: change to "lastModifiedTs
    private Date lastModTs;

    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the changeProposal
     * @since Aug 23, 2016
     */
    public ChangeProposal getChangeProposal() {
        return changeProposal;
    }

    /**
     * @param changeProposal
     *            the changeProposal to set
     * @since Aug 23, 2016
     */
    public void setChangeProposal(ChangeProposal changeProposal) {
        this.changeProposal = changeProposal;
    }

    /**
     * @return the expirationTs
     * @since Oct 28, 2016
     */
    public Date getExpirationTs() {
        return expirationTs;
    }

    /**
     * @param expirataionTs
     *            the ExpirationTs to set
     * @since Oct 28, 2016
     */
    public void setExpirationTs(Date expirationTs) {
        this.expirationTs = expirationTs;
    }

    /**
     * @return the createUserId
     * @since Aug 23, 2016
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     *            the createUserId to set
     * @since Aug 23, 2016
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return the createTs
     * @since Aug 23, 2016
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     *            the createTs to set
     * @since Aug 23, 2016
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return the lockedUserId
     */
    public String getLockedUserId() {
        return lockedUserId;
    }

    /**
     * @param lockedUserId
     *            the lockedUserId to set
     */
    public void setLockedUserId(String lockedUserId) {
        this.lockedUserId = lockedUserId;
    }

    /**
     * @return the lastModUserId
     */
    public String getLastModUserId() {
        return lastModUserId;
    }

    /**
     * @param lastModUserId
     *            the lastModUserId to set
     */
    public void setLastModUserId(String lastModUserId) {
        this.lastModUserId = lastModUserId;
    }

    /**
     * @return the lastModTs
     */
    public Date getLastModTs() {
        return lastModTs;
    }

    /**
     * @param lastModTs
     *            the lastModTs to set
     */
    public void setLastModTs(Date lastModTs) {
        this.lastModTs = lastModTs;
    }

    /**
     * @return the lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     *            the lockControl to set
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ChangeProposalLock [id=" + id + ", changeProposal=" + changeProposal + ", lockedUserId=" + lockedUserId
                + ", expirationTs=" + expirationTs + ", createUserId=" + createUserId + ", createTs=" + createTs
                + ", lastModUserId=" + lastModUserId + ", lastModTs=" + lastModTs + ", lockControl=" + lockControl + "]";
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ChangeProposalLock other) {
        return new CompareToBuilder().append(this.getChangeProposal().getId(), other.getChangeProposal().getId())
                .toComparison();
    }

    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret;
        if (obj == null || !ChangeProposalLock.class.isAssignableFrom(obj.getClass())) {
            ret = false;
        } else if (ChangeProposalLock.class.isAssignableFrom(obj.getClass()) && obj == this) {
            ret = true;
        } else {
            ChangeProposalLock thatObj = (ChangeProposalLock) obj;
            ret = StringUtils.equals(this.getChangeProposal().getExternalId(), thatObj.getChangeProposal().getExternalId())
                    && StringUtils.equals(this.getLockedUserId(), thatObj.getLockedUserId());
        }
        return ret;
    }

    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + this.getId().hashCode() + this.getLockedUserId().hashCode();
        return result;
    }
}
