package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.eclipse.jgit.util.StringUtils;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public enum SamlIpOffice {
	USPTO (StandardIpOfficeCode.US, "^([a-z\\.0-9']+)\\@uspto\\.gov$", "PTO", "USPTO"),
	EPO (StandardIpOfficeCode.EP, "^([a-z\\.0-9']+)\\@epo\\.org$", "EPO");
	
	private StandardIpOfficeCode ipOffice;
	private String emailRegex;
	private List<String> nonstandardCodes;
	private SamlIpOffice(StandardIpOfficeCode ipOffice, String emailMatchRegex, String... nonstandardCodes) {
		this.ipOffice = ipOffice;
		this.nonstandardCodes = Arrays.asList(nonstandardCodes);
		this.emailRegex = emailMatchRegex;
	}
	
	
	
	/**
	 * @return the ipOffice
	 */
	public StandardIpOfficeCode getIpOffice() {
		return ipOffice;
	}

	/**
	 * @return the emailRegex
	 */
	public String getEmailRegex() {
		return emailRegex;
	}

	public static SamlIpOffice byCode(String officeCode) {
		SamlIpOffice ret = null;
		for (SamlIpOffice o: values()) {
			if (o.ipOffice.name().equals(officeCode) || o.nonstandardCodes.contains(officeCode)) {
				ret = o;
				break;
			}
		}
		return ret;
	}



	/**
	 * Identifies record for matching by email domain
	 */
	public static SamlIpOffice mapByEmail(String email) {
		SamlIpOffice ret = null;
		for (SamlIpOffice o: values()) {
			if (Pattern.matches(o.getEmailRegex(), StringUtils.toLowerCase(email))) {
				ret = o;
				break;
			}
		}
		return ret;
	}
	

}
