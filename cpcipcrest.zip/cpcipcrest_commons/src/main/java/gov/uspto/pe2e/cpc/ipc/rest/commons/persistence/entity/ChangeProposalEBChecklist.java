package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposerAction;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposerTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.ChecklistName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.EbclApproverRole;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Entity class for handling CEF Module process data
 * 
 * @author Maximus
 * @date September 10, 2021
 * @version 1.0
 *
 */

@Data
@Entity
@Table(name = "change_proposal_eb_checklist")
public class ChangeProposalEBChecklist implements Comparable<ChangeProposalEBChecklist>, Serializable  {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
    
    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eb_checklist_id_seq")
    @SequenceGenerator(name = "eb_checklist_id_seq", sequenceName = "eb_checklist_id_seq", 
                          initialValue = 1, allocationSize = 1)
    @Column(name = "eb_checklist_id")
    private Long id;
    
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
    
    @NotNull
    @Guid
    @Column(name ="guid_id")
    private String externalId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardChecklistItem.class)
    @JoinColumn(name = "fk_checklist_item_id", referencedColumnName = "checklist_item_id")
    private StandardChecklistItem standardChecklistItem;
    
    @NotNull
    @Enumerated(EnumType.STRING)
	@Column(name ="proposer_type_ct")
    private ProposerTypeCode proposerType;
    
    @NotNull
    @Column(name = "fk_proposer_role_cd")
    @Enumerated(EnumType.STRING)
	private EbclApproverRole standardProposerRole;
    
	@NotNull
    @Enumerated(EnumType.STRING)
	@Column(name ="proposer_action_ct")
	private ProposerAction proposerAction;
  
	@Column(name ="proposer_comment_tx")
	private String proposerComment;
	
	@NotNull
    @Enumerated(EnumType.STRING)
	@Column(name ="checklist_name_ct")
	private ChecklistName checklistName;
	
    @Enumerated(EnumType.STRING)
	@Column(name ="fk_ipo_cd")
	private StandardIpOfficeCode ipOffice;
    
	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	@Override
	public int compareTo(ChangeProposalEBChecklist o) {	
		return new CompareToBuilder().append(this.getId(), o.getId()).toComparison();
	}

	@Override
	public String toString() {
		return "ChangeProposalEBChecklist [id=" + id + ", changeProposal=" + changeProposal
				+ ", externalId=" + externalId + ", standardChecklistItem=" + standardChecklistItem
				+ ", proposerType=" + proposerType + ", standardProposerRole=" + standardProposerRole
				+ ", proposerAction=" + proposerAction + ", proposerComment=" + proposerComment + ", createUserId="
				+ createUserId + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId
				+ ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + "]";
	}
}
