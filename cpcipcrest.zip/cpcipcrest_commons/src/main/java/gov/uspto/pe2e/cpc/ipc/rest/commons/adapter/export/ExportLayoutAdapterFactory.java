package gov.uspto.pe2e.cpc.ipc.rest.commons.adapter.export;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExportDocxReportType;

//TODO: investigate whether this should be a spring bean
public final class ExportLayoutAdapterFactory {
	private static final Logger log = LoggerFactory.getLogger(ExportLayoutAdapterFactory.class);
	public static enum Layout {
		CICL (CICLExportLayoutAdapter.class),
		CRL (CRLExportLayoutAdapter.class),
		DEF (DefExportLayoutAdapter.class),
		PCS (PCSExportLayoutAdapter.class),
		RCL (RCLExportLayoutAdapter.class),
		SCT (SCTExportLayoutAdapter.class),
		STATISTICS (StatisticsExportLayoutAdapter.class),
		VALIDATION (ValidationExportLayoutAdapter.class);
		private Class<? extends ExportLayoutAdapter> layoutAdapterClass;
		private Layout(Class<? extends ExportLayoutAdapter> layoutAdapterClass) {
			this.layoutAdapterClass = layoutAdapterClass;
		}
		private Class<? extends ExportLayoutAdapter> getLayoutAdapterClass() {
			return layoutAdapterClass;
		}
	}
	public static final String EPO = "EUROPEAN PATENT OFFICE";
	public static final String USPTO = "U.S. PATENT AND TRADEMARK OFFICE";
	public static final String V1_FOOTER_TITLE = "CPC Form - v.1";
    public static final String V2_FOOTER_TITLE = "CPC Form - v.2";
    public static final String V5_FOOTER_TITLE = "CPC-Form - v.5";
    public static final String V4_FOOTER_TITLE = "CPC-Form - v.4";
    public static final String V6_FOOTER_TITLE = "CPC Form - v.6";
	public static final String COVERSHEET_TEMPLATE_PATH = "/word/cover-footer.xml";
	public static final String CONTENT_TEMPLATE_PATH = "/word/content-footer.xml";
	
	/**
	 * This method is Here (instead of calling the enum directly) in case future features
	 * require us to pass in resources to the adapter like db repository or Some 
	 * other thread safe instance object
	 * @return
	 */
	public static ExportLayoutAdapter getLayoutAdapter(ExportDocxReportType exportType) {
		ExportLayoutAdapter ela = null;
		try {
			Layout l = Layout.valueOf(exportType.name());
			if (l != null) {
				ela = l.getLayoutAdapterClass().newInstance();
			}
		} catch (Exception e) {
			log.error("Unable to determine adapter for {} return null instance for ExportLayoutAdapter.class",exportType, e);
		}
		return ela;
	}

}
