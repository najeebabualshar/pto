package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.LastValidateStatusCategory;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table change_proposal_ver
 * primary key column is change_proposal_version_id
 * 
 * Follow-up for next release 1.6 TODO: Wire in Audit annotations based on
 * emails and create/update TS. This requires the application to intelligently
 * default to system user when job is running as a background task
 * 
 * @author 2020
 * @version 1.3
 * @date: 03/15/2016
 *
 */
@Entity
@Table(name = "change_proposal_ver", uniqueConstraints = { @UniqueConstraint(columnNames = { "guid_id",
        "fk_change_proposal_id", "version_id" }) })
//, @UniqueConstraint(columnNames = { "guid_id" }) })
public class ChangeProposalVersion implements Comparable<ChangeProposalVersion>, Serializable {

    /**
     * Allowing serialization of datamodel elements 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "change_proposal_ver_id_seq")
//    @SequenceGenerator(name = "change_proposal_ver_id_seq", sequenceName = "change_proposal_ver_id_seq", allocationSize = 1)
//    @Column(name = "change_proposal_ver_id")
//    private Long id;
    @Guid
    @Column(name = "guid_id")
    private String externalId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;

    @NotNull
    @Column(name = "version_id")
    private Integer versionId;

    @NotNull
    @Column(name = "version_create_user_id")
    private String versionCreateUserId; // VARCHAR2(100)

    @NotNull
    @Column(name = "version_create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date versionCreateTs;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ClassificationScheme.class)
    @JoinColumn(name = "fk_last_validate_scheme_id", referencedColumnName = "classification_scheme_id")
    private ClassificationScheme classificationScheme;

    @Column(name = "cef_annex_list_tx")
    private String cefAnnex;// VARCHAR2(255)
    
    @Column(name = "description_tx")
    private String description;// VARCHAR2(4000)

    @Column(name = "cef_post_dt")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date cefPostDate;

    @Column(name = "last_validate_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastValidateDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "last_validate_status_ct")
    private LastValidateStatusCategory lastValidateStatus; // LAST_VALIDATE_STATUS_CT
                                                           // IN('SUCEESS','ERROR')
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")

    /**
     * To get VersionSymbol Set by mapping changeproposalversion with entity VersionSymbol  
     */
    @OrderBy("sort_order_no")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposalVersion",
            targetEntity = VersionSymbol.class)
    private Set<VersionSymbol> sctItems = new TreeSet<>();

    /**
     * To get DescriptionNote Set by mapping changeproposalversion with entity DescriptionNote
     */
    @OrderBy("create_ts")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposalVersion",
            targetEntity = DescriptionNote.class)
    private Set<DescriptionNote> descriptionNotes = new TreeSet<>();

    

    /**
     * @return the externalId
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * @param externalId the externalId to set
     */
    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    /**
     * @return ChangeProposal changeProposal
     */
    public ChangeProposal getChangeProposal() {
        return changeProposal;
    }

    /**
     * @param changeProposal
     */
    public void setChangeProposal(ChangeProposal changeProposal) {
        this.changeProposal = changeProposal;
    }

    /**
     * @return Integer versionId
     */
    public Integer getVersionId() {
        return versionId;
    }

    /**
     * @param versionId
     */
    public void setVersionId(Integer versionId) {
        this.versionId = versionId;
    }    
    
    /**
     * @return cefAnnex
     */
    public String getCefAnnex() {
        return cefAnnex;
    }
    
    /**
     * @param cefAnnex
     */
    public void setCefAnnex(String cefAnnex) {
        this.cefAnnex = cefAnnex;
    }
    
    /**
     * @return description
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the cefPostDate
     */
    public Date getCefPostDate() {
        Date cefPostDateValue = null;
        if (this.cefPostDate != null) {
        	cefPostDateValue = new Date(this.cefPostDate.getTime());
        }
        return cefPostDateValue;
    }

    /**
     * @param cefPostDate the cefPostDate to set
     */
    public void setCefPostDate(Date cefPostDate) {
        this.cefPostDate = cefPostDate;
    }

    /**
     * @return String versionCreateUserId
     */
    public String getVersionCreateUserId() {
        return versionCreateUserId;
    }

    /**
     * @param versionCreateUserId
     */
    public void setVersionCreateUserId(String versionCreateUserId) {
        this.versionCreateUserId = versionCreateUserId;
    }

    /**
     * @return Date versionCreateTs
     */
    public Date getVersionCreateTs() {
        return versionCreateTs;
    }

    /**
     * @param versionCreateTs
     */
    public void setVersionCreateTs(Date versionCreateTs) {
        this.versionCreateTs = versionCreateTs;
    }

    /**
     * @return the classificationScheme
     * @since Aug 23, 2016
     */
    public ClassificationScheme getClassificationScheme() {
        return classificationScheme;
    }

    /**
     * @param classificationScheme the classificationScheme to set
     * @since Aug 23, 2016
     */
    public void setClassificationScheme(ClassificationScheme classificationScheme) {
        this.classificationScheme = classificationScheme;
    }

    /**
     * @return String createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return Date createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return String lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return Date lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @return Integer lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }

    /**
     * @return Date lastValidateDate
     */
    public Date getLastValidateDate() {
        return lastValidateDate;
    }

    /**
     * @param lastValidateDate
     */
    public void setLastValidateDate(Date lastValidateDate) {
        this.lastValidateDate = lastValidateDate;
    }

    /**
     * @return the lastValidateStatus
     */
    public LastValidateStatusCategory getLastValidateStatus() {
        return lastValidateStatus;
    }

    /**
     * @param lastValidateStatus the lastValidateStatus to set
     */
    public void setLastValidateStatus(LastValidateStatusCategory lastValidateStatus) {
        this.lastValidateStatus = lastValidateStatus;
    }

    /**
     * 
     * @return Set<VersionSymbol> stageItems
     * @since May 16, 2016
     */
    public Set<VersionSymbol> getSctItems() {
        if (sctItems == null) {
            sctItems = new TreeSet<>();
        }
        return sctItems;
    }

    /**
     * 
     * @param Set<VersionSymbol> stageItems
     * @since May 16, 2016
     */
    public void setSctItems(Set<VersionSymbol> sctItems) {
        this.sctItems = sctItems;
    }

    /**
     * Null-safe method to add stageItem to collection
     * 
     * @param sctItem
     * @since May 16, 2016
     */
    public void addSctItem(VersionSymbol sctItem) {
        getSctItems().add(sctItem);
    }

    /**
     * @return the descriptionNotes
     * @since Aug 26, 2016
     */
    public Set<DescriptionNote> getDescriptionNotes() {
        if (descriptionNotes == null) {
            descriptionNotes = new TreeSet<>();
        }
        return descriptionNotes;
    }

    /**
     * @param descriptionNotes the descriptionNotes to set
     * @since Aug 26, 2016
     */
    public void setDescriptionNotes(Set<DescriptionNote> descriptionNotes) {
        this.descriptionNotes = descriptionNotes;
    }

    /**
     * Null-safe method to add descriptionNote to collection
     * 
     * @param descriptionNote
     * @since Aug 26, 2016
     */
    public void addDescriptionNote(DescriptionNote descriptionNote) {
        getDescriptionNotes().add(descriptionNote);
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(ChangeProposalVersion other) {
        return new CompareToBuilder()
        		.append(this.getChangeProposal()
                .getExternalId(), other.getChangeProposal().getExternalId())
        		.append(this.getVersionId(),
                        other.getVersionId())
        		.append(this.getExternalId(), other.getExternalId()).toComparison();
    }
    
    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret;
        
        if (obj == null || !(obj instanceof ChangeProposalVersion)) {
            ret = false;
        } else if (ChangeProposalVersion.class.isAssignableFrom(obj.getClass()) && obj == this) {
            ret = true;
        } else {
        	ChangeProposalVersion thatObj = (ChangeProposalVersion) obj;
        	
        	String meProposalCode = this.getChangeProposal().getExternalId();
        	String thatProposalCode = thatObj.getChangeProposal().getExternalId();
        	
            Integer meVersionId = this.getVersionId();
            Integer thatVersionId = thatObj.getVersionId();
          
            
            String meExternalId = this.getExternalId();
            String thatExternalId = thatObj.getExternalId();
            
            ret = meProposalCode.equals(thatProposalCode) && Objects.equals(meVersionId, thatVersionId) 
            		&& meExternalId.equals(thatExternalId) 
            		;
        }
        return ret;
    }

    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        return Objects.hash(this.getChangeProposal().getExternalId(), 
        		this.getExternalId(), this.getVersionId());
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ChangeProposalVersion [externalId=" + getExternalId() + ", changeProposal=" + ((changeProposal != null) ? changeProposal.getId()
                : "null") + ", versionId=" + versionId + ", cefAnnex=" + cefAnnex + ", cefPostDate=" + cefPostDate
                + ", versionCreateUserId=" + versionCreateUserId + ", versionCreateTs=" + versionCreateTs + ", createUserId="
                + createUserId + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId
                + ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + ", lastValidateDate="
                + lastValidateDate + "]";
    }

}
