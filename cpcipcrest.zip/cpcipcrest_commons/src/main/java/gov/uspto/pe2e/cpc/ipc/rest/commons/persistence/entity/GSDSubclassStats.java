package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

/**
 * 
 */
/**
 * Repository for GSDSubclassStatsRepository
 * @author c62924
 * @date: 9/28/2023
 *
 */
@Entity
@Table(name = "gsd_subclass_stats")
@Data
public class GSDSubclassStats implements Serializable {
	
	

	private static final long serialVersionUID = 1L;
	
	@Id
	@NotNull
    @Column(name = "subclass_stats_id")
	private Long subClassStatsId;
	
	@NotNull
    @Column(name = "subclass_cd")
    private String subClassCd; 
	

	@NotNull
    @Column(name = "scheme_version_tx")
    private String schemeVersion; 
	
	
	@NotNull
    @Column(name = "symbol_cnt_no")
    private Long symbolCntNo; 
	
	@NotNull
    @Column(name = "main_group_cnt_no")
    private Long mainGroupCntNo; 
	
	
	@Column(name = "definition_cnt_no")
    private Long definitionCntNo; 
    
	
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; 
    
    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;
    
    
    
    @Override
	public String toString() {
		return "GSDSubclassStats [subClassStatsId=" + subClassStatsId + ", subClassCd=" + subClassCd
				+ ", schemeVersion=" + schemeVersion + ", symbolCntNo=" + symbolCntNo + ", mainGroupCntNo="
				+ mainGroupCntNo + ", definitionCntNo=" + definitionCntNo + ", createUserId=" + createUserId
				+ ", createTs=" + createTs + "]";
	}

	


}
