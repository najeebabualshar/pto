package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;

import org.apache.commons.lang3.builder.CompareToBuilder;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

/**
 * entity for PROJECTED_TASK_PATH_V
 * @author msingh4
 * @date: 02/02/2023
 *
 */
@Entity
@Table(name = "projected_task_path_v")
@Data
public class ProjectedTaskPathView implements Comparable<ProjectedTaskPathView>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name ="guid_id")
	@Guid
	private String id; // This is the db guid format
	
	@Column(name = "seq_id")
	private Long sequenceNumber;
	
	@Column(name = "project_origin_cd")
	private String projectOrigin;
	
	@Column(name = "proposal_type_cd")
	private String projectType;

	@Enumerated(EnumType.STRING)
	@Column(name="proposal_phase_cd")
	private ProposalPhase proposalPhase;
	
	@Column(name="phase_nm")
	private String proposalPhaseName;
	
	@Column(name="task_id")
	private String taskDefinitionKey;
	
	@Column(name="task_title_tx")
	private String taskTitle;
	
	@Column(name="task_order_no")
	private Integer taskOrder;
	
	@Column(name="user_group_tx")
	private String userGroupText;

	@Override
	public String toString() {
		return "ProjectedTaskPathView [sequenceNumber=" + sequenceNumber + ", projectOrigin=" + projectOrigin
				+ ", projectType=" + projectType + ", proposalPhase=" + proposalPhase + ", taskDefinitionKey="
				+ taskDefinitionKey + ", userGroupText=" + userGroupText + "]";
	}

	@Override
	public int compareTo(ProjectedTaskPathView o) {
		return new CompareToBuilder().append(this.sequenceNumber, o.sequenceNumber)
				.append(this.taskDefinitionKey, o.taskDefinitionKey).toComparison();
	}
}
