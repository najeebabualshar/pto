package gov.uspto.pe2e.cpc.ipc.rest.commons.api;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.CloudResource;

public interface ProposalResourceExportHandler {
    
	public CloudResource getDocumentByResourceId(String resourceId);

}
