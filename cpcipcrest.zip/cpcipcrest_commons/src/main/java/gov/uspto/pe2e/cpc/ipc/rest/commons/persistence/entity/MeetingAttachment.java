package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;
import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Entity
@Data
@Table(name = "meeting_attachment", uniqueConstraints = { @UniqueConstraint(name = "pk_meeting_attachment", columnNames = {
        "meeting_attachment_id" }) })
public class MeetingAttachment implements Serializable {
    
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "meeting_attachment_id_seq")
    @SequenceGenerator(name = "meeting_attachment_id_seq", sequenceName = "meeting_attachment_id_seq", initialValue = 1,
            allocationSize = 1)
    @Column(name = "meeting_attachment_id")
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = MeetingPlace.class)
    @JoinColumn(name = "fk_meeting_place_id", referencedColumnName = "meeting_place_id")
    private MeetingPlace meetingPlace;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalDocument.class)
    @JoinColumn(name = "fk_change_proposal_doc_id", referencedColumnName = "change_proposal_doc_id")
    private ChangeProposalDocument changeProposalDocument;

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @NotNull
    @Column(name = "create_user_id")
    private String createUserId;

    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyy-MM-dd HH:mm:ss.SSS")
    private Date lastModTs;

    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModUserId;

    @NotNull
    @Column(name = "lock_control_no")
    @Version
    private Integer lockControlNo;

}