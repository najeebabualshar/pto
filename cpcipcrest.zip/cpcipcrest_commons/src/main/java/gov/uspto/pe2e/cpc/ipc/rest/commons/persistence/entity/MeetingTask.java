package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name = "meeting_task", uniqueConstraints = { @UniqueConstraint(name = "pk_meeting_task_id", columnNames = {
        "meeting_task_id" }) })
public class MeetingTask implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "meeting_task_id_seq")
    @SequenceGenerator(name = "meeting_task_id_seq", sequenceName = "meeting_task_id_seq", initialValue = 1,
            allocationSize = 1)
    @Column(name = "meeting_task_id")
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = MeetingPlace.class)
    @JoinColumn(name = "fk_meeting_place_id", referencedColumnName = "meeting_place_id")
    private MeetingPlace meetingPlace;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardWorkflowTaskConfiguration.class)
    @JoinColumn(name = "fk_task_id", referencedColumnName = "task_id")
    private StandardWorkflowTaskConfiguration standardWorkflowTaskConfiguration;

    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @NotNull
    @Column(name = "create_user_id")
    private String createUserId;

    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModTs;

    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModUserId;

    @NotNull
    @Column(name = "lock_control_no")
    private Integer lockControlNo;

}