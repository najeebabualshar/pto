/**
 * This package is where we put specialty annotation packages
 */ 
package gov.uspto.pe2e.cpc.ipc.rest.commons.api;
