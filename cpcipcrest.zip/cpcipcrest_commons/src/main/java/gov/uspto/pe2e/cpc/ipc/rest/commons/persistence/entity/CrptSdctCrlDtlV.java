package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;

import org.apache.commons.lang3.builder.CompareToBuilder;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
/**
 * The persistent class for the CRPT_SDCT_CRL_DTL_V database table.
 * @author Maximus
 * @date: 05/17/2023
 *
 */
 
@Entity
@Table(name="crpt_sdct_crl_dtl_v")
@Data
public class CrptSdctCrlDtlV implements Comparable<CrptSdctCrlDtlV>, Serializable {
	private static final long serialVersionUID = 1L;
	
	//This view does not have any unique column, so created row number as Id
	@Id
	@Column(name = "crpt_sdct_crl_dtl_id", updatable = false, insertable = false)
	private Long id;

	@Column(name="project_type_ct")
	private String projectTypeCt;

	@Column(name="ref_location_tx")
	private String refLocationTx;

	@Column(name="ref_subsection_tx")
	private String refSubsectionTx;

	@Column(name="scheme_version_tx")
	private String schemeVersionTx;

	@Column(name="source_change_type_cd")
	private String sourceChangeTypeCd;

	@Column(name="source_crl_symbol_tx")
	private String sourceCrlSymbolTx;
	
	@Column(name="version_symbol_guid_id")
	private String versionSymbolGuidId;

	@Column(name="source_guid_id")
	private String sourceGuidId;

	@Column(name="source_project_cd")
	private String sourceProjectCd;

	@Column(name="source_proposal_id")
	private Long sourceProposalId;
	
	@NotNull
	@OneToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "source_proposal_id", referencedColumnName = "change_proposal_id", updatable = false, insertable = false)
	private ChangeProposal changeProposal;

	@Column(name="source_sort_order_no")
	private Integer sourceSortOrderNo;

	@Column(name="source_symbol_tx")
	private String sourceSymbolTx;

	@Column(name="source_version_id")
	private Integer sourceVersionId;

	@Column(name="transfer_to_symbol_list")
	private String transferToSymbolList;

	
	@Override
	public int compareTo(CrptSdctCrlDtlV o) {
		return new CompareToBuilder().append(this.sourceGuidId, o.sourceGuidId).append(this.sourceVersionId, o.sourceVersionId)
				.append(this.sourceSymbolTx, o.sourceSymbolTx).toComparison();
	}


	@Override
	public String toString() {
		return "CrptSdctCrlDtlV [id=" + id + ", projectTypeCt=" + projectTypeCt + ", refLocationTx=" + refLocationTx
				+ ", refSubsectionTx=" + refSubsectionTx + ", schemeVersionTx=" + schemeVersionTx
				+ ", sourceChangeTypeCd=" + sourceChangeTypeCd + ", sourceCrlSymbolTx=" + sourceCrlSymbolTx
				+ ", sourceGuidId=" + sourceGuidId + ", sourceProjectCd=" + sourceProjectCd + ", sourceProposalId="
				+ sourceProposalId + ", changeProposal=" + changeProposal + ", sourceSortOrderNo=" + sourceSortOrderNo
				+ ", sourceSymbolTx=" + sourceSymbolTx + ", sourceVersionId=" + sourceVersionId
				+ ", transferToSymbolList=" + transferToSymbolList + "]";
	}


	
}