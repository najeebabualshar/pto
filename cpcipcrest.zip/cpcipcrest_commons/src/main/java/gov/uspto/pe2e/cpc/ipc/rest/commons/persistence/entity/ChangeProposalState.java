package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalStateType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalSubphase;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table change_proposal_state
 * primary key column is fk_change_proposal_id
 * 
 * @author 2020
 * @version 1.14.0
 * @date: October 20, 2018
 *
 */
@Entity
@Table(name = "change_proposal_state")
public class ChangeProposalState implements Comparable<ChangeProposalState>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Column(name = "fk_change_proposal_id", unique = true, nullable = false)
	private Long id;

	/** user with this associated settings */
	@MapsId
	@OneToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
	@JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
	private ChangeProposal changeProposal;

	@NotNull
	@Column(name = "process_start_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date processStartTs;

	@Enumerated(EnumType.STRING)
	@Column(name = "proposal_phase_tx")
	private ProposalPhase phase;

	@Enumerated(EnumType.STRING)
	@Column(name = "proposal_subphase_tx")
	private ProposalSubphase subphase;

	@NotNull
	@Column(name = "definition_id")
	private String processDefinitionId;

	@NotNull
	@Column(name = "process_instance_id")
	private String processInstanceId;

	@Enumerated(EnumType.STRING)
	@Column(name = "proposal_state_ct")
	private ProposalStateType state;

	@Column(name = "process_end_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date processEndTs;

	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@SuppressWarnings("CPD-END")
	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	@OrderBy("task_start_ts, task_id")
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "changeProposalState", targetEntity = ChangeProposalStateTask.class)
	private Set<ChangeProposalStateTask> activeTasks;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ProjectDetailView.class)
	private ProjectDetailView projectDetailView;

	/**
	 * @return Long id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return ChangeProposal
	 */
	public ChangeProposal getChangeProposal() {
		return changeProposal;
	}

	/**
	 * @param ChangeProposal
	 */
	public void setChangeProposal(ChangeProposal changeProposal) {
		this.changeProposal = changeProposal;
	}

	/**
	 * @return Date processStartTs
	 */
	public Date getProcessStartTs() {
		return processStartTs;
	}

	/**
	 * @param Date
	 */
	public void setProcessStartTs(Date processStartTs) {
		this.processStartTs = processStartTs;
	}

	/**
	 * @return ProposalPhase phase
	 */
	public ProposalPhase getPhase() {
		return phase;
	}

	/**
	 * @param ProposalPhase
	 */
	public void setPhase(ProposalPhase phase) {
		this.phase = phase;
	}

	/**
	 * @return ProposalSubphase subphase
	 */
	public ProposalSubphase getSubphase() {
		return subphase;
	}

	/**
	 * @param ProposalSubphase
	 */
	public void setSubphase(ProposalSubphase subphase) {
		this.subphase = subphase;
	}

	/**
	 * @return String processDefinitionId
	 */
	public String getProcessDefinitionId() {
		return processDefinitionId;
	}

	/**
	 * @param String
	 */
	public void setProcessDefinitionId(String processDefinitionId) {
		this.processDefinitionId = processDefinitionId;
	}

	/**
	 * @return String processInstanceId
	 */
	public String getProcessInstanceId() {
		return processInstanceId;
	}

	/**
	 * @param String
	 */
	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	/**
	 * @return ProposalStateType state
	 */
	public ProposalStateType getState() {
		return state;
	}

	/**
	 * @param ProposalStateType
	 */
	public void setState(ProposalStateType state) {
		this.state = state;
	}

	/**
	 * @return Date processEndTs
	 */
	public Date getProcessEndTs() {
		return processEndTs;
	}

	/**
	 * @param Date
	 */
	public void setProcessEndTs(Date processEndTs) {
		this.processEndTs = processEndTs;
	}

	/**
	 * @return String createUserId
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/**
	 * @param String
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/**
	 * @return Date createTs
	 */
	public Date getCreateTs() {
		return createTs;
	}

	/**
	 * @param Date
	 */
	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	/**
	 * @return String lastModifiedUserId
	 */
	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	/**
	 * @param String
	 */
	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	/**
	 * @return Date lastModifiedTs
	 */
	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	/**
	 * @param Date
	 */
	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	/**
	 * @return Integer lockControl
	 */
	public Integer getLockControl() {
		return lockControl;
	}

	/**
	 * @param Integer
	 */
	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}

	/**
	 * @return Set<ChangeProposalStateTask>
	 */
	public Set<ChangeProposalStateTask> getActiveTasks() {
		if (this.activeTasks == null) {
			this.activeTasks = new TreeSet<>();
		}
		return activeTasks;
	}

	/**
	 * @param Set<ChangeProposalStateTask>
	 */
	public void setActiveTasks(Set<ChangeProposalStateTask> activeTasks) {
		this.activeTasks = activeTasks;
	}


	public ProjectDetailView getProjectDetailView() {
		return projectDetailView;
	}

	public void setProjectDetailView(ProjectDetailView projectDetailView) {
		this.projectDetailView = projectDetailView;
	}
	/**
	 * used for hash based collections.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((changeProposal == null) ? 0 : changeProposal.hashCode());
		result = prime * result + ((phase == null) ? 0 : phase.hashCode());
		result = prime * result + ((processDefinitionId == null) ? 0 : processDefinitionId.hashCode());
		result = prime * result + ((processEndTs == null) ? 0 : processEndTs.hashCode());
		result = prime * result + ((processInstanceId == null) ? 0 : processInstanceId.hashCode());
		result = prime * result + ((processStartTs == null) ? 0 : processStartTs.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((subphase == null) ? 0 : subphase.hashCode());
		return result;
	}

	/**
	 * Indicates whether some other object is "equal to" this one
	 */
	@Override
	public boolean equals(Object obj) {
		boolean ret = false;

		if (obj != null) {
			if (obj == this) {
				ret = true;
			} else if (ChangeProposalState.class.isAssignableFrom(obj.getClass())) {
				ChangeProposalState that = (ChangeProposalState) obj;
				ret = new EqualsBuilder().append(getId(), that.getId()).append(getPhase(), that.getPhase())
						.append(getSubphase(), that.getSubphase()).isEquals();
			}
		}
		return ret;
	}

	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ChangeProposalState other) {
		return new CompareToBuilder().append(this.getId(), other.getId())
				.append(this.getProcessStartTs(), other.getProcessStartTs()).toComparison();

	}

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ChangeProposalState [id=" + id + ", changeProposal=" + changeProposal + ", processStartTs="
                + processStartTs + ", phase=" + phase + ", subphase=" + subphase + ", processDefinitionId="
                + processDefinitionId + ", processInstanceId=" + processInstanceId + ", state=" + state
                + ", processEndTs=" + processEndTs + ", createUserId=" + createUserId + ", createTs=" + createTs
                + ", lastModifiedUserId=" + lastModifiedUserId + ", lastModifiedTs=" + lastModifiedTs + ", lockControl="
                + lockControl + ", activeTasks=" + activeTasks + "]";
    }

}
