package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TWLDocumentStatus;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
@Entity
@Table(name = "change_proposal_twl", uniqueConstraints={ 
        @UniqueConstraint(
            name="pk_change_proposal_twl", 
            columnNames = { "twl_id"}),
        @UniqueConstraint(columnNames = { "guid_id" })
        
})
public class ChangeProposalTWL  implements Comparable<ChangeProposalTWL>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "twl_id_seq")
    @SequenceGenerator(name = "twl_id_seq", 
                  sequenceName = "twl_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "twl_id")
    private Long id;    

    @Guid
    @NotNull
    @Column(name = "guid_id")
    private String externalId;
    
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "fk_ipo_cd")
    private StandardIpOfficeCode standardIpOfficeCode;
    
    @Column(name = "patent_document_id", length=15, columnDefinition = "varchar2" ) 
    @NotNull
    private String patentDocumentId; // Not a foreign key to anything 
    
    @Column(name = "pub_kind_cd", length=2) //      NUMBER(15, 0)     NOT NULL, 
    private String publishedKindCode; // We don't know what these Values are and no way to validate
    
    @Column(name = "comment_tx", length = 4000)
    private String comment; 
    
    @Enumerated(EnumType.STRING)
    @Column(name="status_ct", length=10)
    private TWLDocumentStatus status;

    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    @OrderBy("id")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, 
                        mappedBy = "changeProposalTWL", targetEntity = ChangeProposalTWLDetail.class) // If this object is deleted, this objects in this set are deleted as well
    private Set<ChangeProposalTWLDetail> details; 
    
    /**
     * Adds ChangeProposalTWLDetail to the details set
     * 
     * @param child
     */
    public void add(ChangeProposalTWLDetail child) {
        getDetails().add(child);
    }
    
    /**
     * @return the details list
     * 
     */
    public Set<ChangeProposalTWLDetail> getDetails() {
        if (this.details == null) {
            this.details = new TreeSet<>();
        }
        return details;
    }
    /**
     * @return the changeProposerRoles
     * @since April 07, 2018
     */

    @Override
    public int compareTo(ChangeProposalTWL other) {
        
        return new CompareToBuilder()
                .append(Optional.ofNullable(this.getChangeProposal()).orElse(new ChangeProposal()).getId(), 
                        Optional.ofNullable(other.getChangeProposal()).orElse(new ChangeProposal()).getId())
                .append(this.getId(), other.getId())
                .toComparison();
                
    }

   
    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 37;
        int result = 1;
        result = prime * result + ((changeProposal == null) ? 0 : changeProposal.hashCode());
        result = prime * result + ((externalId == null) ? 0 : externalId.hashCode());
        result = prime * result + ((standardIpOfficeCode == null) ? 0 : standardIpOfficeCode.hashCode());
        result = prime * result + ((publishedKindCode == null) ? 0 : publishedKindCode.hashCode());
        result = prime * result + ((patentDocumentId == null) ? 0 : patentDocumentId.hashCode());
        result = prime * result + ((comment == null) ? 0 : comment.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        return result;
    }

    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = false;

        if (obj != null) {
            if (obj == this) {
                ret = true;
            } else if (ChangeProposalTWL.class.isAssignableFrom(obj.getClass())) {
                ChangeProposalTWL that = (ChangeProposalTWL) obj;
                ret = new EqualsBuilder()
                        .append(getId(), that.getId())
                        .append(getChangeProposal(), that.getChangeProposal())
                        .append(getExternalId(), that.getExternalId())
                        .append(getStandardIpOfficeCode(), that.getStandardIpOfficeCode())
                        .append(getPatentDocumentId(), that.getPatentDocumentId())
                        .append(getPublishedKindCode(), that.getPublishedKindCode())
                        .append(getComment(), that.getComment())
                        .append(getStatus(), that.getStatus())
                        .isEquals();
            }
        }
        return ret;
    }
    
    
    
    
}
