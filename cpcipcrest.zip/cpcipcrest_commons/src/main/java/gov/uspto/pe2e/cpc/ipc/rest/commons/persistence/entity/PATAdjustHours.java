package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * pat_adjust_hrs
 * 
 * @author myoung3
 *
 */
@Entity
@Table(name = "pat_adjust_hrs")
@Data
public class PATAdjustHours {
	
	@Id
	@Column(name ="guid_id")
	@Guid
	private String id; // This is the db guid format
	
	/**
	 * cfk stands for "cross-functional key".  
	 * this is EDAD nomenclature for a natural key shared across systems 
	 */
	@Column(name ="cfk_pc_nm") 
	private String pcEmail;
	
	@Column(name ="pay_period_id")
	private Long payPeriodId;	

	@Column(name ="change_proposal_guid_id")
	@NotNull
	@Guid
	private String changeProposalExternalId; 
	
	/**
	 * this is called task_definition_id but this is not correct.  This is actually the 
	 * task Definition key!  the difference is, the id is assigned when the record is 
	 * persisted for the first time.  whereas, the key is known to the business before they
	 * even have the task defined and submitted for implementation
	 */
	@Column(name ="task_definition_id")
	private String taskDefinitionKey; // Ex: BAT01, PBT05  

	
	@Column(name ="adjusted_reason_tx")
	private String adjustedReason;  

	
	@Column(name ="adjusted_hrs_no", scale = 2, precision = 10)
	private BigDecimal adjustedHours;  
	
	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	@SuppressWarnings("CPD-END")
	
	@Override
	public String toString() {
		return "PATAdjustHours [id=" + id + ", pcEmail=" + pcEmail + ", payPeriodId=" + payPeriodId
				+ ", changeProposalExternalId=" + changeProposalExternalId + ", taskDefinitionKey=" + taskDefinitionKey
				+ ", adjustedReason=" + adjustedReason + ", adjustedHours=" + adjustedHours + ", createUserId="
				+ createUserId + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId
				+ ", lastModifiedTs=" + lastModifiedTs + ", lockControl=" + lockControl + "]";
	}
	

}
