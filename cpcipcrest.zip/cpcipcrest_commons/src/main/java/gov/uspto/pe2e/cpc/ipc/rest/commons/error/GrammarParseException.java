package gov.uspto.pe2e.cpc.ipc.rest.commons.error;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.GrammarValidationMessage;

/**
 * Custom exception for Title Grammar
 * @author 2020
 * @version 1.7
 * @date Mar 30, 2017
 *
 */
public class GrammarParseException extends Exception {

	private static final long serialVersionUID = 1L;

	private transient List<GrammarValidationMessage> validationMessages = new ArrayList<>();

	public GrammarParseException() {
        super();
    }

	public GrammarParseException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

	public GrammarParseException(String message, Throwable cause) {
        super(message, cause);
    }

	public GrammarParseException(String message) {
        super(message);
    }

	public GrammarParseException(Throwable cause) {
        super(cause);
    }

	public GrammarParseException(List<GrammarValidationMessage> validationMessages) {
        super();
        this.validationMessages = validationMessages;
    }

	/**
     * @return the validationMessages
     */
    public List<GrammarValidationMessage> getValidationMessages() {
        if (validationMessages ==  null) {
            validationMessages = new ArrayList<>();
        }
        return validationMessages;
    }

    /**
     * Produces useful toString containing real validation messages
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("GrammarParseException [messages = ");
        sb.append( getValidationMessages()
                .stream()
                .map(entry -> "[" + entry.getExceptionType() + " at char " + entry.getCharacterIndex() + " Message =\""
                        + entry.getMessageText() + "\"]")
                .collect(Collectors.joining(", ")));
        sb.append("]");
        return sb.toString();
    }
    
    
    
    

}
