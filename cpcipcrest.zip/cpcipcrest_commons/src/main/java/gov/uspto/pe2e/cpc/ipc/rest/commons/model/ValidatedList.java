package gov.uspto.pe2e.cpc.ipc.rest.commons.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;
import lombok.Data;
import lombok.experimental.Delegate;

/**
 * This is a special bean used to represent a list object that is automatically validated by spring as a
 * request object.  The list type is generic but what is import is that the @Valid annotation is applied to 
 * each element in the delegated inner list 
 * 
 * Note:
 * To use this feature simply make the controller method arg as such: 
 * @RequestBody @Valid ValidatedList<MyRestContractClass> requestList
 * 
 * Also make sure all bean fields have proper JSR-303 annotations on MyObjectVO to enforce relevant constraints
 * By using this feature, we don't have to write complicated error handling and validation in our controllers.
 * We can just let spring do it and validation errors are reported as Http 400/IllegalArgmentException  
 * 
 * @author 2020 Development Team (myoung3)
 *
 * @param <E>
 */
@Data
public class ValidatedList<E> implements List<E> {
    /**
     * The real list used to hold the object that need to be validated
     */
    @Valid
    @Delegate
    private List<E> list = new ArrayList<>();
}
