package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name = "meeting_place", uniqueConstraints = { @UniqueConstraint(name = "pk_meeting_place", columnNames = {
        "meeting_place_id" }) })
public class MeetingPlace implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "meeting_place_id_seq")
    @SequenceGenerator(name = "meeting_place_id_seq", sequenceName = "meeting_place_id_seq", initialValue = 1,
            allocationSize = 1)

    @Column(name = "meeting_place_id")
    private Long id;

    @Guid
    @NotNull
    @Column(name = "guid_id")
    private String externalId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposal.class)
    @JoinColumn(name = "fk_change_proposal_id", referencedColumnName = "change_proposal_id")
    private ChangeProposal changeProposal;

    @NotNull
    @Column(name = "sort_order_no")
    private Integer sortOrder;

    @NotNull
    @Column(name = "scheduled_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date scheduledTs;
    @NotNull

    @Column(name = "description_tx")
    private String description;

    @Column(name = "agenda_tx")
    private String agenda;

    @Column(name = "notes_tx")
    private String note;

    @NotNull
    @Convert(converter = YesNoConverter.class)
    @Column(name = "delete_in", columnDefinition = "char(1)")
    private Boolean deleted;

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @NotNull
    @Column(name = "create_user_id")
    private String createUserId;

    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId;

    @NotNull
    @Column(name = "lock_control_no")
    @Version
    private Integer lockControlNo;

}