package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationTreeStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import lombok.Data;

/**
 * Entity Class for handling ORM Persistence for table classification_scheme_status
 * primary key is fk_classification_scheme_id
 * 
 * 
 * @author 2020
 * @version 3.3.0
 * @date: 03/08/2023
 *
 */
@Entity
@Data
@Table(name = "classification_scheme_status", uniqueConstraints =  {
		@UniqueConstraint(name = "pk_clsfcn_scheme_status", columnNames = { "fk_classification_scheme_id" }) 
		})
public class ClassificationSchemeStatus implements Serializable {

    /**
     * Allowing serialization of datamodel elements 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "fk_classification_scheme_id")
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ClassificationScheme.class)
    @JoinColumn(name = "fk_classification_scheme_id", referencedColumnName = "classification_scheme_id", insertable=false, updatable=false)
    private ClassificationScheme classificationScheme;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status_ct", columnDefinition = "varchar2")
    private PublicationTreeStatus status;
   
    @Column(name = "failure_tx")
    private String failure;

    @Column(name = "server_name_tx")
    private String serverNameText;

    @Column(name = "thread_id_no")
    private Long threadIdNumber;

    @CreatedBy
    @Column(name = "create_user_id")
    private String createUserId;

    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @Column(name = "last_mod_user_id")
    private String lastModUserId;

    @LastModifiedDate
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    // TODO: change to "lastModifiedTs
    private Date lastModTs;

    @Version
    @Column(name = "lock_control_no")
    private Integer lockControlNo;
    

}
