package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;

import org.apache.commons.lang3.builder.CompareToBuilder;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * PAT SDCT Detail View - This view as PAT info
 * @author vkommareddy
 *
 */
@Entity
@Table(name = "pat_sdct_detail_v")
@Data
public class PATSdctDetailView implements Comparable<PATSdctDetailView>, Serializable {

	/**
	 * Allowing serialization of datamodel elements
	 */
	private static final long serialVersionUID = 1L;
    
    @NotNull
    @Column(name = "change_proposal_cd")
    private String changeProposalCd;    
    
    @Id
    @NotNull	
    @Column(name = "change_proposal_id")
	private Long changeProposalId;    
    
	@Column(name = "change_proposal_guid")
	private String changeProposalGuid;
	
	@Column(name = "last_version_id")
	private Long lastVersionId;
	
	@Column(name = "change_proposal_ver_guid_id")
	private String changeProposalVerGuid;
    
    @Column(name = "project_type_ct")
	private String projectTypeCt;
    
    @Column(name = "project_source_cd")
	private String projectSourceCd;

	@Column(name = "family_count_no")
	private Long familyCount;
	
	@Column(name = "twl_count_no")
	private Long twlCount;
	
	@Column(name = "symbol_cnt")
	private Long symbolCount;
	
	@Column(name = "def_cnt")
	private Long definitionCount;	
	
	@Override
	public int compareTo(PATSdctDetailView o) {
		return new CompareToBuilder().append(this.changeProposalGuid, o.changeProposalGuid).toComparison();
	}
}
