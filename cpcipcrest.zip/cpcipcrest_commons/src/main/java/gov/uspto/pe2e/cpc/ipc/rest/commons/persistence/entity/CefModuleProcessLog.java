package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefModuleName;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity class for handling CEF Module process data
 * 
 * @author Maximus
 * @date September 10, 2021
 * @version 1.0
 *
 */

@Entity
@Table(name = "cef_module_process_log")
public class CefModuleProcessLog implements Comparable<CefModuleProcessLog>, Serializable  {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
    
    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "module_process_log_id_seq")
    @SequenceGenerator(name = "module_process_log_id_seq", sequenceName = "module_process_log_id_seq", 
                          initialValue = 1, allocationSize = 1)
    @Column(name = "module_process_log_id")
    private Long id;
    
    
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = CefProjectProcessLog.class)
    @JoinColumn(name = "fk_project_process_log_id", referencedColumnName = "project_process_log_id")
    private CefProjectProcessLog cefProjectProcessLog;
    
    @NotNull
    @Enumerated(EnumType.STRING)
	@Column(name ="module_name_ct")
    private CefModuleName moduleName;
    
    @NotNull
    @Enumerated(EnumType.STRING)
	@Column(name ="status_ct")
    private CefMigrationStatus status;
    
	@Lob 
	@Column(name ="input_tx", columnDefinition="CLOB")
    private String request;
	
	@Column(name ="exception_tx",length = 4000)
    private String exception;
    
	@SuppressWarnings("CPD-START")
	@CreatedBy
	@NotNull
	@Column(name = "create_user_id")
	private String createUserId; // VARCHAR2(100)

	@CreatedDate
	@NotNull
	@Column(name = "create_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date createTs;

	@LastModifiedBy
	@NotNull
	@Column(name = "last_mod_user_id")
	private String lastModifiedUserId; // VARCHAR2(100)

	@LastModifiedDate
	@NotNull
	@Column(name = "last_mod_ts")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Date lastModifiedTs;

	@NotNull
	@Version
	@Column(name = "lock_control_no")
	private Integer lockControl;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public CefProjectProcessLog getCefProjectProcessLog() {
		return cefProjectProcessLog;
	}

	public void setCefProjectProcessLog(CefProjectProcessLog cefProjectProcessLog) {
		this.cefProjectProcessLog = cefProjectProcessLog;
	}

	public CefModuleName getModuleName() {
		return moduleName;
	}

	public void setModuleName(CefModuleName moduleName) {
		this.moduleName = moduleName;
	}

	public CefMigrationStatus getStatus() {
		return status;
	}

	public void setStatus(CefMigrationStatus status) {
		this.status = status;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Date createTs) {
		this.createTs = createTs;
	}

	public String getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	public void setLastModifiedUserId(String lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}

	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	public Integer getLockControl() {
		return lockControl;
	}

	public void setLockControl(Integer lockControl) {
		this.lockControl = lockControl;
	}
	
	/**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(CefModuleProcessLog other) {
        return new CompareToBuilder().append(this.getId(), other.getId())
                .append(this.getModuleName(), other.getModuleName())
                .append(this.getStatus(), other.getStatus()).toComparison();
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cefProjectProcessLog == null) ? 0 : cefProjectProcessLog.hashCode());
		result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
		result = prime * result + ((createUserId == null) ? 0 : createUserId.hashCode());
		result = prime * result + ((exception == null) ? 0 : exception.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastModifiedTs == null) ? 0 : lastModifiedTs.hashCode());
		result = prime * result + ((lastModifiedUserId == null) ? 0 : lastModifiedUserId.hashCode());
		result = prime * result + ((lockControl == null) ? 0 : lockControl.hashCode());
		result = prime * result + ((moduleName == null) ? 0 : moduleName.hashCode());
		result = prime * result + ((request == null) ? 0 : request.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CefModuleProcessLog other = (CefModuleProcessLog) obj;
		if (cefProjectProcessLog == null) {
			if (other.cefProjectProcessLog != null)
				return false;
		} else if (!cefProjectProcessLog.equals(other.cefProjectProcessLog))
			return false;
		if (createTs == null) {
			if (other.createTs != null)
				return false;
		} else if (!createTs.equals(other.createTs))
			return false;
		if (createUserId == null) {
			if (other.createUserId != null)
				return false;
		} else if (!createUserId.equals(other.createUserId))
			return false;
		if (exception == null) {
			if (other.exception != null)
				return false;
		} else if (!exception.equals(other.exception))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastModifiedTs == null) {
			if (other.lastModifiedTs != null)
				return false;
		} else if (!lastModifiedTs.equals(other.lastModifiedTs))
			return false;
		if (lastModifiedUserId == null) {
			if (other.lastModifiedUserId != null)
				return false;
		} else if (!lastModifiedUserId.equals(other.lastModifiedUserId))
			return false;
		if (lockControl == null) {
			if (other.lockControl != null)
				return false;
		} else if (!lockControl.equals(other.lockControl))
			return false;
		if (moduleName != other.moduleName)
			return false;
		if (request == null) {
			if (other.request != null)
				return false;
		} else if (!request.equals(other.request))
			return false;
		if (status != other.status)
			return false;
		return true;
	}
	
}
