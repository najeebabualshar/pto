package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * This enum defines what type of xml is being published. At the time of the
 * this writing, 2 valid types are DEFINITION and SCHEME
 * 
 * @author 2020
 * @date Nov 12, 2015 10:56:27 AM
 * @version 1.2
 */
public enum SchemaDefinitionPublicationCategory {
    DEFINITION, SCHEME;

}
