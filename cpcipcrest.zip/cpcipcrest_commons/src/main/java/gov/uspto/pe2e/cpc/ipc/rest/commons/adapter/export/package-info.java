/**
 * 
 */
/**
 * 
 * @author 2020
 * @date May 30, 2019
 * @since May 30, 2019
 * @version 1.7
 */
package gov.uspto.pe2e.cpc.ipc.rest.commons.adapter.export;