package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
@Data
@Entity
@Table(name = "related_project_symbol", uniqueConstraints={ 
        @UniqueConstraint(name="pk_related_project_symbol", 
            columnNames = { "related_project_symbol_id"})
        
})
@Slf4j
public class RelatedProjectSymbol  implements Comparable<RelatedProjectSymbol>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "related_project_symbol_id_seq")
    @SequenceGenerator(name = "related_project_symbol_id_seq", 
                  sequenceName = "related_project_symbol_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "related_project_symbol_id")
    private Long id;    

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = RelatedProject.class)
    @JoinColumn(name = "fk_related_project_id", referencedColumnName = "related_project_id")
    private RelatedProject relatedProject;
    
    @NotNull
    @Column(name = "subclass_tx", length=4)
    private String subclass;
    
    @NotNull
    @Column(name = "main_group_tx", length=50)
    private String mainGroup;
    
    @NotNull
    @Column(name = "overlap_symbol_tx", length=50)
    private String overlapSymbolName;
   
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;
    @SuppressWarnings("CPD-END")
    
    
    
    
    /**
     * @return the changeProposerRoles
     * @since April 07, 2018
     */

    @Override
    public int compareTo(RelatedProjectSymbol other) {
        return new CompareToBuilder()
                    .append(Optional.ofNullable(this.getRelatedProject()).orElse(new RelatedProject()).getId(), 
                            Optional.ofNullable(other.getRelatedProject()).orElse(new RelatedProject()).getId())
                    .append(this.getId(), other.getId())
                    .append(this.getOverlapSymbolName(), other.getOverlapSymbolName())
                    .toComparison();
                
    }
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
			
		} if (!(obj instanceof RelatedProjectSymbol)) {
			return false;
		}	
		RelatedProjectSymbol other = (RelatedProjectSymbol) obj;
		return Objects.equals(createTs, other.createTs) && Objects.equals(createUserId, other.createUserId)
				&& Objects.equals(id, other.id) && Objects.equals(mainGroup, other.mainGroup)
				&& Objects.equals(overlapSymbolName, other.overlapSymbolName)
				&& Objects.equals(relatedProject, other.relatedProject) && Objects.equals(subclass, other.subclass);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(createTs, createUserId, id, mainGroup, overlapSymbolName, relatedProject, subclass);
	}

   
    
    
    
}
