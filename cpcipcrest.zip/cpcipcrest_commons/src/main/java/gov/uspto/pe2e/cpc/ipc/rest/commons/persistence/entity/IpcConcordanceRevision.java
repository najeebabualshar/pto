package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.type.YesNoConverter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for IpcConcordanceRevision to store/map Generated and Overridden
 * IPC symbols or CPC only
 * 
 * @author 2020
 * @date Jan 6, 2016 4:52:21 PM
 * @version 1.6
 */

@Entity
@Table(name = "ipc_concordance_revision")
public class IpcConcordanceRevision implements Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "guid_id")
    @Guid
    private String externalId;
//    
//    @GeneratedValue(generator = "foreign")
//    @GenericGenerator(name = "foreign", strategy = "foreign", parameters = {
//            @Parameter(name = "property", value = "versionSymbol") })
//    @Column(name = "version_symbol_id", unique = true)
//    private String id;

    @OneToOne(fetch = FetchType.LAZY, targetEntity = VersionSymbol.class)
    @JoinColumn(name = "guid_id", referencedColumnName = "guid_id", insertable = false, updatable = false)
    private VersionSymbol versionSymbol;   

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = IpcSymbolHierarchy.class)
    @JoinColumn(name = "fk_generated_ipc_symbol_id", referencedColumnName = "ipc_symbol_id")
    private IpcSymbolHierarchy generatedIpcSymbol;
        
    @Column(name = "override_ipc_symbol_cd", length = 50) 
    private String overrideIpcSymbolCode; // VARCHAR2(100)

    @Convert(converter = YesNoConverter.class)
    @Column(name = "cpc_only_in", columnDefinition = "char", length = 1)
    private Boolean cpcOnly;

    @Column(name = "confirmed_user_id", length = 100) // This should be 255 to
                                                      // accomodate email
                                                      // addresses
    private String confirmedUserId; // VARCHAR2(100)

    @Column(name = "confirmed_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date confirmedTs;

    @CreatedBy
    @NotNull
    @Column(name = "create_user_id", length = 100, nullable = false) // This
                                                                     // should
                                                                     // be 255
                                                                     // to
                                                                     // accomodate
                                                                     // email
                                                                     // addresses
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no", nullable = false)
    private Integer lockControl;

//    /**
//     * @return the id
//     */
//
//    public String getId() {
//        return id;
//    }
//
//    /*
//     * @param id the id to set
//     */
//    public void setId(String id) {
//        this.id = id;
//    }

    /**
     * @return the versionSymbol
     */
    public VersionSymbol getVersionSymbol() {
        return versionSymbol;
    }

    /**
     * @param versionSymbol
     *            the versionSymbol to set
     */
    public void setVersionSymbol(VersionSymbol versionSymbol) {
    	if (StringUtils.isEmpty(versionSymbol.getExternalId())) {
    		this.setExternalId(versionSymbol.getExternalId());
    	}
        this.versionSymbol = versionSymbol;
    }

    /**
     * @return the externalId
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * @param externalId
     *            the externalId to set
     */
    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    /**
     * @return the generatedIpcSymbol
     */
    public IpcSymbolHierarchy getGeneratedIpcSymbol() {
        return generatedIpcSymbol;
    }

    /**
     * @param generatedIpcSymbol
     *            the generatedIpcSymbol to set
     */
    public void setGeneratedIpcSymbol(IpcSymbolHierarchy generatedIpcSymbol) {
        this.generatedIpcSymbol = generatedIpcSymbol;
    }
    

	/**
	 * @return the overrideIpcSymbolCode
	 */
	public String getOverrideIpcSymbolCode() {
		return overrideIpcSymbolCode;
	}

	/**
	 * @param overrideIpcSymbolCode the overrideIpcSymbolCode to set
	 */
	public void setOverrideIpcSymbolCode(String overrideIpcSymbolCode) {
		this.overrideIpcSymbolCode = overrideIpcSymbolCode;
	}

	/**
     * @return the cpcOnly
     */
    public Boolean getCpcOnly() {
        return cpcOnly;
    }

    /**
     * @param cpcOnly
     *            the cpcOnly to set
     */
    public void setCpcOnly(Boolean cpcOnly) {
        this.cpcOnly = cpcOnly;
    }

    /**
     * @return the confirmedUserId
     */
    public String getConfirmedUserId() {
        return confirmedUserId;
    }

    /**
     * @param confirmedUserId
     *            the confirmedUserId to set
     */
    public void setConfirmedUserId(String confirmedUserId) {
        this.confirmedUserId = confirmedUserId;
    }

    /**
     * @return the confirmedTs
     */
    public Date getConfirmedTs() {
        return confirmedTs;
    }

    /**
     * @param confirmedTs
     *            the confirmedTs to set
     */
    public void setConfirmedTs(Date confirmedTs) {
        this.confirmedTs = confirmedTs;
    }

    /**
     * @return the lastModifiedUserId
     */
    public String getLastModifiedUserId() {
        return lastModifiedUserId;
    }

    /**
     * @param lastModifiedUserId
     *            the lastModifiedUserId to set
     */
    public void setLastModifiedUserId(String lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }

    /**
     * @return the lastModifiedTs
     */
    public Date getLastModifiedTs() {
        return lastModifiedTs;
    }

    /**
     * @param lastModifiedTs
     *            the lastModifiedTs to set
     */
    public void setLastModifiedTs(Date lastModifiedTs) {
        this.lastModifiedTs = lastModifiedTs;
    }

    /**
     * @return the createUserId
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     *            the createUserId to set
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return the createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     *            the createTs to set
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return the lockControl
     */
    public Integer getLockControl() {
        return lockControl;
    }

    /**
     * @param lockControl
     *            the lockControl to set
     */
    public void setLockControl(Integer lockControl) {
        this.lockControl = lockControl;
    }
    
    
}
