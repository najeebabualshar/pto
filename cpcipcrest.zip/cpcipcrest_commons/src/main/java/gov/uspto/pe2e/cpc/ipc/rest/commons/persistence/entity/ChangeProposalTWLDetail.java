package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Optional;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.AllocationAgreementCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.NonRequestingOfficeAllocationAgreementCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RequestingOfficeAllocationAgreementCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RequestingOfficeTypeCode;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
@Data
@Entity
@Table(name = "change_proposal_twl_dtl", uniqueConstraints={ 
        @UniqueConstraint(name="pk_change_proposal_twl_dtl", 
            columnNames = { "twl_dtl_id"}),
        @UniqueConstraint(columnNames = { "guid_id" })
        
})
@Slf4j
public class ChangeProposalTWLDetail  implements Comparable<ChangeProposalTWLDetail>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "twl_dtl_id_seq")
    @SequenceGenerator(name = "twl_dtl_id_seq", 
                  sequenceName = "twl_dtl_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "twl_dtl_id")
    private Long id;    

    @Guid
    @NotNull
    @Column(name = "guid_id")
    private String externalId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalTWL.class)
    @JoinColumn(name = "fk_change_proposal_twl_id", referencedColumnName = "twl_id")
    private ChangeProposalTWL changeProposalTWL;

//    @NotNull
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ClassificationSymbol.class)
//    @JoinColumn(name = "fk_orig_alloc_symbol_id", referencedColumnName = "symbol_id")
//    private ClassificationSymbol sourceSymbol;
//    

    @NotEmpty
    @Column(name = "orig_full_symbol_tx")
    private String sourceSymbolName;
    
    @NotEmpty
    @Column(name = "xfer_to_full_symbol_tx")
    private String targetSymbolName;

//    @NotNull
//    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ClassificationSymbol.class)
//    @JoinColumn(name = "fk_xfr_to_symbol_id", referencedColumnName = "symbol_id")
//    private ClassificationSymbol targetSymbol;
//               
    @Enumerated(EnumType.STRING)
    @Column(name = "rqst_office_type_cd")
    private RequestingOfficeTypeCode requestingIpOfficeCode;
    
    @Column(name = "rqst_office_comment_tx", length = 250) // why is this 250 while final is 4000
    private String requestingOfficeComment; 

    @Enumerated(EnumType.STRING)
    @Column(name = "non_rqst_office_alloc_agrmt_ct")
    private NonRequestingOfficeAllocationAgreementCategory nonRequestingOfficeAllocationAgreement;

    @Column(name = "non_rqst_office_comment_tx", length = 250) // why is this 250 while final is 4000
    private String nonRequestingOfficeComment; 
 
    @Enumerated(EnumType.STRING)
    @Column(name = "final_alloc_agrmt_ct")
    private AllocationAgreementCategory finalAllocationAgreement;
    
    @Column(name = "final_comment_tx", length = 4000)
    private String finalComment; 
    
    @Column(name = "notes_tx", length = 250)
    private String notes; 
    
    @Enumerated(EnumType.STRING)
    @Column(name = "rqst_office_alloc_agrmt_ct")
    private RequestingOfficeAllocationAgreementCategory requestOfficeAllocationAgreement;
    
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = StandardTWLNextAction.class)
    @JoinColumn(name = "fk_twl_next_action_id", referencedColumnName = "twl_next_action_id")
    private StandardTWLNextAction nextAction;
    
    @SuppressWarnings("CPD-START")
    @CreatedBy
    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @NotNull
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @NotNull
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;
    @SuppressWarnings("CPD-END")
    
    // ignore this date.  This is used to 
    // preserve ordering in the set because we dump the set and recreate with each save
    // at the time we do this, there is no id (not yet saved)
    // and all the createTs values in the set are the same
    // this instance ts allows us to sort by instantiation ts.
    @Transient
    private transient Date instanceTs = new Date();
    
    
    
    
    /**
     * @return the comparison for adding to the Sets
     * @since April 07, 2018
     */

    @Override
    public int compareTo(ChangeProposalTWLDetail other) {
        return new CompareToBuilder()
                    .append(Optional.ofNullable(this.getChangeProposalTWL()).orElse(new ChangeProposalTWL()).getId(), 
                            Optional.ofNullable(other.getChangeProposalTWL()).orElse(new ChangeProposalTWL()).getId())
                    .append(this.getId(), other.getId())
                    .append(this.getInstanceTs(), other.getInstanceTs())
                    .append(this.getSourceSymbolName(), other.getSourceSymbolName())
                    .append(this.getTargetSymbolName(), other.getTargetSymbolName())
                    .toComparison();
                
    }

   
    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {
        final int prime = 37;
        int result = 1;
        result = prime * result + ((changeProposalTWL == null) ? 0 : changeProposalTWL.hashCode());
        result = prime * result + ((externalId == null) ? 0 : externalId.hashCode());
        result = prime * result + ((id == null) ? 0 : getId().hashCode());
        result = prime * result + ((changeProposalTWL == null) ? 0 : changeProposalTWL.hashCode());
        result = prime * result + ((finalAllocationAgreement == null) ? 0 : finalAllocationAgreement.hashCode()); 

        result = prime * result + ((externalId == null) ? 0 : externalId.hashCode());
        result = prime * result + ((finalComment == null) ? 0 : finalComment.hashCode());
        result = prime * result + ((nextAction == null) ? 0 : nextAction.hashCode());
        result = prime * result + ((nonRequestingOfficeAllocationAgreement == null) ? 0 : nonRequestingOfficeAllocationAgreement.hashCode());
        result = prime * result + ((nonRequestingOfficeComment == null) ? 0 : nonRequestingOfficeComment.hashCode());
        result = prime * result + ((notes == null) ? 0 : notes.hashCode());
        result = prime * result + ((requestingIpOfficeCode == null) ? 0 : requestingIpOfficeCode.hashCode());
        result = prime * result + ((nonRequestingOfficeComment == null) ? 0 : nonRequestingOfficeComment.hashCode());

        result = prime * result + ((requestingIpOfficeCode == null) ? 0 : requestingIpOfficeCode.hashCode());
        result = prime * result + ((requestingOfficeComment == null) ? 0 : requestingOfficeComment.hashCode());
        result = prime * result + ((sourceSymbolName == null) ? 0 : sourceSymbolName.hashCode());

        result = prime * result + ((targetSymbolName == null) ? 0 : targetSymbolName.hashCode());
        return result;
    }

    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret = false;

        if (obj != null) {
            if (obj == this) {
                ret = true;
            } else if (ChangeProposalTWLDetail.class.isAssignableFrom(obj.getClass())) {
                ChangeProposalTWLDetail that = (ChangeProposalTWLDetail) obj;
                ret = new EqualsBuilder()
                        .append(getId(), that.getId())
                        .append(getChangeProposalTWL(), that.getChangeProposalTWL())
                        .append(getExternalId(), that.getExternalId())
                        .append(getFinalAllocationAgreement(), that.getFinalAllocationAgreement())
                        .append(getFinalComment(), that.getFinalComment())
                        .append(getNextAction(), that.getNextAction())
                        .append(getNonRequestingOfficeAllocationAgreement(), that.getNonRequestingOfficeAllocationAgreement())

                        .append(getNonRequestingOfficeComment(), that.getNonRequestingOfficeComment())
                        .append(getNotes(), that.getNotes())
                        .append(getRequestingIpOfficeCode(), that.getRequestingIpOfficeCode())
                        .append(getRequestingOfficeComment(), that.getRequestingOfficeComment())
                        .append(getSourceSymbolName(), that.getSourceSymbolName())
                        .append(getTargetSymbolName(), that.getTargetSymbolName())

                        .isEquals();
            }
        }
        return ret;
    }
    
    
    
    
}
