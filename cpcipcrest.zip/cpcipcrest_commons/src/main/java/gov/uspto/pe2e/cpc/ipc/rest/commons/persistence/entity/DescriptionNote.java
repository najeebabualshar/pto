package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.jpa.Guid;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;

/**
 * Entity Class for handling ORM Persistence for table description_note primary
 * key is description_note_id
 * 
 * @author 2020
 * @version 1.5
 * @date: 09/15/2016
 */

@Entity
@Table(name = "description_note", uniqueConstraints = {
        @UniqueConstraint(columnNames = { "guid_id", "fk_change_proposal_ver_id" }) })
public class DescriptionNote implements Comparable<DescriptionNote>, Serializable {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;

    @Id
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "description_note_id_seq")
//    @SequenceGenerator(name = "description_note_id_seq", 
//                sequenceName = "description_note_id_seq", initialValue = 1, allocationSize = 1)
//    @Column(name = "description_note_id")
//    private Long id;
//
    @Guid
    @NotNull
    @Column(name = "guid_id")
    private String externalId;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ChangeProposalVersion.class)
    @JoinColumn(name = "fk_change_proposal_ver_id", referencedColumnName = "guid_id")
    private ChangeProposalVersion changeProposalVersion;

    @NotNull
    @Column(name = "description_note_tx")
    private String descriptionNoteText;

    @NotNull
    @Column(name = "submitter_user_id")
    private String commentUserId;

    @NotNull
    @Column(name = "submit_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date commentTs;

    @Column(name = "delete_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date deleteTs;

    @NotNull
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @NotNull
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

  

    /**
     * @return the externalId
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * @param externalId
     *            the externalId to set
     */
    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    /**
     * @return the changeProposalVersion
     * @since Aug 26, 2016
     */
    public ChangeProposalVersion getChangeProposalVersion() {
        return changeProposalVersion;
    }

    /**
     * @param changeProposalVersion
     *            the changeProposalVersion to set
     * @since Aug 26, 2016
     */
    public void setChangeProposalVersion(ChangeProposalVersion changeProposalVersion) {
        this.changeProposalVersion = changeProposalVersion;
    }

    /**
     * @return the descriptionNoteText
     * @since Aug 26, 2016
     */
    public String getDescriptionNoteText() {
        return descriptionNoteText;
    }

    /**
     * @param descriptionNoteText
     *            the descriptionNoteText to set
     * @since Aug 26, 2016
     */
    public void setDescriptionNoteText(String descriptionNoteText) {
        this.descriptionNoteText = descriptionNoteText;
    }

    /**
     * @return the commentUserId
     * @since Aug 26, 2016
     */
    public String getCommentUserId() {
        return commentUserId;
    }

    /**
     * @param commentUserId
     *            the commentUserId to set
     * @since Aug 26, 2016
     */
    public void setCommentUserId(String commentUserId) {
        this.commentUserId = commentUserId;
    }

    /**
     * @return the commentTs
     * @since Aug 26, 2016
     */
    public Date getCommentTs() {
        return commentTs;
    }

    /**
     * @param commentTs
     *            the commentTs to set
     * @since Aug 26, 2016
     */
    public void setCommentTs(Date commentTs) {
        this.commentTs = commentTs;
    }

    /**
     * @return the deleteTs
     * @since Aug 26, 2016
     */
    public Date getDeleteTs() {
        return deleteTs;
    }

    /**
     * @param deleteTs
     *            the deleteTs to set
     * @since Aug 26, 2016
     */
    public void setDeleteTs(Date deleteTs) {
        this.deleteTs = deleteTs;
    }

    /**
     * @return the createUserId
     * @since Aug 26, 2016
     */
    public String getCreateUserId() {
        return createUserId;
    }

    /**
     * @param createUserId
     *            the createUserId to set
     * @since Aug 26, 2016
     */
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    /**
     * @return the createTs
     * @since Aug 26, 2016
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     *            the createTs to set
     * @since Aug 26, 2016
     */
    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(DescriptionNote other) {
        return new CompareToBuilder().append(this.getCreateTs(), other.getCreateTs())
        		.append(this.getExternalId(), other.getExternalId())
        		.append(this.getCreateTs(), other.getCreateTs())
                .toComparison();

    }
    
    /**
     * used for hash based collections.
     */
    @Override
    public int hashCode() {   
        return Objects.hash(this.getExternalId(), this.getDescriptionNoteText());
    }
    
    /**
     * Indicates whether some other object is "equal to" this one
     */
    @Override
    public boolean equals(Object obj) {
        boolean ret;
        if (obj == null || !(obj instanceof DescriptionNote)) {
            ret = false;
        } else if (DescriptionNote.class.isAssignableFrom(obj.getClass()) && obj == this) {
            ret = true;
        } else {
        	DescriptionNote thatObj = (DescriptionNote) obj;
        	
        	String meProposalVersion = this.getChangeProposalVersion().getExternalId();
        	String thatProposalVersion = thatObj.getChangeProposalVersion().getExternalId();
        	
            
            String meExternalId = this.getExternalId();
            String thatExternalId = thatObj.getExternalId();
            
            ret = meProposalVersion.equals(thatProposalVersion) && meExternalId.equals(thatExternalId) 
            		;
        }
        return ret;
    }

}
