package gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Global Subclass Dashboard Conflict Symbol Table for Push Button Publication
 * @author c54932
 * @date: 09/15/2023
 *
 */
@Entity
@Table(name = "gsd_conflict_symbol")
@Data
public class GSDConflictSymbol implements Comparable<GSDConflictSymbol>, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @Column(name = "conflict_symbol_id")
    private Long id;

    @NotNull
    @Column(name = "source_proposal_id")
    private Long sourceProposalId;

    @NotNull
    @Column(name = "source_proposal_guid_id")
    private String sourceProposalGuidId;

    @NotNull
    @Column(name = "source_project_cd")
    private String sourceProjectCd;

    @NotNull
    @Column(name = "source_proposal_type_cd")
    private String sourceProposalTypeCd;

    @NotNull
    @Column(name = "SOURCE_SUBCLASS_CD")
    private String sourceSubClassCd;

    @Column(name = "source_scheme_version_tx")
    private String sourceSchemeVersionTx;

    @NotNull
    @Column(name = "conflict_symbol_tx")
    private String conflictSymbolTx;

    @NotNull
    @Column(name = "conflict_definition_in", columnDefinition = "char(1)")
    private String conflictDefinitionIn;

    @NotNull
    @Column(name = "conflict_type_cd")
    private String conflictTypeCd;

    @NotNull
    @Column(name = "create_user_id")
    private String createUserId;

    @NotNull
    @Column(name = "create_ts")
    @CreatedDate
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @NotNull
    @Column(name = "last_mod_user_id")
    private String lastModUserId;

    @NotNull
    @Column(name = "last_mod_ts")
    @LastModifiedDate
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModTs;

    @NotNull
    @Column(name = "lock_control_no")
    private Long lockControlNo;

    @Override
    public int compareTo(GSDConflictSymbol o) {
        return new CompareToBuilder().append(this.sourceProposalId, o.sourceProposalId).append(this.sourceSubClassCd, o.sourceSubClassCd)
                .append(this.conflictSymbolTx, o.conflictSymbolTx).append(this.conflictDefinitionIn, o.conflictDefinitionIn).toComparison();
    }

    @Override
    public String toString() {
        return "GSDConflictSymbol{" +
                "id=" + id +
                ", sourceProposalId=" + sourceProposalId +
                ", sourceProposalGuidId='" + sourceProposalGuidId + '\'' +
                ", sourceProjectCd='" + sourceProjectCd + '\'' +
                ", sourceProposalTypeCd='" + sourceProposalTypeCd + '\'' +
                ", sourceSubClassCd=" + sourceSubClassCd +
                ", sourceSchemeVersionTx='" + sourceSchemeVersionTx + '\'' +
                ", conflictSymbolTx='" + conflictSymbolTx + '\'' +
                ", conflictDefinitionIn='" + conflictDefinitionIn + '\'' +
                ", conflictTypeCd='" + conflictTypeCd + '\'' +
                ", createUserId='" + createUserId + '\'' +
                ", createTs=" + createTs +
                ", lastModUserId='" + lastModUserId + '\'' +
                ", lastModTs=" + lastModTs +
                ", lockControlNo=" + lockControlNo +
                '}';
    }

}
