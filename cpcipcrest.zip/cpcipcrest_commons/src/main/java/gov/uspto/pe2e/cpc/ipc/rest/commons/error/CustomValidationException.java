package gov.uspto.pe2e.cpc.ipc.rest.commons.error;

import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

/**
 * Controller Exception thrown when layered validator encounters additional validation errors beyond
 * normal JSR303 annotations on rest contract objects.  This exception is specifically thrown by
 * controller methods to trigger normal exception handling/response mapping in the 
 * @see gov.uspto.pe2e.cpc.ipc.rest.web.controller.error.web.controller.error.GlobalControllerExceptionHandler
 * 
 * Note: this class is only required because spring does not allow customm validators to be layered
 * for a given controller method* 
 * 
 * 
 * @version 1.4
 * @author 2020
 * @date  7/13/2016
 */
public class CustomValidationException extends RuntimeException {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;
    private List<Pair<String,List<Object>>> errors;

    /**
     * Errors Constructor
     * @param errors
     */
    public CustomValidationException(List<Pair<String, List<Object>>> errors) {
		super();
		this.errors = errors;
	}

	/**
	 * @return the errors
	 */
	public List<Pair<String, List<Object>>> getErrors() {
		return errors;
	}
}
