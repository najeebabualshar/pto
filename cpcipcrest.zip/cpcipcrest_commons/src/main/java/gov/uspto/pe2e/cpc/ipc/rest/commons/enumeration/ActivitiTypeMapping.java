package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.InputType;

/**
 * This Enum is to map the object type from Activiti to CPC systems. 
 * @author 2020 llc
 * @date 06/28/2018 
 *
 */
public enum ActivitiTypeMapping {
	DROPDOWN(InputType.STRING),
	DATE(InputType.DATE),
	RADIO_BUTTONS(InputType.STRING),
	TEXT(InputType.STRING),
	MULTI_LINE_TEXT(InputType.TEXT),
	INTEGER(InputType.INT),
	BOOLEAN(InputType.BOOLEAN),
	AMOUNT(InputType.DECIMAL),
	HYPERLINK(InputType.HYPERLINK);
	
	
	private InputType ourType;
	
	private ActivitiTypeMapping(InputType ourType) {
		this.ourType=ourType;
	}

	public InputType getOurType() {
		return ourType;
	}
	

}
